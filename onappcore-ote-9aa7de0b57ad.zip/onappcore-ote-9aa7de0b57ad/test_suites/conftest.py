import os

import pytest
from onapp_helper.user import User
from onapp_helper.billing_plan import BillingPlan
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.template_store import TemplateStore, RelationGroupTemplate
from onapp_helper.template import Template


def pytest_runtest_makereport(item, call):
    if "incremental" in item.keywords:
        if call.excinfo is not None:
            parent = item.parent
            parent._previousfailed = item


def pytest_runtest_setup(item):
    if "incremental" in item.keywords:
        previousfailed = getattr(item.parent, "_previousfailed", None)
        if previousfailed is not None:
            pytest.xfail("previous test failed ({0})".format(previousfailed.name))

    if "verbose" in item.keywords:
        from onapp_helper import test
        # to fix outout use print:
        # [2017 - 04 - 26 09:27:17, 693] INFO
        # Status - 200
        # .
        #
        # [2017 - 04 - 26 09:27:17, 694] INFO
        print('\n')
        test.log.info('#' * 80)
        label = ' '.join([name.upper() for name in item.name.split('_')[1:]])
        test.log.info('#{:^78}#'.format(label))
        test.log.info('#' * 80)


@pytest.fixture(scope="module")
def bucket(request):
    b = Bucket()
    b.label = request.module.__name__
    assert b.create(), b.error

    def fin():
        b.delete()

    request.addfinalizer(fin)
    return b


@pytest.fixture(scope="module")
def user(request, bucket, test):
    user = User(bucket=bucket)
    user.login = request.module.__name__.lower()
    user.password = test.generate_password()
    user.email = '{}@ote.test'.format(request.module.__name__.lower())
    assert user.create(), user.error

    def fin():
        test.execute_as(test.login, test.password)
        user.delete()

    request.addfinalizer(fin)
    return user


@pytest.fixture(scope="module")
def template(request):
    """
    Get any template for Virtual Server
    :param request:
    :return:
    """
    t = Template().get_for_server(
        '',
        obj_route='virtual_server',
        operating_system=["linux", "freebsd"]
    )
    if t.id not in Template().template_ids_allocated_to_group():
        tg = TemplateStore()
        if not tg.get_by_label('OTE'):
            tg.label = "OTE"
            tg.create()
        relation = RelationGroupTemplate(tg)
        relation.attach_template_to_group(template_id=t.id)

    return t


@pytest.fixture(scope='module')
def test():
    from onapp_helper import test as t
    return t


@pytest.fixture(scope='class')
def configute_test_env(test):
    """
    Configure test environment
    :param test:
    :return:
    """
    test.hv_types = ['xen', 'kvm']


@pytest.fixture(
    scope='module',
)
def template_store():
    ts = [ts for ts in TemplateStore().get_all() if ts.label == 'OTE']
    if ts:
        return ts[0]
    else:
        ts = TemplateStore()
        ts.label = 'OTE'
        assert ts.create(), ts.error
        return ts


@pytest.fixture(
    scope='module',
)
def relation_group_template(template_store):
    return RelationGroupTemplate(template_store)


# # pytest -n auto --dist=loadfile (not works with)
# @pytest.fixture(scope='module', autouse=True)
# def setup_log_file_name(request):
#     for handler in test.log.handlers:
#         print('-' * 80)
#         print(handler.__class__.__name__)
#         print('-' * 80)
#         if handler.__class__.__name__ == 'TimedRotatingFileHandler':
#             handler.baseFilename = os.path.join(
#                 test.log_path, f"{request.module.__name__}.log"
#             )
#
#             print(handler.baseFilename)
#             break
