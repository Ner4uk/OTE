
from random import randint

import pytest

from onapp_helper import test
from onapp_helper.data_store import DataStore
from onapp_helper.disk import Disk
from onapp_helper.firewall_rule import FirewallRule
from onapp_helper.hypervisor import Hypervisor
from onapp_helper.hypervisor_zone import HypervisorZone
from onapp_helper.ip_address import IpAddress
from onapp_helper.ip_address_join import IpAddressJoin
from onapp_helper.network_interface import NetworkInterface
from onapp_helper.networks import Network
from onapp_helper.server import VirtualServer
from onapp_helper.template import Template
from test_helper import migrationTH


@pytest.fixture(scope='class')
def template(env_parametrised):
    test.log.info('!!!PREPARE TEMPLATE!!!')
    t = Template()
    t.get_for_server('CentOS 7', obj_route=VirtualServer.route)
    return t


@pytest.fixture(scope='class')
def vs(request, template):
    test.log.info('!!!CREATE VIRTUAL SERVER!!!')
    server = VirtualServer()
    server.label = request.cls.__name__
    server.template = template
    assert server.create(), server.error

    def fin():
        if server.locked:
            server.unlock()
        server.delete()
    request.addfinalizer(fin)

    return server


@pytest.fixture(scope='class')
def additional_disk(request, vs):
    disk = Disk(parent_obj=vs)
    disk.label = request.cls.__name__
    disk.disk_size = 1
    disk.mount_point = '/mnt/additional_disk'
    disk.file_system = 'ext4'
    disk.require_format_disk = True
    disk.mounted = True
    disk.data_store_id = test.env.ds.id
    assert disk.create(), disk.error

    return disk


@pytest.fixture(scope='class')
def primary_nic(vs):
    test.log.info('!!!GET PRIMARY NIC!!!')
    return vs.network_interface.get_primary()


@pytest.fixture(scope='class')
def additional_nic(vs):
    test.log.info('!!!CREATE ADDITIONAL NIC!!!')
    nic = NetworkInterface(parent_obj=vs)
    primary_interface_network_join_id = vs.network_interface.get_primary().network_join_id
    network_join_id = [
        nj.id for nj in test.env.network_joins
        if nj.id != primary_interface_network_join_id
    ][0]
    assert nic.add(
        label='eth1',
        rate_limit=90,
        primary=False,
        network_join_id=network_join_id
    ), nic.error

    return nic


@pytest.fixture(scope='class')
def additional_nic_ip_address(vs, additional_nic):
    test.log.info('!!!CREATE ADDITIONAL NIC IP ADDRESS!!!')
    network_join = [
        nj for nj in test.env.network_joins
        if nj.id == additional_nic.network_join_id
    ][0]
    ip = IpAddress(parent_obj=Network(id=network_join.network_id))
    assert ip.assign_to_server(
        vs, network_interface_id=additional_nic.id
    ), ip.error
    vs.rebuild_network(force=True)
    assert vs.ping(target=ip.address)

    return ip


@pytest.fixture(scope='class')
def custom_firewall_rule_for_primary_nic(vs):
    test.log.info('!!!CREATE CUSTOM FIREWALL RULE FOR PRIMARY NIC!!!')
    fwr = FirewallRule(server=vs)
    address = '.'.join(
        [str(randint(10, 250)) for _ in range(4)]
    )
    assert fwr.create(
        address=address,
        command=FirewallRule.COMMAND.accept,
        protocol=FirewallRule.PROTOCOL.icmp,
        network_interface_id=vs.network_interface.get_primary().id,
        port=8080
    ), fwr.error
    assert fwr.apply(), fwr.error

    return fwr


@pytest.fixture(scope='class')
def custom_firewall_rule_for_additional_nic(vs, additional_nic):
    test.log.info('!!!CREATE CUSTOM FIREWALL RULE FOR ADDITIONAL NIC!!!')
    fwr = FirewallRule(server=vs)
    address = '.'.join(
        [str(randint(10, 250)) for _ in range(4)]
    )
    assert fwr.create(
        address=address,
        command=FirewallRule.COMMAND.accept,
        protocol=FirewallRule.PROTOCOL.icmp,
        network_interface_id=additional_nic.id,
        port=8080
    ), fwr.error
    assert fwr.apply(), fwr.error

    return fwr


@pytest.fixture(scope='class')
def src_ds(vs):
    test.log.info('!!!GET SOURCE DATA STORE!!!')
    # Assume that source data store is the primary disk data store
    return DataStore(id=vs.get_primary_disk().data_store_id)


@pytest.fixture(scope='class')
def dst_ds(dst_hv):
    test.log.info('!!!GET DESTINATION DATA STORE!!!')
    return migrationTH.get_destination_data_store(
        test.env.ds, dst_hv, HypervisorZone(id=dst_hv.hypervisor_group_id)
    )


@pytest.fixture(scope='class')
def src_hv(vs):
    test.log.info('!!!GET SOURCE HYPERVISOR!!!')
    hv = Hypervisor(id=vs.hypervisor_id)
    return hv


@pytest.fixture(scope='class')
def dst_hv(vs):
    test.log.info('!!!GET DESTINATION HYPERVISOR!!!')
    return migrationTH.get_destination_hv(vs.hypervisor_id)


@pytest.fixture(scope='class')
def dst_primary_ip_address(vs):
    test.log.info('!!!GET DESTINATION PRIMARY IP ADDRESS!!!')
    return IpAddressJoin(parent_obj=vs).get_primary().ip_address['address']


@pytest.fixture(scope='class')
def dst_additional_ip_address(vs, dst_primary_ip_address):
    test.log.info('!!!GET DESTINATION ADDITIONAL IP ADDRESS!!!')
    return [
        join.ip_address['address'] for join in IpAddressJoin(parent_obj=vs).get_all()
        if join.ip_address['address'] != dst_primary_ip_address
    ][0]
