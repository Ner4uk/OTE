__author__ = 'zhuk'
__doc__ = """https://onappdev.atlassian.net/browse/CORE-13048
Server configuration:

server
      \
      |<- primary_network_interface <- ip address <- firewall_rule
      |                           `- custom firewall rule
      |<- additional_network_interface <- ip address <- firewall_rule
                                  `- custom firewall rule
                                  

"""
__since__ = 6.1

import pytest

from onapp_helper import test
from test_helper import migrationTH
from test_helper.base_fluidity_test import BaseFluidityTest


ENV_PARAMS = [
    ('xen', 'centos6'),
    ('xen', 'centos7'),
    ('kvm', 'centos6'),
    ('kvm', 'centos7'),
]


@pytest.fixture(
    scope='class',
    params=ENV_PARAMS,
    ids=[f'{key}_{value}' for key, value in ENV_PARAMS]
)
def env_parametrised(request):
    test.log.info('!!!GET ENVIRONMENT!!!')
    test.hv_types, test.hv_distros = ([p] for p in request.param)
    test.load_env(
        migrate_server=True,
        # migrate_disk=True,
        use_two_network_joins=True
    )
    if not test.env.hv.id:
        pytest.skip('Hypervisor with required parameters not found')


@pytest.fixture(scope='class')
def dst_hv(vs, src_hv):
    test.log.info('!!!GET DESTINATION HYPERVISOR!!!')
    return migrationTH.get_destination_hv(
        test.env.hv.id, migrationTH.get_destination_hv_zone(src_hv)
    )


@pytest.fixture(scope='class')
def migration_type():
    return 'full'


#################################### Marks #####################################
# Component
@pytest.mark.fluidity
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.sequentially
################################## End of marks ################################
@pytest.mark.verbose
class TestFluidityBetweenZonesCold(BaseFluidityTest):
    __doc__ = "ColdFullMigrate"
    pass
