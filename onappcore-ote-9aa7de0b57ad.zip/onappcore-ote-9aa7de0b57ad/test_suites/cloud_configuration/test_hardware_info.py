# ignore

import pytest
from onapp_helper import test
from onapp_helper.hardware_info import HardwareInfo
from onapp_helper.backup_server import BackupServer
from onapp_helper.hypervisor import Hypervisor


@pytest.fixture(
    scope='class',
    params=[Hypervisor, BackupServer]
)
def hardware(request):
    if request.param == Hypervisor:
        hvs = [
            hv for hv in Hypervisor().get_all(online=True)
            if hv.hypervisor_type in ['xen', 'kvm']
        ]
        if hvs:
            return HardwareInfo(parent_obj=hvs[0])
    elif request.param == BackupServer:
        bss = [bs for bs in BackupServer().get_all()]
        if bss:
            return HardwareInfo(parent_obj=bss[0])

    return None



#################################### Marks #####################################
# Component
@pytest.mark.cloud_configurations
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version < 5.7, reason=test.not_supported_msg(HardwareInfo)
)
@pytest.mark.verbose
class TestHardwareInfo:
    """
    https://onappdev.atlassian.net/browse/CORE-10736
    """
    def setup_class(self):
        self.custom_field_value = 100500
        self.custom_field_label = 'OTE'

    def test_get_hardware_info(self, hardware):
        test.gen_api_doc = 'Get Hardware Info'
        assert hardware.get(), hardware.error
        assert hardware.status_code == 200

    def test_update_hardware_info(self, hardware):
        test.gen_api_doc = 'Update Hardware Info'
        assert hardware.update_info(), hardware.error

    def test_get_custom_fields(self, hardware):
        test.gen_api_doc = 'Get Custom Fields'
        assert hardware.get_custom_fields(), hardware.error
        assert hardware.status_code == 200

    def test_add_custom_field(self, hardware):
        test.gen_api_doc = 'Add Custom Fields'
        assert hardware.add_custom_field(
            self.custom_field_label,
            self.custom_field_value,
            custom_field=HardwareInfo.CUSTOM_FIELDS.bios_serial_number,
        ), hardware.error

        assert hardware.status_code == 201

        assert [
            field for field in hardware.bios_serial_number_custom_fields
            if field[self.custom_field_label] == self.custom_field_value
        ]

    def test_edit_custom_field(self, hardware):
        # Get element position
        position = 0
        for i in range(len(hardware.bios_serial_number_custom_fields)):
            if hardware.bios_serial_number_custom_fields[i][
                self.custom_field_label] == self.custom_field_value:
                position = i
                break

        test.gen_api_doc = 'Edit Custom Fields'
        assert hardware.edit_custom_field(
            self.custom_field_label,
            self.custom_field_value + 99,
            custom_field=HardwareInfo.CUSTOM_FIELDS.bios_serial_number,
            position=position
        ), hardware.error

        assert hardware.get(), hardware.error

        field = None
        for f in hardware.bios_serial_number_custom_fields:
            if f[self.custom_field_label] == self.custom_field_value + 99:
                field = True
        assert field

    def test_delete_custom_field(self, hardware):
        # Get element position
        position = 0
        for i in range(len(hardware.bios_serial_number_custom_fields)):
            if hardware.bios_serial_number_custom_fields[i][
                self.custom_field_label] == self.custom_field_value + 99:
                position = i
                break

        test.gen_api_doc = 'Delete Custom Fields'
        assert hardware.delete_custom_field(
            custom_field=HardwareInfo.CUSTOM_FIELDS.bios_serial_number,
            position=position
        ), hardware.error

        assert hardware.get(), hardware.error

        field = None
        for f in hardware.bios_serial_number_custom_fields:
            if f[self.custom_field_label] == self.custom_field_value + 99:
                field = True
        assert not field

    def test_add_custom_field_with_slot(self, hardware):
        test.gen_api_doc = 'Add Custom Fields With Slots'
        assert hardware.add_custom_field(
            self.custom_field_label,
            self.custom_field_value,
            custom_field=HardwareInfo.CUSTOM_FIELDS.memory,
            slots=True,
            slot_pos=0
        ), hardware.error

        assert [
            field for field in hardware.memory_slots_custom_fields["0"]
            if field[self.custom_field_label] == self.custom_field_value
        ]

    def test_edit_custom_field_with_slot(self, hardware):
        # Get element position
        position = 0
        for i in range(len(hardware.memory_slots_custom_fields["0"])):
            if hardware.memory_slots_custom_fields["0"][i][
                self.custom_field_label] == self.custom_field_value:
                position = i
                break

        test.gen_api_doc = 'Edit Custom Fields With Slots'
        assert hardware.edit_custom_field(
            self.custom_field_label,
            self.custom_field_value + 99,
            custom_field=HardwareInfo.CUSTOM_FIELDS.memory,
            slots=True,
            position=position,
            slot_pos=0
        ), hardware.error

        assert hardware.get(), hardware.error

        field = None
        for f in hardware.memory_slots_custom_fields["0"]:
            if f[self.custom_field_label] == self.custom_field_value + 99:
                field = True
        assert field

    def test_delete_custom_field_with_slot(self, hardware):
        # Get element position
        position = 0
        for i in range(len(hardware.memory_slots_custom_fields["0"])):
            if hardware.memory_slots_custom_fields["0"][i][
                self.custom_field_label] == self.custom_field_value + 99:
                position = i
                break

        test.gen_api_doc = 'Delete Custom Fields With Slots'
        assert hardware.delete_custom_field(
            custom_field=HardwareInfo.CUSTOM_FIELDS.memory,
            slots=True,
            position=position,
            slot_pos=0
        ), hardware.error

        assert hardware.get(), hardware.error

        if "0" in hardware.memory_slots_custom_fields:
            field = None
            for f in hardware.memory_slots_custom_fields["0"]:
                if f[self.custom_field_label] == self.custom_field_value + 99:
                    field = True
            assert not field
        else:
            assert not hardware.memory_slots_custom_fields
