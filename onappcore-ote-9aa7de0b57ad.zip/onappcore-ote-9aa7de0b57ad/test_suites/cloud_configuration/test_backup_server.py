# daily
import pytest
from onapp_helper.backup_server import BackupServer
from onapp_helper import test


#################################### Marks #####################################
# Component
@pytest.mark.cloud_configurations
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
class TestBackupServerFunctionality():
    def setup_class(self):
        self.bs = BackupServer()

    def teardown_class(self):
        pass

    def test_create_backup_server(self):
        self.bs.label = self.__class__.__name__
        self.bs.ip_address = '192.168.6.252'
        self.bs.capacity = 40
        assert self.bs.create()

    def test_edit_backup_server_label(self):
        self.bs.label = ''.join([self.bs.label, 'New'])
        assert self.bs.edit()
        assert 'New' in self.bs.label

    def test_delete_backup_server(self):
        assert self.bs.delete()