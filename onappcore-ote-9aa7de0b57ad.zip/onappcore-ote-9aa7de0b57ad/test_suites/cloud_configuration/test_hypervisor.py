# daily
from onapp_helper.hypervisor import Hypervisor
from onapp_helper.hypervisor_zone import HypervisorZone
from onapp_helper.data_store import DataStore
from onapp_helper.data_store_zone import DataStoreZone
from onapp_helper.networks import Network
from onapp_helper.network_zone import NetworkZone
from onapp_helper.data_store_join import DataStoreJoin
from onapp_helper.network_join import NetworkJoin
from onapp_helper.backup_server import BackupServer
from onapp_helper.backup_server_join import BackupServerJoin
from onapp_helper.bsz import BSZ
from onapp_helper import test
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.cloud_configurations
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.incremental
class TestHypervisorFunctionality():
    def setup_class(self):
        try:
            self.hvz = HypervisorZone()
            self.hvz.label = self.__name__
            assert self.hvz.create(), self.hvz.error

            self.hv = Hypervisor()

            self.dsz = DataStoreZone()
            self.dsz.label = self.__name__
            assert self.dsz.create(), self.dsz.error

            self.ds = DataStore()
            self.ds.label = self.__name__
            self.ds.data_store_type = 'lvm'
            self.ds.data_store_size = 40
            self.ds.data_store_group_id = self.dsz.id
            assert self.ds.create(), self.ds.error

            self.netz = NetworkZone()
            self.netz.label = self.__name__
            assert self.netz.create(), self.netz.error

            self.network = Network()
            self.network.label = self.__name__
            self.network.network_group_id = self.netz.id
            assert self.network.create(), self.network.error

            self.bsz = BSZ()
            self.bsz.label = self.__name__
            assert self.bsz.create(), self.bsz.error

            self.bs = BackupServer()
            self.bs.label = self.__name__
            self.bs.enabled = True
            self.bs.capacity = 200
            self.bs.ip_address = '192.168.6.254'
            assert self.bs.create(), self.bs.error

            self.bsz.attach_bs(self.bs)

            self.hv_ds_join = DataStoreJoin(self.hv)
            self.hv_network_join = NetworkJoin(self.hv)
            self.hv_bs_join = BackupServerJoin(self.hv)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        attributes = (
            'network',
            'netz',
            'ds',
            'dsz',
            'hv',
            'hvz',
            'bs',
            'bsz'
        )
        test.clean_up_resources(attributes, self)

    def test_create_hypervisor(self):
        self.hv.label = self.__class__.__name__
        self.hv.hypervisor_group_id = self.hvz.id
        self.hv.ip_address = '192.168.6.253'
        self.hv.hypervisor_type = 'xen'
        assert self.hv.create(), self.hv.error

    def test_edit_hypervisor_label(self):
        self.hv.label = ''.join([self.hv.label, 'New'])
        assert self.hv.edit(), self.hv.error
        assert 'New' in self.hv.label

    def test_add_data_store_join(self):
        assert self.hv_ds_join.add(self.ds), self.hv_ds_join.error
        assert self.hv_ds_join.data_store_id == self.ds.id

    def test_remove_data_store_join(self):
        assert self.hv_ds_join.remove(), self.hv_ds_join.error

    def test_add_network_join(self):
        assert self.hv_network_join.add(self.network), self.hv_network_join.error
        assert self.hv_network_join.network_id == self.network.id

    def test_remove_network_join(self):
        assert self.hv_network_join.remove(), self.hv_network_join.error

    def test_add_backup_server_join(self):
        test.gen_api_doc = 'Attach Backup Server to Hypervisor.'
        assert self.hv_bs_join.add(self.bs), self.hv_bs_join.error
        assert self.hv_bs_join.backup_server_id == self.bs.id

    def test_remove_backup_server_join(self):
        test.gen_api_doc = 'Detach Backup Server from Hypervisor.'
        assert self.hv_bs_join.remove(), self.hv_bs_join.error

    def test_delete_hypervisor(self):
        assert self.hv.delete(), self.hv.error
