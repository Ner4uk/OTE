# daily
import pytest
from onapp_helper.bsz import BSZ
from onapp_helper.backup_server import BackupServer
from onapp_helper import test


#################################### Marks #####################################
# Component
@pytest.mark.cloud_configurations
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
class TestBackupServerZoneFunctionality():
    def setup_class(self):
        self.bs = BackupServer()
        self.bs.label = self.__name__
        self.bs.ip_address = '192.168.6.249'
        self.bs.capacity = 40
        self.bs.create()

        self.bsz = BSZ()

        self.create_params = {
            'label': self.__name__,
            'server_type': BSZ.SERVER_TYPE.virtual,
            'location_group_id': None
        }

        self.edit_params = {
            'label': f"{self.__name__}New",
            'server_type': BSZ.SERVER_TYPE.smart,
            'location_group_id': None,
        }

    def teardown_class(self):
        self.bs.delete()

    @pytest.mark.parametrize(
        "param,value,msg",
        [
            ('label', None, "can't be blank"),
            ('label', '', "can't be blank"),
            # ('label', 123, "can't be blank"),  # can be created

            ('server_type', None, "is not included in the list"),
            ('server_type', '', "is not included in the list"),
            ('server_type', 123, "is not included in the list"),
            ('server_type', 'wrong', "is not included in the list"),

            # https://onappdev.atlassian.net/browse/CORE-12445
            ('location_group_id', '', "can't be blank"),
            ('location_group_id', 123, "can't be blank"),
        ]
    )
    def test_should_not_be_possible_to_create_zone_with_wrong_params(
            self, param, value, msg
    ):
        self.reset_resource_params(self.create_params)

        self.bsz.__dict__[param] = value

        if self.bsz.create():
            self.bsz.delete()
            assert False, f'Should not be created with {param} - {value}'

        assert msg in self.bsz.error[param]

    def test_create_backup_server_zone(self):
        self.bsz.label = self.__class__.__name__
        self.bsz.create()

    def test_edit_backup_server_zone_label(self):
        self.bsz.label = ''.join([self.bsz.label, 'New'])
        assert self.bsz.edit()
        assert 'New' in self.bsz.label

    def test_assign_bs_to_bsz(self):
        assert self.bsz.attach_bs(self.bs)
        test.update_object(self.bs)
        assert self.bs.backup_server_group_id == self.bsz.id

    def test_unassign_bs_from_bsz(self):
        assert self.bsz.detach_bs(self.bs)
        test.update_object(self.bs)
        assert not self.bs.backup_server_group_id

    def test_delete_backup_server_zone(self):
        assert self.bsz.delete()

    def reset_resource_params(self, params):
        self.bsz.__dict__.update(params)
