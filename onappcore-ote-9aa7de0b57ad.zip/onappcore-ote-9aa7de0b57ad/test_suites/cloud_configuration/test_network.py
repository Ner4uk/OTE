# daily
import pytest
from onapp_helper.networks import Network
from onapp_helper import test


#################################### Marks #####################################
# Component
@pytest.mark.cloud_configurations
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
class TestNetworkFunctionality():
    def setup_class(self):
        self.network = Network()

    def teardown_class(self):
        pass

    def test_create_network(self):
        self.network.label = self.__class__.__name__
        assert self.network.create()

    def test_edit_network_label(self):
        self.network.label = ''.join([self.network.label, 'New'])
        assert self.network.edit()
        assert 'New' in self.network.label

    def test_delete_network(self):
        assert self.network.delete()