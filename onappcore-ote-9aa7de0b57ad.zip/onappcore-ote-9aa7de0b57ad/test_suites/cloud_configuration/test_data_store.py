# daily
import pytest
from onapp_helper.data_store import DataStore
from onapp_helper import test


#################################### Marks #####################################
# Component
@pytest.mark.cloud_configurations
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
class TestDataStoreFunctionality():
    def setup_class(self):
        self.d_store = DataStore()
        self.d_store.label = self.__name__
        self.d_store.data_store_type = 'lvm'
        self.d_store.data_store_size = 40

    def teardown_class(self):
        pass

    def test_create_datastore_with_data_store_group_id_0(self):
        self.d_store.data_store_group_id = 0
        assert not self.d_store.create()
        assert 'could not be found' in self.d_store.error['data_store_group_id']

    def test_create_datastore(self):
        self.d_store.data_store_group_id = None
        assert self.d_store.create()

    def test_edit_datastore_label(self):
        self.d_store.label = ''.join([self.d_store.label, 'New'])
        assert self.d_store.edit()
        assert 'New' in self.d_store.label

    def test_delete_datastore(self):
        assert self.d_store.delete()