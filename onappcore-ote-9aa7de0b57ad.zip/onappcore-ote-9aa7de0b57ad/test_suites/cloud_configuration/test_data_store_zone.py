# daily
import pytest
from onapp_helper.data_store import DataStore
from onapp_helper.data_store_zone import DataStoreZone
from onapp_helper import test


#################################### Marks #####################################
# Component
@pytest.mark.cloud_configurations
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
class TestDataStoreZoneFunctionality():
    def setup_class(self):
        self.d_store = DataStore()
        self.dsz = DataStoreZone()
        self.d_store.label = self.__name__
        self.d_store.data_store_type = 'lvm'
        self.d_store.data_store_size = 40
        assert self.d_store.create()

        self.create_params = {
            'label': self.__name__,
            'server_type': DataStoreZone.SERVER_TYPE.virtual,
            'location_group_id': None
        }

        self.edit_params = {
            'label': f"{self.__name__}New",
            'server_type': DataStoreZone.SERVER_TYPE.smart,
            'location_group_id': None,
        }

    @pytest.mark.parametrize(
        "param,value,msg",
        [
            ('label', None, "can't be blank"),
            ('label', '', "can't be blank"),
            # ('label', 123, "can't be blank"),  # can be created

            ('server_type', None, "is not included in the list"),
            ('server_type', '', "is not included in the list"),
            ('server_type', 123, "is not included in the list"),
            ('server_type', 'wrong', "is not included in the list"),
            # https://onappdev.atlassian.net/browse/CORE-12445
            ('location_group_id', '', "can't be blank"),
            ('location_group_id', 123, "can't be blank"),
        ]
    )
    def test_should_not_be_possible_to_create_zone_with_wrong_params(
            self, param, value, msg
    ):
        self.reset_resource_params(self.create_params)

        self.dsz.__dict__[param] = value

        if self.dsz.create():
            self.dsz.delete()
            assert False, f'Should not been created with {param} - {value}'

        assert msg in self.dsz.error[param]

    def teardown_class(self):
        self.d_store.delete()

    def test_create_data_store_zone(self):
        self.dsz.label = self.__class__.__name__
        self.dsz.create()

    def test_edit_data_store_zone(self):
        self.dsz.label = ''.join([self.dsz.label, 'New'])
        assert self.dsz.edit()
        assert 'New' in self.dsz.label

    def test_attach_ds_to_dsz(self):
        assert self.dsz.attach_ds(self.d_store)
        test.update_object(self.d_store)
        assert self.d_store.data_store_group_id == self.dsz.id

    def test_detach_ds_to_dsz(self):
        assert self.dsz.detach_ds(self.d_store)
        test.update_object(self.d_store)
        assert not self.d_store.data_store_group_id

    def test_delete_data_store_zone(self):
        assert self.dsz.delete()

    def reset_resource_params(self, params):
        self.dsz.__dict__.update(params)