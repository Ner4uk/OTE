# daily
import pytest
from onapp_helper.networks import Network
from onapp_helper.network_zone import NetworkZone
from onapp_helper import test


#################################### Marks #####################################
# Component
@pytest.mark.cloud_configurations
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
class TestNetworkZoneFunctionality():
    def setup_class(self):
        self.network = Network()
        self.netz = NetworkZone()
        self.network.label = self.__name__
        assert self.network.create()

        self.create_params = {
            'label': self.__name__,
            'server_type': NetworkZone.SERVER_TYPE.virtual,
            'location_group_id': None
        }

        self.edit_params = {
            'label': f"{self.__name__}New",
            'server_type': NetworkZone.SERVER_TYPE.smart,
            'location_group_id': None,
        }

    def teardown_class(self):
        self.network.delete()

    @pytest.mark.parametrize(
        "param,value,msg",
        [
            ('label', None, "can't be blank"),
            ('label', '', "can't be blank"),
            # ('label', 123, "can't be blank"),  # can be created

            ('server_type', None, "is not included in the list"),
            ('server_type', '', "is not included in the list"),
            ('server_type', 123, "is not included in the list"),
            ('server_type', 'wrong', "is not included in the list"),

            # https://onappdev.atlassian.net/browse/CORE-12445
            ('location_group_id', '', "can't be blank"),
            ('location_group_id', 123, "can't be blank"),
        ]
    )
    def test_should_not_be_possible_to_create_zone_with_wrong_params(
            self, param, value, msg
    ):
        self.reset_resource_params(self.create_params)

        self.netz.__dict__[param] = value

        if self.netz.create():
            self.netz.delete()
            assert False, f'Should not been created with {param} - {value}'

        assert msg in self.netz.error[param]

    def test_create_network_zone(self):
        self.netz.label = self.__class__.__name__
        self.netz.create()

    def test_edit_network_zone_label(self):
        self.netz.label = ''.join([self.netz.label, 'New'])
        assert self.netz.edit()
        assert 'New' in self.netz.label

    def test_attach_network_to_netz(self):
        assert self.netz.attach_network(self.network)
        test.update_object(self.network)
        assert self.network.network_group_id == self.netz.id

    def test_detach_network_from_netz(self):
        assert self.netz.detach_network(self.network)
        test.update_object(self.network)
        assert not self.network.network_group_id

    def test_delete_network_zone(self):
        assert self.netz.delete()

    def reset_resource_params(self, params):
        self.netz.__dict__.update(params)