# ignore
import os
from time import sleep

import pytest

from onapp_helper import test
from onapp_helper.base_helper import BaseHelper
from onapp_helper.billing_plan import BillingPlan
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.user import User
from onapp_helper.vsphere.vsphere_cli import VSphereVM

__maintainer__ = 'QAOH'

VERSION_TO_INSTALL = 5.7
USE_TESTING_REPO = False
USE_STAGING_REPO = False
USE_DEVELOPMENT_REPO = False
CLOUDBOOT_IMAGES_TO_INSTALL = 'onapp-ramdisk-centos6-kvm onapp-ramdisk-centos7-kvm'
# The constants below are used to deploy CP on a VMWare VS
MANAGE_VSPHERE = False  # False to avoid manipulating the vsphere vms, just be sure to provide ready-to install cp host
VSPHERE_CP_HOST = 'ostack_cp_oh'  # vsphere vm label - this vm should be reverted to clean pre-install state(Centos 7)
TIME_FOR_VSPHERE_VM_2START = 30  # seconds for Centos to start reply to pings
SNAPSHOT_TO_USE = 'Centos7properRoutes'  # make it empty to avoid restoring from snapshot


@pytest.mark.ignore
class TestDeployControlPanel:
    def setup_class(self):
        if MANAGE_VSPHERE:
            try:
                cp = VSphereVM(VSPHERE_CP_HOST)
                if SNAPSHOT_TO_USE:
                    cp.restore_from_snapshot(SNAPSHOT_TO_USE)
                if cp.power_state() == 'poweredOff':
                    test.log.warning(f"Starting {VSPHERE_CP_HOST} in VSphere...")
                    cp.on()
                cp_power_state = cp.power_state()
                assert cp_power_state == 'poweredOn', f"The {VSPHERE_CP_HOST} is in state {cp_power_state}"
                assert self.ping(address=test.cp.host, timeout=TIME_FOR_VSPHERE_VM_2START)
            except Exception as e:
                test.log.error(f"Test setup failed - {e}")
                exit(e)

    @staticmethod
    def ping(address, timeout):
        cmd = "ping -c 1 " + address
        test.log.info(cmd)
        return BaseHelper().wait_for_action(
            lambda: os.system(cmd) == 0,
            timeout=timeout
        )

    @pytest.mark.incremental
    def test_cp_installation(self):
        test.cp.install(version=VERSION_TO_INSTALL,
                        use_cdn=False,
                        testing=USE_TESTING_REPO,
                        staging=USE_STAGING_REPO,
                        development=USE_DEVELOPMENT_REPO
                        )
        assert "Finished Control Panel version" in test.cp.execute('tail -n 1 /root/onapp-cp-install.log'), \
            f"CP install failed, last strings in log were:{test.cp.execute('tail -n 5 /root/onapp-cp-install.log')}"

    @pytest.mark.incremental
    def test_set_cp_license(self):
        # Provide synced time on cp to allow for licensing
        from datetime import datetime
        assert test.cp.ext_execute(f"date -u +%T -s {datetime.utcnow().strftime('%T')}")
        license_insert_status, license_insert_message = test.cp.ext_execute(
            f"echo 'license_key: {test.license_key}' >> /onapp/interface/config/on_app.yml")
        assert not license_insert_status, license_insert_message
        if test.licensing_server == 'staging':
            lic_fix_status, lic_fix_message = test.cp.ext_execute(
                "sed -i 's/licensing.onapp.com/staging-dashboard.onapp.com/g' "
                "/onapp/interface/config/environments/production.rb")
            assert not lic_fix_status, lic_fix_message
        licensing_restart_status, licensing_restart_message = test.cp.ext_execute('service onapp-licensing restart')
        assert not licensing_restart_status, licensing_restart_message

    @pytest.mark.incremental
    def test_store_install(self):
        if CLOUDBOOT_IMAGES_TO_INSTALL:
            images_installed_status, images_installed_message = test.cp.ext_execute('yum -y install '
                                                                                + CLOUDBOOT_IMAGES_TO_INSTALL)
            assert not images_installed_status, images_installed_message
        assert test.cp.store_install(), 'Failed to install Integrated Storage on CP'
        # TODO test.cp_version = VERSION_TO_INSTALL #check - as at the moment it is 0.0 ?

    @pytest.mark.incremental
    @pytest.mark.skipif(test.cp.user == 'admin', reason='The default admin user is to be used')
    def test_cp_create_admin_user(self):
        test.execute_as('admin', 'changeme')
        if test.cp_version < 5.6:
            self.billing_plan = BillingPlan()
            self.billing_plan.label = f"Billing Plan for {test.cp.user}"
            assert self.billing_plan.create(), self.billing_plan.error
            self.user = User(bp=self.billing_plan)
        else:
            self.user_bucket = Bucket()
            self.user_bucket.label = f"Bucket for {test.cp.user}"
            assert self.user_bucket.create(), self.user_bucket.error
            self.user = User(bucket=self.user_bucket)
        self.user.login = test.cp.user
        self.user.password = test.cp.password
        self.user.email = test.cp.user + '@' + __maintainer__ + '.test'
        assert self.user.create(), self.user.error

    def test_customize_cp_settings(self):
        test.load_env()
        assert test.onapp_settings.set(
            license_key=test.license_key,
            cloud_boot_enabled=True,
            cloud_boot_target=test.clb_net_ip,
            cloud_boot_domain_name_servers=test.clb_net_ip,
            nfs_root_ip=test.clb_net_ip,
            storage_enabled=True,
            storage_unicast=True,
            enforce_redundancy=False,
            password_enforce_complexity=False
        )
        httpd_restart_status, httpd_restart_message = test.cp.restart_httpd()  # otherwise settings are not applied
        assert not httpd_restart_status, httpd_restart_message
        test.log.info("Waiting 30 sec for OnApp services to start")
        sleep(30)
        test.onapp_settings.get()
        assert test.onapp_settings.cloud_boot_enabled, "Cloudboot not enabled"
        assert test.onapp_settings.storage_enabled, "Integrated Storage not enabled"
