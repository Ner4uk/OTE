# ignore
import pytest

from onapp_helper import test

__maintainer__ = 'QAOH'

VERSION_TO_INSTALL = 5.7
USE_TESTING_REPO = False
USE_STAGING_REPO = False
USE_DEVELOPMENT_REPO = False
UPGRADE_STORAGE = True


@pytest.mark.ignore
@pytest.mark.incremental
class TestUpgradeControlPanel:
    def test_cp_upgrade(self):

        assert test.cp.upgrade(version=VERSION_TO_INSTALL, testing=USE_TESTING_REPO, staging=USE_STAGING_REPO,
                               development=USE_DEVELOPMENT_REPO), 'Failed to upgrade CP'
        assert test.cp.get_version().startswith(str(VERSION_TO_INSTALL))
        assert 'Finished Control Panel version' in test.cp.execute('tail -n 1 /root/onapp-cp-install.log'), \
            'CP upgrade failed '

    def test_set_cp_license(self):
        httpd_stop_status, httpd_stop_message = test.cp.ext_execute(
            'service httpd stop')  # otherwise it throws SystemError: 'License Invalid'
        assert not httpd_stop_status, httpd_stop_message
        if test.licensing_server == 'staging':
            lic_fix_status, lic_fix_message = test.cp.ext_execute(
                "sed -i 's/licensing.onapp.com/staging-dashboard.onapp.com/g' "
                "/onapp/interface/config/environments/production.rb")
            assert not lic_fix_status, lic_fix_message
        httpd_start_status, httpd_start_message = test.cp.ext_execute('service httpd start')
        assert not httpd_start_status, httpd_start_message
        onapp_restart_status, onapp_restart_message = test.cp.ext_execute('service onapp restart')
        assert not onapp_restart_status, onapp_restart_message
        licens_restart_status, licens_restart_message = test.cp.ext_execute('service onapp-licensing restart')
        assert not licens_restart_status, licens_restart_message

    @pytest.mark.skipif(not UPGRADE_STORAGE, reason='Storage upgrade not requested')
    def test_store_upgrade(self):
        assert test.cp.store_upgrade(), 'Failed to upgrade storage on CP'
