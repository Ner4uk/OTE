import pytest
from ruamel import yaml

from onapp_helper import test


@pytest.fixture(scope='class')
def platform_version_is_centos6():
    return test.cp.platform_version_is_centos6()


@pytest.mark.ignore
@pytest.mark.incremental
class TestChecksControlPanel:
    def test_check_inet(self):
        status, message = test.cp.ext_execute('ping -c1 google.com')
        assert not status, 'There is no Internet connection:' \
                           f'{message}'

    def test_check_snmptrap_address(self):
        snmptrap_addresses = f'snmptrap_addresses: {test.host}'
        check_address = f"grep {snmptrap_addresses} /onapp/interface/config/on_app.yml"
        status, message = test.cp.ext_execute(check_address)
        assert snmptrap_addresses in message, 'Snmptrap addresses not found:' \
                                              f'{message}'

    def test_check_on_app_owner(self):
        status, message = test.cp.ext_execute(
            "ls -l /onapp/interface/config/on_app.yml | awk '{print $3}' | grep 'onapp'")
        assert not status and 'onapp' in message,\
            'OnApp owner was not found in on_app.yml:' \
            f'{message}'

    def test_check_on_app_group(self):
        status, message = test.cp.ext_execute(
            "ls -l /onapp/interface/config/on_app.yml | awk '{print $4}' | grep 'onapp'")
        assert not status and 'onapp' in message,\
            'OnApp group was not found:' \
            f'{message}'

    def test_cat_on_app_yml(self):
        status, message = test.cp.ext_execute(
            'cat /onapp/interface/config/on_app.yml')
        assert not status, 'OnApp YML was not found:' \
                           f'{message}'

    """ MYSQL """

    def test_cat_database_yml(self):
        status, message = test.cp.ext_execute(
            'cat /onapp/interface/config/database.yml')
        assert not status, 'DataBase YML was not found:' \
                           f'{message}'

    def test_check_mysql_conf_file(self):
        status, message = test.cp.ext_execute("test -f /etc/my.cnf")
        assert not status, 'MySql configuration file was not found:' \
                           f'{message}'
        status, message = test.cp.ext_execute("test -s /etc/my.cnf")
        assert not status, 'MySql configuration file exists but it is empty:' \
                           f'{message}'

    def test_check_mysql_onapp_init(self):
        status, message = test.cp.ext_execute("test -f /etc/init.d/onapp-db")
        assert not status, 'MySql OnApp init was not found:' \
                           f'{message}'

    def test_check_onapp_db_folder(self):
        status, message = test.cp.ext_execute("test -d /var/lib/mysql/")
        assert not status, 'OnApp DB folder was not found:' \
                           f'{message}'

    def test_check_owner_db_yml(self):
        status, message = test.cp.ext_execute(
            "ls -l /onapp/interface/config/database.yml  | awk '{print $3}' | grep onapp")
        assert not status and 'onapp' in message, 'DB owner onapp was not found:' \
                                                  f'{message}'

    def test_check_group_db_yml(self):
        status, message = test.cp.ext_execute(
            "ls -l /onapp/interface/config/database.yml  | awk '{print $4}' | grep onapp")
        assert not status and 'onapp' in message, 'DB group onapp was not found:' \
                                                  f'{message}'

    def test_check_dbdpersist_http(self):
        dbdpersist = 'DBDPersist   On'
        grep = f"grep '{dbdpersist}' /etc/httpd/conf.d/onapp.conf"
        status, message = test.cp.ext_execute(grep)
        assert not status and dbdpersist in message, 'HTTP DBDPersist On was not found:' \
                                                     f'{message}'

    def test_check_dbdexptime_http(self):
        dbdexptime = 'DBDExptime   300'
        grep = f"grep '{dbdexptime}' /etc/httpd/conf.d/onapp.conf"
        status, message = test.cp.ext_execute(grep)
        assert not status and dbdexptime in message, 'HTTP DBDExptime 300 was not found:' \
                                                     f'{message}'

    def test_check_dbdmax_http(self):
        dbdmax = 'DBDMax       10'
        grep = f"grep '{dbdmax}' /etc/httpd/conf.d/onapp.conf"
        status, message = test.cp.ext_execute(grep)
        assert not status and dbdmax in message, 'HTTP DBDMax 10 was not found:' \
                                                 f'{message}'

    def test_check_dbdmin_http(self):
        dbdmin = 'DBDMin       1'
        grep = f"grep '{dbdmin}' /etc/httpd/conf.d/onapp.conf"
        status, message = test.cp.ext_execute(grep)
        assert not status and dbdmin in message, 'HTTP DBDMin 1 was not found:' \
                                                 f'{message}'

    """ RABBITMQ """

    def test_check_rmq_rpm_admin(self):
        status, message = test.cp.ext_execute(
            "rpm -qa | grep rabbitmq-admin")
        assert not status and 'rabbitmq-admin' in message, 'RabbitMQ admin rpm was not found:' \
                                                           f'{message}'

    def test_check_rmq_rpm_cp(self):
        status, message = test.cp.ext_execute(
            "rpm -qa | grep onapp-cp-rabbitmq")
        assert not status and 'onapp-cp-rabbitmq' in message, 'OnApp CP RabbitMQ rpm was not found:' \
                                                              f'{message}'

    def test_check_rmq_rpm_server(self):
        status, message = test.cp.ext_execute(
            "rpm -qa | grep rabbitmq-server")
        assert not status and 'rabbitmq-server' in message, 'RabbitMQ server rpm was not found:' \
                                                            f'{message}'

    def test_check_rmq_folder(self):
        status, message = test.cp.ext_execute(
            "test -d /var/lib/rabbitmq/")
        assert not status, 'RabbitMQ folder was not found:' \
                           f'{message}'

    def test_check_rmq_init_onapp(self):
        status, message = test.cp.ext_execute(
            "test -f /etc/init.d/onapp-mq")
        assert not status, 'OnApp RabbitMQ init file was not found:' \
                           f'{message}'

    def test_check_rmq_init(self):
        status, message = test.cp.ext_execute(
            "test -f /etc/init.d/rabbitmq-server")
        assert not status, 'RabbitMQ server file was not found:' \
                           f'{message}'

    def test_check_rmq_response(self):
        status, message = test.cp.ext_execute(
            "rabbitmqctl list_users")
        assert not status and 'Listing users' in message, 'RabbitMQ users list is empty:' \
                                                          f'{message}'

    def test_check_rmq_main_log_file(self):
        hostname = test.clouds_config.section
        test_f = f"test -f /var/log/rabbitmq/rabbit@{hostname}.log"
        status, message = test.cp.ext_execute(test_f)
        assert not status, f'RabbitMQ main log file with hostname: {hostname} was not found: ' \
                           f'{message}'

    def test_check_rmq_shutdown_err(self):
        status, message = test.cp.ext_execute("test -f /var/log/rabbitmq/shutdown_err")
        assert not status, 'RabbitMQ server file was not found:' \
                           f'{message}'

    def test_check_rmq_shutdown_log(self):
        status, message = test.cp.ext_execute("test -f /var/log/rabbitmq/shutdown_log")
        assert not status, 'RabbitMQ shutdown_err file was not found:' \
                           f'{message}'

    def test_check_rmq_startup_err(self):
        status, message = test.cp.ext_execute("test -f /var/log/rabbitmq/startup_err")
        assert not status, 'RabbitMQ startup_err file was not found:' \
                           f'{message}'

    def test_check_rmq_startup_log(self):
        status, message = test.cp.ext_execute("test -f /var/log/rabbitmq/startup_log")
        assert not status, 'RabbitMQ startup_log file was not found:' \
                           f'{message}'

    def test_check_rmq_mgr_file(self):
        status, message = test.cp.ext_execute("test -f  /onapp/onapp-rabbitmq/.rabbitmq.mgr")
        assert not status, 'RabbitMQ mgr file was not found:' \
                           f'{message}'

    """ REDIS """

    def test_cat_redis_yml(self):
        status, message = test.cp.ext_execute('cat /onapp/interface/config/redis.yml')
        assert not status and 'host' in message, 'Redis yml file was not found:' \
                                                 f'{message}'

    def test_check_redis_rpm_cp(self):
        status, message = test.cp.ext_execute("rpm -qa | grep onapp-cp-redis")
        assert not status and 'onapp-cp-redis' in message, 'Redis OnApp CP rpm file was not found:' \
                                                           f'{message}'

    def test_check_redis_rpms(self):
        status, message = test.cp.ext_execute("rpm -qa | grep '^redis'")
        assert not status and 'redis' in message, 'Redis rpm file was not found:' \
                                                  f'{message}'

    def test_check_redis_rubygem_rails(self):
        status, message = test.cp.ext_execute("rpm -qa | grep rubygem-redis-rails")
        assert not status and 'rubygem-redis-rails' in message, 'RubyGems redis rails file was not found:' \
                                                                f'{message}'

    def test_check_redis_rubygem_store(self):
        status, message = test.cp.ext_execute("rpm -qa | grep rubygem-redis-store")
        assert not status and 'rubygem-redis-store' in message, 'RubyGems redis store file was not found:' \
                                                                f'{message}'

    def test_check_redis_rubygem_redis(self):
        status, message = test.cp.ext_execute("rpm -qa | grep rubygem-redis")
        assert not status and 'rubygem-redis' in message, 'RubyGems redis was not found:' \
                                                          f'{message}'

    def test_check_redis_rubygem_actionpack(self):
        status, message = test.cp.ext_execute("rpm -qa | grep rubygem-redis-actionpack")
        assert not status and 'rubygem-redis-actionpack' in message, 'RubyGems redis actionpack was not found:' \
                                                                     f'{message}'

    def test_check_redis_rubygem_activesupport(self):
        status, message = test.cp.ext_execute("rpm -qa | grep rubygem-redis-activesupport")
        assert not status and 'rubygem-redis-activesupport' in message, 'RubyGems redis activesupport was not found:' \
                                                                        f'{message}'

    def test_check_redis_rubygem_objects(self):
        status, message = test.cp.ext_execute("rpm -qa | grep rubygem-redis-objects")
        assert not status and 'rubygem-redis-objects' in message, 'RubyGems redis objects was not found:' \
                                                                  f'{message}'

    def test_check_redis_init_onapp(self):
        status, message = test.cp.ext_execute("test -f /etc/init.d/onapp-redis")
        assert not status, 'redis_init_onapp file was not found:' \
                           f'{message}'

    def test_check_redis_sentinel_onapp(self):
        status, message = test.cp.ext_execute("test -f /etc/init.d/onapp-redis-sentinel")
        assert not status, 'onapp-redis-sentinel file was not found:' \
                           f'{message}'

    def test_check_redis_yml(self):
        status, message = test.cp.ext_execute("test -f /onapp/interface/config/redis.yml")
        assert not status, 'Redis yml file was not found:' \
                           f'{message}'

    def test_check_redis_yml_owner(self):
        status, message = test.cp.ext_execute(
            "ls -l  /onapp/interface/config/redis.yml | awk '{print $3}'| grep onapp")
        assert not status and 'onapp' in message, 'Redis yml owner file was not found:' \
                                                  f'{message}'

    def test_check_redis_yml_group(self):
        status, message = test.cp.ext_execute(
            "ls -l  /onapp/interface/config/redis.yml | awk '{print $4}'| grep onapp")
        assert not status and 'onapp' in message, 'Redis yml group file was not found:' \
                                                  f'{message}'

    def test_check_redis_conf(self):
        status, message = test.cp.ext_execute("test -f /etc/redis.conf")
        assert not status, 'Redis configuration file was not found:' \
                           f'{message}'

    def test_check_redis_sentinel_conf(self):
        status, message = test.cp.ext_execute("test -f /etc/redis-sentinel.conf")
        assert not status, 'Redis sentinel configuration file was not found:' \
                           f'{message}'

    def test_check_redis_folder(self):
        status, message = test.cp.ext_execute("test -d /var/lib/redis/")
        assert not status, 'Redis folder was not found:' \
                           f'{message}'

    def test_get_name_redis_rdb(self):
        status, message = test.cp.ext_execute("awk '/^dbfilename/ {print $2}' /etc/redis.conf")
        assert not status and 'onapp.rdb' in message, 'Redis rdb conf file was not found:' \
                              f'{message}'
        status, message = test.cp.ext_execute("test -f /var/lib/redis/onapp.rdb")
        assert not status, 'Redis onapp.rdb file was not found:' \
                           f'{message}'

    def test_check_redis_bind(self):
        status, message = test.cp.ext_execute("grep 'bind 127.0.0.1' /etc/redis.conf")
        assert not status and 'bind 127.0.0.1' in message, 'Redis bind was not found:' \
                                                           f'{message}'

    def test_check_redis_port(self):
        status, message = test.cp.ext_execute("grep '^port 0' /etc/redis.conf")
        assert not status and 'port 0' in message, 'Redis port was not found:' \
                              f'{message}'

    def test_check_redis_pidfile_path(self):
        status, message = test.cp.ext_execute(
            "grep 'pidfile /var/run/redis/redis.pid' /etc/redis.conf")
        assert not status and 'pidfile /var/run/redis/redis.pid' in message, \
            'Redis pidfile_path was not found:' \
            f'{message}'

    """ Make sure that everything is running """

    def test_check_onapp_engine_status(self):
        status, message = test.cp.ext_execute(
            "service onapp-engine status | grep running")
        assert not status and 'is running' in message, \
            'Service onapp-engine status is not running:' \
            f'{message}'

    def test_check_onapp_vnc_proxy(self):
        status, message = test.cp.ext_execute(
            "service onapp-vnc-proxy status | grep running")
        assert not status and 'is running' in message, \
            'Service onapp-vnc-proxy status is not running:' \
            f'{message}'

    def test_check_crond_status(self):
        status, message = test.cp.ext_execute(
            "service crond status | grep running")
        assert not status and 'running' in message, \
            'Service crond status is not running:' \
            f'{message}'

    def test_check_monit_status(self):
        status, message = test.cp.ext_execute(
            "service monit status | grep running")
        assert not status and 'running' in message, \
            'Service monit status is not running:' \
            f'{message}'

    def test_check_connection_to_db(self):
        status, config = test.cp.ext_execute('cat /onapp/interface/config/database.yml')
        config_dict = yaml.load(config, Loader=yaml.Loader)
        db = config_dict['production']['database']
        result = test.cp.mysql_execute("SHOW DATABASES;")
        assert result and db in result, 'DB connection refused:' \
                                        f'Config: {config}' \
                                        f'DB: {db}, result: {result}'

    def test_check_connection_to_rmq(self):
        status, rbt_login = test.cp.ext_execute(
            "awk '{print $1}' /onapp/onapp-rabbitmq/.rabbitmq.mgr")
        assert not status, 'rbt login was not found:' \
                           f'{rbt_login}'
        status, rbt_password = test.cp.ext_execute(
            "awk '{print $2}' /onapp/onapp-rabbitmq/.rabbitmq.mgr")
        assert not status, 'rbt password was not found:' \
                           f'{rbt_password}'
        rbt_login, rbt_password = rbt_login.replace('\n', ''), rbt_password.replace('\n', '')
        curl = f"curl -X GET http://localhost:15672/api/users -u {rbt_login}:{rbt_password}"
        status, connect = test.cp.ext_execute(curl)
        assert not status and rbt_login in connect and 'rbtvcd' in connect, 'Rabbitmq connection refused:' \
                                                                            f'{connect}'

    def test_check_connection_to_redis(self):
        status, path = test.cp.ext_execute(
            "awk '/path/ {print $2}' /onapp/interface/config/redis.yml")
        assert not status, 'Path to redis was not found:' \
                           f'{path}'
        connection_to_redis = f"redis-cli -s {path.splitlines()[0]} ping"
        status, connect = test.cp.ext_execute(connection_to_redis)
        assert not status and 'PONG' in connect, 'No Redis connection:' \
                              f'{connect}'

    def test_check_api_availability(self):
        curl = f"curl -I -X GET -u admin:changeme http://{test.host}/settings/license.json | grep 'Status: 200 OK'"
        status, message = test.cp.ext_execute(curl)
        assert not status and 'Status: 200 OK' in message,\
            'API is not available:' \
            f'{message}'

    """ Mariadb """

    @pytest.mark.skipif(platform_version_is_centos6, reason='Not supported')
    def test_check_rpm_mariadb(self):
        status, message = test.cp.ext_execute("rpm -qa | grep mariadb")
        assert not status and 'mariadb' in message, 'Mariadb rpm was not found:' \
                                                    f'{message}'

    @pytest.mark.skipif(platform_version_is_centos6, reason='Not supported')
    def test_check_redis_service_c7(self):
        status, message = test.cp.ext_execute(
            "test -f /usr/lib/systemd/system/redis.service")
        assert not status, 'Redis service was not found:' \
                           f'{message}'

    @pytest.mark.skipif(platform_version_is_centos6, reason='Not supported')
    def test_check_redis_sentinel_service_c7(self):
        status, message = test.cp.ext_execute(
            "test -f /usr/lib/systemd/system/redis-sentinel.service")
        assert not status, 'Redis sentinel service was not found:' \
                           f'{message}'

    @pytest.mark.skipif(platform_version_is_centos6, reason='Not supported')
    def test_check_redis_sentinel_init(self):
        status, message = test.cp.ext_execute("test -f /etc/init.d/redis-sentinel")
        assert not status, 'Redis sentinel init file was not found:' \
                           f'{message}'

    @pytest.mark.skipif(platform_version_is_centos6, reason='Not supported')
    def test_check_mysql_rpm(self):
        if test.cp.platform_version_is_centos6():
            status, message = test.cp.ext_execute("rpm -qa | grep mysql-server")
            assert not status and 'mysql-server' in message, 'MySql rpm was not found:' \
                                                             f'{message}'

    @pytest.mark.skipif(platform_version_is_centos6, reason='Not supported')
    def test_check_redis_init(self):
        status, message = test.cp.ext_execute("test -f /etc/init.d/redis")
        assert not status, 'Redis init file was not found:' \
                           f'{message}'
