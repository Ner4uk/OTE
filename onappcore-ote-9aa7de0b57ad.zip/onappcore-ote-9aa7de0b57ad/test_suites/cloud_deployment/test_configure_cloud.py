# ignore
import ipaddress
import time

import pytest

from onapp_helper.billing_plan import BillingPlan
from onapp_helper.bucket.access_controls import add_all_resources_to_bucket
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.cloud_boot_ip_address import CloudBootIpAddress
from onapp_helper.cloudbooted_resource import CloudBooted
from onapp_helper.data_store import DataStore
from onapp_helper.data_store_zone import DataStoreZone
from onapp_helper.hypervisor_zone import *
from onapp_helper.ip_network import IpNetwork
from onapp_helper.network_zone import NetworkZone
from onapp_helper.networks import CloudbootNetwork
from onapp_helper.networks import Network
from onapp_helper.template import Template
from onapp_helper.template_store import TemplateStore, RelationGroupTemplate
from onapp_helper.user import User
from onapp_helper.server import VirtualServer
from onapp_helper.vsphere.vsphere_cli import VSphereVM

__maintainer__ = 'QAOH'

"*********************************TEST DATA START******************************"
VS_TYPE = 'virtual'
CLOUDBOOT_OS = 'centos6'
CUSTOM_CONFIG = 'mkdir /onapp/backups;mount -t nfs -o rw 10.0.52.233:/onapp/backups /onapp/backups'  # TODO fix hardcoding
NETWORK_MASK = '24'
TEST_NETWORK1 = '10.20.30.0'
TEST_NETWORK1_MASK = '24'
TEST_NETWORK2 = '10.20.40.0'
TEST_NETWORK2_MASK = '24'
TEMPLATES_TO_INSTALL = ['Ubuntu']
VSPHERE_HYPERVISOR_HOSTS = ['ostack_clb1_oh', 'ostack_clb2_oh']  # vsphere vms labels
TIME_FOR_VSPHERE_VM_2START = 500  # seconds for Centos to start
"*********************************TEST DATA END******************************"


@pytest.mark.skipif(
    test.cp_version < 5.4,
    reason=f"Current CP version {test.cp_version} does not support new networking style"
)
@pytest.mark.verbose
@pytest.mark.ignore
@pytest.mark.incremental
class TestConfigureCloud:
    def setup_class(self):
        test.use_cloud_boot_hv = True
        try:
            self.hypervisor = CloudBooted()
            self.hypervisor.hypervisor_type = 'kvm'
            self.hypervisor.cloud_boot_os = CLOUDBOOT_OS
            self.hypervisor_zone = HypervisorZone()
            self.hvs = []
            self.hypervisor_zone.server_type = VS_TYPE
            self.hypervisor_zone.label = 'HypervizorZone_' + self.__name__
            self.datastore_zone = DataStoreZone()
            self.datastore_zone.server_type = VS_TYPE
            self.datastore_zone.label = 'DataStoreZone_' + self.__name__
            self.network_zone = NetworkZone()
            self.network_zone.server_type = VS_TYPE
            self.network_zone.label = 'NetworkZone_' + self.__name__
            self.template_store = TemplateStore()
            self.template_store.label = 'Test_TStore_' + self.__name__ + __maintainer__
            self.template = Template()
            self.cloudboot_network = CloudbootNetwork()
            self.cloudboot_ipnet = IpNetwork(self.cloudboot_network)
            self.cloudboot_ipnet.label = 'ClbIpNet'
            self.cloudboot_ipaddresses = CloudBootIpAddress()
            self.shared_network_1 = Network()
            self.shared_network_1.type = Network.NETWORK_TYPE.shared
            self.shared_network_1.label = 'Network_1_' + self.__name__
            self.shared_network_2 = Network()
            self.shared_network_2.type = Network.NETWORK_TYPE.shared
            self.shared_network_2.label = 'Network_2_' + self.__name__
            if test.cp_version > 5.5:  # here HV zones got custom config
                self.hypervisor.apply_hypervisor_group_custom_config = 1
                self.hypervisor_zone.custom_config = CUSTOM_CONFIG
                self.user_bucket = Bucket()
                self.user_bucket.label = 'Fully-Loaded_Bucket_' + __maintainer__
                assert self.user_bucket.create(), self.user_bucket.error
                self.user = User(bucket=self.user_bucket)
            else:
                self.hypervisor.custom_config = CUSTOM_CONFIG
                self.billing_plan = BillingPlan()
                self.billing_plan.label = 'BillingPlan_' + __maintainer__
                assert self.billing_plan.create(), self.billing_plan.error
                self.user = User(bp=self.billing_plan)
            self.user.login = __maintainer__ + 'test_user'
            self.user.password = test.generate_password()
            self.user.email = __maintainer__ + '@test.co.ua'
            assert self.user.create(), self.user.error
            self.vs = '' #to provide self.vs visibility in testcases

        except:
            self.teardown_class(self)
            exit()

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        attributes = (
            'vs',
            'user',
            'billing_plan',
            'bucket',
        )
        test.clean_up_resources(attributes, self)

    def test_zones_setup(self):
        assert self.hypervisor_zone.create(), self.hypervisor_zone.error
        assert self.datastore_zone.create(), self.datastore_zone.error
        assert self.network_zone.create(), self.network_zone.error

    def test_create_cloudboot_network(self):
        """
        Create cloudboot ip address pool
        1.calculate pool of ip addresses from the clb_net_ip of CP
        2.exclude all the unacceptable addresses
        3.create ip net with the default range
        4.add some addresses for cloudboots from the available in pool
        """
        cnet = ipaddress.ip_interface(test.cp.clb_net_ip + '/' + NETWORK_MASK).network
        self.cloudboot_ipnet.network_address = str(cnet.network_address)
        self.cloudboot_ipnet.network_mask = NETWORK_MASK
        self.cloudboot_ipnet.add_default_ip_range = 1
        self.cloudboot_ipnet.create()
        ips = [str(i) for i in cnet if str(i) != test.cp.clb_net_ip]
        del ips[:2]
        del ips[-1]
        for ip_addr in ips[:10]:
            self.cloudboot_ipaddresses.address = ip_addr
            assert self.cloudboot_ipaddresses.create(), self.cloudboot_ipaddresses.error
        assert ips[:10] == [p.address for p in self.cloudboot_ipaddresses.get_all()]

    def test_create_cloudboot_hypervisors(self, request):
        self.hypervisor.hypervisor_group_id = self.hypervisor_zone.id
        for host in VSPHERE_HYPERVISOR_HOSTS:
            hv = VSphereVM(host)
            power_state = hv.power_state()
            if power_state == 'poweredOff':
                test.log.warning(f"Virtual machine {host} in VSphere is down - starting it...")
                hv.on()
            elif power_state == 'poweredOn':
                test.log.warning(f"Virtual machine {host} in VSphere is up - rebooting it...")
                hv.reset()
            else:
                test.log.error(f"Virtual machine {host} in VSphere is in state {power_state.state} - it is not ok!")
                exit(AssertionError)
            power_state = hv.power_state()
            assert power_state == 'poweredOn', f"The VM {host} in VSphere is in state {power_state}"
        test.log.info(f"Let's give it {TIME_FOR_VSPHERE_VM_2START} seconds to get up...")
        time.sleep(TIME_FOR_VSPHERE_VM_2START)

        test.load_env()
        for asset in test.env.assets:
            self.hypervisor.label = request.node.name + '_' + asset.mac[-2:]
            test.env.clb_ips = CloudBootIpAddress().get_all_free()
            self.hypervisor.pxe_ip_address_id = test.env.clb_ips[0].id
            assert self.hypervisor.create(asset.mac), self.hypervisor.error
            self.hvs.append(self.hypervisor.id)
        test.log.info(f"Let's give it {TIME_FOR_VSPHERE_VM_2START} seconds to get up...")
        time.sleep(TIME_FOR_VSPHERE_VM_2START)

    def test_edit_cloudbooted_compute_resource(self):
        for hv_id in self.hvs:
            hv = CloudBooted(hv_id)
            test.log.warning(f"Let's deal with {hv.label}")
            # hv.get_devices()
            # disks = [i['hypervisor_disk_device']['id'] for i in hv.response if 'hypervisor_disk_device' in i]
            # nics = [i['hypervisor_network_interface_device']['id'] for i in hv.response if
            #         'hypervisor_network_interface_device' in i]
            # del nics[-1]  # assign only the 1st nic to IS, later the 2nd will be used for public vm, probably
            assert hv.pass_devices_to_storage(assign_all=True), f"Failed to edit HV {hvs[1].label}"
            hv.reboot()  # required if configuring by api

    def test_arrange_datastore(self, request):
        time_to_sleep = TIME_FOR_VSPHERE_VM_2START * 2
        test.log.info(f"Let's give it {time_to_sleep} seconds to get up and storage controllers to update...")
        time.sleep(time_to_sleep)
        self.ds = ISDataStore(self.hypervisor_zone)
        self.ds.nodes = self.hypervisor_zone.get_is_nodes()
        self.ds.name = request.node.name
        self.ds.replicas = 2
        self.ds.stripes = 2
        assert self.ds.create(), self.ds.error
        traditional_ds = DataStore().get_by_params(parameters={"identifier": self.ds.id})[0]
        assert self.datastore_zone.attach_ds(traditional_ds)
        assert DataStoreJoin(self.hypervisor_zone).add(traditional_ds)

    def test_arrange_two_networks(self):
        self.shared_network_1.network_group_id = self.network_zone.id
        self.shared_network_1.type = Network.NETWORK_TYPE.shared
        assert self.shared_network_1.create(), self.shared_network_1.error
        self.shared_network_2.network_group_id = self.network_zone.id
        self.shared_network_2.type = Network.NETWORK_TYPE.shared
        assert self.shared_network_2.create(), self.shared_network_2.error
        self.ipv4_net_1 = IpNetwork(self.shared_network_1)
        self.ipv4_net_1.label = f"IPNet_1_{TEST_NETWORK1}/{TEST_NETWORK1_MASK}"
        self.ipv4_net_1.network_address = TEST_NETWORK1
        self.ipv4_net_1.network_mask = TEST_NETWORK1_MASK
        self.ipv4_net_1.add_default_ip_range = 1
        assert self.ipv4_net_1.create(), self.ipv4_net_1.error
        self.ipv4_net_2 = IpNetwork(self.shared_network_2)
        self.ipv4_net_2.label = f"IPNet_2_{TEST_NETWORK1}/{TEST_NETWORK1_MASK}"
        self.ipv4_net_2.network_address = TEST_NETWORK2
        self.ipv4_net_2.network_mask = TEST_NETWORK2_MASK
        self.ipv4_net_2.add_default_ip_range = 1
        assert self.ipv4_net_2.create(), self.ipv4_net_2.error
        self.hvz_network_join_1 = NetworkJoin(self.hypervisor_zone)
        self.hvz_network_join_1.interface = 'dummy0'
        self.hvz_network_join_2 = NetworkJoin(self.hypervisor_zone)
        self.hvz_network_join_2.interface = 'dummy1'
        assert self.hvz_network_join_1.add(self.shared_network_1), self.hvz_network_join_1.error
        assert self.hvz_network_join_2.add(self.shared_network_2), self.hvz_network_join_2.error

    def test_arrange_some_templates(self):
        self.template_store.create()
        self.relation_group_template = RelationGroupTemplate(self.template_store)
        available_templates = sorted(Template().available(), key=lambda k: k.min_memory_size)
        t_to_install = [t for t in available_templates if t.virtualization == 'xen,kvm,kvm_virtio'][0]
        assert self.template.download(manager_id=t_to_install.manager_id), self.template.error
        t_to_install = self.template.get_by_manager_id(t_to_install.manager_id)
        self.template_store.relation_group_template.template_id = t_to_install.id
        assert self.template_store.relation_group_template.attach_template_to_group(), \
            self.template_store.relation_group_template.error

    def test_create_virtual_server(self, request):
        if test.cp_version > 5.5:
            add_all_resources_to_bucket(bucket=self.user_bucket)
        test.load_env()
        self.vs = VirtualServer()
        test.execute_as(self.user.login, self.user.password)
        self.vs.label = request.node.name + __maintainer__
        self.vs.required_virtual_machine_startup = 0
        assert self.vs.create(), self.vs.error

    def test_delete_virtual_server(self):
        assert self.vs.delete(), self.vs.error
