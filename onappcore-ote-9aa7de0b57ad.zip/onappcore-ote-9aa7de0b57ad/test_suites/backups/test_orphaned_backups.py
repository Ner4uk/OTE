
import pytest
from onapp_helper import test
from onapp_helper.bucket import access_controls as ac
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.billing_plan import BillingPlan
from onapp_helper.user import User
from onapp_helper.backup import Backup
from onapp_helper.server import VirtualServer


#################################### Marks #####################################
# Component
@pytest.mark.backups
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.sequentially
################################## End of marks ################################
# @pytest.mark.skipif(
#     test.cp_version < 5.8,
#     reason="The issue CORE-7960 has not fixed yet."
# )
@pytest.mark.verbose
class TestOrphanedBackups:
    __doc__ = """
    Test orphaned backups for changing VS owner and destroy VS owner:
    https://onappdev.atlassian.net/browse/CORE-7960 and 
    https://onappdev.atlassian.net/browse/SUPPORT-2369
    """

    def setup_class(self):
        test.load_env()
        try:
            if test.cp_version < 5.6:
                self.billing_plan1 = BillingPlan()
                self.billing_plan1.label = "{}_1".format(self.__name__)
                assert self.billing_plan1.create(), self.billing_plan1.error

                self.billing_plan2 = BillingPlan()
                self.billing_plan2.label = "{}_2".format(self.__name__)
                assert self.billing_plan2.create(), self.billing_plan2.error

                self.user1 = User(bp=self.billing_plan1)
                self.user2 = User(bp=self.billing_plan2)
            else:
                self.bucket1 = Bucket()
                self.bucket1.label = "{}_1".format(self.__name__)
                assert self.bucket1.create(), self.bucket1.error

                self.bucket2 = Bucket()
                self.bucket2.label = "{}_2".format(self.__name__)
                assert self.bucket2.create(), self.bucket2.error

                ac.add_env_to_bucket(self.bucket1)
                ac.add_env_to_bucket(self.bucket2)

                backup_ac = ac.BackupsAC(parent_obj=self.bucket1).get()
                backup_ac.limits.limit = 0
                backup_ac.edit()

                self.user1 = User(bucket=self.bucket1)
                self.user2 = User(bucket=self.bucket2)

            self.user1.login = "{}_1".format(self.__name__.lower())
            self.user1.password = test.generate_password()
            self.user1.email = "{}@ote.test".format(self.user1.login)
            assert self.user1.create(), self.user1.error

            self.user2.login = "{}_2".format(self.__name__.lower())
            self.user2.password = test.generate_password()
            self.user2.email = "{}@ote.test".format(self.user2.login)
            assert self.user2.create(), self.user2.error

            self.vs = VirtualServer()
            self.vs.label = self.__name__

            self.backup = Backup(parent_obj=self.vs)

            test.execute_as(self.user1.login, self.user1.password)

        except:
            self.teardown_class(self)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        attributes = (
            'vs',
            'user2',
            'user1',
            'bucket2',
            'bucket1',
            'billing_plan2',
            'billing_plan1'
        )
        test.clean_up_resources(attributes, self)

    def test_create_a_new_vs(self):
        assert self.vs.create(), self.vs.error
        assert self.vs.user_id == self.user1.id

    def test_create_a_new_backup(self):
        assert self.backup.create(), self.backup.error
        assert self.backup.user_id == self.user1.id

    def test_change_vs_owner_from_user1_to_user2_with_no_actions_for_backups(self):
        assert self.vs.change_owner(self.user2.id)
        assert self.vs.user_id == self.user2.id

    def test_wait_for_destroy_backup_transaction(self):
        assert self.backup.transaction_handler('destroy_backup')

    def test_backup_should_be_removed(self):
        assert not self.backup.get()

    def test_create_one_more_backup(self):
        assert self.backup.create(), self.backup.error
        assert self.backup.user_id == self.user2.id

    def test_change_vs_owner_from_user2_to_user1_with_move_action_for_backups(self):
        assert self.vs.change_owner(self.user1.id, backups_action='move')
        assert self.vs.user_id == self.user1.id

    def test_backup_owner_should_be_changed(self):
        assert self.backup.get(), self.backup.error
        assert self.backup.user_id == self.user1.id

    # https://onappdev.atlassian.net/browse/SUPPORT-2369
    # Steps to reproduce the issue:

    # 1. delete VM (without deleting its backup)
    # 2. delete user (the VM's owner)
    # 3. erase user
    # 4. delete the backup via UI - will fail with the error mentioned earlier
    # Result: the backup is still in the db and can't be deleted via UI
    def test_execute_tests_as_admin(self):
        test.execute_as(test.login, test.password)

    def test_delete_vs_without_deleting_its_backups(self):
        assert self.vs.delete(destroy_all_backups=False), self.vs.error

    def test_backups_exist_after_vs_was_deleted(self):
        assert self.user1.backups(), self.user1.error

    def test_customer_field_should_be_present(self):
        # https://onappdev.atlassian.net/browse/CORE-10243
        if test.cp_version < 6.0:
            pytest.skip("Supported since 6.0")
        backup = self.user1.backups()[-1]
        assert backup.user_id == self.user1.id
        assert backup.user_id is not None

    def test_delete_user_without_erasing(self):
        assert self.user1.backups(), self.user1.error
        assert self.user1.delete(force=False), self.user1.error

    def test_backups_should_be_deleted(self):
        assert self.backup.transaction_handler('destroy_backup')
        assert not self.user1.backups()

    def test_erase_user(self):
        assert self.user1.delete(force=False), self.user1.error
