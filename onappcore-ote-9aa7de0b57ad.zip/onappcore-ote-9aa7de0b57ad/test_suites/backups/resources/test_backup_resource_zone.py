
import pytest
from onapp_helper import test
from onapp_helper.backups import resource


#################################### Marks #####################################
# Component
@pytest.mark.backups
@pytest.mark.backup_resources
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.sequentially
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version < 5.8, reason=test.not_supported_msg(resource.ResourceZone)
)
@pytest.mark.verbose
class TestBackupResourceZone:
    def setup_class(self):
        self.backup_resource_zone = resource.ResourceZone(label=self.__name__)

    @pytest.mark.parametrize('label', [None, ''])
    def test_create_backup_resource_zone_with_incorrect_params(self, label):
        self.backup_resource_zone.label = label
        assert not self.backup_resource_zone.create()
        assert "can't be blank" in self.backup_resource_zone.error['label']

    def test_create_backup_resource_zone_with_correct_params(self):
        self.backup_resource_zone.label = self.__class__.__name__
        assert self.backup_resource_zone.create(), self.backup_resource_zone.error

    def test_backup_resource_zone_resource_exists_in_db(self):
        assert self.__class__.__name__ in test.cp.mysql_execute(
            f"SELECT label FROM backups_resource_zones "
            f"WHERE id={self.backup_resource_zone.id}"
        )

    def test_check_backup_resource_after_create(self):
        self.backup_resource_zone.get()
        assert self.backup_resource_zone.label == self.__class__.__name__

    def test_edit_backup_resource_zone(self):
        assert self.backup_resource_zone.edit(
            label=f"{self.__class__.__name__}New"
        ), self.backup_resource_zone.error

    def test_check_backup_resource_after_edit(self):
        self.backup_resource_zone.get()
        assert self.backup_resource_zone.label == f"{self.__class__.__name__}New"

    def test_delete_backup_resource_zone(self):
        assert self.backup_resource_zone.delete(), self.backup_resource_zone.error

    def test_you_can_not_get_backup_resource_zone_after_delete(self):
        assert not self.backup_resource_zone.get()
        assert 'Resource not found' in self.backup_resource_zone.error

    def test_backup_resource_zone_resource_does_not_exists_in_db(self):
        assert not test.cp.mysql_execute(
            f"SELECT * FROM backups_resource_zones "
            f"WHERE id={self.backup_resource_zone.id}"
        )