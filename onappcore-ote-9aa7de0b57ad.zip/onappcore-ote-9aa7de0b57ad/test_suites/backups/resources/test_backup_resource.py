
import pytest
from onapp_helper import test
from onapp_helper.backups import resource


#################################### Marks #####################################
# Component
@pytest.mark.backups
@pytest.mark.backup_resources
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.sequentially
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version < 5.8, reason=test.not_supported_msg(resource.Resource)
)
@pytest.mark.verbose
class TestBackupResource:
    def setup_class(self):
        self.backup_resource = resource.Resource()
        self.backup_resource_zone = resource.ResourceZone(label=self.__name__)
        self.backup_resource_zone.create()

        self.create_params = {
            'label': self.__name__,
            'enabled': True,
            'resource_zone_id': self.backup_resource_zone.id,
            'plugin': 'veeam',
            'primary_host': 'http://192.168.1.1',
            'secondary_host': 'http://192.168.1.1',
            'username': 'testBR',
            'password': 'testBPpass',
        }

        self.edit_params = {
            'label': f"{self.__name__}New",
            'enabled': False,
            'resource_zone_id': None,
            'plugin': 'veeam',
            'primary_host': 'http://192.168.1.23',
            'secondary_host': 'http://192.168.1.34',
            'username': 'testBRnew',
            'password': 'testBPpassNEW',
        }

    def teardown_class(self):
        [
            br.delete() for br in resource.Resource().get_all()
            if self.__name__ in br.label
        ]
        self.backup_resource.delete()
        self.backup_resource_zone.delete()

    @pytest.mark.parametrize("param,value,msg", [
        ('label', None, "can't be blank"),
        ('label', '', "can't be blank"),
        # ('label', -111, ''),

        ('resource_zone_id', 0, ''),  # error message return resource_zone ???
        ('resource_zone_id', -123, ''),
        ('resource_zone_id', 'resource_zone_id', ''),

        ('plugin', None, ''),
        ('plugin', 123, ''),
        ('plugin', '', ''),
        ('plugin', 'fqewfqrtrrt', ''),

        ('primary_host', None, "can't be blank"),
        ('primary_host', -123, 'is invalid URL'),
        ('primary_host', 0, 'is invalid URL'),
        ('primary_host', '', "can't be blank"),
        ('primary_host', '192.168.1.1', 'is invalid URL'),
        ('primary_host', 'http://192.168.1.1.242342', ''),
        ('primary_host', 'http://342.168.1.1', ''),

        # ('secondary_host', None, ''),  # can be blank
        ('secondary_host', -123, 'is invalid URL'),
        ('secondary_host', 0, 'is invalid URL'),
        # ('secondary_host', '', ''),  # can be blank
        ('secondary_host', '192.168.1.1', 'is invalid URL'),
        ('secondary_host', 'http://192.168.1.1.242342', ''),
        ('secondary_host', 'http://342.168.1.1', ''),

        ('username', None, "can't be blank"),
        ('username', 123, ''),
        ('username', '', "can't be blank"),

        ('password', None, "can't be blank"),
        ('password', 123, ''),
        ('password', '', "can't be blank"),
    ])
    def test_create_resource_with_wrong_params(self, param, value, msg):
        self.reset_resource_params(self.create_params)

        self.backup_resource.__dict__[param] = value
        assert not self.backup_resource.create()

        assert msg in self.backup_resource.error[param]

    def test_create_with_correct_params(self):
        self.reset_resource_params(self.create_params)

        assert self.backup_resource.create()

    def test_check_params_after_create(self):
        for key, value in self.create_params.items():
            assert self.backup_resource.__dict__[key] == value

    @pytest.mark.parametrize("param,value,msg", [
        ('label', None, "can't be blank"),
        ('label', '', "can't be blank"),
        # ('label', -111, ''),

        ('resource_zone_id', 0, ''),  # error message return resource_zone ???
        ('resource_zone_id', -123, ''),
        ('resource_zone_id', 'resource_zone_id', ''),

        ('plugin', None, ''),
        ('plugin', 123, ''),
        ('plugin', '', ''),
        ('plugin', 'fqewfqrtrrt', ''),

        ('primary_host', None, "can't be blank"),
        ('primary_host', -123, 'is invalid URL'),
        ('primary_host', 0, 'is invalid URL'),
        ('primary_host', '', "can't be blank"),
        ('primary_host', '192.168.1.1', 'is invalid URL'),
        ('primary_host', 'http://192.168.1.1.242342', ''),
        ('primary_host', 'http://342.168.1.1', ''),

        # ('secondary_host', None, ''),  # can be blank
        ('secondary_host', -123, 'is invalid URL'),
        ('secondary_host', 0, 'is invalid URL'),
        # ('secondary_host', '', ''),  # can be blank
        ('secondary_host', '192.168.1.1', 'is invalid URL'),
        ('secondary_host', 'http://192.168.1.1.242342', ''),
        ('secondary_host', 'http://342.168.1.1', ''),

        ('username', None, "can't be blank"),
        ('username', 123, ''),
        ('username', '', "can't be blank"),

        ('password', None, "can't be blank"),
        ('password', 123, ''),
        ('password', '', "can't be blank"),
    ])
    def test_edit_resource_with_wrong_params(self, param, value, msg):
        assert not self.backup_resource.edit(**{param: value})

        assert msg in self.backup_resource.error[param]

    def test_edit_with_correct_params(self):
        assert self.backup_resource.edit(**self.edit_params)

    def test_edit_params_after_create(self):
        for key, value in self.edit_params.items():
            assert self.backup_resource.__dict__[key] == value

    def reset_resource_params(self, params):
        self.backup_resource.__dict__.update(params)




