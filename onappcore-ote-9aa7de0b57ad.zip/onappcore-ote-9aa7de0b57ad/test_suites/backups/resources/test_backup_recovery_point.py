# ignore
import pytest
from onapp_helper import test
from onapp_helper.backups import resource
from onapp_helper.server import VirtualServer


@pytest.fixture(scope='class', autouse=True)
def vs(request):
    # test.use_backup_plugin = True  # may be for future should be implemented...
    test.load_env()
    test.jira.connect()

    s = VirtualServer()
    s.label = request.cls.__name__
    s.rate_limit = None
    if not s.create():
        pytest.skip(s.error)

    def fin():
        if s.locked:
            s.unlock()
        s.delete()

    request.addfinalizer(fin)
    return s


@pytest.fixture(scope='class', autouse=True)
def backup_resource(request, vs):
    br = resource.Resource().get_all()[0]
    br.add_to_server(vs)

    def fin():
        br.remove_from_server(vs)

    request.addfinalizer(fin)
    return br


@pytest.fixture(scope='class', autouse=True)
def recovery_point(request, vs):
    return resource.RecoveryPoint(vs)


#################################### Marks #####################################
# Component
@pytest.mark.backups
@pytest.mark.backup_resources
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.sequentially
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version < 5.7, reason=test.not_supported_msg(resource.Resource)
)
class TestBackupRecoveryPoint:

    def test_create_recovery_point(self, recovery_point, backup_resource):
        assert recovery_point.create(backup_resource.id), recovery_point.error

        # https://onappdev.atlassian.net/browse/CORE-12334
        if not test.jira.issue_is_closed('CORE-12334'):
            recovery_point = recovery_point.get_all()[0]

        assert test.wait_for_action(
            lambda : recovery_point.sync()
                     and recovery_point.get_all()[0].state == 'available',
            timeout=300, step=20
        )

    def test_get_all_recovery_points(self, recovery_point):
        assert len(
            [rp.id for rp in recovery_point.get_all()]
        ) == 1

    def test_restore_recovery_point(self, recovery_point):
        assert recovery_point.get_all()[0].restore()

        recovery_point.sync()

    # # Not supported
    # def test_delete_recovery_point(self, recovery_point: resource.RecoveryPoint):
    #     assert recovery_point.get_all()[0].delete()
    #
    #     recovery_point.sync()
    #
    #     assert len(
    #         [rp.id for rp in recovery_point.get_all()]
    #     ) == 0
