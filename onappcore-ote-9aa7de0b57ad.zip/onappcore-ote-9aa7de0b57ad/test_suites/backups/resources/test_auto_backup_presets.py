
import pytest
from onapp_helper import test
from onapp_helper.backups import resource

params = {
    'hourly': {
        'create': {
            'max_recovery_points': 4,
            'enabled': True,
            'period': resource.HOURLY
        },
        'edit': {
            'max_recovery_points': 2,
            'enabled': False,
            'period': resource.HOURLY
        }
    },
    'daily': {
        'create': {
            'frequency': 2,
            'max_recovery_points': 12,
            'enabled': True,
            'period': resource.DAILY,
            'start_time': test.get_time_str(shift=90, utc=True)
        },
        'edit': {
            'frequency': 12,
            'max_recovery_points': 2,
            'enabled': False,
            'period': resource.DAILY,
            'start_time': test.get_time_str(shift=190, utc=True)
        },
    },
    'weekly': {
        'create': {
            'days_to_run_on': [1, 2],
            'max_recovery_points': 1,
            'enabled': True,
            'period': resource.WEEKLY,
            'start_time': test.get_time_str(shift=90, utc=True)
        },
        'edit': {
            'days_to_run_on': [5, 6],
            'max_recovery_points': 3,
            'enabled': False,
            'period': resource.WEEKLY,
            'start_time': test.get_time_str(shift=190, utc=True)
        },
    },
    'monthly': {
        'create': {
            'day_to_run_on': 12,
            'week_to_run_on': 3,
            'max_recovery_points': 3,
            'enabled': True,
            'period': resource.MONTHLY,
            'start_time': test.get_time_str(shift=90, utc=True)
        },
        'edit': {
            'day_to_run_on': 2,
            'week_to_run_on': 1,
            'max_recovery_points': 8,
            'enabled': False,
            'period': resource.MONTHLY,
            'start_time': test.get_time_str(shift=190, utc=True)
        }
    },
    'yearly': {
        'create': {
            'max_recovery_points': 4,
            'enabled': True,
            'period': resource.YEARLY
        },
        'edit': {
            'max_recovery_points': 7,
            'enabled': False,
            'period': resource.YEARLY
        }
    }
}


@pytest.fixture(
    scope="class",
    params=[
        params['hourly'],
        params['daily'],
        params['weekly'],
        params['monthly'],
        params['yearly']
    ]
)
def params(request):
    return request.param


#################################### Marks #####################################
# Component
@pytest.mark.backups
@pytest.mark.backup_resources
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.sequentially
################################## End of marks ################################
@pytest.mark.verbose
class TestAutoBackupPresets:
    __doc__ = """
      In this test we check just presets functionality without Virtual Server
    """

    def setup_class(self):
        self.resource = resource.Resource(
            label=self.__name__,
            enabled=True,
            plugin='veeam',
            primary_host='http://192.168.1.1',
            secondary_host='http://192.168.1.2',
            username=self.__name__.lower(),
            password=test.generate_password()
        )
        assert self.resource.create(), self.resource.delete()

        self.preset = resource.Preset(self.resource)

    def teardown_class(self):
        self.resource.delete()

    def test_create_auto_backup_preset(self, params):
        assert self.preset.create(**params['create']), self.preset.error

    def test_check_auto_backup_preset_after_create(self, params):
        assert self.preset.get()
        for key, value in params['create'].items():
            assert self.preset.__dict__[key] == value

    def test_edit_auto_backup_present(self, params):
        assert self.preset.edit(**params['edit']), self.preset.error

    def test_check_auto_backup_present_after_edit(self, params):
        assert self.preset.get()
        for key, value in params['edit'].items():
            assert self.preset.__dict__[key] == value

    def test_delete_auto_backup_present(self, params):
        assert self.preset.delete(), self.preset.error