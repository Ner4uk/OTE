# daily

__author__ = 'zhuk'

import time
import pytest

from onapp_helper import test
from onapp_helper.bucket import access_controls as ac

from test_helper import backupTH
# TODO - extend test from SF backups tests

CMD = 'fdisk /dev/onapp' if test.cp_version < 6.0 else 'mkfs'


@pytest.fixture(scope='module')
def load_env():
    test.load_env()

    if not test.env.hvz.id:
        pytest.skip("No available HVZ.")
    if not test.env.dsz.id:
        pytest.skip("No available DSZ.")
    if not test.env.netz.id:
        pytest.skip("No available NetZ.")
    if not test.env.backup_servers:
        pytest.skip("No available Backup Servers")

    # Configure incremental backups options
    options = [
        'allow_incremental_backups', 'rsync_option_acls', 'rsync_option_xattrs'
    ]

    options_dict = {
        option: True for option in options
        if not test.onapp_settings.__dict__[option]
    }

    if options_dict:
        test.log.info(f"Set {options_dict.keys()} as True")
        assert test.onapp_settings.set(**options_dict)


#################################### Marks #####################################
# Component
@pytest.mark.backups
@pytest.mark.incremental_backups
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.sequentially
################################## End of marks ################################
@pytest.mark.verbose
@pytest.mark.parametrize(
    'backup_target_execution',
    [
        'HV',
        'BS'
    ],
    scope='class'
)
class TestIncrementalBackup:
    def test_tune_fstab(self, backup_target_execution, vs, additional_disk):
        """Add to fstab acls options"""
        fstab = vs.execute('cat  /etc/fstab').split('\n')

        # fstab output contain 'Warning'
        # # Device		Mountpoint	FStype	Options		Dump	Pass#
        # /dev/vtbd1		none		swap	sw		0	0
        # /dev/vtbd0s1a		/		ufs	rw		1	1
        # Warning: Permanently added '10.84.37.38' (RSA) to the list of known hosts.

        vs.execute('echo "" > /etc/fstab')
        for line in fstab:
            if 'Warning' not in line:  # Do not write 'Warning'
                if not line.startswith('#'):
                    line = line.replace(' rw ', ' rw,acls ')
                    line = line.replace('\trw\t', '\trw,acls\t')
                vs.execute(f'echo "{line}" >> /etc/fstab')

        vs.execute('cat /etc/fstab')
        vs.execute('mount')
        vs.execute(f'umount {additional_disk.mount_point}')
        vs.execute('mount -a')
        vs.execute('mount')

    def test_configure_bucket(self, backup_target_execution, vs, bucket):
        # Remove all to set selected above
        for bs in test.env.backup_servers:
            ac.BackupServerZoneAC(
                parent_obj=bucket,
                target_id=bs.backup_server_group_id
            ).delete()

        if backup_target_execution == 'BS':
            bsz_ac = ac.BackupServerZoneAC(
                parent_obj=bucket,
                target_id=test.env.backup_servers[-1].backup_server_group_id
            )
            assert bsz_ac.create(), bsz_ac.error

            backup_ac = ac.BackupsAC(parent_obj=bucket)
            backup_ac.get()
            backup_ac.limits.limit = 0
            assert backup_ac.edit(), backup_ac.error

    def test_edit_grub_config_file(self, backup_target_execution, vs):
        if vs.template.operating_system == 'freebsd':
            pytest.skip('Grub cfg is not supported by FreeBSD')
        else:
            backupTH.edit_grub_config(vs)
            assert backupTH.check_grub_config(vs)

    @pytest.mark.skipif(test.cp_version < 6.1, reason='Not fixed')
    def test_create_backup_without_options(
            self, backup_target_execution, backup_with_optional_params
    ):
        assert backup_with_optional_params.create(), \
            backup_with_optional_params.error

    def test_create_backup_with_options(
            self, backup_target_execution, backup_with_optional_params
    ):
        assert backup_with_optional_params.create(note='test_note'), \
            backup_with_optional_params.error
        assert backup_with_optional_params.note == 'test_note'

    def test_create_some_file_on_disk(
            self, backup_target_execution, vs, files
    ):
        for file in files:
            backupTH.create_file(vs, file)
            assert backupTH.file_exist(vs, file)

    @pytest.mark.skipif(
        test.cp_version < 6.0,
        reason='https://onappdev.atlassian.net/browse/CORE-12272'
    )
    def test_change_file_acl(self, backup_target_execution, vs, files):
        for file in files:
            backupTH.set_facl(vs, file)
            assert backupTH.check_facl(vs, file)

    @pytest.mark.skipif(
        test.cp_version < 6.0,
        reason='https://onappdev.atlassian.net/browse/CORE-12272'
    )
    def test_change_file_xattr(self, backup_target_execution, vs, files):
        for file in files:
            backupTH.set_xattr(vs, file)
            assert backupTH.check_xattr(vs, file)

    def test_create_backup(self, backup_target_execution, backup_zero):
        time.sleep(180)  # to be sure that files are present on disks (sync)
        assert backup_zero.create(), backup_zero.error

    def test_create_one_more_backup(self, backup_target_execution, backup):
        time.sleep(180)
        assert backup.create(), backup.error
        assert backup.backup_size < 300000

    def test_backup_type_should_be_incremental(
            self, backup_target_execution, backup
    ):
        assert backup.backup_type == 'incremental'

    def test_backup_location(self, backup_target_execution, backup):
        if backup_target_execution == 'BS':
            assert backup.backup_server_id
        elif backup_target_execution == 'HV':
            assert not backup.backup_server_id
        else:
            assert False, 'Undefined backup target'

    def test_delete_file_from_disk(
            self, backup_target_execution, vs, files
    ):
        for file in files:
            backupTH.delete_file(vs, file)
            assert not backupTH.file_exist(vs, file)

    def test_restore_backup(self, backup_target_execution, backup):
        assert backup.restore(), backup.error

        if backup.backup_type == backup.TYPE.normal:
            action = 'restore_backup'
        elif backup.backup_type == backup.TYPE.incremental:
            action = 'restore_incremental_backup'
        backup.transaction_handler(action=action)

        assert CMD not in backup.transaction.log_output

    def test_that_file_is_present_on_disk(
            self, backup_target_execution, vs, files
    ):
        for file in files:
            assert backupTH.file_exist(vs, file)

    @pytest.mark.skipif(
        test.cp_version < 6.0,
        reason='https://onappdev.atlassian.net/browse/CORE-12272'
    )
    def test_check_file_attributes_after_restoring_backup(
            self, backup_target_execution, vs, files
    ):
        for file in files:
            assert backupTH.check_facl(vs, file)

    @pytest.mark.skipif(
        test.cp_version < 6.0,
        reason='https://onappdev.atlassian.net/browse/CORE-12272'
    )
    def test_check_file_xattributes_after_restoring_backup(
            self, backup_target_execution, vs, files
    ):
        for file in files:
            assert backupTH.check_xattr(vs, file)

    def test_convert_to_template(
            self, backup_target_execution, backup, custom_template
    ):
        assert backup.convert(label=self.__class__.__name__), \
            backup.template.error
        custom_template.__dict__.update(backup.template.__dict__)
        assert custom_template.label == self.__class__.__name__

    def test_rebuild_from_custom_template(
            self,
            backup_target_execution,
            vs,
            template,
            custom_template,
            files
    ):
        # Delete file (if possible)
        for file in files:
            backupTH.delete_file(vs, file)
            assert not backupTH.file_exist(vs, file)

        # Rebuild from template
        if template.id:
            vs.template = custom_template
            assert vs.rebuild(), vs.error
        else:
            raise SystemError('The custom template has not been created.')

    def test_check_grub_config_file_for_custom_template(
            self, backup_target_execution, vs
    ):
        """
        grub file should not be rewritten to default for vs built from custom
        template
        """
        if vs.template.operating_system == 'freebsd':
            pytest.skip('Grub cfg is not supported by free bsd')
        else:
            assert backupTH.check_grub_config(vs)

    def test_check_if_file_is_present_on_custom_template(
            self,
            backup_target_execution,
            vs,
            additional_disk,
            files
    ):
        vs.execute(f'umount {additional_disk.mount_point}')
        for file in files:
            assert backupTH.file_exist(vs, file)

    @pytest.mark.skipif(
        test.cp_version < 6.0,
        reason='https://onappdev.atlassian.net/browse/CORE-12272'
    )
    def test_check_file_attributes_after_rebuilding_from_custom_template(
            self, backup_target_execution, vs, files
    ):
        for file in files:
            assert backupTH.check_facl(vs, file)

    @pytest.mark.skipif(
        test.cp_version < 6.0,
        reason='https://onappdev.atlassian.net/browse/CORE-12272'
    )
    def test_check_file_xattributes_after_rebuilding_from_custom_template(
            self, backup_target_execution, vs, files
    ):
        for file in files:
            assert backupTH.check_xattr(vs, file)

    # Check restore backup with force option ###################################
    @pytest.mark.skipif(
        test.cp_version < 5.9,
        reason="https://onappdev.atlassian.net/browse/CORE-12149"
    )
    def test_delete_file_before_restoring_with_force_option(
            self, backup_target_execution, vs, files
    ):
        for file in files:
            backupTH.delete_file(vs, file)
            assert not backupTH.file_exist(vs, file)

    @pytest.mark.skipif(
        test.cp_version < 5.9,
        reason="https://onappdev.atlassian.net/browse/CORE-12149"
    )
    def test_restore_backup_with_force_option(
            self, backup_target_execution, backup, template
    ):
        if template.operating_system == 'freebsd':
            # https://onappdev.atlassian.net/browse/CORE-13361
            assert not backup.restore(force_restore=True)
            assert 'You cannot force restore a FreeBSD virtual server ' \
                   'from an incremental backup' in backup.error['base']
        else:
            assert backup.restore(force_restore=True), backup.error
            backup.transaction_handler(action='restore_incremental_backup')

            # Check that required option is present!!!
            # should be 2 fdisk commands for primary and additional disk
            assert backup.transaction.log_output.count(CMD) == 2

    @pytest.mark.skipif(
        test.cp_version < 5.9,
        reason="https://onappdev.atlassian.net/browse/CORE-12149"
    )
    def test_that_file_is_present_on_disk_for_restored_backup_with_force_option(
            self,
            backup_target_execution,
            vs,
            files,
            template
    ):
        if template.operating_system == 'freebsd':
            pytest.skip(
                'It does not work for FreeBSD templates'
                ' (https://onappdev.atlassian.net/browse/CORE-13361)'
            )

        for file in files:
            assert backupTH.file_exist(vs, file)

    @pytest.mark.skipif(
        test.cp_version < 6.0,
        reason='https://onappdev.atlassian.net/browse/CORE-12272'
    )
    def test_check_file_attributes_after_restore_backup_with_force_option(
            self, backup_target_execution, vs, files, template
    ):
        if template.operating_system == 'freebsd':
            pytest.skip(
                'It does not work for FreeBSD templates'
                ' (https://onappdev.atlassian.net/browse/CORE-13361)'
            )

        for file in files:
            assert backupTH.check_facl(vs, file)

    @pytest.mark.skipif(
        test.cp_version < 6.0,
        reason='https://onappdev.atlassian.net/browse/CORE-12272'
    )
    def test_check_file_xattributes_after_restore_backup_with_force_option(
            self, backup_target_execution, vs, files, template
    ):
        if template.operating_system == 'freebsd':
            pytest.skip(
                'It does not work for FreeBSD templates'
                ' (https://onappdev.atlassian.net/browse/CORE-13361)'
            )

        for file in files:
            assert backupTH.check_xattr(vs, file)

    @pytest.mark.skipif(
        test.cp_version < 5.9,
        reason="https://onappdev.atlassian.net/browse/CORE-12149"
    )
    def test_convert_restored_backup_with_force_option_to_template(
            self,
            backup_target_execution,
            backup,
            custom_template_with_force_option,
            template
    ):
        if template.operating_system == 'freebsd':
            pytest.skip(
                'It does not work for FreeBSD templates'
                ' (https://onappdev.atlassian.net/browse/CORE-13361)'
            )

        template_label = f"{self.__class__.__name__}2"

        assert backup.convert(label=template_label), backup.template.error
        custom_template_with_force_option.__dict__.update(
            backup.template.__dict__
        )
        assert custom_template_with_force_option.label == template_label

    @pytest.mark.skipif(
        test.cp_version < 5.9,
        reason="https://onappdev.atlassian.net/browse/CORE-12149"
    )
    def test_rebuild_from_custom_template_converted_from_backup_with_force_option(
            self,
            backup_target_execution,
            vs,
            files,
            custom_template_with_force_option,
            template
    ):
        if template.operating_system == 'freebsd':
            pytest.skip(
                'It does not work for FreeBSD templates'
                ' (https://onappdev.atlassian.net/browse/CORE-13361)'
            )

        # Delete file (if possible)
        for file in files:
            backupTH.delete_file(vs, file)
            assert not backupTH.file_exist(vs, file)

        # Rebuild from template
        if custom_template_with_force_option.id:
            vs.template = custom_template_with_force_option
            assert vs.rebuild(), vs.error
        else:
            raise SystemError('The custom template has not been created.')

    @pytest.mark.skipif(
        test.cp_version < 5.9,
        reason="https://onappdev.atlassian.net/browse/CORE-12149"
    )
    def test_file_should_be_after_rebuilding_from_custom_template_with_force_option(
            self, backup_target_execution, vs, files, additional_disk, template
    ):
        if template.operating_system == 'freebsd':
            pytest.skip(
                'It does not work for FreeBSD templates'
                ' (https://onappdev.atlassian.net/browse/CORE-13361)'
            )

        vs.execute(f'umount {additional_disk.mount_point}')
        for file in files:
            assert backupTH.file_exist(vs, file)

    @pytest.mark.skipif(
        test.cp_version < 6.0,
        reason='https://onappdev.atlassian.net/browse/CORE-12272'
    )
    def test_check_file_attributes_after_rebuilding_from_custom_template_with_force_option(
            self,
            backup_target_execution,
            vs,
            files,
            template
    ):
        if template.operating_system == 'freebsd':
            pytest.skip(
                'It does not work for FreeBSD templates'
                ' (https://onappdev.atlassian.net/browse/CORE-13361)'
            )

        for file in files:
            assert backupTH.check_facl(vs, file)

    @pytest.mark.skipif(
        test.cp_version < 6.0,
        reason='https://onappdev.atlassian.net/browse/CORE-12272'
    )
    def test_check_file_xattributes_after_rebuilding_from_custom_template_with_force_option(
            self,
            backup_target_execution,
            vs,
            files,
            template
    ):
        if template.operating_system == 'freebsd':
            pytest.skip(
                'It does not work for FreeBSD templates'
                ' (https://onappdev.atlassian.net/browse/CORE-13361)'
            )

        for file in files:
            assert backupTH.check_xattr(vs, file)

    ############################################################################

    def test_delete_backup(self, backup_target_execution, backup):
        assert backup.delete(), backup.error

    def test_rebuild_server_with_system_template(
            self,
            backup_target_execution,
            vs,
            template
    ):
        vs.template = template
        assert vs.rebuild(), vs.error

    def test_delete_custom_template(
            self,
            backup_target_execution,
            custom_template
    ):
        assert custom_template.delete(), custom_template.error

    def test_delete_custom_template_with_force_option(
            self,
            backup_target_execution,
            custom_template_with_force_option,
            template
    ):
        if template.operating_system == 'freebsd':
            pytest.skip(
                'It does not work for FreeBSD templates'
                ' (https://onappdev.atlassian.net/browse/CORE-13361)'
            )

        assert custom_template_with_force_option.delete(), \
            custom_template_with_force_option.error
