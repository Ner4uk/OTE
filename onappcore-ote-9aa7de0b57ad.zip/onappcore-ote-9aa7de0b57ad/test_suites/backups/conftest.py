import os
import pytest

from onapp_helper import test

from onapp_helper.backup import Backup
from onapp_helper.bucket import access_controls as ac
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.disk import Disk
from onapp_helper.server import VirtualServer
from onapp_helper.template import Template
# TODO - extend test from SF backups tests
from onapp_helper.user import User
from onapp_helper.template_store import TemplateStore, RelationGroupTemplate

from test_helper import backupTH


@pytest.fixture(scope='module')
def bucket(request, load_env):
    b = Bucket()
    b.label = request.module.__name__
    assert b.create(), b.error
    ac.add_env_to_bucket(b)

    def fin():
        if b.get():
            b.delete()
    request.addfinalizer(fin)

    return b


@pytest.fixture(scope='module')
def user(request, bucket):
    u = User(bucket=bucket)
    u.login = request.module.__name__
    u.password = test.generate_password()
    u.email = f'{u.login}@ote.test'
    assert u.create(), u.error
    test.execute_as(u.login, u.password)

    def fin():
        test.execute_as(test.login, test.password)
        if u.get():
            u.delete()
    request.addfinalizer(fin)

    return u


@pytest.fixture(scope='module')
def vs(request, user, template):
    vs = VirtualServer()
    vs.label = request.module.__name__
    vs.template = template
    vs.disks_attributes = [
        {
            'disk_size': vs.template.min_disk_size,
            'data_store_id': test.env.ds.id,
            'primary': True,
            'is_swap': False,
            'min_iops': 1
        },
        {
            'disk_size': 1,
            'data_store_id': test.env.ds.id,
            'primary': False,
            'is_swap': True,
            'min_iops': 1
        }
    ]
    assert vs.create(), vs.error
    vs.get_grub_config_file_path()

    def fin():
        if vs.get():
            if vs.locked:
                vs.unlock()
            vs.delete()

    request.addfinalizer(fin)

    return vs


@pytest.fixture(scope='class')
def backup(request, vs):
    b = Backup(parent_obj=vs)

    def fin():
        b.delete()

    request.addfinalizer(fin)
    return b


@pytest.fixture(scope='class')
def backup_zero(request, vs):
    """Used for incremental backups as first backup (not for restore and
    converting)"""
    b = Backup(parent_obj=vs)

    def fin():
        b.delete()

    request.addfinalizer(fin)
    return b


@pytest.fixture(scope='class')
def additional_disk_backup(request, vs):
    """For normal backup"""
    b = Backup(parent_obj=vs)

    def fin():
        b.delete()

    request.addfinalizer(fin)
    return b


@pytest.fixture(scope='class')
def backups(request, backup, additional_disk_backup):
    """For normal backup"""
    return [backup, additional_disk_backup]


@pytest.fixture()
def backup_with_optional_params(request, vs):
    b = Backup(parent_obj=vs)

    def fin():
        b.delete()

    request.addfinalizer(fin)
    return b


@pytest.fixture(
    scope='module',
)
def template_store():
    return [ts for ts in TemplateStore().get_all() if ts.label == 'OTE'][0]


@pytest.fixture(
    scope='module',
)
def relation_group_template(template_store):
    return RelationGroupTemplate(template_store)


@pytest.fixture(
    scope='module',
    params=[
        'CentOS 7.4 x64',
        'Ubuntu 17.04',
        'FreeBSD 10.0 x64',  # 'FreeBSD 11.1 x64',
    ]
)
def template(request, relation_group_template):
    """
    The other templates have different mount options, actually works for 'rw'
    """
    installed = Template().installed(query=request.param)
    if installed:
        t = installed[0]
    else:
        available = [
            t for t in Template().available(query=request.param)
            if 'xen' in t.virtualization and 'kvm' in t.virtualization
        ]
        if available:
            t = available[0]
            assert t.download(), t.error

    relation_group_template.attach_template_to_group(t.id)
    return t


@pytest.fixture(scope='class')
def custom_template(vs):
    return Template()


@pytest.fixture(scope='class')
def custom_template_with_force_option(vs):
    return Template()


@pytest.fixture(scope='module')
def additional_disk(request, vs):
    disk = Disk(parent_obj=vs)
    disk.label = request.module.__name__
    disk.disk_size = 1
    disk.mount_point = '/mnt/additional_disk'
    disk.file_system = 'ext4'
    disk.require_format_disk = True
    disk.mounted = True
    disk.data_store_id = test.env.ds.id
    assert disk.create(), disk.error

    return disk


@pytest.fixture(scope='module')
def files(vs, additional_disk):
    return [
        os.path.join(vs.working_path, backupTH.TEST_FILE_NAME),
        os.path.join(additional_disk.mount_point, backupTH.TEST_FILE_NAME)
    ]
