# daily

__author__ = 'zhuk'

from onapp_helper.backup import Backup
from onapp_helper import test
from onapp_helper.server import VirtualServer
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.backups
@pytest.mark.auto_backups
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.sequentially
################################## End of marks ################################
@pytest.mark.incremental
class TestServerAutoBackup:
    def setup_class(self):
        test.load_env()

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        try:
            if not test.onapp_settings.get().allow_incremental_backups:
                test.log.info("Set 'allow_incremental_backups' as True")
                assert test.onapp_settings.set(allow_incremental_backups=True)

            self.vs = VirtualServer()
            self.vs.label = self.__name__
            assert self.vs.create(), self.vs.error
            self.b = Backup(self.vs)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        attributes = (
            'vs',
        )
        test.clean_up_resources(attributes, self)

    def test_turn_on_auto_backups(self):
        assert self.vs.enable_auto_backups(), self.vs.error

    def test_count_of_schedules_should_be_4(self):
        assert len(self.vs.schedule.get_all()) == 4

    def test_count_of_auto_backups_should_be_4(self):
        backups = self.vs.get_incremental_backups()
        assert len(
            [b for b in backups if b.built and b.initiated != 'manual']
        ) == 4
