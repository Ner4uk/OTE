#! /usr/bin/env python

__author__ = 'zhuk'

from onapp_helper.server import BaremetalServer
from onapp_helper.recipe.recipe import Recipe, RecipeStep
from onapp_helper.recipe.custom_recipe_variables import CustomRecipeVariable
from onapp_helper import test
import pytest

# test.cp.ssh.port = 2222


# @pytest.mark.skipif(
#     not test.env.hv.id or
#     not (
#             test.env.hv.ip_address == '192.168.1.41' and
#             test.env.hv.host == 'hv000c296570d3'
#     ),
#     reason="No available HV."
# )

@pytest.mark.verbose
@pytest.mark.baremetal
#@pytest.mark.incremental
class TestBaremetal():
    def setup_class(self):
        test.server_types = ['baremetal']
        test.use_cloud_boot_hv = True
        test.load_env()

        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        try:
            self.bs = BaremetalServer()

            self.custom_recipe_variable = CustomRecipeVariable()
            self.custom_recipe_variable.name = 'OTE'
            self.custom_recipe_variable.value = '90'
            self.custom_recipe_variable.enabled = True

            # Create a Recipe on add action
            self.recipe = Recipe()
            self.recipe.label = self.__name__
            self.recipe.compatible_with = Recipe.COMPATIBLE_WITH.unix
            assert self.recipe.create(), self.recipe.error

            # Add recipe step
            self.recipe_step = RecipeStep(self.recipe)
            self.recipe_step.script = 'echo $OTE >> /tmp/recipe_test'
            self.recipe_step.on_success = RecipeStep.ON_SUCCESS.proceed
            self.recipe_step.on_failure = RecipeStep.ON_FAILURE.fail
            self.recipe_step.result_source = RecipeStep.RESULT_SOURCE.exit_code
            assert self.recipe_step.create(), self.recipe_step.error

            self.bs.recipe_joins_attributes.append(self.recipe.id)
            self.bs.custom_recipe_variables = self.custom_recipe_variable.get_as_dict()

        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        if hasattr(self, 'role') and self.role.control_panel_recipe_manage:
            self.role.permission_ids.remove(
                self.permissions.control_panel_recipe_manage.id
            )
            assert self.role.edit(), self.role.error
        attributes = (
            'bs',
            'recipe'
        )
        test.clean_up_resources(attributes, self)

    def test_create_baremetal_server_with_specified_domain(self):
        DOMAIN = 'tesT24.za-7-z.a.ua'
        # Create VirtualServer
        self.bs.domain = DOMAIN
        assert self.bs.create(), self.bs.error
        assert DOMAIN in self.bs.execute('cat /etc/resolv.conf')

    # def test_check_control_panel_recipe_join_execution(self):
    #     assert self.bs.transaction_handler(
    #         "run_recipe_on_vm", parent_id=self.bs.id
    #     ), self.bs.error

    # def test_check_if_recipe_has_been_executed(self):
    #     assert '90' in self.bs.execute('cat /tmp/recipe_test')

    def test_enable_recovery_mode(self):
        assert self.bs.enable_recovery(), self.bs.error

    def test_disable_recovery_mode(self):
        assert self.bs.disable_recovery(), self.bs.error
