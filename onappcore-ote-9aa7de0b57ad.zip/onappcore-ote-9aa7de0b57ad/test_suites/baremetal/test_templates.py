#! /usr/bin/env python

__author__ = 'zhuk'

from onapp_helper.bucket import access_controls as ac
from onapp_helper.server import BaremetalServer
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.template import Template
from onapp_helper.template_store import TemplateStore
from onapp_helper.user import User
from onapp_helper import test
import os
import time
import pytest


@pytest.mark.incremental
@pytest.mark.baremetal
class TestTemplatesForProvisionBaremetal:
    def setup_class(self):
        test.server_types = ['baremetal']
        test.load_env(use_cloud_boot_hv=True)
        test.cp.ssh.port = 2222

        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        self.bms = BaremetalServer()
        self.available_templates = Template().available()
        self.installed_templates = Template().installed()
        self.manager_ids_for_updates = [
            template.manager_id for template in Template().upgrades()
            ]
        self.all_templates = self.available_templates + self.installed_templates
        self.template_store = TemplateStore()
        self.template_store.label = 'TemplatesForProvisionBaremetal'
        if not self.template_store.get_by_label(self.template_store.label):
            self.template_store.create()

        self.file_name = os.path.join(
            test.wd, "doc/{}".format(
                'templates_for_provision_baremetal_server.csv'
            )
        )
        if not os.path.exists(self.file_name):
            with open(self.file_name, 'w'):
                pass

    def teardown_class(self):
        self.template_store.delete()
        pass
        # if self.bs.get():
        #     self.bs.destroy()
        # test.cp.ssh.execute(command='reboot', tunnel_host=test.env.hv.ip_address)

    def test_templates_for_provision_baremetal(self):
        with open(self.file_name) as pbs:
            checked_templates = pbs.read()

        templates_for_testing = [
            template for template in self.all_templates
            if template.baremetal_server and
            template.manager_id not in checked_templates and
            template.operating_system != "windows"
            ]

        # Get a list of templates to check
        total_count = len(templates_for_testing)
        for template in templates_for_testing:
            template.should_be_deleted = False
            if not template.state:
                if template.download(template.manager_id):
                    template.should_be_deleted = True
            if template.manager_id in self.manager_ids_for_updates:
                template.upgrade()
            # Add template to template store
            self.template_store.relation_group_template.attach_template_to_group(
                template_id=template.id
            )
            if not template.should_be_deleted:
                time.sleep(120)  # EnsureComputeResourceOffline/Online
            # Attach template store to an access control
            user = User().search(test.login)[0]
            bucket = Bucket(id=user.bucket_id)
            ac.TemplateGroupsAC(
                parent_obj=bucket, target_id=self.template_store.id, server_type=ac.SERVER_TYPE.other
            ).create()
            # Run main test
            self.provision_baremetal(template)
            # Delete template from template store
            self.template_store.relation_group_template.detach_template_from_group()
            if template.should_be_deleted:
                # Delete template
                template.delete()
                test.cp.ssh.execute(
                    'rm -rfv /onapp/backups/templates/{}'.format(
                        template.file_name
                    )
                )
                test.cp.ssh.execute(
                    'rm -rfv /onapp/templates/{}'.format(template.file_name)
                )
            total_count -= 1
            test.log.info("{} template(s) left...".format(total_count))

    def provision_baremetal(self, template):
        """
        manager_id;version;provision;connection

        :param template:
        :return:
        """
        if self._hv_online():
            fields = []
            self.bms.label = self.__class__.__name__
            self.bms.template = template
            fields.append(self.bms.template.manager_id)
            fields.append(self.bms.template.version)
            if self.bms.create():
                fields.append('provisioned')
                if self.bms.template.operating_system == "windows":
                    exit()
                    if self.bms.execute():
                        fields.append('connected\n')
                else:  # linux
                    if self.bms.execute('cat /etc/issue'):
                        fields.append('connected\n')
                    else:
                        fields.append('no connection\n')
            else:
                fields.append('provision failed\n')
                provision_file_name = os.path.join(
                    test.wd, "doc/{}".format(
                        '_'.join(
                            [
                                self.bms.template.manager_id,
                                self.bms.template.version
                            ]
                        )
                    )
                )
                with open(provision_file_name, 'w') as pfn:
                    pfn.write(self.bms.transaction.log_output)
            self.bms.delete()

            with open(self.file_name, 'a') as pbs:
                pbs.write(';'.join(fields))
            return True

        else:
            raise TimeoutError('Hypervisor is offline...')

    def _hv_online(self):
        attempts = 30  # 5 minutes
        test.update_object(test.env.hv)
        while not test.env.hv.online and attempts:
            time.sleep(10)
            test.update_object(test.env.hv)
            attempts -= 1
        if attempts:
            return True
        return False
