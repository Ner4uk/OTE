# daily

__author__ = 'zhuk'

from onapp_helper.data_store import DataStore
from onapp_helper.disk import Disk
from onapp_helper import test
from onapp_helper.server import VirtualServer
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.disks
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.sequentially
################################## End of marks ################################
@pytest.mark.verbose
class TestMigrateDisk:
    def setup_class(self):
        test.load_env(migrate_disk=True)

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")
        if len(test.env.dsz.attached_data_stores()) < 2:
            pytest.skip("No available Datastores for migrate.")

        try:
            self.vs = VirtualServer()
            self.vs.label = self.__name__
            assert self.vs.create(), self.vs.error
            ds_joins = test.env.hv.data_store_joins() + test.env.hvz.data_store_joins()
            self.data_stores = [
                DataStore(id=ds_join.data_store_id) for ds_join in ds_joins
            ]
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        attributes = (
            'vs',
        )
        test.clean_up_resources(attributes, self)

    def test_check_migration_for_primary_disk(self):
        primary = self.vs.get_primary_disk()
        destination_data_store = [ds for ds in self.data_stores if
                                  ds.id != primary.data_store_id and
                                  ds.enabled and not ds.local_hypervisor_id][0]
        assert primary.migrate(
            data_store_id=destination_data_store.id, type='cold'
        ), primary.error
        assert primary.data_store_id == destination_data_store.id

    def test_check_migration_for_swap_disk(self):
        swap = self.vs.get_swap_disk()
        destination_data_store = [ds for ds in self.data_stores if
                                  ds.id != swap.data_store_id and
                                  ds.enabled and not ds.local_hypervisor_id][0]
        assert swap.migrate(
            data_store_id=destination_data_store.id, type='cold'
        ), swap.error
        assert swap.data_store_id == destination_data_store.id

    def test_check_migration_for_additional_disk(self):
        additional_disk = Disk(parent_obj=self.vs)
        additional_disk.label = self.__class__.__name__
        assert additional_disk.create(), additional_disk.error
        destination_data_store = [ds for ds in self.data_stores if
                                  ds.id != additional_disk.data_store_id and
                                  ds.enabled and not ds.local_hypervisor_id][0]
        assert additional_disk.migrate(
            data_store_id=destination_data_store.id, type='cold'
        ), additional_disk.error
        assert additional_disk.data_store_id == destination_data_store.id
