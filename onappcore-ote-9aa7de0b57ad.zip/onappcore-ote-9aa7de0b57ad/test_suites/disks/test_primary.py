# daily
__author__ = 'zhuk'


import pytest
from onapp_helper import test
from onapp_helper.disk import Disk
from onapp_helper.server import VirtualServer


#################################### Marks #####################################
# Component
@pytest.mark.disks
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.sequentially
################################## End of marks ################################
@pytest.mark.incremental
class TestPrimaryDisk:
    def setup_class(self):
        test.load_env()

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        try:
            self.vs = VirtualServer()
            self.vs.label = self.__name__
            assert self.vs.create(), self.vs.error

            self.primary_disk = self.vs.get_primary_disk()

        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        attributes = (
            'vs',
        )
        test.clean_up_resources(attributes, self)

    def test_validate_vs_min_disk_size(self):
        vs = VirtualServer()
        vs.label = 'vs_min_disk_size'
        vs.set_template()

        # Primary
        vs.disks_attributes.append(
            {
                'disk_size': vs.template.min_disk_size - 1,
                'data_store_id': test.env.ds.id,
                'primary': True,
                'is_swap': False,
                'min_iops': 1
            }
        )
        if vs.template.allowed_swap:
            # Swap
            vs.disks_attributes.append(
                {
                    'disk_size': 1,
                    'data_store_id': test.env.ds.id,
                    'primary': False,
                    'is_swap': True,
                    'min_iops': 1
                }
            )
        assert not vs.create()
        msg = f"must be greater than or equal to {vs.template.min_disk_size} GB " \
            f"to meet system requirements"

        assert msg in self.vs.error['primary_disk_size']

    def test_block_ability_create_vs_with_disk_more_than_2TB(self):
        # https://onappdev.atlassian.net/browse/CORE-14256
        if test.cp_version < 6.2:
            pytest.skip('This is supported since 6.2')

        vs = VirtualServer()
        vs.label = 'block_ability_create_vs_with_disk_more_than_2TB'
        vs.set_template()

        # Primary
        vs.disks_attributes.append(
            {
                'disk_size': 2049,
                'data_store_id': test.env.ds.id,
                'primary': True,
                'is_swap': False,
                'min_iops': 1
            }
        )
        if vs.template.allowed_swap:
            # Swap
            vs.disks_attributes.append(
                {
                    'disk_size': 1,
                    'data_store_id': test.env.ds.id,
                    'primary': False,
                    'is_swap': True,
                    'min_iops': 1
                }
            )
        assert not vs.create()
        assert 'Disk size should be up to 2 TB' in self.vs.error['base']

    def test_create_file_on_primary_disk(self):
        self.vs.execute('echo "pd_test" > /root/pd_test')
        assert 'pd_test' in self.vs.execute('ls -l /root/'), self.vs.error

    def test_increase_primary_disk(self):
        new_size = self.primary_disk.disk_size + 1
        self.primary_disk.disk_size = new_size
        assert self.primary_disk.edit(), self.primary_disk.error
        assert self.primary_disk.disk_size == new_size
        assert pytest.approx(
            round(self.vs.native_disk_size('/'), 1), abs=0.3
        ) == self.vs.template.min_disk_size + 1

    def test_file_should_be_available_on_primary_disk_after_increase(self):
        assert 'pd_test' in self.vs.execute('ls -l /root/')

    def test_decrease_primary_disk(self):
        new_size = self.primary_disk.disk_size - 1
        self.primary_disk.disk_size = new_size
        assert self.primary_disk.edit(), self.primary_disk.error
        assert self.primary_disk.disk_size == new_size
        assert pytest.approx(
            round(self.vs.native_disk_size('/'), 1), abs=0.3
        ) == self.vs.template.min_disk_size

    def test_block_ability_edit_disk_more_than_2TB(self):
        # https://onappdev.atlassian.net/browse/CORE-14256
        if test.cp_version < 6.2:
            pytest.skip('This is supported since 6.2')

        self.primary_disk.disk_size = 2049  # 2TB
        assert not self.primary_disk.edit()
        assert 'Disk size should be up to 2 TB' in self.primary_disk.error['base']

    def test_file_should_be_available_on_primary_disk_after_decrease(self):
        assert 'pd_test' in self.vs.execute('ls -l /root/')

    def test_should_be_impossible_to_add_second_primary_disk(self):
        second_primary_disk = Disk(self.vs)
        second_primary_disk.disk_size = self.primary_disk.disk_size
        second_primary_disk.primary = 1
        second_primary_disk.mounted = True
        second_primary_disk.file_system = self.primary_disk.file_system
        second_primary_disk.require_format_disk = True
        second_primary_disk.hot_attach = True
        assert not second_primary_disk.create()
        assert 'must only have one primary disk' in second_primary_disk.error['primary']