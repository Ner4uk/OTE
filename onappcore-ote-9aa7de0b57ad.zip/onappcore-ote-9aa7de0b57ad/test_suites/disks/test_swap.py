# daily
#Disk has not been added: Mount Point is invalid
#! /usr/bin/env python

__author__ = 'zhuk'
from onapp_helper import test
import pytest
from onapp_helper.server import VirtualServer
from onapp_helper.disk import Disk


#################################### Marks #####################################
# Component
@pytest.mark.disks
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.sequentially
################################## End of marks ################################
@pytest.mark.incremental
class TestAdditionalSwap:
    def setup_class(self):
        test.load_env()

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        try:
            self.vs = VirtualServer()
            self.additional_swap = Disk(self.vs)
            # Create VS
            self.vs.label = self.__name__
            assert self.vs.create(), self.vs.error
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        attributes = (
            'vs',
        )
        test.clean_up_resources(attributes, self)

    # Check Additional Swap
    def test_additional_swap_create(self):
        self.additional_swap.label = self.__class__.__name__
        self.additional_swap.disk_size = 1
        self.additional_swap.is_swap = True
        self.additional_swap.require_format_disk = False
        self.additional_swap.mounted = '0'
        assert self.additional_swap.create(), self.additional_swap.error
        assert self.additional_swap.label == self.__class__.__name__
        assert 1.8 <= round(self.vs.native_swap_size(), 1) <= 2.0, self.vs.error

    def test_edit_increase_additional_swap(self):
        self.additional_swap.label = 'increase_{0}'.format(self.__class__.__name__)
        new_size = self.additional_swap.disk_size + 1
        self.additional_swap.disk_size = new_size
        assert self.additional_swap.edit(), self.additional_swap.error
        assert self.additional_swap.disk_size == new_size
        assert self.additional_swap.label == 'increase_{0}'.format(self.__class__.__name__)
        assert 2.8 <= round(self.vs.native_swap_size(), 1) <= 3.0, self.vs.error

    def test_edit_decrease_additional_swap(self):
        self.additional_swap.label = 'decrease_{0}'.format(self.__class__.__name__)
        new_size = self.additional_swap.disk_size - 1
        self.additional_swap.disk_size = new_size
        assert self.additional_swap.edit(), self.additional_swap.error
        assert self.additional_swap.disk_size == new_size
        assert self.additional_swap.label == 'decrease_{0}'.format(self.__class__.__name__)
        assert 1.8 <= round(self.vs.native_swap_size(), 1) <= 2.0, self.vs.error

    def test_additional_swap_delete(self):
        assert self.additional_swap.delete(), self.additional_swap.error
        assert 0.8 <= round(self.vs.native_swap_size(), 1) <= 1.0, self.vs.error
