import time
import pytest
from onapp_helper import test
from onapp_helper.server import VirtualServer
from onapp_helper.backup import Backup
from onapp_helper.template import Template
from onapp_helper.disk import Disk

__author__ = 'zhuk'


@pytest.fixture(
    scope="class",
    params=[
        'ext3',
        'ext4',
        'xfs',
    ]
)
def file_system(request):
    return request.param


#################################### Marks #####################################
# Component
@pytest.mark.disks
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.sequentially
################################## End of marks ################################
# @pytest.mark.incremental
@pytest.mark.verbose
class TestAdditionalDisk:
    def setup_class(self):
        test.load_env()

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        try:
            self.vs = VirtualServer()
            self.backup = Backup(parent_obj=self.vs)
            self.custom_template = Template()
            self.additional_d = Disk(self.vs)
            # Create VS
            self.vs.label = 'AdditionalDiskTest'
            assert self.vs.create(), self.vs.error
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        attributes = (
            'vs',
        )
        test.clean_up_resources(attributes, self)

    def test_block_ability_create_disk_more_than_2TB(self, file_system):
        # https://onappdev.atlassian.net/browse/CORE-14256
        if test.cp_version < 6.2:
            pytest.skip('This is supported since 6.2')
        self.validate_test(file_system)

        self.additional_d.mount_point = self.mount_point(file_system)
        self.additional_d.file_system = file_system
        self.additional_d.disk_size = 2049  # 2TB
        assert not self.additional_d.create()
        assert 'Disk size should be up to 2 TB' in self.additional_d.error['base']

    def test_validate_additional_disk_creation_with_wrong_mount_point(self, file_system):
        """https://onappdev.atlassian.net/browse/CORE-6314"""
        self.validate_test(file_system)

        self.additional_d.mount_point = 'sadhf'
        self.additional_d.file_system = file_system
        self.additional_d.disk_size = 1
        assert not self.additional_d.create()
        assert 'is invalid' in self.additional_d.error['mount_point']

    # Check Additional Disk Attach
    def test_attach_additional_disk(self, file_system):
        self.validate_test(file_system)

        if not self.vs.booted:
            assert self.vs.start(), self.vs.error
        self.additional_d.disk_size = 1
        self.additional_d.mount_point = self.mount_point(file_system)
        self.additional_d.mounted = True
        self.additional_d.file_system = file_system
        self.additional_d.require_format_disk = True
        self.additional_d.hot_attach = True
        test.port_is_open(host=self.vs.ip_address)
        assert self.additional_d.create(), self.additional_d.error

        if self.additional_d.is_hot_operations_possible():
            assert self.additional_d.transaction.action == 'attach_disk'
        assert 0.8 <= round(
            self.vs.native_disk_size(self.mount_point(file_system)), 1
        ) <= 1.0

    def test_create_file_on_disk(self, file_system):
        self.validate_test(file_system)
        self.create_file(file_system)
        assert self.file_is_present(file_system)

    def test_check_fstab_for_additional_disk(self, file_system):
        self.validate_test(file_system)

        assert file_system in self.vs.execute(
            'cat /etc/fstab | grep {}'.format(self.additional_d.mount_point)
        )

    def test_check_mount_for_additional_disk(self, file_system):
        self.validate_test(file_system)

        assert file_system in self.vs.execute(
            'mount | grep {}'.format(self.additional_d.mount_point)
        )

    def test_increase_additional_disk(self, file_system):
        self.validate_test(file_system)

        new_size = self.additional_d.disk_size + 1
        self.additional_d.disk_size = new_size
        self.additional_d.require_format_disk = False
        assert self.additional_d.edit(), self.additional_d.error
        assert self.additional_d.disk_size == new_size
        assert 1.8 <= round(
            self.vs.native_disk_size(self.mount_point(file_system)), 1
        ) <= 2.0
        assert self.file_is_present(file_system)

    def test_decrease_additional_disk(self, file_system):
        self.validate_test(file_system)

        new_size = self.additional_d.disk_size - 1
        self.additional_d.disk_size = new_size
        self.additional_d.require_format_disk = False
        if file_system == 'xfs':
            assert not self.additional_d.edit()
            assert "cannot be decreased for XFS file system" in \
                   self.additional_d.error['disk_size']
        else:
            assert self.additional_d.edit(), self.additional_d.error
            assert self.additional_d.disk_size == new_size
            assert 0.8 <= round(
                self.vs.native_disk_size(self.mount_point(file_system)), 1
            ) <= 1.0
            assert self.file_is_present(file_system)

    def test_block_ability_edit_disk_more_than_2TB(self, file_system):
        # https://onappdev.atlassian.net/browse/CORE-14256
        if test.cp_version < 6.2:
            pytest.skip('This is supported since 6.2')
        self.validate_test(file_system)

        self.additional_d.disk_size = 2049  # 2TB
        assert not self.additional_d.edit()
        assert 'Disk size should be up to 2 TB' in self.additional_d.error['base']

    def test_detach_additional_disk(self, file_system):
        self.validate_test(file_system)

        if not self.vs.booted:
            assert self.vs.start(), self.vs.error
        assert self.additional_d.delete(), self.additional_d.error

        if self.additional_d.is_hot_operations_possible():
            assert self.additional_d.transaction.action == 'detach_disk'
        assert not self.vs.native_disk_size(self.mount_point(file_system))
        assert self.file_is_not_present(file_system)

    # Check Additional Disk Add
    def test_build_additional_disk(self, file_system):
        import time
        self.validate_test(file_system)
        if self.vs.booted:
            # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            # Fatal: OnApp::Models::FSTabError: if not sleep
            time.sleep(30)
            assert self.vs.stop(), self.vs.error
        # !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
        # Fatal: OnApp::Models::FSTabError: if not sleep
        time.sleep(30)
        self.additional_d.disk_size = 1
        self.additional_d.mount_point = self.mount_point(file_system)
        self.additional_d.mounted = True
        self.additional_d.file_system = file_system
        self.additional_d.require_format_disk = True
        self.additional_d.hot_attach = False
        assert self.additional_d.create(), self.additional_d.error

        if not self.additional_d.is_hot_operations_possible():
            assert self.additional_d.transaction.action == 'build_disk'
        assert self.vs.start(), self.vs.error
        assert 0.8 <= round(
            self.vs.native_disk_size(self.mount_point(file_system)), 1
        ) <= 1.0

    def test_destroy_additional_disk(self, file_system):
        self.validate_test(file_system)

        if self.vs.booted:
            assert self.vs.stop(), self.vs.error
        assert self.additional_d.delete(), self.additional_d.error
        if not self.additional_d.is_hot_operations_possible():
            assert self.additional_d.transaction.action == 'destroy_disk'
        assert self.vs.start(), self.vs.error
        assert not self.vs.native_disk_size(self.mount_point(file_system))

    def test_create_additional_disk_to_check_backups(self, file_system):
        self.validate_test(file_system)

        if self.vs.booted:
            assert self.vs.stop(), self.vs.error
        import time; time.sleep(10)
        self.additional_d.disk_size = 2
        self.additional_d.mount_point = self.mount_point(file_system)
        self.additional_d.mounted = True
        self.additional_d.file_system = file_system
        self.additional_d.require_format_disk = True
        self.additional_d.hot_attach = False
        assert self.additional_d.create(), self.additional_d.error

        if not self.additional_d.is_hot_operations_possible():
            assert self.additional_d.transaction.action == 'build_disk'
        assert self.vs.start(), self.vs.error
        assert 1.8 <= round(
            self.vs.native_disk_size(self.mount_point(file_system)), 1
        ) <= 2.0
        # pytest.set_trace()

    # Check incremental backup for additional disk
    def test_create_incremental_backup(self, file_system):
        self.validate_test(file_system)

        assert test.onapp_settings.get(), test.onapp_settings.error
        if not test.onapp_settings.allow_incremental_backups:
            assert test.onapp_settings.set(allow_incremental_backups=True)

        # Create file on disk
        self.create_file(file_system)
        assert self.file_is_present(file_system)
        self.backup.backup_type = Backup.TYPE.incremental
        assert self.backup.create(), self.backup.error
        assert self.backup.backup_type == 'incremental'
        # pytest.set_trace()

    def test_restore_incremental_backup(self, file_system):
        # restore
        self.validate_test(file_system)

        self.remove_file(file_system)
        assert self.file_is_not_present(file_system)
        assert self.backup.restore(), self.backup.error
        assert self.file_is_present(file_system)
        # pytest.set_trace()

    def test_convert_incremental_backup_to_template(self, file_system):
        # convert
        self.validate_test(file_system)

        assert self.backup.convert(
            label="{}{}".format(self.__class__.__name__, file_system)
        ), self.backup.error
        # pytest.set_trace()

    def test_rebuild_server_from_custom_template(self, file_system):
        # rebuild
        self.validate_test(file_system)

        self.vs.template = self.backup.template
        assert self.vs.rebuild(), self.vs.error
        assert self.file_is_present(file_system)
        # pytest.set_trace()

    def test_delete_incremental_backup(self, file_system):
        # delete backup
        self.validate_test(file_system)

        assert self.backup.delete(), self.backup.error
        # pytest.set_trace()

    def test_rebuild_server_and_delete_custom_template(self, file_system):
        # rebuild server
        self.validate_test(file_system)

        self.vs.template.id = self.vs.template_id = None
        self.vs.set_template()
        if self.vs.memory < self.vs.template.min_memory_size:
            self.vs.memory = self.vs.template.min_memory_size
            assert self.vs.edit(), self.vs.error
        assert self.vs.rebuild(), self.vs.error

        # Delete custom template
        custom_templates = Template()._get_objects(
            query='search_filter[query]={}'.format(
                self.backup.label
            )
        )

        if custom_templates:
            assert custom_templates[0].delete(), custom_templates[0].error
        # pytest.set_trace()

    def test_create_normal_backup(self, file_system):
        # create
        self.validate_test(file_system)

        assert test.onapp_settings.get(), test.onapp_settings.error
        if test.onapp_settings.allow_incremental_backups:
            assert test.onapp_settings.set(allow_incremental_backups=False)

        # to prevent 'Backups are not supported' error during backup creation
        time.sleep(10)

        # Create file on disk
        if self.file_is_not_present(file_system):
            self.create_file(file_system)
            time.sleep(30)  # To be sure that file is present on disk
            assert self.file_is_present(file_system)
        self.backup.backup_type = Backup.TYPE.normal
        assert self.backup.create(disk=self.additional_d), self.backup.error
        assert self.backup.backup_type == Backup.TYPE.normal
        # pytest.set_trace()

    def test_restore_normal_backup(self, file_system):
        # restore
        self.validate_test(file_system)

        self.remove_file(file_system)
        assert self.file_is_not_present(file_system)
        assert self.backup.restore(), self.backup.error
        assert self.file_is_present(file_system)
        # pytest.set_trace()

    def test_delete_normal_backup(self, file_system):
        # restore
        self.validate_test(file_system)

        # pytest.set_trace()
        assert self.backup.delete(), self.backup.error

    def test_format_disk_with_xfs_to_ext4(self, file_system):
        EXT4 = 'ext4'
        self.validate_test(file_system)
        if file_system != 'xfs':
            pytest.skip("Test is running only for xfs disk.")
        self.additional_d.file_system = EXT4
        self.additional_d.require_format_disk = True
        assert self.additional_d.edit(), self.additional_d.error
        assert EXT4 in self.vs.execute(
            'mount | grep {}'.format(self.additional_d.mount_point)
        ), '{} is not mounted'.format(self.additional_d.mount_point)
        assert EXT4 in self.vs.execute(
            'cat /etc/fstab | grep {}'.format(self.additional_d.mount_point)
        ), 'Wrong file system in fstab file'

    def test_format_disk_with_ext4_to_xfs(self, file_system):
        # https://onappdev.atlassian.net/browse/CORE-11577
        XFS = 'xfs'
        self.validate_test(file_system)
        if file_system != 'ext4':
            pytest.skip("Test is running only for ext4 disk.")
        self.additional_d.file_system = XFS
        self.additional_d.require_format_disk = True
        assert self.additional_d.edit(), self.additional_d.error
        assert XFS in self.vs.execute(
            'mount | grep {}'.format(self.additional_d.mount_point)
        ), '{} is not mounted. This file system might not be supported by ' \
           'current template ({})'.format(
            self.additional_d.mount_point, self.vs.template.file_name
        )
        assert XFS in self.vs.execute(
            'cat /etc/fstab | grep {}'.format(self.additional_d.mount_point)
        ), 'Wrong file system in fstab file'

    def test_delete_additional_disk(self, file_system):
        self.validate_test(file_system)

        assert self.additional_d.delete(), self.additional_d.error
        assert self.file_is_not_present(file_system)

    # This is not a test cases
    def skip_if_xfs_is_not_supported(self, file_system):
        if test.cp_version < 5.4 and file_system == 'xfs':
            pytest.skip(
                "XFS file system is supported since 5.4, the current version is {}".format(
                    test.cp_version
                )
            )

    def skip_if_ext4_is_not_supported_by_template(self, file_system):
        if file_system == 'ext4' and not self.vs.template.ext4:
            pytest.skip(
                "Current template is not support {} file system".format(
                    file_system
                )
            )

    def validate_test(self, file_system):
        self.skip_if_ext4_is_not_supported_by_template(file_system)
        self.skip_if_xfs_is_not_supported(file_system)

    def mount_point(self, file_system):
        return '/mnt/{}_disk'.format(file_system)

    def file_is_present(self, file_system):
        return '100M' in self.vs.execute(
            'ls -l {}'.format(self.mount_point(file_system))
        )

    def file_is_not_present(self, file_system):
        return '100M' not in self.vs.execute(
            'ls -l {}'.format(self.mount_point(file_system))
        )

    def remove_file(self, file_system):
        return self.vs.execute(
            'rm -rfv {}/100M'.format(self.mount_point(file_system))
        )

    def create_file(self, file_system):
        self.vs.execute(
            'dd if=/dev/urandom of={}/100M bs=1024k count=100'.format(
                self.mount_point(file_system)
            )
        )
