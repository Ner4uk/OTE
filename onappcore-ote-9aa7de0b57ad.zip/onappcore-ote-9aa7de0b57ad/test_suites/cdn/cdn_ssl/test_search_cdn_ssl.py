# ignore

#! /usr/bin/env python

__author__ = 'andrii dovhan'

import pytest
from onapp_helper.cdn.cdn_ssl import CdnSsl
from onapp_helper import test


#################################### Marks #####################################
# Component
@pytest.mark.cdn
@pytest.mark.cdn_ssl
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
class TestSearchCdnSsl():
    def setup_class(self):
        self.cdn_ssl_1=CdnSsl()
        self.cdn_ssl_1.create({ 'name': 'test_search_1' })
        self.cdn_ssl_2=CdnSsl()
        self.cdn_ssl_2.create({ 'name': 'test_search_2' })

    def teardown_class(self):
        assert self.cdn_ssl_1.delete()
        assert self.cdn_ssl_2.delete()

    def test_make_sure_two_cdn_ssl_cert_are_created(self):
        assert len(self.cdn_ssl_1.get_all()) >= 2, self.cdn_ssl_1.error

    def test_search_cdn_ssl_cert_by_id(self):
        self.cdn_ssl_1.search(str(self.cdn_ssl_1.id)), self.cdn_ssl_1.error
        assert len(self.cdn_ssl_1.response) == 1, self.cdn_ssl_1.error
        assert self.cdn_ssl_1.get_all()

    def test_search_cdn_ssl_cert_by_name(self):
        self.cdn_ssl_1.search(self.cdn_ssl_1.name), self.cdn_ssl_1.error
        assert len(self.cdn_ssl_1.response) == 1, self.cdn_ssl_1.error

    def test_delete_cdn_ssl_1_and_search(self):
        self.cdn_ssl_1.search('testnamewhichisnotexist'), self.cdn_ssl_1.error
        assert len(self.cdn_ssl_1.response) == 0, self.cdn_ssl_1.error

