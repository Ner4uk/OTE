# ignore

#! /usr/bin/env python

__author__ = 'andrii dovhan'

import pytest
from onapp_helper.cdn.cdn_ssl import CdnSsl
from onapp_helper import test
from test_helper.generatorTH import generate_name


#################################### Marks #####################################
# Component
@pytest.mark.cdn
@pytest.mark.cdn_ssl
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
class TestNegativeCreateCdnSsl():
    def setup_class(self):
        self.cdn_ssl=CdnSsl()
        self.cdn_ssl.create()

    def teardown_class(self):
        assert self.cdn_ssl.delete(), self.cdn_ssl.error

    def test_not_edit_with_incorrect_name(self):
        assert not self.cdn_ssl.update({ 'name': 'тест' })
        assert 'is invalid' in self.cdn_ssl.error['name']

    def test_not_edit_with_incorrect_cert(self):
        assert not self.cdn_ssl.update({ 'cert': generate_name() })
        assert 'An error occurred managing the resource remotely, please try again later. Invalid combination of SSL cert and key' \
               in self.cdn_ssl.error['base']

    def test_not_edit_with_incorrect_key(self):
        assert not self.cdn_ssl.update({ 'key': generate_name() })
        assert 'An error occurred managing the resource remotely, please try again later. SSL private key must pkcs8 compatible' in \
               self.cdn_ssl.error['base']
