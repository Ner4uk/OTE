# ignore

#! /usr/bin/env python

__author__ = 'andrii dovhan'

from onapp_helper.cdn.cdn_ssl import CdnSsl
from onapp_helper import test
from test_helper.generatorTH import generate_name

import pytest
#################################### Marks #####################################
# Component
@pytest.mark.cdn
@pytest.mark.cdn_ssl
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
class TestCdnSsl():
    def setup_class(self):
        self.cdn_ssl=CdnSsl()

    def test_create_cdn_ssl_cet(self):
        assert self.cdn_ssl.create(), self.cdn_ssl.error

    def test_get_cdn_ssl_cert(self):
        assert self.cdn_ssl.get(), self.cdn_ssl.error

    def test_get_all_cdn_ssl_cert(self):
        assert self.cdn_ssl.get_all(), self.cdn_ssl.error

    def test_update_cdn_ssl_cert(self):
        new_name = {'name': 'TestEditSslCert'}
        assert self.cdn_ssl.update(new_name), self.cdn_ssl.error
        assert new_name['name'] == self.cdn_ssl.name

    def test_delete_cdn_ssl_cert(self):
        assert self.cdn_ssl.delete(), self.cdn_ssl.error
