# ignore

#! /usr/bin/env python

__author__ = 'andrii dovhan'

import pytest
from onapp_helper.cdn.cdn_ssl import CdnSsl
from onapp_helper import test
from test_helper.generatorTH import generate_name


#################################### Marks #####################################
# Component
@pytest.mark.cdn
@pytest.mark.cdn_ssl
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
class TestNegativeCreateCdnSsl():
    def setup_class(self):
        self.cdn_ssl = CdnSsl()

    def test_not_create_with_name_more_than_255_characters(self):
        assert not self.cdn_ssl.create({ 'name': generate_name(256) })
        assert "is too long (maximum is 255 characters)" in self.cdn_ssl.error['name'][0]

    def test_not_create_all_params_are_empty(self):
        # https://onappdev.atlassian.net/browse/CORE-8589, should be "can't be blank"
        assert not self.cdn_ssl.create({ 'name': None, 'cert': None, 'key': None })
        assert "is invalid" in self.cdn_ssl.error['cert']
        assert "can\'t be blank" in self.cdn_ssl.error['cert']
        assert "is invalid" in self.cdn_ssl.error['key']
        assert "can\'t be blank" in self.cdn_ssl.error['key']

    def test_not_create_cdn_ssl_cert_with_incorrect_key_and_cert_format(self):
        assert not self.cdn_ssl.create({ 'cert': generate_name(), 'key': generate_name() })
        assert "An error occurred managing the resource remotely, please try again later. Invalid combination of SSL cert and key" in \
               self.cdn_ssl.error['base']

    def test_not_create_cdn_ssl_cert_with_incorrect_key_cert_format(self):
        assert not self.cdn_ssl.create({ 'key': generate_name() })
        assert "An error occurred managing the resource remotely, please try again later. SSL private key must pkcs8 compatible" in \
               self.cdn_ssl.error['base']

    def test_not_create_cdn_ssl_cert_with_cyrylic_name(self):
        assert not self.cdn_ssl.create({ 'name': 'тест' })
        assert "is invalid" in self.cdn_ssl.error['name']
