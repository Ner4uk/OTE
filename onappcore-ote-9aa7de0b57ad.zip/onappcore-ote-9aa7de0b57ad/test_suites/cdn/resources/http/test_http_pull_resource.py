# ignore
import pytest

from onapp_helper import test
from onapp_helper.cdn import resource


@pytest.fixture(
    scope='class',
    autouse=True
)
def cdn_resource(request, user):
    r = resource.CdnResource()
    return r


@pytest.fixture(autouse=True)
def data(request, eg1):
    return {
        "cdn_hostname": 'testhttppulresource.ote',
        "resource_type": resource.HTTP_PULL,
        "cdn_ssl_certificate_id": None,
        "edge_group_ids": [eg1.id],
        "origins": ['ote.com']
    }


#################################### Marks #####################################
# Component
@pytest.mark.cdn
@pytest.mark.cdn_resources
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version < 5.6,
    reason="Buckets supported since 5.6 version."
)
@pytest.mark.verbose
class TestHTTPPULLResource:
    @pytest.mark.parametrize(
        "param,value,msg", [
            ('cdn_hostname', 'google', "Cdn hostname Name can not be a top level domain"),
            ('cdn_hostname', 'google..com', "Cdn hostname Domain Name has incorrect format"),
            ('cdn_hostname', '', "Cdn hostname can't be blank"),
            ('origins', [
                '10.23.34.45', '10.63.34.45', '10.73.34.45', '10.3.34.45'
            ], "Origins accepts maximum 3 IP Addresses or single Domain Name"),
            ('origins', [
                'test', 'testtwo', 'testthree'
            ], [
                "Origin include invalid IP/Hostname for 'test'",
                "Origins include invalid IP 'test'",
                "Origins include invalid IP 'testtwo'",
                "Origins include invalid IP 'testthree'"]
            ),
            ('origins', ['54.23.43.242', 'test', 'testtwo'], [
                "Origins include invalid IP 'test'",
                "Origins include invalid IP 'testtwo'"
            ]),
            ('origins', ['23.43.123.45', '23.43.123.45'], "Origins include duplicated IP"),
            ('origins', '', "Origin accept single Domain/IP Address and can "
                            "not be blank for CDN Resources with HTTP PULL-type. "
                            "For multiple IP Addresses can be used Origins"),
            ('origins', [
                '10.23.34.45:1025', '10.63.34.45:1026', '10.73.34.45:1027'
            ], "Origins include different ports"),
            ('edge_group_ids', '99999999', "Edge groups can't be blank"),
            ('edge_group_ids', '', "Edge groups can't be blank"),
            ('resource_type', 'HTTP_PULLII', "You do not have permissions for this action"),
            ('origins', ['54.23.43.242:999'], [
                'Origin include invalid port', 'Origins include invalid port'
            ]),
            ('origins', ['54.23.43.242:65536'], [
                'Origin include invalid port', 'Origins include invalid port'
            ]),
            # Advanced
            # ('', '', ''),
            # ('', '', ''),
            # ('', '', ''),
            # ('', '', ''),
            # ('', '', ''),
            # ('', '', ''),
            # ('', '', ''),
            # ('', '', ''),
            # ('', '', ''),
        ]
    )
    def test_negative_create(self, param, value, msg, cdn_resource, data):
        data.update({param: value})
        assert not cdn_resource.create(**data)
        if not isinstance(msg, list):
            assert msg in cdn_resource.error
        else:
            for m in msg:
                assert m in cdn_resource.error

    def test_create_resource(self, cdn_resource, data):
        assert cdn_resource.create(**data), cdn_resource.error

    @pytest.mark.parametrize(
        "param,value", [
            ("cdn_hostname", 'newhostname.test.com'),
            ('origins', ['100.100.100.100'])
        ]
    )
    def test_edit_resource(self, param, value, cdn_resource):
        assert cdn_resource.edit(**{param: value}), cdn_resource.error
        assert cdn_resource.__dict__[param] == value

    def test_delete_resource(self, cdn_resource):
        assert cdn_resource.delete(), cdn_resource.error
        assert not cdn_resource.get()
