# ignore


import pytest

from onapp_helper import test
from onapp_helper.bucket.access_controls import EdgeGroupsAC
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.bucket.rate_cards import EdgeGroupsRC
from onapp_helper.cdn.edge_group import EdgeGroup
from onapp_helper.cdn.resource import CdnResource
from onapp_helper.user import User

__maintainer__ = 'QAOH'


#################################### Marks #####################################
# Component
@pytest.mark.cdn
@pytest.mark.cdn_resources
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version < 5.6,
    reason="Buckets supported since 5.6 version."
)
@pytest.mark.verbose
@pytest.mark.incremental
class TestCdnHttpPullHappyPath:
    def setup_class(self):
        test.load_env()
        try:
            '''do the steps required to facilitate cdn in the CP'''
            self.user_bucket = Bucket()
            self.user_bucket.label = self.__name__ + __maintainer__
            assert self.user_bucket.create(), self.user_bucket.error
            self.user = User(bucket=self.user_bucket)
            self.user.login = self.__name__ + '_' + __maintainer__ + 'auto'
            self.user.password = test.generate_password()
            self.user.email = __maintainer__ + '@' + self.__name__ + '.auto'
            assert self.user.create(), self.user.error
            self.edge_group = EdgeGroup()
            self.edge_group.label = self.__class__.__name__ + "_EG"
            assert self.edge_group.create(), self.edge_group.error
            assert self.edge_group.modify()  # assign all the available locations
            self.edge_group_ac = EdgeGroupsAC(
                parent_obj=self.user_bucket,
                target_id=self.edge_group.id,
                server_type=EdgeGroupsAC.SERVER_TYPE.other
            )
            assert self.edge_group_ac.create(), self.edge_group_ac.error
            self.edge_group_rc = EdgeGroupsRC(
                parent_obj=self.user_bucket,
                target_id=self.edge_group.id,
                server_type=EdgeGroupsRC.SERVER_TYPE.other
            )
            assert self.edge_group_rc.create(), self.edge_group_rc.error
            self.cdn_resource = CdnResource()
            self.cdn_resource.cdn_hostname = __maintainer__ + self.__name__ + '.auto'
            self.cdn_resource.resource_type = 'HTTP_PULL'
            self.cdn_resource.origins = ['test.com']
            self.cdn_resource.edge_group_ids = [self.edge_group.id]
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        attributes = (
            'user',
            'user_bucket',
            'edge_group',
        )
        test.clean_up_resources(attributes, self)

    def test_create_resource(self):
        test.execute_as(self.user.login, self.user.password)
        assert self.cdn_resource.create(), self.cdn_resource.error

    def test_edit_resource(self):
        new_cdn_hostname = 'newhostname.test.com'
        new_origins = ['100.100.100.100']
        assert self.cdn_resource.edit(
            cdn_hostname=new_cdn_hostname,
            origins=new_origins
        ), self.cdn_resource.error
        assert self.cdn_resource.cdn_hostname == new_cdn_hostname
        assert self.cdn_resource.origins == new_origins

    def test_delete_resource(self):
        assert self.cdn_resource.delete(), self.cdn_resource.error
