import pytest

from onapp_helper import test
from onapp_helper.cdn.edge_group import EdgeGroup
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.bucket.access_controls import EdgeGroupsAC
from onapp_helper.user import User


@pytest.fixture(
    scope='module', autouse=True
)
def eg1(request):
    eg = EdgeGroup()
    eg.label = 'TestHTTPPULL1'
    eg.create()
    eg.modify()

    def fin():
        eg.delete()

    request.addfinalizer(fin)
    return eg


@pytest.fixture(
    scope='module', autouse=True
)
def eg2(request):
    eg = EdgeGroup()
    eg.label = 'TestHTTPPULL2'
    eg.create()
    eg.modify()

    def fin():
        eg.delete()

    request.addfinalizer(fin)
    return eg


@pytest.fixture(
    scope='module', autouse=True
)
def bucket(request, eg1, eg2):
    b = Bucket()
    b.label = 'TestHTTPPULL'
    b.create()

    eg1_ac = EdgeGroupsAC(
        parent_obj=b,
        target_id=eg1.id,
        server_type=EdgeGroupsAC.SERVER_TYPE.other
    )
    eg1_ac.create()

    eg2_ac = EdgeGroupsAC(
        parent_obj=b,
        target_id=eg2.id,
        server_type=EdgeGroupsAC.SERVER_TYPE.other
    )
    eg2_ac.create()

    def fin():
        b.delete()

    request.addfinalizer(fin)

    return b


@pytest.fixture(
    scope='module', autouse=True
)
def user(request, bucket):
    u = User(bucket=bucket)
    u.login = 'testhttppull'
    u.password = test.generate_password()
    u.email = f'{u.login}@ote.test'
    u.create()
    test.execute_as(u.login, u.password)

    def fin():
        test.execute_as(test.login, test.password)
        u.delete()

    request.addfinalizer(fin)
    return u

