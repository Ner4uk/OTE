import pytest

from onapp_helper import test
from onapp_helper.cdn.edge_group import EdgeGroup

__maintainer__ = 'QAOH'


#################################### Marks #####################################
# Component
@pytest.mark.cdn
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
@pytest.mark.incremental
class TestEdgeGroupBasics:
    def setup_class(self):
        self.edge_group = EdgeGroup()

    def test_edge_group_create(self):
        self.edge_group.label = self.__class__.__name__ + "_EG"
        assert self.edge_group.create(), self.edge_group.error

    def test_edge_group_edit(self):
        self.edge_group.label += "_edited"
        assert self.edge_group.edit(), self.edge_group.error
        assert self.edge_group.get_by_label(self.__class__.__name__ + "_EG" + "_edited"), self.edge_group.error

    def test_edge_group_add_location(self):
        assert self.edge_group.get(), self.edge_group.error  # refresh assigned_locations
        assigned_locations = self.edge_group.assigned_locations
        assert self.edge_group.get_available_locations(), self.edge_group.error
        location_to_assign = self.edge_group.available_locations[0]['location']['id']
        assert self.edge_group.assign_location(location_to_assign)
        assigned_locations.append(location_to_assign)
        assert self.edge_group.get(), self.edge_group.error  # refresh assigned_locations
        assert assigned_locations == [location['location']['id'] for location in self.edge_group.assigned_locations]

    def test_edge_group_modify(self):
        assert self.edge_group.get_available_locations(), self.edge_group.error
        available_locations = self.edge_group.available_locations
        assert self.edge_group.modify(), self.edge_group.error
        assert self.edge_group.get(), self.edge_group.error  # refresh assigned_locations
        sortkey = lambda el: el['location']['id']
        assert sorted(self.edge_group.assigned_locations, key=sortkey) == sorted(available_locations, key=sortkey)

    def test_edge_group_delete(self):
        assert self.edge_group.delete(), self.edge_group.error
        assert not self.edge_group.get()
        assert self.edge_group.error == ['EdgeGroup not found', 'EdgeGroup']
