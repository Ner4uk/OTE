# ignore

import pytest
import re

from onapp_helper import test
from onapp_helper.bucket.access_controls import EdgeGroupsAC
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.bucket.rate_cards import EdgeGroupsRC
from onapp_helper.cdn.edge_group import EdgeGroup
from onapp_helper.cdn.resource import CdnIpRanges
from onapp_helper.cdn.resource import CdnResource
from onapp_helper.user import User

__maintainer__ = 'QAOH'


#################################### Marks #####################################
# Component
@pytest.mark.cdn
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
class TestCdnIpRanges():
    def setup_class(self):
        try:
            '''do the steps required to facilitate cdn in the CP'''
            self.cdn_ip_ranges = CdnIpRanges()
            self.user_bucket = Bucket()
            self.user_bucket.label = self.__name__ + __maintainer__
            assert self.user_bucket.create(), self.user_bucket.error
            self.user = User(bucket=self.user_bucket)
            self.user.login = self.__name__ + '_' + __maintainer__ + 'auto'
            self.user.password = test.generate_password()
            self.user.email = __maintainer__ + '@' + self.__name__ + '.auto'
            assert self.user.create(), self.user.error
            self.edge_group = EdgeGroup()
            self.edge_group.label = self.__class__.__name__ + "_EG"
            assert self.edge_group.create(), self.edge_group.error
            assert self.edge_group.modify()  # assign all the available locations
            self.edge_group_ac = EdgeGroupsAC(
                parent_obj=self.user_bucket,
                target_id=self.edge_group.id,
                server_type=EdgeGroupsAC.SERVER_TYPE.other
            )
            assert self.edge_group_ac.create(), self.edge_group_ac.error
            self.edge_group_rc = EdgeGroupsRC(
                parent_obj=self.user_bucket,
                target_id=self.edge_group.id,
                server_type=EdgeGroupsRC.SERVER_TYPE.other
            )
            assert self.edge_group_rc.create(), self.edge_group_rc.error
            self.cdn_resource = CdnResource()
            self.cdn_resource.cdn_hostname = __maintainer__ + self.__name__ + '.auto'
            self.cdn_resource.resource_type = 'HTTP_PULL'
            self.cdn_resource.origins = ['test.com']
            self.cdn_resource.edge_group_ids = [self.edge_group.id]
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        attributes = (
            'user',
            'user_bucket',
            'edge_group'
        )
        test.clean_up_resources(attributes, self)

    # def test_get_cdn_ip_ranges(self):
    #     assert self.cdn_ip_ranges.get(), "Failed to get ip ranges"
    #     assert isinstance(self.cdn_ip_ranges.edge_ips, list)

    def test_compare_acquired_ip_ranges_to_aflexi_response(self):
        test.execute_as(self.user.login, self.user.password)
        assert self.cdn_resource.create(), self.cdn_resource.error
        assert self.cdn_ip_ranges.get(), "Failed to get ip ranges"
        logged = test.cp.execute(
            'tail -n 50 /onapp/interface/log/production_aflexi.log'
        )
        es = re.compile(r'\x1B\[[0-?]*[ -/]*[@-~]', re.UNICODE)
        es = es.sub('', logged)
        logged = es.replace('\n', '')
        aflexi_user = test.cp.mysql_execute(
            f"select aflexi_username from users where id={self.user.id};"
        )[0]
        # aflexi_user = 'onapp-pub-1-f3bb17e94e39431c34b9990af089b970'
        regex = f"getEdgeIps \[{aflexi_user}\].+?User\.getEdgeIps.+?Result:.+?(\[.*?\])"
        matches = re.search(regex, logged)
        assert matches, "No getEdgeIps statement found in aflexi log"
        assert eval(matches.group(1)) == self.cdn_ip_ranges.response['edge_ips']
