# ignore
#  https://onappdev.atlassian.net/browse/CORE-6699

import pytest
from onapp_helper import test
from datetime import date, timedelta
import time
from onapp_helper.dashboard_statistics import DashboardStatistics


#################################### Marks #####################################
# Component
@pytest.mark.bucket
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
class TestDashboardStatistics:
    def setup_class(self):
        self.dashboard_stat = DashboardStatistics()

    def teardown_class(self):
        pass

    def test_get_all_dashboard_stat(self):
        assert self.dashboard_stat.get(), self.dashboard_stat.error
        print(list(self.dashboard_stat.response.keys()))
        assert len(list(self.dashboard_stat.response.keys())) == 10

    @pytest.mark.parametrize('resource_name', [
        'cpus',
        'disk_size',
        'bandwidth',
        'baremetal_servers',
        'smart_servers',
        'iops',
        'memory',
        'virtual_servers',
        'provider_cpu_usage',
        'provider_storage_usage'
    ])
    def test_get_dashboard_stat(self, resource_name):
        assert self.dashboard_stat.get(stats_for=[resource_name]), \
            self.dashboard_stat.error
        assert len(list(self.dashboard_stat.response.keys())) == 1

    @pytest.mark.parametrize('resource_name', [
        'cpus',
        'disk_size',
        'bandwidth',
        'baremetal_servers',
        'smart_servers',
        'iops',
        'memory',
        'virtual_servers',
        'provider_cpu_usage',
        'provider_storage_usage'
    ])
    def test_get_stats_for_a_particular_period(self, resource_name):
        startdate = (date.today() - timedelta(days=3)).strftime("%Y-%m-%d")
        enddate = (date.today() - timedelta(days=1)).strftime("%Y-%m-%d")
        assert self.dashboard_stat.get(
            stats_for=[resource_name],
            startdate=startdate,
            enddate=enddate
        ), self.dashboard_stat.error

        # Should contain stat only one resource
        assert len(list(self.dashboard_stat.response.keys())) == 1
        # The resource name should be 'cpus'
        assert resource_name in list(self.dashboard_stat.response.keys())
        # The only one record should be for a previous 3 days
        assert len(self.dashboard_stat.cpus) == 3

        [print(time.ctime(t[0]/1000)) for t in self.dashboard_stat.cpus]
