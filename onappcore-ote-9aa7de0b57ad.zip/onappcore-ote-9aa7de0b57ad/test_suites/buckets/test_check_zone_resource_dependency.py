# ignore
__author__ = 'zhuk'
__doc__ = """
Steps to reproduce

Create legacy billing resource for some zone using legacy api routes for backward compatibility
Remove zone
Get resources via API
Actual result
Resource is present

Expected result
Resource should be deleted"""
__since__ = 6.0  # Describe version since this functional available

import pytest
import time

from onapp_helper import test
from onapp_helper.billing_plan import BillingPlan
from onapp_helper.br_helper.hvz import HVZBR
from onapp_helper.br_helper.dsz import DSZBR
from onapp_helper.br_helper.ntz import NTZBR
from onapp_helper.br_helper.bsz import BSZBR
from onapp_helper.br_helper.edge_group import EdgeGroupBR
from onapp_helper.br_helper.recipe_group import RecipeGroupBR
from onapp_helper.br_helper.service_addon_store import ServiceAddonStoreBR
from onapp_helper.br_helper.template_store import TemplateStoreBR
from onapp_helper.template_store import TemplateStore
from onapp_helper.hypervisor_zone import HypervisorZone
from onapp_helper.data_store_zone import DataStoreZone
from onapp_helper.network_zone import NetworkZone
from onapp_helper.bsz import BSZ
from onapp_helper.cdn.edge_group import EdgeGroup
from onapp_helper.recipe.recipe_groups import RecipeGroup
from onapp_helper.service_addon.service_addon_group import ServiceAddonGroup


#################################### Marks #####################################
# Component
@pytest.mark.bucket
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.sequentially
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 6.0, reason="Not supported")
@pytest.mark.verbose
class TestCheckZoneResourceDependency:
    def setup_class(self):
        test.api_version.set(5.4)
        self.billing_plan = BillingPlan()
        self.billing_plan.label = self.__name__
        assert self.billing_plan.create(), self.billing_plan.error

    def teardown_class(self):
        assert self.billing_plan.delete()

    @pytest.mark.parametrize(
        "zone, resource",
        [
            (HypervisorZone, HVZBR),
            (DataStoreZone, DSZBR),
            (NetworkZone, NTZBR),
            (TemplateStore, TemplateStoreBR),
            (BSZ, BSZBR),
            (EdgeGroup, EdgeGroupBR),
            (RecipeGroup, RecipeGroupBR),
            (ServiceAddonGroup, ServiceAddonStoreBR),
        ]
    )
    def test_check_relation(self, zone, resource):
        test_zone = zone()
        test_zone.label = f'OTE{zone.__name__}'
        assert test_zone.create(), test_zone.error()

        br = resource(billing_plan=self.billing_plan, target_id=test_zone.id)
        assert br.create(), br.error()

        assert br.get(), br.error
        assert test_zone.get(), br.error

        # if br.__class__.__name__ == 'TemplateStoreBR':
        #     pytest.set_trace()

        assert test_zone.delete(), test_zone.error
        time.sleep(5)
        assert not br.get()

