# ignore

__doc__ = """
1. Create Billing Plan with old API 
2. Add a couple of base resources
3. Clone Billing Plan
4. Check Bucket (cloned) especially access controls and rate cards
"""


import pytest
from onapp_helper import test
from onapp_helper.user import User
from onapp_helper.billing_plan import BillingPlan
from onapp_helper.br_helper.hvz import HVZBR
from onapp_helper.br_helper.dsz import DSZBR
from onapp_helper.br_helper.ntz import NTZBR
from onapp_helper.br_helper.vm_limit import VMLimit
from onapp_helper.br_helper.template import TemplateBR
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.bucket import access_controls as ac
from onapp_helper.bucket import rate_cards as rc


@pytest.fixture(scope='class', autouse=True)
def cloned_billing_plan(request):
    bp = BillingPlan()

    def fin():
        bp.delete()

    request.addfinalizer(fin)
    return bp


#################################### Marks #####################################
# Component
@pytest.mark.bucket
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.verbose
class TestCloneBillingPlanAndCheckBucket:
    def setup_class(self):
        test.hv_types = ['kvm']
        test.load_env()

        self.billing_plan = BillingPlan()
        self.billing_plan.label = self.__name__
        assert self.billing_plan.create(), self.billing_plan.error

        self.hvz_br = HVZBR(
            billing_plan=self.billing_plan,
            target_id=test.env.hvz.id
        )
        # limits
        self.hvz_br.limits.limit_memory = 2048
        self.hvz_br.limits.limit_default_cpu = 234
        self.hvz_br.limits.limit_cpu = 300
        self.hvz_br.prices.price_on_memory = 90
        self.hvz_br.prices.price_on_cpu_share = 0.098
        assert self.hvz_br.create(), self.hvz_br.error

        self.dsz_br = DSZBR(
            billing_plan=self.billing_plan,
            target_id=test.env.dsz.id
        )
        self.dsz_br.limits.limit = 20
        self.dsz_br.limits.limit_reads_completed_free = 1209
        self.dsz_br.prices.price_reads_completed = 0.234
        assert self.dsz_br.create(), self.dsz_br.error

        self.ntz_br = NTZBR(
            billing_plan=self.billing_plan,
            target_id=test.env.netz.id
        )
        self.ntz_br.limits.limit_ip = 10
        self.ntz_br.limits.limit_rate = 500
        self.ntz_br.prices.price_ip_on = 0.5423
        assert self.ntz_br.create(), self.ntz_br.error

        self.vm_limit = VMLimit(
            billing_plan=self.billing_plan
        )
        self.vm_limit.limits.limit = 10
        assert self.vm_limit.create(), self.vm_limit.error

        self.template_br = TemplateBR(
            billing_plan=self.billing_plan
        )
        self.template_br.limits.limit = 123
        self.template_br.prices.price = 0.54
        assert self.template_br.create(), self.template_br.error

        self.user1 = User(bp=self.billing_plan)
        self.user1.login = f"{self.__name__}1"
        self.user1.password = test.generate_password()
        self.user1.email = f"{self.user1.login}@ote.test"
        assert self.user1.create(), self.user1.error

        self.user2 = User(bp=self.billing_plan)
        self.user2.login = f"{self.__name__}2"
        self.user2.password = test.generate_password()
        self.user2.email = f"{self.user2.login}@ote.test"
        assert self.user2.create(), self.user2.error

    def teardown_class(self):
        attributes = (
            'user1',
            'user2',
            'billing_plan'
        )
        test.clean_up_resources(attributes, self)

    def test_clone_billing_plan(self, cloned_billing_plan):
        assert cloned_billing_plan.clone(self.user2.id, self.billing_plan.id)

    def test_check_cloned_billing_plan_id_for_user2(self, cloned_billing_plan):
        assert self.user2.get(), self.user2.error
        assert self.user2.billing_plan_id == cloned_billing_plan.id

    def test_check_count_of_base_resources(self, cloned_billing_plan):
        assert len(self.billing_plan.get_base_resources()) == 5
        assert len(cloned_billing_plan.get_base_resources()) == 5

    def test_check_bucket(self, cloned_billing_plan):
        assert Bucket(id=cloned_billing_plan.id)

    def test_check_access_controls(self, cloned_billing_plan):
        b = Bucket(id=cloned_billing_plan.id)

        hvz_ac = ac.ComputeZoneAC(parent_obj=b, target_id=test.env.hvz.id)
        assert hvz_ac.get()
        assert hvz_ac.limits.limit_memory == 2048
        assert hvz_ac.limits.limit_default_cpu == 234
        assert hvz_ac.limits.limit_cpu == 300

        dsz_ac = ac.DataStoreZoneAC(parent_obj=b, target_id=test.env.dsz.id)
        assert dsz_ac.get()
        assert dsz_ac.limits.limit == 20

        ntz_ac = ac.NetworkZoneAC(parent_obj=b, target_id=test.env.netz.id)
        assert ntz_ac.get()
        assert ntz_ac.limits.limit_ip == 10
        assert ntz_ac.limits.limit_rate == 500

        vm_ac = ac.VirtualServerAC(parent_obj=b)
        assert vm_ac.get()
        assert vm_ac.limits.limit == 10

        template_ac = ac.TemplatesAC(parent_obj=b)
        assert template_ac.get()
        assert template_ac.limits.limit == 123

    def test_check_rate_cards(self, cloned_billing_plan):
        b = Bucket(id=cloned_billing_plan.id)

        hvz_rc = rc.ComputeZoneRC(parent_obj=b, target_id=test.env.hvz.id)
        assert hvz_rc.get()
        assert hvz_rc.prices.price_on_memory == 90
        assert hvz_rc.prices.price_on_cpu_share == 0.098

        dsz_rc = rc.DataStoreZoneRC(parent_obj=b, target_id=test.env.dsz.id)
        assert dsz_rc.get()
        assert dsz_rc.prices.limit_reads_completed_free == 1209
        assert dsz_rc.prices.price_reads_completed == 0.234

        ntz_rc = rc.NetworkZoneRC(parent_obj=b, target_id=test.env.netz.id)
        assert ntz_rc.get()
        assert ntz_rc.prices.price_ip_on == 0.5423

        vm_rc = rc.VirtualServerRC(parent_obj=b)
        assert not vm_rc.get()

        template_rc = rc.TemplatesRC(parent_obj=b)
        assert template_rc.get()
        assert template_rc.prices.price == 0.54
