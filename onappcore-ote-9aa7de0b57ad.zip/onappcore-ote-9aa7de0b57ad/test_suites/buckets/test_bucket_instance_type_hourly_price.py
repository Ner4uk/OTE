import pytest

from onapp_helper import test
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.bucket import access_controls as ac
from onapp_helper.bucket import rate_cards as rc
from onapp_helper.instance_package import InstancePackage
from onapp_helper.stats.user_stats import UserStats
from onapp_helper.stats.vm_stat import VmStat
from onapp_helper.user import User
from onapp_helper.server import VirtualServer
from onapp_helper.ip_address import IpAddress
from test_helper import billingTH


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.hourly_price
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
@pytest.mark.skipif(
    test.cp_version < 4.1,
    reason=f"Does not supported by ({test.cp_version})"
)
@pytest.mark.incremental
class TestInstanceTypeHourlyPrice:
    def setup_class(self):
        test.cp.generate_10MB_test_file()
        test.load_env()

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        test.run_at(minutes=40)

        try:
            self.bucket = Bucket()
            self.bucket.label = self.__name__
            assert self.bucket.create()

            ac.add_env_to_bucket(self.bucket)

            self.instance_type = InstancePackage()
            self.instance_type.label = self.__name__
            self.instance_type.cpus = 2
            self.instance_type.memory = 512
            self.instance_type.disk_size = 7
            self.instance_type.bandwidth = 10
            assert self.instance_type.create(), self.instance_type.error

            # https://onappdev.atlassian.net/browse/CORE-11921
            # This ticket also fixes a bug with tracking instance packages
            # bandwidth changes on the billing side (it tracked only creation,
            # but bandwidth changes were untracked)
            self.instance_type.bandwidth = 1
            assert self.instance_type.edit(), self.instance_type.error

            # Get targets
            self.hvz_id = test.env.hvz.id
            self.ntz_id = test.env.netz.id
            self.dsz_id = test.env.dsz.id

            self.instance_type_ac = ac.InstancePackageAC(
                parent_obj=self.bucket,
                target_id=self.instance_type.id
            )
            # Set IT preferences
            self.instance_type_ac.preferences.hypervisor_group_ids.append(self.hvz_id)
            self.instance_type_ac.preferences.data_store_group_ids.append(self.dsz_id)
            self.instance_type_ac.preferences.network_group_ids.append(self.ntz_id)
            assert self.instance_type_ac.create(), self.instance_type_ac.error

            self.instance_type_rc = rc.InstancePackageRC(
                parent_obj=self.bucket,
                target_id=self.instance_type.id
            )
            # Set IT prices
            self.instance_type_rc.prices.price_on = 100
            self.instance_type_rc.prices.price_off = 20
            self.instance_type_rc.prices.price_overused_bandwidth = 99
            # Create IT limit
            assert self.instance_type_rc.create(), self.instance_type_ac.error

            # Set NZ prices
            self.ntz_rc = rc.NetworkZoneRC(parent_obj=self.bucket, target_id=self.ntz_id)
            self.ntz_rc.prices.price_ip_on = 5.5
            self.ntz_rc.prices.price_ip_off = 0.5
            assert self.ntz_rc.create(), self.ntz_rc.error

            self.user = User(bucket=self.bucket)
            self.user.login = 'instancetypehourlyprice'
            self.user.password = test.generate_password()
            self.user.email = 'user@instancetypehourlyprice.test'
            assert self.user.create(), self.user.error
            test.execute_as(self.user.login, self.user.password)

            self.vs = VirtualServer()
            # test.env.ip_address.assign_ip_addresses_to_user(ip_addresses=[test.env.ip_address.id], user=self.user)

            if test.cp_version >= 5.4:
                self.vs.selected_ip_address = test.env.ip_address.address
            else:
                self.vs.selected_ip_address_id = test.env.ip_address.id

            self.vs.label = self.__name__
            self.vs.instance_package_id = self.instance_type.id
            assert self.vs.create(), self.vs.error

            self.user_stats = UserStats(self.user)
            self.vm_stat = VmStat(parent_obj=self.vs)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        attributes = (
            'user',
            'bucket',
            'instance_type'
        )
        test.clean_up_resources(attributes, self)

    def test_if_vs_has_build(self):
        assert self.vs.booted and self.vs.built

    def test_add_2nd_ip_address(self):
        # Prepare 2nd IP address
        ip_address_2 = IpAddress(parent_obj=test.env.net).get_free(
            selected_ip_addresses=[test.env.ip_address.address]
        )
        join_for_2nd_ip = self.vs.ip_address_join
        # Add 2nd IP to check if price for 2nd IP included to VM cost
        assert join_for_2nd_ip.assign_to_server(
            address=ip_address_2.address,
        ), join_for_2nd_ip.error

    def test_check_cpu(self):
        assert self.vs.cpus == self.instance_type.cpus

    def test_memory(self):
        assert self.vs.memory == self.instance_type.memory

    def test_total_disk_size(self):
        assert sum(
            [d.disk_size for d in self.vs.disks()]
        ) == self.instance_type.disk_size

    def test_load_more_than_1gb_of_data_to_check_owerused_bandwith(self):
        for i in range(15):
            self.vs.download_100MB_of_data()

    def test_price_on(self):
        assert billingTH.price_comparator(
            self.vs.price_per_hour,
            self.instance_type_rc.prices.price_on + self.ntz_rc.prices.price_ip_on
        )

    def test_price_off(self):
        assert billingTH.price_comparator(
            self.vs.price_per_hour_powered_off,
            self.instance_type_rc.prices.price_off + self.ntz_rc.prices.price_ip_off
        )

    def test_wait_for_statistics(self):
        # Check Usage Statistics
        self.vm_stat.stats_waiter()
        self.vm_stat.get_hourly_stat_for_the_last_hour()
        self.user_stats.get_user_stat_for_the_last_hour()

    def test_vm_resources_cost(self):
        assert billingTH.price_comparator(
            self.instance_type_rc.prices.price_on + \
            self.ntz_rc.prices.price_ip_on,
            self.vm_stat.vm_resources_cost
        )

    def test_bandwidth_overused_cost(self):
        total_value = self.vm_stat.get_networks_data_received_value() + \
                      self.vm_stat.get_networks_data_sent_value()
        price_overused_bandwidth = self.instance_type_rc.prices.price_overused_bandwidth
        expected_price = (total_value - 1) * price_overused_bandwidth

        assert billingTH.price_comparator(
            expected_price,
            self.vm_stat.get_instance_package_bandwidth_overused_cost(),
            precision=2.5
        )

    def test_bandwidth_overused_value(self):
        assert self.vm_stat.get_instance_package_bandwidth_overused_value() == \
        pytest.approx(0.5, abs=0.07)

    @pytest.mark.skipif(test.cp_version < 6.0, reason='Not implemented')
    def test_check_instance_package_id(self):
        assert self.vm_stat.get_instance_package_id() == self.instance_type.id

    def test_check_instance_package_cost(self):
        assert self.vm_stat.get_instance_package_cost() == self.instance_type_rc.prices.price_on
