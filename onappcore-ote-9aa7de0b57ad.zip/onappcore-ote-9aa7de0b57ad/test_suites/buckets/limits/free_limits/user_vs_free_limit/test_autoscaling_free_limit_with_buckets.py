import pytest

from onapp_helper import test
from onapp_helper.server import VirtualServer, ApplicationServer
from onapp_helper.autoscaling import MemoryUp
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.bucket import access_controls as ac
from onapp_helper.bucket import rate_cards as rc
from onapp_helper.user import User

# Stats
from onapp_helper.stats.user_stats import UserStats


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.limits
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
@pytest.mark.incremental
class TestAutoscalingMaxLimit:
    def setup_class(self):
        test.load_env()

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        test.run_at(minutes=40)

        try:
            self.bucket = Bucket()
            self.bucket.label = self.__name__
            assert self.bucket.create()

            ac.add_env_to_bucket(self.bucket)

            self.vs = VirtualServer()
            self.apps = ApplicationServer()
            self.user = User(bucket=self.bucket)

            self.vm_monit_rc = rc.AutoscaledServersRC(parent_obj=self.bucket)
            assert self.vm_monit_rc.create(), self.vm_monit_rc.error

            self.user.login = 'autoscalingfreelimitstest'
            self.user.password = test.generate_password()
            self.user.email = 'user@autoscalingfreelimits.test'
            assert self.user.create(), self.user.error

            test.execute_as(self.user.login, self.user.password)

            self.vs.label = self.__name__
            assert self.vs.create(), self.vs.error

            assert self.vs.autoscale_enable(), self.vs.error

            self.memory_autoscaling_up = MemoryUp(self.vs)
            self.vm_monit_rc.prices.limit_free = 1
            self.vm_monit_rc.prices.price = 100
            assert self.vm_monit_rc.edit(), self.vm_monit_rc.error

            self.user_stats = UserStats(self.user)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        self.user.delete()
        self.bucket.delete()

    def test_set_memory_up(self):
        self.memory_autoscaling_up.enabled = 1
        self.memory_autoscaling_up.adjust_units = 128
        self.memory_autoscaling_up.for_minutes = 5
        self.memory_autoscaling_up.limit_trigger = 10
        self.memory_autoscaling_up.up_to = 1024
        assert self.memory_autoscaling_up.create(), self.memory_autoscaling_up.error

    def test_get_stat(self):
        self.user_stats.stats_waiter()
        self.user_stats.get_user_stat_for_the_last_hour()

    def test_monit_cost_should_be_0(self):
        assert self.user_stats.monit_cost == float(
            (1 - self.vm_monit_rc.prices.limit_free) *
            self.vm_monit_rc.prices.price
        )
