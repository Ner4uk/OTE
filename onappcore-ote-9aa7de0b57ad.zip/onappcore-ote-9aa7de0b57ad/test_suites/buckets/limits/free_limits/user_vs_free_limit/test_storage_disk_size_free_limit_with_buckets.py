import pytest

from onapp_helper import test
from onapp_helper.backup import Backup
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.bucket import access_controls as ac
from onapp_helper.bucket import rate_cards as rc

from onapp_helper.template import Template
from onapp_helper.user import User
from onapp_helper.server import VirtualServer

# Stats
from onapp_helper.stats.user_stats import UserStats
from test_helper.billingTH import price_comparator_with_round


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.limits
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
@pytest.mark.verbose
class TestCheckStorageDiskSizeAndBackupTemplatesFreeLimits:
    __doc__ = """
    1. Configure Bucket:
        - deny storing backups on BSZ
        - set free limits and prices
    2. Create backups (auto, manual), templates
    3. Waiting for statistics
    4. Compare expected value with actual. Check that for onapp >= 5.9 auto 
    backups count limit/price also works
    """

    def setup_class(self):
        test.load_env()

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        test.run_at(minutes=40)

        try:
            # Setup
            self.bucket = Bucket()
            self.bucket.label = self.__name__
            assert self.bucket.create()

            ac.add_env_to_bucket(self.bucket)

            # Setup AC
            for bs in test.env.backup_servers:
                self.bsz_ac = ac.BackupServerZoneAC(
                    parent_obj=self.bucket,
                    target_id=bs.backup_server_group_id
                )
                if self.bsz_ac.get():
                    break

            # Set free limits for RC
            self.storage_disk_size_rc = rc.ComputeResourceStoringRC(
                parent_obj=self.bucket
            )
            self.storage_disk_size_rc.prices.limit_free = 1
            self.storage_disk_size_rc.prices.price = 10
            assert self.storage_disk_size_rc.create(), \
                self.storage_disk_size_rc.error

            self.template_rc = rc.TemplatesRC(parent_obj=self.bucket)
            self.template_rc.prices.limit_free = 1
            self.template_rc.prices.price = 20
            assert self.template_rc.create(), self.template_rc.error

            self.backup_rc = rc.BackupsRC(parent_obj=self.bucket)
            self.backup_rc.prices.limit_free = 1
            self.backup_rc.prices.price = 30
            assert self.backup_rc.create(), self.backup_rc.error

            if hasattr(self, 'bsz_ac'):
                # Deny using BSZ for backups/templates
                self.bsz_ac.limits.limit_template = 0
                self.bsz_ac.limits.limit_backup = 0
                self.bsz_ac.limits.limit_backup_disk_size = 0
                self.bsz_ac.limits.limit_template_disk_size = 0
                assert self.bsz_ac.edit(), self.bsz_ac.error

            # Create User and VS
            self.user = User(bucket=self.bucket)
            self.user.login = "storagefreelimitstest"
            self.user.password = test.generate_password()
            self.user.email = 'user@storagefreelimitstest.test'
            assert self.user.create()
            # Login as new user
            test.execute_as(self.user.login, self.user.password)

            self.vs = VirtualServer()
            self.vs.rate_limit = 0  #  Unlimited
            self.vs.label = self.__name__
            assert self.vs.create(), self.vs.error

            self.template = Template()

            self.backups = []

            # Better with normal backups
            if test.onapp_settings.get().allow_incremental_backups:
                assert test.onapp_settings.set(allow_incremental_backups=False)
            self.user_stats = UserStats(self.user)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        attributes = (
            'vs',
            'user',
            'bucket'
        )
        test.clean_up_resources(attributes, self)

    def test_create_auto_backups(self):
        backups = self.vs.get_primary_disk().enable_auto_backups()
        assert len(backups) == 4

    def test_create_backups_to_reach_free_disk_size_limit(self):
        while True:
            backup = Backup(self.vs)
            backup.create()
            self.backups.append(backup)
            if self.vs.get_backups_size() > 1048576:
                break

    def test_create_template(self):
        assert self.backups[0].convert(
            label=self.__class__.__name__
        ), self.backups[0].template.error
        self.template.__dict__.update(self.backups[0].template.__dict__)

    def test_get_stat(self):
        self.user_stats.stats_waiter()
        self.user_stats.get_user_stat_for_the_last_hour()

    #  User VS limits
    def test_backups_cost(self):
        assert self.user_stats.backup_cost == \
               self.vs.get_backups_count() * self.backup_rc.prices.price

    def test_backups_discount(self):
        assert self.user_stats.backup_discount_due_to_free == \
               self.backup_rc.prices.limit_free * self.backup_rc.prices.price

    def test_templates_cost(self):
        assert self.user_stats.template_cost == self.template_rc.prices.price

    def test_templates_discount(self):
        assert self.user_stats.template_discount_due_to_free == \
               self.template_rc.prices.limit_free * self.template_rc.prices.price

    def test_storage_disk_size_cost(self):
        total_bu_size = self.vs.get_backups_size()
        test.log.info("Total_bu_size - {0}".format(total_bu_size))
        total_storage_disk_size_in_GB = (total_bu_size + self.template.template_size) / 1048576.0
        assert price_comparator_with_round(
            total_storage_disk_size_in_GB *
            self.storage_disk_size_rc.prices.price,
            self.user_stats.storage_disk_size_cost,
            ndigits=2
        )

    def test_storage_disk_size_discount(self):
        total_bu_size = self.vs.get_backups_size()
        test.log.info("Total_bu_size - {0}".format(total_bu_size))
        assert price_comparator_with_round(
            self.storage_disk_size_rc.prices.limit_free *
            self.storage_disk_size_rc.prices.price,
            self.user_stats.storage_disk_size_discount_due_to_free,
            ndigits=2
        )

    # BSZ Limits
    def test_backup_count_cost_should_be_0(self):
        assert self.user_stats.backup_count_cost == 0.0

    def test_backup_count_discount_should_be_0(self):
        assert self.user_stats.backup_count_discount_due_to_free == 0.0

    def test_backup_disk_size_cost_should_be_0(self):
        assert self.user_stats.backup_disk_size_cost == 0.0

    def test_backup_disk_size_discount_should_be_0(self):
        assert self.user_stats.backup_disk_size_discount_due_to_free == 0.0

    def test_template_count_cost_should_be_0(self):
        assert self.user_stats.template_count_cost == 0.0

    def test_template_count_discount_should_be_0(self):
        assert self.user_stats.template_count_discount_due_to_free == 0.0

    def test_template_disk_size_cost_should_be_0(self):
        assert self.user_stats.template_disk_size_cost == 0.0

    def test_template_disk_size_discount_should_be_0(self):
        assert self.user_stats.template_disk_size_discount_due_to_free == 0.0

    def test_total_cost(self):
        total_cost = sum(
            [
                self.vs.get_backups_count() * self.backup_rc.prices.price,
                self.template_rc.prices.price,
                (
                    self.vs.get_backups_size() + self.template.template_size
                ) / 1048576.0 * self.storage_disk_size_rc.prices.price,
            ]
        )
        assert price_comparator_with_round(
            total_cost,
            self.user_stats.total_cost,
            ndigits=2
        )

    def test_user_resources_cost(self):
        user_resources_cost = sum(
            [
                self.vs.get_backups_count() * self.backup_rc.prices.price,
                self.template_rc.prices.price,
                (
                    self.vs.get_backups_size() + self.template.template_size
                ) / 1048576.0 * self.storage_disk_size_rc.prices.price,
            ]
        )
        assert price_comparator_with_round(
            user_resources_cost,
            self.user_stats.user_resources_cost,
            ndigits=2
        )

    def test_user_resources_discount_due_to_free(self):
        user_resources_discount_due_to_free = sum(
            [
                self.backup_rc.prices.limit_free * self.backup_rc.prices.price,
                self.template_rc.prices.limit_free * self.template_rc.prices.price,
                self.storage_disk_size_rc.prices.limit_free *
                self.storage_disk_size_rc.prices.price,
            ]
        )
        assert price_comparator_with_round(
            user_resources_discount_due_to_free,
            self.user_stats.user_resources_discount_due_to_free,
            ndigits=2
        )

    def test_total_discount_due_to_free(self):
        total_discount_due_to_free = sum(
            [
                self.backup_rc.prices.limit_free * self.backup_rc.prices.price,
                self.template_rc.prices.limit_free * self.template_rc.prices.price,
                self.storage_disk_size_rc.prices.limit_free *
                self.storage_disk_size_rc.prices.price,
            ]
        )
        assert price_comparator_with_round(
            total_discount_due_to_free,
            self.user_stats.total_discount_due_to_free,
            ndigits=2
        )

    def test_total_cost_with_discount(self):
        total_cost = sum(
            [
                self.vs.get_backups_count() * self.backup_rc.prices.price,
                self.template_rc.prices.price,
                (
                    self.vs.get_backups_size() + self.template.template_size
                ) / 1048576.0 * self.storage_disk_size_rc.prices.price,
            ]
        )
        discount_due_to_free = sum(
            [
                self.backup_rc.prices.limit_free * self.backup_rc.prices.price,
                self.template_rc.prices.limit_free * self.template_rc.prices.price,
                self.storage_disk_size_rc.prices.limit_free *
                self.storage_disk_size_rc.prices.price,
            ]
        )
        assert price_comparator_with_round(
            total_cost - discount_due_to_free,
            self.user_stats.total_cost_with_discount,
            ndigits=2
        )
