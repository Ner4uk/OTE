from onapp_helper import test

from onapp_helper.bucket import access_controls as ac
from onapp_helper.bucket import rate_cards as rc
from onapp_helper.server import VirtualServer
from onapp_helper.user import User
from onapp_helper.bucket.bucket import Bucket
# Stats
from onapp_helper.stats.vm_stat import VmStat
import pytest
#from onapp_helper. import UserStats


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.limits
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
class TestMinIOPSFreeLimits:
    def setup_class(self):
        test.ds_types = ['solidfire']
        test.load_env()
        if not test.env.dsz.id or test.env.ds.data_store_type != 'solidfire':
            pytest.skip(
                "There is no SolidFire data store on - {0}.".format(test.host)
            )

        test.run_at(minutes=40)

        try:
            # Setup
            self.bucket = Bucket()
            self.bucket.label = self.__name__
            assert self.bucket.create()

            ac.add_env_to_bucket(self.bucket)

            # Setup for base resources
            self.min_iops_ac = ac.SolidfireDataStoreZoneAC(
                parent_obj=self.bucket,
                target_id=test.env.dsz.id
            )
            assert self.min_iops_ac.get(), self.min_iops_ac.error

            self.min_iops_rc = rc.SolidfireDataStoreZoneRC(
                parent_obj=self.bucket,
                target_id=test.env.dsz.id
            )

            # Set free limits for base resources
            self.min_iops_ac.limits.limit = 1200
            assert self.min_iops_ac.edit(), self.min_iops_ac.error

            self.min_iops_rc.prices.limit_free = 500
            self.min_iops_rc.prices.price_on = 100
            self.min_iops_rc.prices.price_off = 10
            assert self.min_iops_rc.create(), self.min_iops_rc.error

            # Create User and VS
            self.user = User(bucket=self.bucket)
            self.user.login = "miniopsfreelimitstest"
            self.user.password = test.generate_password()
            self.user.email = 'user@miniopsfreelimitstest.test'
            assert self.user.create()
            # Login as new user
            test.execute_as(self.user.login, self.user.password)

            self.vs = VirtualServer()
            self.vs.rate_limit = 0  #  Unlimited
            self.vs.label = self.__name__
            self.vs.primary_disk_min_iops = 600
            self.vs.swap_disk_min_iops = 600
            assert self.vs.create(), self.vs.error
            self.total_min_iops = sum(
                [d.min_iops for d in self.vs.disks()]
            )
            #time.sleep(300)

            self.vm_stat = VmStat(parent_obj=self.vs)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        attributes = (
            'vs',
            'user',
            'bucket'
        )
        test.clean_up_resources(attributes, self)

    def test_hourly_price_on_should_be_0(self):
        assert float(self.vs.price_per_hour) == self.total_min_iops * \
                                                self.min_iops_rc.prices.price_on

    def test_hourly_price_off_should_be_0(self):
        assert float(self.vs.price_per_hour_powered_off) == \
               self.total_min_iops * self.min_iops_rc.prices.price_off

    def test_get_stat(self):
        self.vm_stat.stats_waiter()
        self.vm_stat.get_hourly_stat_for_the_last_hour()

    def test_min_iops_cost(self):
        if self.vs.booted:
            price = self.min_iops_rc.prices.price_on
        else:
            price = self.min_iops_rc.prices.price_off
        assert self.vm_stat.get_disks_disk_min_iops_cost() == float(self.total_min_iops * price)
