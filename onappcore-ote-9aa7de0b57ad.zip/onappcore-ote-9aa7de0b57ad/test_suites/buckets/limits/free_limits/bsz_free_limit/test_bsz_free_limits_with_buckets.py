import time

import pytest

from onapp_helper import test
from onapp_helper.backup import Backup
from onapp_helper.backup_server import BackupServer
from onapp_helper.bsz import BSZ
from onapp_helper.bucket import access_controls as ac
from onapp_helper.bucket import rate_cards as rc
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.stats.user_stats import UserStats
from onapp_helper.template import Template
from onapp_helper.template_ova import OVA
from onapp_helper.user import User
from onapp_helper.server import VirtualServer
from test_helper.billingTH import price_comparator_with_round

ONE_GB_IN_MB = 1048576


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.limits
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
@pytest.mark.verbose
class TestBSZFreeLimits:
    __doc__ = """
    1. Configure Bucket:
        - deny storing backups on HV
        - set free limits and prices
    2. Create backups(auto, normal), templates, upload ovas
    3. Waiting for statistics
    4. Compare expected value with actual. Check that for onapp >= 5.9 auto 
    backups count limit/price also works
    """

    def setup_class(self):
        test.hv_types = ['kvm']  # because of OVA?
        test.load_env()

        if not test.env.backup_servers:
            pytest.skip('There is no backup servers attached to HV/HVZ')

        test.run_at(minutes=30)
        try:
            #  Select BS for OVA
            self.backup_server = BackupServer().get_for_ova()

            # Setup
            self.bucket = Bucket()
            self.bucket.label = self.__name__
            assert self.bucket.create()

            ac.add_env_to_bucket(self.bucket)

            # Configure bucket
            # 'Reset' bucket backup server zone settings
            for bs in test.env.backup_servers:
                ac.BackupServerZoneAC(
                    parent_obj=self.bucket,
                    target_id=bs.backup_server_group_id
                ).delete()

            bsz_ac = ac.BackupServerZoneAC(
                parent_obj=self.bucket,
                target_id=self.backup_server.backup_server_group_id
            )
            assert bsz_ac.create(), bsz_ac.error

            # #  Setup for base resources
            # self.bsz_ac = ac.BackupServerZoneAC(
            #     parent_obj=self.bucket,
            #     target_id=test.env.backup_servers[0].backup_server_group_id
            # ).get()
            self.bsz_rc = rc.BackupServerZoneRC(
                parent_obj=self.bucket,
                target_id=bsz_ac.target_id
            )
            assert self.bsz_rc.create(), self.bsz_rc.error

            # Deny using another backup server groups
            backup_server_group_ids = BSZ().get_unique_key_values('id')
            backup_server_group_ids.remove(
                test.env.backup_servers[0].backup_server_group_id
            )

            self.storage_disk_size_ac = ac.ComputeResourceStoringAC(
                parent_obj=self.bucket
            )
            self.storage_disk_size_ac.get()

            self.storage_disk_size_rc = rc.ComputeResourceStoringRC(
                parent_obj=self.bucket
            )
            assert self.storage_disk_size_rc.create(), \
                self.storage_disk_size_rc.error

            self.template_ac = ac.TemplatesAC(parent_obj=self.bucket)
            self.template_ac.get()

            self.template_rc = rc.TemplatesRC(parent_obj=self.bucket)
            assert self.template_rc.create(), self.template_rc.error

            self.backup_ac = ac.BackupsAC(parent_obj=self.bucket)
            self.backup_ac.get()

            self.backup_rc = rc.BackupsRC(parent_obj=self.bucket)
            assert self.backup_rc.create(), self.backup_rc.error

            # Set free limits for base resources
            self.storage_disk_size_ac.limits.limit = 0
            assert self.storage_disk_size_ac.edit(), \
                self.storage_disk_size_ac.error

            self.storage_disk_size_rc.prices.limit_free = 0
            self.storage_disk_size_rc.prices.price = 0
            assert self.storage_disk_size_rc.edit(), \
                self.storage_disk_size_rc.error

            self.template_ac.limits.limit = 0
            assert self.template_ac.edit(), self.template_ac.error

            self.template_rc.prices.limit_free = 0
            self.template_rc.prices.price = 0
            assert self.template_rc.edit(), self.template_rc.error

            self.backup_ac.limits.limit = 0
            assert self.backup_ac.edit(), self.backup_ac.error

            self.backup_rc.prices.limit_free = 0
            self.backup_rc.prices.price = 0
            assert self.backup_rc.edit(), self.backup_rc.error

            # Configure BSZ RC
            self.bsz_rc.prices.limit_template_free = 1
            self.bsz_rc.prices.limit_backup_free = 1
            self.bsz_rc.prices.limit_ova_free = 1
            self.bsz_rc.prices.limit_backup_disk_size_free = 1
            self.bsz_rc.prices.limit_template_disk_size_free = 1
            self.bsz_rc.prices.limit_ova_disk_size_free = 1
            self.bsz_rc.prices.price_template = 10
            self.bsz_rc.prices.price_template_disk_size = 10.2
            self.bsz_rc.prices.price_backup = 20
            self.bsz_rc.prices.price_backup_disk_size = 5.3
            self.bsz_rc.prices.price_ova = 30
            self.bsz_rc.prices.price_ova_disk_size = 25.48
            assert self.bsz_rc.edit(), self.bsz_rc.error

            # Create User and VS
            self.user = User(bucket=self.bucket)
            self.user.login = "bszfreelimitstest"
            self.user.password = test.generate_password()
            self.user.email = 'user@bszfreelimitstest.test'
            assert self.user.create()
            # Login as new user
            test.execute_as(self.user.login, self.user.password)

            self.vs = VirtualServer()
            self.vs.rate_limit = 0  #  Unlimited
            self.vs.label = self.__name__
            assert self.vs.create(), self.vs.error

            self.template = Template()

            self.backups = []
            self.templates = []
            self.ovas = []

            # Better with normal backups
            if test.onapp_settings.get().allow_incremental_backups:
                assert test.onapp_settings.set(allow_incremental_backups=False)
            self.user_stats = UserStats(self.user)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        ovas_to_delete = [
            o for o in OVA().get_all() if o.user_id == self.user.id
            ]
        for ova in ovas_to_delete:
            if ova.locked:
                ova.unlock()
            ova.delete()

        test.execute_as(test.login, test.password)
        attributes = (
            'vs',
            'user',
            'bucket'
        )
        test.clean_up_resources(attributes, self)

    def test_create_auto_backups(self):
        backups = self.vs.get_primary_disk().enable_auto_backups()
        assert len(backups) == 4

    def test_create_backups_to_reach_1GB_disk_size_limit(self):
        while self.vs.get_backups_size() < 1048576:
            backup = Backup(self.vs)
            backup.create()
            assert backup.backup_server_id

    def test_create_templates_to_reach_1GB_disk_size_limit(self):
        backup = self.vs.get_backups()[-1]
        # Check that impossible to create backups with more than 1GB total size.
        template_count = 1  # for template label TestBSZFreeLimits1
        while True:
            assert backup.convert(
                label=self.__class__.__name__ + str(template_count)
            ), backup.template.error
            template_count += 1
            self.templates.append(backup.template)
            if sum([t.template_size for t in self.templates]) > 1048576:
                break

    def test_upload_ovas_to_reach_1GB_disk_size_limit(self):
        counter = 1
        while True:
            if test.cp_version >= 5.7:
                ova_template_src = OVA()
                ova_template_src.label = "{}{}{}".format(
                    self.__class__.__name__,
                    'OVA',
                    counter
                )
                ova_template_src.min_memory_size = 512
                ova_template_src.version = 7.5
                ova_template_src.backup_server_id = self.backup_server.id
                ova_template_src.file_url = 'http://templates.repo.onapp.com/ova/centos6.ova'
                assert ova_template_src.upload(), ova_template_src.error
                self.ovas.append(ova_template_src)
                if sum([o.template_size for o in self.ovas]) > 1572864:
                    break
                counter += 1
                time.sleep(30)

            else:
                ova = OVA()
                ova.label = "{}{}{}".format(
                    self.__class__.__name__,
                    'OVA',
                    counter
                )
                ova.backup_server_id = self.backup_server.id
                ova.file_url = 'http://templates.repo.onapp.com/ova/centos6.ova'
                ova.operating_system_distro = ova.OPERATING_SYSTEM_DISTROS.rhel
                ova.operating_system = ova.OPERATING_SYSTEMS.linux
                assert ova.upload(), ova.error
                self.ovas.append(ova)
                if sum([o.template_size for o in self.ovas]) > 1572864:
                    break
                counter += 1
                time.sleep(30)

        test.log.info('***{}'.format(sum([o.template_size for o in self.ovas])))
        assert sum([o.template_size for o in self.ovas]) > 1048576

    def test_get_stat(self):
        self.user_stats.stats_waiter()
        self.user_stats.get_user_stat_for_the_last_hour()

    def test_backup_count_cost(self):
        assert price_comparator_with_round(
            self.user_stats.backup_count_cost,
            self.vs.get_backups_count() * self.bsz_rc.prices.price_backup,
            6
        )
        # assert self.user_stats.backup_count_cost == float(
        #     len(self.backups) * self.bsz_rc.prices.price_backup
        # )

    def test_backups_count_discount(self):
        assert price_comparator_with_round(
            self.user_stats.backup_count_discount_due_to_free,
            self.bsz_rc.prices.limit_backup_free *
            self.bsz_rc.prices.price_backup,
            6
        )
        # assert self.user_stats.backup_count_discount_due_to_free == \
        #        self.bsz_rc.prices.limit_backup_free * self.bsz_rc.prices.price_backup

    def test_template_count_cost(self):
        assert price_comparator_with_round(
            self.user_stats.template_count_cost,
            len(self.templates) * self.bsz_rc.prices.price_template,
            6
        )
        # assert self.user_stats.template_count_cost == float(
        #     len(self.templates) * self.bsz_rc.prices.price_template
        # )

    def test_templates_count_discount(self):
        assert price_comparator_with_round(
            self.user_stats.template_count_discount_due_to_free,
            self.bsz_rc.prices.limit_template_free *
            self.bsz_rc.prices.price_template,
            6
        )
        # assert self.user_stats.template_count_discount_due_to_free == \
        #        self.bsz_rc.prices.limit_template_free * self.bsz_rc.prices.price_template

    def test_backup_disk_size_cost(self):
        total_bu_size = self.vs.get_backups_size()
        test.log.info("Total_bu_size - {0}".format(total_bu_size))
        total_backup_disk_size_in_gb = total_bu_size / 1048576.0
        assert price_comparator_with_round(
            self.user_stats.backup_disk_size_cost,
            total_backup_disk_size_in_gb *
            self.bsz_rc.prices.price_backup_disk_size,
            6
        )
        # assert round(
        #     self.user_stats.backup_disk_size_cost, 2
        # ) == round(
        #     float(
        #         total_backup_disk_size_in_gb * self.bsz_rc.prices.price_backup_disk_size
        #     ), 2
        # )

    def test_template_disk_size_cost(self):
        total_template_size = sum([t.template_size for t in self.templates])
        test.log.info("Total_template_size - {0}".format(total_template_size))
        total_template_disk_size_in_gb = total_template_size / 1048576.0
        assert price_comparator_with_round(
            self.user_stats.template_disk_size_cost,
            total_template_disk_size_in_gb *
            self.bsz_rc.prices.price_template_disk_size,
            6
        )
        # assert round(
        #     self.user_stats.template_disk_size_cost, 2
        # ) == round(
        #     float(
        #         total_template_disk_size_in_gb * self.bsz_rc.prices.price_template_disk_size
        #     ), 2
        # )

    def test_backups_disk_size_discount(self):
        assert price_comparator_with_round(
            self.user_stats.backup_disk_size_discount_due_to_free,
            self.bsz_rc.prices.limit_backup_disk_size_free *
            self.bsz_rc.prices.price_backup_disk_size,
            6
        )
        # assert self.user_stats.backup_disk_size_discount_due_to_free == \
        #        self.bsz_rc.prices.limit_backup_disk_size_free * self.bsz_rc.prices.price_backup_disk_size

    def test_templates_disk_size_discount(self):
        assert price_comparator_with_round(
            self.user_stats.template_disk_size_discount_due_to_free,
            self.bsz_rc.prices.limit_template_disk_size_free *
            self.bsz_rc.prices.price_template_disk_size,
            6
        )
        # assert self.user_stats.template_disk_size_discount_due_to_free == \
        #        self.bsz_rc.prices.limit_template_disk_size_free * self.bsz_rc.prices.price_template_disk_size

    def test_ova_count_cost(self):
        assert price_comparator_with_round(
            self.user_stats.ova_count_cost,
            len(self.ovas) * self.bsz_rc.prices.price_ova,
            6
        )
        # assert self.user_stats.ova_count_cost == float(
        #     len(self.ovas) * self.bsz_rc.prices.price_ova
        # )

    def test_ovas_count_discount(self):
        assert price_comparator_with_round(
            self.user_stats.ova_count_discount_due_to_free,
            self.bsz_rc.prices.limit_ova_free * self.bsz_rc.prices.price_ova,
            6
        )
        # assert self.user_stats.ova_count_discount_due_to_free == \
        #        self.bsz_rc.prices.limit_ova_free * self.bsz_rc.prices.price_ova

    def test_ova_disk_size_cost(self):
        total_ova_size = sum([ova.template_size for ova in self.ovas])
        test.log.info("Total_ova_size - {0}".format(total_ova_size))
        total_ova_disk_size_in_gb = total_ova_size / 1048576.0
        assert price_comparator_with_round(
            self.user_stats.ova_size_cost,
            total_ova_disk_size_in_gb * self.bsz_rc.prices.price_ova_disk_size,
            6
        )
        # assert round(
        #     self.user_stats.ova_size_cost, 2
        # ) == round(
        #     float(
        #         total_ova_disk_size_in_gb * self.bsz_rc.prices.price_ova_disk_size
        #     ), 2
        # )

    def test_ovas_disk_size_discount(self):
        assert price_comparator_with_round(
            self.user_stats.ova_size_discount_due_to_free,
            self.bsz_rc.prices.limit_ova_disk_size_free *
            self.bsz_rc.prices.price_ova_disk_size,
            6
        )
        # assert self.user_stats.ova_size_discount_due_to_free == \
        #        self.bsz_rc.prices.limit_ova_disk_size_free * self.bsz_rc.prices.price_ova_disk_size

    def test_backup_cost_should_be_0(self):
        assert self.user_stats.backup_cost == 0.0

    def test_template_cost_should_be_0(self):
        assert self.user_stats.template_cost == 0.0

    def test_storage_disk_size_cost_should_be_0(self):
        assert self.user_stats.storage_disk_size_cost == 0.0

    def test_total_cost(self):
        total_cost = sum(
            [
                self.vs.get_backups_count() * self.bsz_rc.prices.price_backup,
                self.vs.get_backups_size() / 1048576.0 * self.bsz_rc.prices.price_backup_disk_size,
                len(self.templates) * self.bsz_rc.prices.price_template,
                sum([t.template_size for t in self.templates]) / 1048576.0 *
                self.bsz_rc.prices.price_template_disk_size,
                len(self.ovas) * self.bsz_rc.prices.price_ova,
                sum([ova.template_size for ova in self.ovas]) / 1048576.0 * self.bsz_rc.prices.price_ova_disk_size
            ]
        )
        assert price_comparator_with_round(
            total_cost,
            self.user_stats.total_cost,
            ndigits=2
        )

    def test_user_resources_cost(self):
        user_resources_cost = sum(
            [
                self.vs.get_backups_count() * self.bsz_rc.prices.price_backup,
                self.vs.get_backups_size() / 1048576.0 * self.bsz_rc.prices.price_backup_disk_size,
                len(self.templates) * self.bsz_rc.prices.price_template,
                sum([t.template_size for t in self.templates]) / 1048576.0 *
                self.bsz_rc.prices.price_template_disk_size,
                len(self.ovas) * self.bsz_rc.prices.price_ova,
                sum([ova.template_size for ova in self.ovas]) / 1048576.0 * self.bsz_rc.prices.price_ova_disk_size
            ]
        )
        assert price_comparator_with_round(
            user_resources_cost,
            self.user_stats.user_resources_cost,
            ndigits=2
        )

    def test_user_resources_discount_due_to_free(self):
        user_resources_discount_due_to_free = sum(
            [
                self.bsz_rc.prices.limit_backup_free * self.bsz_rc.prices.price_backup,
                self.bsz_rc.prices.limit_backup_disk_size_free *
                self.bsz_rc.prices.price_backup_disk_size,

                self.bsz_rc.prices.limit_template_free *
                self.bsz_rc.prices.price_template,
                self.bsz_rc.prices.limit_template_disk_size_free *
                self.bsz_rc.prices.price_template_disk_size,

                self.bsz_rc.prices.limit_ova_free * self.bsz_rc.prices.price_ova,
                self.bsz_rc.prices.limit_ova_disk_size_free *
                self.bsz_rc.prices.price_ova_disk_size,
            ]
        )
        assert price_comparator_with_round(
            user_resources_discount_due_to_free,
            self.user_stats.user_resources_discount_due_to_free,
            ndigits=2
        )

    def test_total_discount_due_to_free(self):
        total_discount_due_to_free = sum(
            [
                self.bsz_rc.prices.limit_backup_free * self.bsz_rc.prices.price_backup,
                self.bsz_rc.prices.limit_backup_disk_size_free *
                self.bsz_rc.prices.price_backup_disk_size,

                self.bsz_rc.prices.limit_template_free *
                self.bsz_rc.prices.price_template,
                self.bsz_rc.prices.limit_template_disk_size_free *
                self.bsz_rc.prices.price_template_disk_size,

                self.bsz_rc.prices.limit_ova_free * self.bsz_rc.prices.price_ova,
                self.bsz_rc.prices.limit_ova_disk_size_free *
                self.bsz_rc.prices.price_ova_disk_size,
            ]
        )
        assert price_comparator_with_round(
            total_discount_due_to_free,
            self.user_stats.total_discount_due_to_free,
            ndigits=2
        )

    def test_total_cost_with_discount(self):
        total_cost = sum(
            [
                self.vs.get_backups_count() * self.bsz_rc.prices.price_backup,
                self.vs.get_backups_size() / 1048576.0 * self.bsz_rc.prices.price_backup_disk_size,
                len(self.templates) * self.bsz_rc.prices.price_template,
                sum([t.template_size for t in self.templates]) / 1048576.0 *
                self.bsz_rc.prices.price_template_disk_size,
                len(self.ovas) * self.bsz_rc.prices.price_ova,
                sum([ova.template_size for ova in self.ovas]) / 1048576.0 * self.bsz_rc.prices.price_ova_disk_size
            ]
        )
        discount_due_to_free = sum(
            [
                self.bsz_rc.prices.limit_backup_free * self.bsz_rc.prices.price_backup,
                self.bsz_rc.prices.limit_backup_disk_size_free *
                self.bsz_rc.prices.price_backup_disk_size,

                self.bsz_rc.prices.limit_template_free *
                self.bsz_rc.prices.price_template,
                self.bsz_rc.prices.limit_template_disk_size_free *
                self.bsz_rc.prices.price_template_disk_size,

                self.bsz_rc.prices.limit_ova_free * self.bsz_rc.prices.price_ova,
                self.bsz_rc.prices.limit_ova_disk_size_free *
                self.bsz_rc.prices.price_ova_disk_size,
            ]
        )
        assert price_comparator_with_round(
            total_cost - discount_due_to_free,
            self.user_stats.total_cost_with_discount,
            ndigits=2
        )

    def test_delete_ova_files(self):
        assert False not in [o.delete_ova_files() for o in self.ovas]

    def test_get_a_new_stat(self):
        self.user_stats.stats_waiter()
        self.user_stats.get_user_stat_for_the_last_hour()

    def test_ova_count_cost_for_0_count(self):
        assert price_comparator_with_round(
            self.user_stats.ova_count_cost,
            len(self.ovas) * self.bsz_rc.prices.price_ova,
            6
        )
        # assert self.user_stats.ova_count_cost == len(self.ovas) * \
        #                                          self.bsz_rc.prices.price_ova

    def test_ova_count_discount_due_to_free_for_0_count(self):
        assert price_comparator_with_round(
            self.user_stats.ova_count_discount_due_to_free,
            self.bsz_rc.prices.price_ova * self.bsz_rc.prices.limit_ova_free,
            6
        )
        # assert self.user_stats.ova_count_discount_due_to_free == \
        #        self.bsz_rc.prices.price_ova * self.bsz_rc.prices.limit_ova_free

    def test_ova_disk_size_cost_for_0_disk_size(self):
        assert self.user_stats.ova_size_cost == 0.0
        assert self.user_stats.ova_size_discount_due_to_free == 0.0

    def test_total_cost_with_deleted_ova_files(self):
        total_cost = sum(
            [
                self.vs.get_backups_count() * self.bsz_rc.prices.price_backup,
                self.vs.get_backups_size() / 1048576.0 * self.bsz_rc.prices.price_backup_disk_size,
                len(self.templates) * self.bsz_rc.prices.price_template,
                sum([t.template_size for t in self.templates]) / 1048576.0 *
                self.bsz_rc.prices.price_template_disk_size,
                len(self.ovas) * self.bsz_rc.prices.price_ova,
                sum(
                    [ova.template_size for ova in OVA().get_own()]
                ) / 1048576.0 * self.bsz_rc.prices.price_ova_disk_size
            ]
        )
        assert price_comparator_with_round(
            total_cost,
            self.user_stats.total_cost,
            ndigits=2
        )

    def test_user_resources_cost_with_deleted_ova_files(self):
        user_resources_cost = sum(
            [
                self.vs.get_backups_count() * self.bsz_rc.prices.price_backup,
                self.vs.get_backups_size() / 1048576.0 * self.bsz_rc.prices.price_backup_disk_size,
                len(self.templates) * self.bsz_rc.prices.price_template,
                sum([t.template_size for t in self.templates]) / 1048576.0 *
                self.bsz_rc.prices.price_template_disk_size,
                len(self.ovas) * self.bsz_rc.prices.price_ova,
                sum(
                    [ova.template_size for ova in OVA().get_own()]
                ) / 1048576.0 * self.bsz_rc.prices.price_ova_disk_size
            ]
        )
        assert price_comparator_with_round(
            user_resources_cost,
            self.user_stats.user_resources_cost,
            ndigits=2
        )

    def test_user_resources_discount_due_to_free_with_deleted_ova_files(self):
        user_resources_discount_due_to_free = sum(
            [
                self.bsz_rc.prices.limit_backup_free * self.bsz_rc.prices.price_backup,
                self.bsz_rc.prices.limit_backup_disk_size_free *
                self.bsz_rc.prices.price_backup_disk_size,

                self.bsz_rc.prices.limit_template_free *
                self.bsz_rc.prices.price_template,
                self.bsz_rc.prices.limit_template_disk_size_free *
                self.bsz_rc.prices.price_template_disk_size,

                self.bsz_rc.prices.limit_ova_free * self.bsz_rc.prices.price_ova,
                # self.bsz_rc.prices.limit_ova_disk_size_free *  # deleted
                # self.bsz_rc.prices.price_ova_disk_size,
            ]
        )
        assert price_comparator_with_round(
            user_resources_discount_due_to_free,
            self.user_stats.user_resources_discount_due_to_free,
            ndigits=2
        )

    def test_total_discount_due_to_free_with_deleted_ova_files(self):
        total_discount_due_to_free = sum(
            [
                self.bsz_rc.prices.limit_backup_free * self.bsz_rc.prices.price_backup,
                self.bsz_rc.prices.limit_backup_disk_size_free *
                self.bsz_rc.prices.price_backup_disk_size,

                self.bsz_rc.prices.limit_template_free *
                self.bsz_rc.prices.price_template,
                self.bsz_rc.prices.limit_template_disk_size_free *
                self.bsz_rc.prices.price_template_disk_size,

                self.bsz_rc.prices.limit_ova_free * self.bsz_rc.prices.price_ova,
                # self.bsz_rc.prices.limit_ova_disk_size_free *
                # self.bsz_rc.prices.price_ova_disk_size,
            ]
        )
        assert price_comparator_with_round(
            total_discount_due_to_free,
            self.user_stats.total_discount_due_to_free,
            ndigits=2
        )

    def test_total_cost_with_discount_with_deleted_ova_files(self):
        total_cost = sum(
            [
                self.vs.get_backups_count() * self.bsz_rc.prices.price_backup,
                self.vs.get_backups_size() / 1048576.0 * self.bsz_rc.prices.price_backup_disk_size,
                len(self.templates) * self.bsz_rc.prices.price_template,
                sum([t.template_size for t in self.templates]) / 1048576.0 *
                self.bsz_rc.prices.price_template_disk_size,
                len(self.ovas) * self.bsz_rc.prices.price_ova,
                sum(
                    [ova.template_size for ova in OVA().get_own()]
                ) / 1048576.0 * self.bsz_rc.prices.price_ova_disk_size
            ]
        )

        discount_due_to_free = sum(
            [
                self.bsz_rc.prices.limit_backup_free * self.bsz_rc.prices.price_backup,
                self.bsz_rc.prices.limit_backup_disk_size_free *
                self.bsz_rc.prices.price_backup_disk_size,

                self.bsz_rc.prices.limit_template_free *
                self.bsz_rc.prices.price_template,
                self.bsz_rc.prices.limit_template_disk_size_free *
                self.bsz_rc.prices.price_template_disk_size,

                self.bsz_rc.prices.limit_ova_free * self.bsz_rc.prices.price_ova,
                # self.bsz_rc.prices.limit_ova_disk_size_free *
                # self.bsz_rc.prices.price_ova_disk_size,
            ]
        )
        assert price_comparator_with_round(
            total_cost - discount_due_to_free,
            self.user_stats.total_cost_with_discount,
            ndigits=2
        )
