__doc__ = "https://docs.onapp.com/agm/latest/buckets/billing-calculation#id-.BillingCalculationv6.0-hourly"

from onapp_helper import test
import pytest

from onapp_helper.bucket import access_controls as ac
from onapp_helper.bucket import rate_cards as rc
from onapp_helper.server import VirtualServer
from onapp_helper.user import User
from onapp_helper.bucket.bucket import Bucket
# Stats
from onapp_helper.stats.vm_stat import VmStat
from onapp_helper.stats.user_stats import UserStats
from test_helper.billingTH import *


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.limits
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.verbose
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
# @pytest.mark.incremental
class TestDSZFreeMonthlyLimits:
    def setup_class(self):
        test.load_env()
        test.run_at(minutes=45)

        try:
            # Setup
            self.bucket = Bucket()
            self.bucket.label = self.__name__
            assert self.bucket.create()

            ac.add_env_to_bucket(self.bucket)

            # Setup for base resources
            # self.dsz_ac = ac.DataStoreZoneAC(
            #     parent_obj=self.bucket,
            #     target_id=test.env.dsz.id
            # ).get()

            # Create User and VS
            self.user = User(bucket=self.bucket)
            self.user.login = "dszfreemonthlylimitstest"
            self.user.password = test.generate_password()
            self.user.email = 'user@dszfreemonthlylimitstest.test'
            assert self.user.create()
            # Login as new user
            test.execute_as(self.user.login, self.user.password)

            self.vs = VirtualServer()
            self.vs.rate_limit = 0  #  Unlimited
            self.vs.label = self.__name__
            assert self.vs.create(), self.vs.error

            # Set free limits and prices
            self.dsz_rc = rc.DataStoreZoneRC(
                parent_obj=self.bucket,
                target_id=test.env.dsz.id
            )
            self.dsz_rc.prices.limit_free_monthly = 6
            self.dsz_rc.prices.price_on = 100
            self.dsz_rc.prices.price_off = 2
            self.dsz_rc.prices.limit_data_read_free_monthly = 1.5
            self.dsz_rc.prices.price_data_read = 100
            self.dsz_rc.prices.limit_data_written_free_monthly = 3
            self.dsz_rc.prices.price_data_written = 100
            self.dsz_rc.prices.limit_reads_completed_free_monthly = 1
            self.dsz_rc.prices.price_reads_completed = 100
            self.dsz_rc.prices.limit_writes_completed_free_monthly = 1
            self.dsz_rc.prices.price_writes_completed = 100

            assert self.dsz_rc.create(), self.dsz_rc.error

            self.vm_stat = VmStat(parent_obj=self.vs)
            self.user_stat = UserStats(parent_obj=self.user)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        attributes = (
            'vs',
            'user',
            'bucket'
        )
        test.clean_up_resources(attributes, self)

    def test_generate_1GB_of_data(self):
        self.vs.execute(
            'cd {0} && dd if=/dev/urandom of=1GB bs=1024k count=1000'.format(
                self.vs.working_path
            )
        )
        assert '1GB' in self.vs.execute(
            'cd {0} && ls -l'.format(self.vs.working_path)
        )

    def test_copy_1GB_of_data(self):
        self.vs.execute(
            'cd {0} && cp ./1GB ./1GB_copy'.format(
                self.vs.working_path
            )
        )
        assert '1GB_copy' in self.vs.execute(
            'cd {0} && ls -l'.format(self.vs.working_path)
        )

    def test_get_stat(self):
        self.vm_stat.stats_waiter()
        self.vm_stat.get_hourly_stat_for_the_last_hour()
        self.user_stat.get_user_stat_for_the_last_hour()
        self.vs.get()
        self.user.get()

    def test_hourly_price_on(self):
        assert float(self.vs.price_per_hour) == self.vs.price_on_calculated(
            dsz_rc=self.dsz_rc
        ) == self.vs.total_disk_size * self.dsz_rc.prices.price_on

    def test_hourly_price_off(self):
        assert float(self.vs.price_per_hour_powered_off) == self.vs.price_off_calculated(
            dsz_rc=self.dsz_rc
        ) == self.vs.total_disk_size * self.dsz_rc.prices.price_off

    def test_disk_size_cost(self):
        if self.vs.booted:
            price = self.vs.disks_price_on
        else:
            price = self.vs.disks_price_off
        assert self.vm_stat.get_disks_disk_size_cost() == price

    def test_data_read_cost(self):
        test.log.info(
            "Data read value - {0}".format(
                self.vm_stat.get_disks_data_read_value()
            )
        )
        calculated_cost = self.vm_stat.get_disks_data_read_value() * self.dsz_rc.prices.price_data_read

        assert price_comparator_with_round(
            calculated_cost, self.vm_stat.get_disks_data_read_cost(), 2
        )

    def test_data_written_cost(self):
        test.log.info(
            "Data written value - {0}".format(
                self.vm_stat.get_disks_data_written_value()
            )
        )
        calculated_cost = self.vm_stat.get_disks_data_written_value() * self.dsz_rc.prices.price_data_written

        assert price_comparator_with_round(
            calculated_cost, self.vm_stat.get_disks_data_written_cost(), 2
        )

    def test_reads_completed_cost(self):
        calculated_cost = self.vm_stat.get_disks_output_requests_value() * \
                          self.dsz_rc.prices.price_reads_completed
        assert price_comparator_with_round(
            calculated_cost, self.vm_stat.get_disks_output_requests_cost(), 2
        )

    def test_writes_completed_cost(self):
        calculated_cost = self.vm_stat.get_disks_input_requests_value() * \
                          self.dsz_rc.prices.price_writes_completed
        assert price_comparator_with_round(
            calculated_cost, self.vm_stat.get_disks_input_requests_cost(), 2
        )

    def test_check_discount_due_to_free(self):
        """
        total_free should be the same as discount_due_to_free
        """
        total_disk_size_free = self.dsz_rc.prices.limit_free_monthly * \
                               self.dsz_rc.prices.price_on

        data_read_free = get_free_amount(
            self.vm_stat.get_disks_data_read_value(),
            self.dsz_rc.prices.limit_data_read_free_monthly
        ) * self.dsz_rc.prices.price_data_read

        data_written_free = get_free_amount(
            self.vm_stat.get_disks_data_written_value(),
            self.dsz_rc.prices.limit_data_written_free_monthly
        ) * self.dsz_rc.prices.price_data_written

        reads_completed_free = get_free_amount(
            self.vm_stat.get_disks_input_requests_value(),
            self.dsz_rc.prices.limit_reads_completed_free_monthly
        ) * self.dsz_rc.prices.price_reads_completed

        writes_completed_free = get_free_amount(
            self.vm_stat.get_disks_output_requests_value(),
            self.dsz_rc.prices.limit_writes_completed_free_monthly
        ) * self.dsz_rc.prices.price_writes_completed

        total_free = sum(
            [
                total_disk_size_free,
                data_read_free,
                data_written_free,
                reads_completed_free,
                writes_completed_free
            ]
        )

        assert price_comparator_with_round(
            total_free, self.user.discount_due_to_free, 2
        )

    def test_change_limit_free_monthly(self):
        self.dsz_rc.prices.limit_free_monthly = 1
        assert self.dsz_rc.edit(), self.dsz_rc.error

    def test_generate_1GB_of_data_to_check_free_monthly_limit(self):
        self.vs.execute(
            'cd {0} && dd if=/dev/urandom of=1GB bs=1024k count=1000'.format(
                self.vs.working_path
            )
        )
        assert '1GB' in self.vs.execute(
            'cd {0} && ls -l'.format(self.vs.working_path)
        )

    def test_copy_1GB_of_data_to_check_free_monthly_limit(self):
        self.vs.execute(
            'cd {0} && cp ./1GB ./1GB_copy'.format(self.vs.working_path)
        )
        assert '1GB_copy' in self.vs.execute(
            'cd {0} && ls -l'.format(self.vs.working_path)
        )

    def test_get_stat_to_check_free_monthly_limit(self):
        self.vm_stat.stats_waiter()
        self.vm_stat.get_hourly_stat_for_the_last_hour()
        self.user_stat.get_user_stat_for_the_last_hour()
        self.vs.get()
        self.user.get()

    def test_hourly_price_on_to_check_free_monthly_limit(self):
        assert float(self.vs.price_per_hour) == self.vs.price_on_calculated(
            dsz_rc=self.dsz_rc
        ) == self.vs.total_disk_size * self.dsz_rc.prices.price_on

    def test_hourly_price_off_to_check_free_monthly_limit(self):
        assert float(self.vs.price_per_hour_powered_off) == self.vs.price_off_calculated(
            dsz_rc=self.dsz_rc
        ) == self.vs.total_disk_size * self.dsz_rc.prices.price_off

    def test_disk_size_cost_to_check_free_monthly_limit(self):
        if self.vs.booted:
            price = self.vs.disks_price_on
        else:
            price = self.vs.disks_price_off
        assert self.vm_stat.get_disks_disk_size_cost() == price

    def test_data_read_cost_to_check_free_monthly_limit(self):
        test.log.info(
            "Data read value - {0}".format(
                self.vm_stat.get_disks_data_read_value()
            )
        )
        calculated_cost = self.vm_stat.get_disks_data_read_value() * self.dsz_rc.prices.price_data_read

        assert price_comparator_with_round(
            calculated_cost, self.vm_stat.get_disks_data_read_cost(), 2
        )

    def test_data_written_cost_to_check_free_monthly_limit(self):
        test.log.info(
            "Data written value - {0}".format(
                self.vm_stat.get_disks_data_written_value()
            )
        )
        calculated_cost = self.vm_stat.get_disks_data_written_value() * self.dsz_rc.prices.price_data_written

        assert price_comparator_with_round(
            calculated_cost, self.vm_stat.get_disks_data_written_cost(), 2
        )

    def test_reads_completed_cost_to_check_free_monthly_limit(self):
        calculated_cost = self.vm_stat.get_disks_output_requests_value() * \
                          self.dsz_rc.prices.price_reads_completed
        assert price_comparator_with_round(
            calculated_cost, self.vm_stat.get_disks_output_requests_cost(), 2
        )

    def test_writes_completed_cost_to_check_free_monthly_limit(self):
        calculated_cost = self.vm_stat.get_disks_input_requests_value() * \
                          self.dsz_rc.prices.price_writes_completed
        assert price_comparator_with_round(
            calculated_cost, self.vm_stat.get_disks_input_requests_cost(), 2
        )

    def test_check_discount_due_to_free_to_check_free_monthly_limit(self):
        total_disk_size_free = self.dsz_rc.prices.limit_free_monthly * self.dsz_rc.prices.price_on

        vm_stats = self.vm_stat.get_hourly_stat() # get all vs stats ass list
        #  of objects

        data_read_free = get_free_amount(
            sum([vm_stat.get_disks_data_read_value() for vm_stat in vm_stats]),
            self.dsz_rc.prices.limit_data_read_free_monthly
        ) * self.dsz_rc.prices.price_data_read

        data_written_free = get_free_amount(
            sum([vm_stat.get_disks_data_written_value() for vm_stat in vm_stats]),
            self.dsz_rc.prices.limit_data_written_free_monthly
        ) * self.dsz_rc.prices.price_data_written

        reads_completed_free = get_free_amount(
            sum([vm_stat.get_disks_input_requests_value() for vm_stat in vm_stats]),
            self.dsz_rc.prices.limit_reads_completed_free_monthly
        ) * self.dsz_rc.prices.price_reads_completed

        writes_completed_free = get_free_amount(
            sum([vm_stat.get_disks_output_requests_value() for vm_stat in vm_stats]),
            self.dsz_rc.prices.limit_writes_completed_free_monthly
        ) * self.dsz_rc.prices.price_writes_completed

        total_free = sum(
            [
                total_disk_size_free,
                data_read_free,
                data_written_free,
                reads_completed_free,
                writes_completed_free
            ]
        )

        assert price_comparator_with_round(
            total_free, self.user.discount_due_to_free, 2
        )

    def test_check_user_billing_details_according_to_monthly_limits(self):
        assert self.user.get(), self.user.error
        assert self.user_stat.get(), self.user_stat.error

        # total cost
        vm_cost_for_first_hour = sum(
            [
                6 * self.dsz_rc.prices.price_on
            ]
        )
        vm_usage_cost_for_first_hour = sum(
            [
                1 * self.dsz_rc.prices.price_data_read,
                2 * self.dsz_rc.prices.price_data_written
            ]
        )
        vm_cost_for_second_hour = sum(
            [
                6 * self.dsz_rc.prices.price_on
            ]
        )
        vm_usage_cost_for_second_hour = sum(
            [
                1 * self.dsz_rc.prices.price_data_read,
                2 * self.dsz_rc.prices.price_data_written
            ]
        )
        total_cost_expected = sum(
            [
                vm_cost_for_first_hour,
                vm_usage_cost_for_first_hour,
                vm_cost_for_second_hour,
                vm_usage_cost_for_second_hour
            ]
        )

        assert price_comparator(
            total_cost_expected,
            self.user.total_amount,
            precision=0.5
        )

        assert price_comparator(
            total_cost_expected,
            self.user_stat.total_cost,
            precision=0.5
        )

        # discount due to free
        vm_discount_for_month = sum(
            [
                1 * self.dsz_rc.prices.price_on,
            ]
        )
        vm_usage_discount_for_month = sum(
            [
                get_free_amount(
                    1 + 1, self.dsz_rc.prices.limit_data_read_free_monthly
                ) * self.dsz_rc.prices.price_data_read,
                get_free_amount(
                    2 + 2, self.dsz_rc.prices.limit_data_written_free_monthly
                ) * self.dsz_rc.prices.price_data_written,

            ]
        )

        discount_expected = sum(
            [
                vm_discount_for_month,
                vm_usage_discount_for_month,
            ]
        )

        assert price_comparator(
            discount_expected,
            self.user.discount_due_to_free,
            precision=0.5
        )

        assert price_comparator(
            discount_expected,
            self.user_stat.total_discount_due_to_free,
            precision=0.5
        )

        # total cost with discount
        total_cost_with_discount_expected = total_cost_expected - discount_expected

        assert price_comparator(
            total_cost_with_discount_expected,
            self.user.total_amount_with_discount,
            precision=0.5
        )

        assert price_comparator(
            total_cost_with_discount_expected,
            self.user_stat.total_cost_with_discount,
            precision=0.5
        )

        # outstanding amount
        outstanding_amount_expected = total_cost_with_discount_expected

        assert price_comparator(
            outstanding_amount_expected,
            self.user.outstanding_amount,
            precision=0.5
        )

        # monthly_discount_due_to_free from user_stat
        if test.cp_version >= 6.0:
            assert self.user_stat.monthly_discount_due_to_free == \
                   pytest.approx(discount_expected)

        # monthly fee
        assert 0.0 == self.user.monthly_price

        # payments
        assert 0.0 == self.user.payment_amount

        # Check monthly bills
        mbs = self.user.monthly_bills()
        if mbs:
            # https://onappdev.atlassian.net/browse/CORE-11744
            assert mbs[0].cost == self.user.total_amount_with_discount
        else:
            assert False, "No monthly bills available for user {}".format(
                self.user.id
            )
