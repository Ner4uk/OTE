import pytest
from onapp_helper import test

from onapp_helper.bucket import access_controls as ac
from onapp_helper.bucket import rate_cards as rc
from onapp_helper.server import VirtualServer
from onapp_helper.user import User
from onapp_helper.bucket.bucket import Bucket
# Stats
from onapp_helper.stats.vm_stat import VmStat
from onapp_helper.stats.user_stats import UserStats

from test_helper.billingTH import price_comparator_with_round, get_free_amount


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.limits
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
class TestHVZFreeLimits:
    def setup_class(self):
        test.load_env()
        test.run_at(minutes=40)

        try:
            # Setup
            self.bucket = Bucket()
            self.bucket.label = self.__name__
            assert self.bucket.create()

            ac.add_env_to_bucket(self.bucket)

            # Setup for base resources
            # self.hvz_ac = ac.ComputeZoneAC(
            #     parent_obj=self.bucket,
            #     target_id=test.env.hvz.id
            # ).get()

            # Create User and VS
            self.user = User(bucket=self.bucket)
            self.user.login = "hvzfreelimitstest"
            self.user.password = test.generate_password()
            self.user.email = 'user@hvzfreelimitstest.test'
            assert self.user.create()
            # Login as new user
            test.execute_as(self.user.login, self.user.password)

            self.vs = VirtualServer()
            self.vs.rate_limit = 0  #  Unlimited
            self.vs.label = self.__name__
            self.vs.cpus = 2
            self.vs.memory = 512
            self.vs.cpu_shares = 50
            assert self.vs.create(), self.vs.error

            # Set free limits to RC
            self.hvz_rc = rc.ComputeZoneRC(
                parent_obj=self.bucket,
                target_id=test.env.hvz.id
            )
            self.hvz_rc.prices.limit_free_cpu = self.vs.cpus - 1
            self.hvz_rc.prices.price_on_cpu = 100
            self.hvz_rc.prices.price_off_cpu = 2
            self.hvz_rc.prices.limit_free_cpu_share = self.vs.cpu_shares
            self.hvz_rc.prices.price_on_cpu_share = 100
            self.hvz_rc.prices.price_off_cpu_share = 2
            self.hvz_rc.prices.limit_free_memory = self.vs.memory - 256
            self.hvz_rc.prices.price_on_memory = 100
            self.hvz_rc.prices.price_off_memory = 2
            assert self.hvz_rc.create(), self.hvz_rc.error

            self.vm_stat = VmStat(parent_obj=self.vs)
            self.user_stat = UserStats(parent_obj=self.user)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        attributes = (
            'user',
            'bucket'
        )
        test.clean_up_resources(attributes, self)

    def test_get_stat(self):
        self.vm_stat.stats_waiter()
        self.vm_stat.get_hourly_stat_for_the_last_hour()
        self.user_stat.get_user_stat_for_the_last_hour()
        self.vs.get()
        self.user.get()

    def test_check_hourly_price_on(self):
        assert float(self.vs.price_per_hour) == self.vs.price_on_calculated(
            hvz_rc=self.hvz_rc
        )

    def test_check_hourly_price_off(self):
        assert float(self.vs.price_per_hour_powered_off) == self.vs.price_off_calculated(
             hvz_rc=self.hvz_rc
        )

    def test_cpu_cost(self):
        if self.vs.booted:
            price = self.vs.cpu_price_on
        else:
            price = self.vs.cpu_price_off
        assert self.vm_stat.get_vm_cpus_cost() == price

    def test_cpu_share_cost(self):
        if self.vs.booted:
            price = self.vs.cpu_shares_price_on
        else:
            price = self.vs.cpu_shares_price_off
        assert self.vm_stat.get_vm_cpu_shares_cost() == price

    def test_memory_cost(self):
        if self.vs.booted:
            price = self.vs.memory_price_on
        else:
            price = self.vs.memory_price_off
        assert self.vm_stat.get_vm_memory_cost() == price

    def test_check_discount_due_to_free(self):
        cpu_cost_free = get_free_amount(
            self.vs.cpus,
            self.hvz_rc.prices.limit_free_cpu
        ) * self.hvz_rc.prices.price_on_cpu

        cpu_share_cost_free = get_free_amount(
            self.vs.cpu_shares,
            self.hvz_rc.prices.limit_free_cpu_share
        ) * self.hvz_rc.prices.price_on_cpu_share

        memory_cost_free = get_free_amount(
            self.vs.memory,
            self.hvz_rc.prices.limit_free_memory
        ) * self.hvz_rc.prices.price_on_memory

        total_free = sum(
            [
                cpu_cost_free,
                cpu_share_cost_free,
                memory_cost_free
            ]
        )
        assert price_comparator_with_round(
            total_free, self.user_stat.total_discount_due_to_free, 2
        )

        assert price_comparator_with_round(
            total_free, self.user_stat.vm_discount_due_to_free, 2
        )

        assert price_comparator_with_round(
            total_free, self.user.discount_due_to_free, 2
        )
