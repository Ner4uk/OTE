__doc__ = "https://docs.onapp.com/agm/latest/buckets/billing-calculation#id-.BillingCalculationv6.0-hourly"

import pytest
from onapp_helper import test

from onapp_helper.bucket import access_controls as ac
from onapp_helper.bucket import rate_cards as rc
from onapp_helper.server import VirtualServer
from onapp_helper.user import User
from onapp_helper.bucket.bucket import Bucket
# Stats
from onapp_helper.stats.vm_stat import VmStat
from onapp_helper.stats.user_stats import UserStats

from test_helper.billingTH import *
from onapp_helper.ip_address import IpAddress

#from onapp_helper. import UserStats


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.limits
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.verbose
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
class TestNTZFreeMonthlyLimits:
    def setup_class(self):
        test.load_env()
        test.run_at(minutes=45)
        test.cp.generate_10MB_test_file()

        try:
            # Setup
            self.bucket = Bucket()
            self.bucket.label = self.__name__
            assert self.bucket.create()

            ac.add_env_to_bucket(self.bucket)

            # Create User and VS
            self.user = User(bucket=self.bucket)
            self.user.login = "ntzfreemonthlylimitstest"
            self.user.password = test.generate_password()
            self.user.email = 'user@ntzfreemonthlylimitstest.test'
            assert self.user.create()
            # Login as new user
            test.execute_as(self.user.login, self.user.password)

            self.vs = VirtualServer()
            self.vs.rate_limit = 0  #  Unlimited
            self.vs.label = self.__name__
            assert self.vs.create(), self.vs.error

            # RC
            self.ntz_rc = rc.NetworkZoneRC(
                parent_obj=self.bucket,
                target_id=test.env.netz.id
            )
            self.ntz_rc.prices.limit_ip_free_monthly = 1
            self.ntz_rc.prices.price_ip_on = 100
            self.ntz_rc.prices.price_ip_off = 2
            self.ntz_rc.prices.limit_rate_free = int(self.vs.port_speed() / 2)
            self.ntz_rc.prices.price_rate_on = 100
            self.ntz_rc.prices.price_rate_off = 2
            self.ntz_rc.prices.limit_data_received_free_monthly = 1
            self.ntz_rc.prices.price_data_received = 100
            self.ntz_rc.prices.limit_data_sent_free_monthly = 1
            self.ntz_rc.prices.price_data_sent = 100
            assert self.ntz_rc.create(), self.ntz_rc.error

            self.vm_stat = VmStat(parent_obj=self.vs)
            self.user_stat = UserStats(parent_obj=self.user)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        attributes = (
            'vs',
            'user',
            'bucket',
        )
        test.clean_up_resources(attributes, self)

    def test_download_500MB_of_data(self):
        for i in range(5):
            self.vs.download_100MB_of_data()

    def test_get_stat(self):
        self.vm_stat.stats_waiter()
        self.vm_stat.get_hourly_stat_for_the_last_hour()
        self.user_stat.get_user_stat_for_the_last_hour()
        self.vs.get()
        self.user.get()

    def test_hourly_price_on(self):
        expected = self.vs.price_on_calculated(
            ntz_rc=self.ntz_rc
        )
        actual = float(self.vs.price_per_hour)
        print('Expected: {}'.format(expected))
        print('Actual: {}'.format(actual))
        assert actual == expected

    def test_hourly_price_off(self):
        expected = self.vs.price_off_calculated(
            ntz_rc=self.ntz_rc
        )
        actual = float(self.vs.price_per_hour_powered_off)
        print('Expected: {}'.format(expected))
        print('Actual: {}'.format(actual))
        assert actual == expected

    def test_ip_address_cost(self):
        if self.vs.booted:
            expected = self.vs.ip_price_on
        else:
            expected = self.vs.ip_price_off

        # expected = price * (self.vm_stat.vm_last_hour_stat.ip_addresses.value - self.ntz_br.own_limits.limit_ip_free)
        actual = self.vm_stat.get_networks_ip_addresses_cost()
        print('Expected: {}'.format(expected))
        print('Actual: {}'.format(actual))
        assert actual == expected

    def test_rate_cost(self):
        if self.vs.booted:
            expected = self.vs.rate_limit_price_on
        else:
            expected = self.vs.rate_limit_price_off
        # rate_value = self.vm_stat.vm_last_hour_stat.rate.value
        # if not rate_value: # 0
        #     rate_value = self.vs.port_speed()
        # expected = price * (rate_value - self.ntz_br.own_limits.limit_rate_free)
        actual = self.vm_stat.get_networks_port_speed_cost()
        print('Expected: {}'.format(expected))
        print('Actual: {}'.format(actual))
        assert actual == expected

    def test_data_received_cost(self):
        calculated_cost = self.vm_stat.get_networks_data_received_value() * self.ntz_rc.prices.price_data_received
        print(
            'Data received cost: \n\t calculated - {}\n\t real - {}'.format(
                calculated_cost, self.vm_stat.get_networks_data_received_cost()
            )
        )
        assert price_comparator_with_round(
            calculated_cost, self.vm_stat.get_networks_data_received_cost(), 2
        )

    def test_data_sent_cost(self):
        calculated_cost = self.vm_stat.get_networks_data_sent_value() * self.ntz_rc.prices.price_data_sent
        print(
            'Data sent cost: \n\t calculated - {}\n\t real - {}'.format(
                calculated_cost, self.vm_stat.get_networks_data_sent_cost()
            )
        )
        assert price_comparator_with_round(
            calculated_cost, self.vm_stat.get_networks_data_sent_cost(), 2
        )

    def test_check_discount_due_to_free(self):
        # rate_cost_free = get_free_amount(
        #     self.vs.port_speed(),
        #     self.ntz_rc.prices.limit_rate_free
        # ) * self.ntz_rc.prices.price_rate_on

        ip_cost_free = get_free_amount(
            len(self.vs.ip_address_join.get_all()),
            self.ntz_rc.prices.limit_ip_free_monthly
        ) * self.ntz_rc.prices.price_ip_on

        data_sent_cost_free = get_free_amount(
            self.vm_stat.get_networks_data_sent_value(),
            self.ntz_rc.prices.limit_data_sent_free_monthly
        ) * self.ntz_rc.prices.price_data_sent

        data_received_cost_free = get_free_amount(
            self.vm_stat.get_networks_data_received_value(),
            self.ntz_rc.prices.limit_data_received_free_monthly
        ) * self.ntz_rc.prices.price_data_received

        total_free = sum(
            [
                # rate_cost_free,
                ip_cost_free,
                data_sent_cost_free,
                data_received_cost_free
            ]
        )

        assert price_comparator_with_round(
            total_free, self.user.discount_due_to_free, 2
        )

    def test_download_2GB_of_data_to_check_free_monthly_limit(self):
        for i in range(20):
            self.vs.download_100MB_of_data()

    def test_add_one_more_ip_address_to_vs(self):
        ip_address = IpAddress(parent_obj=test.env.net).get_free()

        if test.cp_version <= 5.3:
            assert self.vs.ip_address_join.assign_to_server(
                address=ip_address.address
            ), self.vs.ip_address_join.error
        else:
            assert self.vs.ip_address_join.assign_to_server(
                ip_address_id=ip_address.id
            ), self.vs.ip_address_join.error

    def test_get_stat_to_check_free_monthly_limit(self):
        self.vm_stat.stats_waiter()
        # self.vm_stat.get_hourly_stat_for_the_last_hour()
        self.user_stat.get_user_stat_for_the_last_hour()
        self.vs.get()
        self.user.get()

    def test_check_hourly_price_on(self):
        expected = self.vs.price_on_calculated(
            ntz_rc=self.ntz_rc
        )
        actual = float(self.vs.price_per_hour)
        print('Expected: {}'.format(expected))
        print('Actual: {}'.format(actual))
        assert actual == expected

    def test_check_hourly_price_off(self):
        expected = self.vs.price_off_calculated(
            ntz_rc=self.ntz_rc
        )
        actual = float(self.vs.price_per_hour_powered_off)
        print('Expected: {}'.format(expected))
        print('Actual: {}'.format(actual))
        assert actual == expected

    def test_ip_address_cost_to_check_free_monthly_limit(self):
        if self.vs.booted:
            expected = self.vs.ip_price_on
        else:
            expected = self.vs.ip_price_off

        # expected = price * (self.vm_stat.vm_last_hour_stat.ip_addresses.value - self.ntz_br.own_limits.limit_ip_free)

        vm_stat = self.vm_stat.get_hourly_stat()
        actual = vm_stat[-1].get_networks_ip_addresses_cost()
        print('Expected: {}'.format(expected))
        print('Actual: {}'.format(actual))
        assert actual == expected

    def test_rate_cost_to_check_free_monthly_limit(self):
        if self.vs.booted:
            expected = self.vs.rate_limit_price_on
        else:
            expected = self.vs.rate_limit_price_off
        # rate_value = self.vm_stat.vm_last_hour_stat.rate.value
        # if not rate_value: # 0
        #     rate_value = self.vs.port_speed()
        # expected = price * (rate_value - self.ntz_br.own_limits.limit_rate_free)

        vm_stat = self.vm_stat.get_hourly_stat()
        actual = vm_stat[-1].get_networks_port_speed_cost()
        print('Expected: {}'.format(expected))
        print('Actual: {}'.format(actual))
        assert actual == expected

    def test_data_received_cost_to_check_free_monthly_limit(self):
        vm_stat = self.vm_stat.get_hourly_stat()
        calculated_cost = (
                vm_stat[-1].get_networks_data_received_value() *
                self.ntz_rc.prices.price_data_received
        )
        print(
            'Data received cost: \n\t calculated - {}\n\t real - {}'.format(
                calculated_cost, vm_stat[-1].get_networks_data_received_cost()
            )
        )
        assert price_comparator_with_round(
            calculated_cost, vm_stat[-1].get_networks_data_received_cost(), 2
        )

    def test_data_sent_cost_to_check_free_monthly_limit(self):
        vm_stat = self.vm_stat.get_hourly_stat()
        calculated_cost = vm_stat[-1].get_networks_data_sent_value() * \
                          self.ntz_rc.prices.price_data_sent
        print(
            'Data sent cost: \n\t calculated - {}\n\t real - {}'.format(
                calculated_cost, vm_stat[-1].get_networks_data_sent_cost()
            )
        )
        assert price_comparator_with_round(
            calculated_cost, vm_stat[-1].get_networks_data_sent_cost(), 2
        )

    def test_check_discount_due_to_free_to_check_free_monthly_limit(self):
        vm_stat = self.vm_stat.get_hourly_stat()
        # rate_cost_free = get_free_amount(
        #     self.vs.port_speed(),
        #     self.ntz_rc.prices.limit_rate_free
        # ) * self.ntz_rc.prices.price_rate_on

        ip_cost_free = get_free_amount(
            len(self.vs.ip_address_join.get_all()),
            self.ntz_rc.prices.limit_ip_free_monthly
        ) * self.ntz_rc.prices.price_ip_on

        network_data_sent = [
            stat.get_networks_data_sent_value() for stat in vm_stat
        ]
        data_sent_cost_free = get_free_amount(
            sum(network_data_sent),
            self.ntz_rc.prices.limit_data_sent_free_monthly
        ) * self.ntz_rc.prices.price_data_sent

        networks_data_received = [
            stat.get_networks_data_received_value() for stat in vm_stat
        ]
        data_received_cost_free = get_free_amount(
            sum(networks_data_received),
            self.ntz_rc.prices.limit_data_received_free_monthly
        ) * self.ntz_rc.prices.price_data_received

        total_free = sum(
            [
                # rate_cost_free,
                ip_cost_free,
                data_sent_cost_free,
                data_received_cost_free
            ]
        )

        assert price_comparator_with_round(
            total_free, self.user.discount_due_to_free, 2
        )

    def test_check_user_billing_details_according_to_monthly_limits(self):
        assert self.user.get(), self.user.error
        assert self.user_stat.get(), self.user_stat.error

        # total cost
        vm_cost_for_first_hour = sum(
            [
                self.vs.port_speed() * self.ntz_rc.prices.price_rate_on,
                1 * self.ntz_rc.prices.price_ip_on,
            ]
        )
        vm_usage_cost_for_first_hour = sum(
            [
                0.5 * self.ntz_rc.prices.price_data_received,
            ]
        )
        vm_cost_for_second_hour = sum(
            [
                self.vs.port_speed() * self.ntz_rc.prices.price_rate_on,
                2 * self.ntz_rc.prices.price_ip_on,
            ]
        )
        vm_usage_cost_for_second_hour = sum(
            [
                2 * self.ntz_rc.prices.price_data_received,
            ]
        )
        total_cost_expected = sum(
            [
                vm_cost_for_first_hour,
                vm_usage_cost_for_first_hour,
                vm_cost_for_second_hour,
                vm_usage_cost_for_second_hour
            ]
        )

        assert price_comparator(
            total_cost_expected,
            self.user.total_amount,
            precision=0.5
        )

        assert price_comparator(
            total_cost_expected,
            self.user_stat.total_cost,
            precision=0.5
        )

        # discount due to free
        vm_discount_for_first_hour = sum(
            [
                self.vs.port_speed() * self.ntz_rc.prices.price_rate_on,
                get_free_amount(
                    1, self.ntz_rc.prices.limit_ip_free_monthly
                ) * self.ntz_rc.prices.price_ip_on,
            ]
        )
        vm_usage_discount_for_first_hour = sum(
            [
                get_free_amount(
                    0.5, self.ntz_rc.prices.limit_data_received_free_monthly
                ) * self.ntz_rc.prices.price_data_received,
            ]
        )
        vm_discount_for_second_hour = sum(
            [
                self.vs.port_speed() * self.ntz_rc.prices.price_rate_on,
                get_free_amount(
                    2, self.ntz_rc.prices.limit_ip_free_monthly
                ) * self.ntz_rc.prices.price_ip_on,
            ]
        )
        vm_usage_discount_for_second_hour = sum(
            [
                get_free_amount(
                    2, self.ntz_rc.prices.limit_data_received_free_monthly
                ) * self.ntz_rc.prices.price_data_received,
            ]
        )
        discount_expected = sum(
            [
                vm_discount_for_first_hour,
                vm_usage_discount_for_first_hour,
                vm_discount_for_second_hour,
                vm_usage_discount_for_second_hour
            ]
        )

        assert price_comparator(
            discount_expected,
            self.user.discount_due_to_free,
            precision=0.5
        )

        assert price_comparator(
            discount_expected,
            self.user_stat.total_discount_due_to_free,
            precision=0.5
        )

        # total cost with discount
        total_cost_with_discount_expected = total_cost_expected - discount_expected

        assert price_comparator(
            total_cost_with_discount_expected,
            self.user.total_amount_with_discount,
            precision=0.5
        )

        assert price_comparator(
            total_cost_with_discount_expected,
            self.user_stat.total_cost_with_discount,
            precision=0.5
        )

        # outstanding amount
        outstanding_amount_expected = total_cost_with_discount_expected

        assert price_comparator(
            outstanding_amount_expected,
            self.user.outstanding_amount,
            precision=0.5
        )

        # monthly_discount_due_to_free from user_stat
        if test.cp_version >= 6.0:
            assert self.user_stat.monthly_discount_due_to_free == \
                   pytest.approx(discount_expected)

        # monthly fee
        assert 0.0 == self.user.monthly_price

        # payments
        assert 0.0 == self.user.payment_amount

        # Check monthly bills
        mbs = self.user.monthly_bills()
        if mbs:
            # https://onappdev.atlassian.net/browse/CORE-11744
            assert mbs[0].cost == self.user.total_amount
        else:
            assert False, "No monthly bills available for user {}".format(
                self.user.id
            )
