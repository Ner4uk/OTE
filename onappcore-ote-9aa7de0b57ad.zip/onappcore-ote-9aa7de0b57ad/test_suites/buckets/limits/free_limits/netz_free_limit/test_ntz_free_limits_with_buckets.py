__doc__ = "https://docs.onapp.com/agm/latest/buckets/billing-calculation#id-.BillingCalculationv6.0-hourly"

import pytest
from onapp_helper import test

from onapp_helper.bucket import access_controls as ac
from onapp_helper.bucket import rate_cards as rc
from onapp_helper.server import VirtualServer
from onapp_helper.user import User
from onapp_helper.bucket.bucket import Bucket
# Stats
from onapp_helper.stats.vm_stat import VmStat
from onapp_helper.stats.user_stats import UserStats

from test_helper.billingTH import price_comparator_with_round, get_free_amount
from onapp_helper.ip_address import IpAddress

#from onapp_helper. import UserStats


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.limits
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
@pytest.mark.verbose
class TestNTZFreeLimits:
    def setup_class(self):
        test.load_env()
        test.run_at(minutes=40)
        test.cp.generate_10MB_test_file()

        try:
            # Setup
            self.bucket = Bucket()
            self.bucket.label = self.__name__
            assert self.bucket.create()

            ac.add_env_to_bucket(self.bucket)

            # Create User and VS
            self.user = User(bucket=self.bucket)
            self.user.login = "ntzfreelimitstest"
            self.user.password = test.generate_password()
            self.user.email = 'user@ntzfreelimitstest.test'
            assert self.user.create()
            # Login as new user
            test.execute_as(self.user.login, self.user.password)

            self.vs = VirtualServer()
            self.vs.rate_limit = 0  #  Unlimited
            self.vs.label = self.__name__
            assert self.vs.create(), self.vs.error

            # RC
            self.ntz_rc = rc.NetworkZoneRC(
                parent_obj=self.bucket,
                target_id=test.env.netz.id
            )
            self.ntz_rc.prices.limit_ip_free = 1
            self.ntz_rc.prices.price_ip_on = 100
            self.ntz_rc.prices.price_ip_off = 2
            self.ntz_rc.prices.limit_rate_free = int(self.vs.port_speed() / 2)
            self.ntz_rc.prices.price_rate_on = 100
            self.ntz_rc.prices.price_rate_off = 2
            self.ntz_rc.prices.limit_data_received_free = 1
            self.ntz_rc.prices.price_data_received = 100
            self.ntz_rc.prices.limit_data_sent_free = 1
            self.ntz_rc.prices.price_data_sent = 100
            assert self.ntz_rc.create(), self.ntz_rc.error

            self.vm_stat = VmStat(parent_obj=self.vs)
            self.user_stat = UserStats(parent_obj=self.user)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        attributes = (
            'vs',
            'user',
            'bucket',
        )
        test.clean_up_resources(attributes, self)

    def test_download_2GB_of_data(self):
        for i in range(20):
            self.vs.download_100MB_of_data()

    def test_add_one_more_ip_address_to_vs(self):
        ip_address = IpAddress(parent_obj=test.env.net).get_free()

        if test.cp_version <= 5.3:
            assert self.vs.ip_address_join.assign_to_server(
                address=ip_address.address
            ), self.vs.ip_address_join.error
        else:
            assert self.vs.ip_address_join.assign_to_server(
                ip_address_id=ip_address.id
            ), self.vs.ip_address_join.error

    def test_get_stat(self):
        self.vm_stat.stats_waiter()
        self.vm_stat.get_hourly_stat_for_the_last_hour()
        self.user_stat.get_user_stat_for_the_last_hour()
        self.vs.get()
        self.user.get()

    def test_hourly_price_on(self):
        expected = self.vs.price_on_calculated(
            ntz_rc=self.ntz_rc
        )
        actual = float(self.vs.price_per_hour)
        print('Expected: {}'.format(expected))
        print('Actual: {}'.format(actual))
        assert actual == expected

    def test_hourly_price_off(self):
        expected = self.vs.price_off_calculated(
            ntz_rc=self.ntz_rc
        )
        actual = float(self.vs.price_per_hour_powered_off)
        print('Expected: {}'.format(expected))
        print('Actual: {}'.format(actual))
        assert actual == expected

    def test_ip_address_cost(self):
        if self.vs.booted:
            expected = self.vs.ip_price_on
        else:
            expected = self.vs.ip_price_off

        # expected = price * (self.vm_stat.vm_last_hour_stat.ip_addresses.value - self.ntz_br.own_limits.limit_ip_free)
        actual = self.vm_stat.get_networks_ip_addresses_cost()
        print('Expected: {}'.format(expected))
        print('Actual: {}'.format(actual))
        assert actual == expected

    def test_rate_cost(self):
        if self.vs.booted:
            expected = self.vs.rate_limit_price_on
        else:
            expected = self.vs.rate_limit_price_off
        # rate_value = self.vm_stat.vm_last_hour_stat.rate.value
        # if not rate_value: # 0
        #     rate_value = self.vs.port_speed()
        # expected = price * (rate_value - self.ntz_br.own_limits.limit_rate_free)
        actual = self.vm_stat.get_networks_port_speed_cost()
        print('Expected: {}'.format(expected))
        print('Actual: {}'.format(actual))
        assert actual == expected

    def test_data_received_cost(self):
        calculated_cost = self.vm_stat.get_networks_data_received_value() * self.ntz_rc.prices.price_data_received
        print(
            'Data received cost: \n\t calculated - {}\n\t real - {}'.format(
                calculated_cost, self.vm_stat.get_networks_data_received_cost()
            )
        )
        assert price_comparator_with_round(
            calculated_cost, self.vm_stat.get_networks_data_received_cost(), 2
        )

    def test_data_sent_cost(self):
        calculated_cost = self.vm_stat.get_networks_data_sent_value() * self.ntz_rc.prices.price_data_sent
        print(
            'Data sent cost: \n\t calculated - {}\n\t real - {}'.format(
                calculated_cost, self.vm_stat.get_networks_data_sent_cost()
            )
        )
        assert price_comparator_with_round(
            calculated_cost, self.vm_stat.get_networks_data_sent_cost(), 2
        )

    def test_check_discount_due_to_free(self):
        # rate_cost_free = get_free_amount(
        #     self.vs.port_speed(),
        #     self.ntz_rc.prices.limit_rate_free
        # ) * self.ntz_rc.prices.price_rate_on

        ip_cost_free = get_free_amount(
            len(self.vs.ip_address_join.get_all()),
            self.ntz_rc.prices.limit_ip_free
        ) * self.ntz_rc.prices.price_ip_on

        data_sent_cost_free = get_free_amount(
            self.vm_stat.get_networks_data_sent_value(),
            self.ntz_rc.prices.limit_data_sent_free
        ) * self.ntz_rc.prices.price_data_sent

        data_received_cost_free = get_free_amount(
            self.vm_stat.get_networks_data_received_value(),
            self.ntz_rc.prices.limit_data_received_free
        ) * self.ntz_rc.prices.price_data_received

        total_free = sum(
            [
                # rate_cost_free, # is not included in to discount
                ip_cost_free,
                data_sent_cost_free,
                data_received_cost_free
            ]
        )
        assert price_comparator_with_round(
            total_free, self.user_stat.total_discount_due_to_free, 2
        )

        assert price_comparator_with_round(
            total_free, self.user_stat.user_resources_discount_due_to_free, 2
        )

        assert price_comparator_with_round(
            total_free, self.user.discount_due_to_free, 2
        )

