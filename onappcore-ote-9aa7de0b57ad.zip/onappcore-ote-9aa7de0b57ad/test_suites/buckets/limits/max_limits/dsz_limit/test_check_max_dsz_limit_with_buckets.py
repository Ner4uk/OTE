import pytest
from onapp_helper import test

from onapp_helper.bucket import access_controls as ac
from onapp_helper.server import VirtualServer
from onapp_helper.user import User
from onapp_helper.bucket.bucket import Bucket


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.limits
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
class TestDSZMaxLimits:
    def setup_class(self):
        test.load_env()

        try:
            # Setup
            self.bucket = Bucket()
            self.bucket.label = self.__name__
            assert self.bucket.create()

            ac.add_all_resources_to_bucket(self.bucket)

            # Setup for base resources
            self.dsz_ac = ac.DataStoreZoneAC(
                parent_obj=self.bucket,
                target_id=test.env.dsz.id
            )
            assert self.dsz_ac.get()

            # Create User and VS
            self.user = User(bucket=self.bucket)
            self.user.login = "dszmaxlimitstest"
            self.user.password = test.generate_password()
            self.user.email = 'user@dszmaxlimitstest.test'
            assert self.user.create()
            # Login as new user
            test.execute_as(self.user.login, self.user.password)

            self.vs = VirtualServer()
            self.vs.rate_limit = 0  #  Unlimited
            self.vs.label = self.__name__
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        attributes = (
            'user',
            'bucket'
        )
        test.clean_up_resources(attributes, self)

    def test_set_max_disk_size_as_0(self):
        self.dsz_ac.limits.limit = 0
        self.dsz_ac.edit()

    def test_check_that_you_can_not_create_vs(self):
        assert not self.vs.create()
        assert 'billing limit exceeded for this data store zone' in self.vs.error['primary_disk_size']
        assert 'Size billing limit exceeded for this data store zone' in self.vs.error['disks']
        assert 'billing limit exceeded for this data store zone' in self.vs.error['swap_disk_size']
