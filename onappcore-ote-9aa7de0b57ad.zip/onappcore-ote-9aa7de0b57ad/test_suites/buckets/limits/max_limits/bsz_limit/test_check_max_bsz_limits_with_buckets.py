# https://onappdev.atlassian.net/browse/CORE-5554

import time
import pytest
from onapp_helper.bucket import access_controls as ac
from onapp_helper.backup import Backup
from onapp_helper.template_ova import OVA
from onapp_helper.backup_server import BackupServer
from onapp_helper.user import User
from onapp_helper.bucket.bucket import Bucket
from onapp_helper import test
from onapp_helper.server import VirtualServer

BASE_LIMIT_MSG = "You have reached your {} creation limit"
REACHED_BACKUP_CREATION_LIMIT_MSG = BASE_LIMIT_MSG.format('Backup')
REACHED_TEMPLATE_CREATION_LIMIT_MSG = BASE_LIMIT_MSG.format('template')
REACHED_OVA_CREATION_LIMIT_MSG = BASE_LIMIT_MSG.format('OVA')

BASE_DISK_SIZE_MSG = "You have reached your {} Disk Size Max limit"
REACHED_OVA_DISK_SIZE_MSG = BASE_DISK_SIZE_MSG.format("OVA")


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.limits
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
@pytest.mark.verbose
class TestMaxBSZLimit:
    __doc__ = """
    1. Configure Bucket:
        - deny storing backups on HV
        - set limits
    2. Create backups (auto, manual), templates, upload ovas
    3. Waiting for statistics
    4. Compare expected value with actual. Check that for onapp >= 5.9 auto 
    backups count limit/price also works
    """

    def setup_class(self):
        test.hv_types = ['kvm']  # To be compatible with OVA
        test.load_env()

        if not test.env.backup_servers:
            pytest.skip('There is no backup servers attached to HV/HVZ')
        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        try:
            # ToDo - First of all need to check if Backup server available and ready for backups!!!
            # ToDo - ASAP uncomment and change if needed error messages in asserts
            #  Select BS for OVA
            self.backup_server = BackupServer().get_for_ova()

            self.bucket = Bucket()
            self.bucket.label = self.__name__
            assert self.bucket.create()

            ac.add_env_to_bucket(self.bucket)

            # Remove all to set selected above
            for bs in test.env.backup_servers:
                ac.BackupServerZoneAC(
                    parent_obj=self.bucket,
                    target_id=bs.backup_server_group_id
                ).delete()

            bsz_ac = ac.BackupServerZoneAC(
                parent_obj=self.bucket,
                target_id=self.backup_server.backup_server_group_id
            )
            assert bsz_ac.create(), bsz_ac.error

            self.backup_ac = ac.BackupsAC(parent_obj=self.bucket)
            self.backup_ac.get()
            self.backup_ac.limits.limit = 0
            assert self.backup_ac.edit(), self.backup_ac.error

            self.template_ac = ac.TemplatesAC(parent_obj=self.bucket)
            self.template_ac.get()
            self.template_ac.limits.limit = 0
            assert self.template_ac.edit(), self.template_ac.error

            self.storage_disk_size_ac = ac.ComputeResourceStoringAC(
                parent_obj=self.bucket
            )
            self.storage_disk_size_ac.get()
            self.storage_disk_size_ac.limits.limit = 0
            assert self.storage_disk_size_ac.edit()

            self.user = User(bucket=self.bucket)
            self.user.login = 'bszmaxlimitstest'
            self.user.password = test.generate_password()
            self.user.email = 'user@bszmaxlimits.test'
            assert self.user.create()
            test.execute_as(self.user.login, self.user.password)

            self.vs = VirtualServer()
            self.vs.label = self.__name__
            assert self.vs.create(), self.vs.error
            self.primary_disk = self.vs.get_primary_disk()

            self.backups = []
            self.templates = []

            for bs in test.env.backup_servers:
                self.bsz_ac = ac.BackupServerZoneAC(
                    parent_obj=self.bucket,
                    target_id=bs.backup_server_group_id
                )
                if self.bsz_ac.get():
                    break

            if test.onapp_settings.get().allow_incremental_backups:
                assert test.onapp_settings.set(allow_incremental_backups=False)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        ovas_to_delete = [
            o for o in OVA().get_all() if o.user_id == self.user.id
            ]
        for ova in ovas_to_delete:
            if ova.locked:
                ova.unlock()
            ova.delete()

        test.execute_as(test.login, test.password)
        self.user.delete()
        self.bucket.delete()

    def test_set_max_limit_for_backups_as_0(self):
        self.bsz_ac.limits.limit_backup = 0
        assert self.bsz_ac.edit()

    def test_you_can_not_take_a_backup_for_limit_0(self):
        b = Backup(self.vs)
        assert not b.create(note='check max limits')
        if test.cp_version >= 5.7:
            error_msg = b.transaction.log_output
            if b.locked:
                b.unlock()
            b.delete()
        else:
            error_msg = b.error['base']
        assert REACHED_BACKUP_CREATION_LIMIT_MSG in error_msg

    # Billing Backups count limits does not work with autobackups
    # https://onappdev.atlassian.net/browse/CORE-5467
    @pytest.mark.skipif(
        test.cp_version >= 5.9,
        reason="Limitation for auto backups supported since 5.9, (CORE-12200)"
    )
    def test_you_can_take_disk_autobackups_for_limit_0(self):
        backups = self.primary_disk.enable_auto_backups()
        assert len(backups) == 4

    ############################################################################
    # Auto backups limitation supported since 5.9 ##############################
    # https://onappdev.atlassian.net/browse/CORE-12200
    # COUNT LIMITATION
    @pytest.mark.skipif(
        test.cp_version < 5.9,
        reason="Limitation for auto backups supported since 5.9, (CORE-12200)"
    )
    @pytest.mark.parametrize('limit', [0, 3])
    def test_you_can_not_take_disk_auto_backups_for_limit_less_than_4(self, limit):
        self.bsz_ac.limits.limit_backup = limit
        assert self.bsz_ac.edit()

        backups = self.primary_disk.enable_auto_backups()
        assert len(backups) == 4  # but schedule transactions should be failed

        for b in backups:
            log_output = b.transaction.log_output
            if b.locked:
                b.unlock()
            assert b.delete(), b.error
            assert REACHED_BACKUP_CREATION_LIMIT_MSG in log_output

        schedules = self.vs.get_primary_disk().schedule.get_all()
        for s in schedules:
            assert s.delete(), s.error

    # https://onappdev.atlassian.net/browse/CORE-12200
    @pytest.mark.skipif(
        test.cp_version < 5.9,
        reason="Limitation for auto backups supported since 5.9, (CORE-12200)"
    )
    def test_you_can_take_disk_auto_backups_for_limit_4(self):
        self.bsz_ac.limits.limit_backup = 4
        assert self.bsz_ac.edit()
        backups = self.primary_disk.enable_auto_backups()
        assert len(backups) == 4

    @pytest.mark.skipif(
        test.cp_version < 5.9,
        reason="Limitation for auto backups supported since 5.9, (CORE-12200)"
    )
    def test_you_can_not_add_manual_backup_if_limit_4_and_4_auto_backups_is_present(self):
        if self.vs.get_auto_backups_count() != 4:
            pytest.skip("Backups count is not equal to 4th")
        b = Backup(self.vs)
        assert not b.create(note='check max limits')

        if test.cp_version >= 5.7:
            assert REACHED_BACKUP_CREATION_LIMIT_MSG in b.transaction.log_output
            b.delete()
        else:
            assert REACHED_BACKUP_CREATION_LIMIT_MSG in b.error['base']

    @pytest.mark.skipif(
        test.cp_version < 5.9,
        reason="Limitation for auto backups supported since 5.9, (CORE-12200)"
    )
    def test_you_can_add_manual_backup_if_limit_5_and_4_auto_backups_is_present(self):
        self.bsz_ac.limits.limit_backup = 5
        assert self.bsz_ac.edit()
        if self.vs.get_backups_count() != 4:
            pytest.skip("Backups count is not equal to 4th")
        b = Backup(self.vs)
        assert b.create(note='check max limits'), b.error

    @pytest.mark.skipif(
        test.cp_version < 5.9,
        reason="Limitation for auto backups supported since 5.9, (CORE-12200)"
    )
    def test_schedules_should_works_if_count_limit_reached(self):
        # Get daily schedule
        daily_schedule = [
            s for s in self.primary_disk.schedule.get_all()
            if s.period == s.PERIOD.days
        ][0]

        # Change daily schedule start time to get auto backup running
        daily_schedule.start_at = test.get_time_str(shift=30, utc=True)
        assert daily_schedule.edit(), daily_schedule.error
        test.wait_for_action(
            lambda: self.vs.get_auto_backups_count() == 5, timeout=180, step=5
        )

        auto_backups = [
            b for b in self.vs.get_backups() if b.initiated == 'days'
        ]

        old_daily_backup = [b for b in auto_backups if b.built][0]
        rotated_daily_backup = [b for b in auto_backups if not b.built][0]

        assert rotated_daily_backup.transaction_handler(
            action="take_backup"
        )
        assert old_daily_backup.transaction_handler(
            action='destroy_backup'
        )
        assert self.vs.get_auto_backups_count() == 4

    @pytest.mark.skipif(
        test.cp_version < 5.9,
        reason="Limitation for auto backups supported since 5.9, (CORE-12200)"
    )
    def test_remove_schedules_after_count_limitation(self):
        for s in self.vs.get_primary_disk().schedule.get_all():
            assert s.delete(), s.error

    @pytest.mark.skipif(
        test.cp_version < 5.9,
        reason="Limitation for auto backups supported since 5.9, (CORE-12200)"
    )
    def test_remove_all_existed_backups_after_count_limitation(self):
        for b in self.vs.get_backups():
            assert b.delete(), b.error

    # SIZE LIMITATION
    @pytest.mark.skipif(
        test.cp_version < 5.9,
        reason="Limitation for auto backups supported since 5.9, (CORE-12200)"
    )
    def test_set_backup_disk_size_to_0(self):
        self.bsz_ac.limits.limit_backup = None
        self.bsz_ac.limits.limit_backup_disk_size = 0
        assert self.bsz_ac.edit()

    @pytest.mark.skipif(
        test.cp_version < 5.9,
        reason="Limitation for auto backups supported since 5.9, (CORE-12200)"
    )
    def test_you_can_not_create_auto_backups_if_backup_disk_size_limit_is_0(self):
        backups = self.primary_disk.enable_auto_backups()
        assert len(backups) == 4  # but schedule transactions should be failed

        for b in backups:
            assert REACHED_BACKUP_CREATION_LIMIT_MSG in b.transaction.log_output
            assert b.delete(), b.error

        schedules = self.vs.get_primary_disk().schedule.get_all()
        for s in schedules:
            assert s.delete(), s.error

    @pytest.mark.skipif(
        test.cp_version < 5.9,
        reason="Limitation for auto backups supported since 5.9, (CORE-12200)"
    )
    def test_you_can_not_create_manual_backup_if_backup_disk_size_limit_is_0(self):
        b = Backup(parent_obj=self.vs)
        assert not b.create(note='check max limits')

        if test.cp_version >= 5.7:
            assert REACHED_BACKUP_CREATION_LIMIT_MSG in b.transaction.log_output
            b.delete()
        else:
            assert REACHED_BACKUP_CREATION_LIMIT_MSG in b.error['base']

    @pytest.mark.skipif(
        test.cp_version < 5.9,
        reason="Limitation for auto backups supported since 5.9, (CORE-12200)"
    )
    def test_exceed_backup_disk_size_limit_for_manual_backup(self):
        """
        You can not create manual backup if total backups disk size is more
        than 1GB.
        :return:
        """
        self.bsz_ac.limits.limit_backup = None
        self.bsz_ac.limits.limit_backup_disk_size = 1
        assert self.bsz_ac.edit()

        while self.vs.get_backups_size() < 1048576:
            b = Backup(parent_obj=self.vs)
            assert b.create(note='check max limits'), b.error

        b = Backup(parent_obj=self.vs)
        assert not b.create(note='check max limits')

        if test.cp_version >= 5.7:
            assert REACHED_BACKUP_CREATION_LIMIT_MSG in b.transaction.log_output
            b.delete()
        else:
            assert REACHED_BACKUP_CREATION_LIMIT_MSG in b.error['base']

    @pytest.mark.skipif(
        test.cp_version < 5.9,
        reason="Limitation for auto backups supported since 5.9, (CORE-12200)"
    )
    def test_you_can_not_create_auto_backups_if_backup_disk_size_limit_reached(self):
        backups = self.primary_disk.enable_auto_backups()
        assert len(backups) == 4  # but schedule transactions should be failed

        for b in backups:
            assert REACHED_BACKUP_CREATION_LIMIT_MSG in b.transaction.log_output
            assert b.delete(), b.error

        schedules = self.vs.get_primary_disk().schedule.get_all()
        for s in schedules:
            assert s.delete(), s.error

    @pytest.mark.skipif(
        test.cp_version < 5.9,
        reason="Limitation for auto backups supported since 5.9, (CORE-12200)"
    )
    def test_you_can_create_manual_backup_if_backup_disk_size_limit_10(self):
        self.bsz_ac.limits.limit_backup_disk_size = 10
        assert self.bsz_ac.edit()

        b = Backup(parent_obj=self.vs)
        assert b.create(note='check max limits'), b.error

    @pytest.mark.skipif(
        test.cp_version < 5.9,
        reason="Limitation for auto backups supported since 5.9, (CORE-12200)"
    )
    def test_you_can_create_auto_backups_if_backup_disk_size_limit_10(self):
        self.bsz_ac.limits.limit_backup_disk_size = 10
        assert self.bsz_ac.edit()

        backups = self.primary_disk.enable_auto_backups()
        assert len(
            [b for b in backups if b.built and b.initiated != 'manual']
        ) == 4

    @pytest.mark.skipif(
        test.cp_version < 5.9,
        reason="Limitation for auto backups supported since 5.9, (CORE-12200)"
    )
    def test_remove_schedules_after_size_limitation(self):
        for s in self.vs.get_primary_disk().schedule.get_all():
            assert s.delete(), s.error

    @pytest.mark.skipif(
        test.cp_version < 5.9,
        reason="Limitation for auto backups supported since 5.9, (CORE-12200)"
    )
    def test_remove_all_existed_backups_after_size_limitation(self):
        for b in self.vs.get_backups():
            assert b.delete(), b.error

    ############################################################################

    #TODO Check size limit for autobackups.

    def test_set_max_limit_for_templates_as_0_and_1_for_backups(self):
        self.bsz_ac.limits.limit_backup_disk_size = None
        self.bsz_ac.limits.limit_backup = 1
        self.bsz_ac.limits.limit_template = 0
        assert self.bsz_ac.edit()

    def test_you_can_not_convert_backup_with_template_limit_0(self):
        # Take a backup
        b = Backup(self.vs)
        assert b.create(note='check max limits')
        self.backups.append(b)
        # Try convert to template
        assert not b.convert()
        assert REACHED_TEMPLATE_CREATION_LIMIT_MSG in b.template.error['base'][0]

    def test_allow_to_create_one_template(self):
        # Allow 1 Template per BSZ.
        self.bsz_ac.limits.limit_template = 1
        assert self.bsz_ac.edit()

    def test_should_be_impossible_to_create_a_2nd_backup(self):
        b = Backup(self.vs)
        assert not b.create(note='check max limits')
        if test.cp_version >= 5.7:
            assert REACHED_BACKUP_CREATION_LIMIT_MSG in b.transaction.log_output
            b.delete()
        else:
            assert REACHED_BACKUP_CREATION_LIMIT_MSG in b.error['base']

    def test_check_max_limit_for_template(self):
        # Create 1 Template - should be possible.
        assert self.backups[0].convert(label=self.__class__.__name__), self.backups[0].template.error

        self.templates.append(self.backups[0].template)

        # Create the 2-nd one - should be impossible.
        assert not self.backups[0].convert()
        assert REACHED_TEMPLATE_CREATION_LIMIT_MSG in self.backups[0].template.error['base'][0]

    def test_set_max_backups_and_templates_disk_size_limit_as_1GB(self):
        # Reset BR
        self.bsz_ac.limits.limit_backup = None
        self.bsz_ac.limits.limit_template = None
        # Allow 1GB of backups per BSZ
        self.bsz_ac.limits.limit_backup_disk_size = 1
        # Allow 1GB of templates per BSZ
        self.bsz_ac.limits.limit_template_disk_size = 1
        assert self.bsz_ac.edit()

    def test_exceed_max_limit_for_backup_disk_size(self):
        """ CORE-5554. In some cases it is impossible. We reserve 0.1GB of disk space during backup creation, for example:
            Set limit 1GB:
            1) total disk size = 800MB, add 100MB reserved 900 < 1000 so we can create one more backup/template and
                exceed the limit;
            2) total disk size = 990MB, add 100MB reserved 1100 > 1000 so we can not create one more backup/template and
                exceed the limit in real;

        """
        while True:
            backup = Backup(self.vs)
            if not backup.create() or self.vs.get_backups_size() > 1572864:
                if test.cp_version >= 5.7:
                    assert REACHED_BACKUP_CREATION_LIMIT_MSG in backup.transaction.log_output
                    backup.delete()
                else:
                    assert REACHED_BACKUP_CREATION_LIMIT_MSG in backup.error['base']
                # assert 'You have exceeded your backup disk size creation limit' in backup.error['base']
                break
            self.backups.append(backup)
        test.log.info(f'*** {self.vs.get_backups_size()}')
        assert self.vs.get_backups_size() > 1048576

    def test_you_can_not_take_a_backup_if_max_limit_exceeded(self):
        b = Backup(self.vs)
        assert not b.create(note='check max limits')
        if test.cp_version >= 5.7:
            assert REACHED_BACKUP_CREATION_LIMIT_MSG in b.transaction.log_output
            b.delete()
        else:
            assert REACHED_BACKUP_CREATION_LIMIT_MSG in b.error['base']

    def test_exceed_max_limit_for_template_disk_size(self):
        backup = self.backups[0]
        while True:
            if (
                    not backup.convert()
            ) or (
                    sum([t.template_size for t in self.templates]) > 1572864
            ):
                break
            self.templates.append(backup.template)
        test.log.info(f'*** {sum([t.template_size for t in self.templates])}')
        assert sum([t.template_size for t in self.templates]) < 1048576

    def test_you_can_not_convert_a_backup_if_max_limit_exceeded(self):
        assert not self.backups[0].convert()
        if test.cp_version >= 5.7:
            assert 'You have reached your max template disk size limit' in \
                   self.backups[0].template.error['base']
        else:
            assert REACHED_TEMPLATE_CREATION_LIMIT_MSG in self.backups[0].template.error['base']

    def test_set_0_limit_for_ova_count(self):
        self.bsz_ac.limits.limit_ova = 0
        assert self.bsz_ac.edit(), self.bsz_ac.error

    def test_should_be_impossible_to_upload_ova_with_0_limit(self):
        if test.cp_version >= 5.7:
            ova_template_src = OVA()
            ova_template_src.label = self.__class__.__name__
            ova_template_src.min_memory_size = 512
            ova_template_src.version = 7.5
            ova_template_src.backup_server_id = self.backup_server.id
            ova_template_src.file_url = 'http://templates.repo.onapp.com/ova/centos6.ova'
            assert not ova_template_src.upload()
            assert REACHED_OVA_CREATION_LIMIT_MSG in ova_template_src.error["base"]

        else:
            ova = OVA()
            ova.label = self.__class__.__name__
            ova.backup_server_id = self.backup_server.id
            ova.file_url = 'http://templates.repo.onapp.com/ova/centos6.ova'
            ova.operating_system_distro = ova.OPERATING_SYSTEM_DISTROS.rhel
            ova.operating_system = ova.OPERATING_SYSTEMS.linux
            assert not ova.upload()
            assert REACHED_OVA_CREATION_LIMIT_MSG in ova.error["base"]

    def test_should_be_impossible_to_upload_ova_with_total_size_more_than_1_GB(self):
        self.bsz_ac.limits.limit_ova = None
        self.bsz_ac.limits.limit_ova_disk_size = 1
        assert self.bsz_ac.edit()
        ovas = []
        counter = 0
        while True:
            if test.cp_version >= 5.7:
                ova_template_src = OVA()
                ova_template_src.label = self.__class__.__name__ + str(counter)
                ova_template_src.min_memory_size = 512
                ova_template_src.version = 7.5
                ova_template_src.backup_server_id = self.backup_server.id
                ova_template_src.file_url = 'https://sourceforge.net/projects/virtualappliances/files/Linux/CentOS/CentOS-6.4-i386-minimal.ova'
                if not ova_template_src.upload() or sum(
                        [o.template_size for o in ovas]) > 1572864:
                    assert REACHED_OVA_DISK_SIZE_MSG in ova_template_src.error["base"]
                    break
                ovas.append(ova_template_src)
                counter += 1
                time.sleep(30)

            else:
                ova = OVA()
                ova.label = self.__class__.__name__ + str(counter)
                ova.backup_server_id = self.backup_server.id
                ova.file_url = 'https://sourceforge.net/projects/virtualappliances/files/Linux/CentOS/CentOS-6.4-i386-minimal.ova'
                ova.operating_system_distro = ova.OPERATING_SYSTEM_DISTROS.rhel
                ova.operating_system = ova.OPERATING_SYSTEMS.linux
                if not ova.upload() or sum(
                        [o.template_size for o in ovas]) > 1572864:
                    assert REACHED_OVA_DISK_SIZE_MSG in ova.error["base"]
                    break
                ovas.append(ova)
                counter += 1
                time.sleep(30)

        test.log.info(f'*** {sum([o.template_size for o in ovas])}')
        assert sum([o.template_size for o in ovas]) > 1048576
        [o.delete() for o in ovas]
