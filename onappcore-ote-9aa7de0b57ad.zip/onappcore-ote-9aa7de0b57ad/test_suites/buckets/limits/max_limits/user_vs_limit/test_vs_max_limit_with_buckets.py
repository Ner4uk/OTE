from onapp_helper.bucket import access_controls as ac
from onapp_helper.bucket.access_controls import add_all_resources_to_bucket
from onapp_helper.user import User
from onapp_helper.bucket.bucket import Bucket
from onapp_helper import test
from onapp_helper.server import VirtualServer, ApplicationServer
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.limits
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
@pytest.mark.incremental
class TestVsMaxLimits:
    def setup_class(self):
        test.load_env()

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        try:
            self.bucket = Bucket()
            self.bucket.label = self.__name__
            assert self.bucket.create()

            ac.add_all_resources_to_bucket(self.bucket)

            self.apps = ApplicationServer()
            self.vs = VirtualServer()
            self.user = User(bucket=self.bucket)

            add_all_resources_to_bucket(bucket=self.bucket)
            self.vs_ac = ac.VirtualServerAC(parent_obj=self.bucket)
            assert self.vs_ac.get(), self.vs_ac.error

            self.user.login = 'vsmaxlimitstest'
            self.user.password = test.generate_password()
            self.user.email = 'user@vsmaxlimits.test'
            assert self.user.create()
            test.execute_as(self.user.login, self.user.password)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        self.vs.delete()
        self.user.delete()
        self.bucket.delete()

    def test_set_0_max_limit(self):
        self.vs_ac.limits.limit = 0
        assert self.vs_ac.edit()

    def test_should_be_impossible_to_create_virtual_server(self):
        assert not self.vs.create()
        assert 'Virtual server limit exceeded' in self.vs.error['base'][0]

    def test_set_1_max_limit(self):
        self.vs_ac.limits.limit = 1
        assert self.vs_ac.edit()

    def test_should_be_possible_to_create_virtual_server(self):
        assert self.vs.create(), self.vs.error

    def test_you_can_edit_vs(self):
        self.vs.label += '2'
        assert self.vs.edit(), self.vs.error
