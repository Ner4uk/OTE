from onapp_helper.bucket import access_controls as ac
from onapp_helper.server import ApplicationServer
from onapp_helper.user import User
from onapp_helper.bucket.bucket import Bucket
from onapp_helper import test
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.limits
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
@pytest.mark.incremental
class TestApplicationMaxLimits:
    def setup_class(self):
        test.load_env(use_public_network=True)

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        try:
            self.bucket = Bucket()
            self.bucket.label = self.__name__
            assert self.bucket.create()

            ac.add_all_resources_to_bucket(self.bucket)

            self.apps = ApplicationServer()
            self.apps.template.find_any('ApplicationServer')
            self.user = User(bucket=self.bucket)

            self.as_ac = ac.ApplicationServersAC(parent_obj=self.bucket).get()

            self.user.login = 'applicationmaxlimitstest'
            self.user.password = test.generate_password()
            self.user.email = 'user@applicationmaxlimits.test'
            assert self.user.create()
            test.execute_as(self.user.login, self.user.password)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        self.user.delete()
        self.bucket.delete()

    @pytest.mark.skipif(
        test.cp_version < 4.2, reason="{0} API version does not support current functionality.".format(
            test.cp_version
        )
    )
    def test_set_0_max_limit(self):
        self.as_ac.limits.limit = 0
        assert self.as_ac.edit()

    @pytest.mark.skipif(
        test.cp_version < 4.2, reason="{0} API version does not support current functionality.".format(
            test.cp_version
        )
    )
    def test_should_be_impossible_to_create_application_server(self):
        assert not self.apps.create()
        assert 'Application server limit exceeded' in self.apps.error['base']