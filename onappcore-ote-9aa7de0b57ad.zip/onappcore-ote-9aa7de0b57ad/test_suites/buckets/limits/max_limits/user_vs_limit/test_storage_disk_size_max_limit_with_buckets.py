# https://onappdev.atlassian.net/browse/CORE-5554
import pytest

from onapp_helper import test
from onapp_helper.server import VirtualServer
from onapp_helper.backup import Backup
from onapp_helper.bsz import BSZ
from onapp_helper.bucket import access_controls as ac
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.iso import ISO
from onapp_helper.template import Template
from onapp_helper.user import User
from onapp_helper.schedule import Schedule

BASE_LIMIT_MSG = "You have reached your {} creation limit"
REACHED_BACKUP_CREATION_LIMIT_MSG = BASE_LIMIT_MSG.format('Backup')
REACHED_TEMPLATE_CREATION_LIMIT_MSG = BASE_LIMIT_MSG.format('template')
REACHED_OVA_CREATION_LIMIT_MSG = BASE_LIMIT_MSG.format('OVA')

BASE_DISK_SIZE_MSG = "You have reached your {} Disk Size Max limit"
REACHED_OVA_DISK_SIZE_MSG = BASE_DISK_SIZE_MSG.format("OVA")

# error message
EM = "You have reached your 'Templates, ISO's & Backups Storage' limit"
RESERVED_STORAGE_SIZE = 100 * 1024  # 100MB in KB
STORAGE_DISK_SIZE_LIMIT = 2


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.limits
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
# @pytest.mark.incremental
@pytest.mark.verbose
class TestStorageDiskSizeMaxLimit:
    def setup_class(self):
        test.load_env()

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        try:
            self.bucket = Bucket()
            self.bucket.label = self.__name__
            assert self.bucket.create(), self.bucket.error

            ac.add_all_resources_to_bucket(bucket=self.bucket)

            self.user = User(bucket=self.bucket)
            self.user.login = 'storagedisksizemaxlimitstest'
            self.user.password = test.generate_password()
            self.user.email = 'user@storagedisksizemaxlimits.test'
            assert self.user.create(), self.user.error
            test.execute_as(self.user.login, self.user.password)

            self.vs = VirtualServer()
            self.vs.label = self.__name__
            assert self.vs.create(), self.vs.error

            self.primary_disk = self.vs.get_primary_disk()

            self.schedule = Schedule(target=self.bu_source)

            self.backup = Backup(self.vs)
            self.template = Template()
            self.iso = ISO()

            for bsz in BSZ().get_all():

                bsz_ac = ac.BackupServerZoneAC(
                    parent_obj=self.bucket,
                    target_id=bsz.id,
                    server_type=bsz.server_type
                )
                if not bsz_ac.get():
                    assert bsz_ac.create(), bsz_ac.error
                assert bsz_ac.get(), bsz_ac.error
                bsz_ac.limits.limit_backup_disk_size = 0
                bsz_ac.limits.limit_backup = 0
                bsz_ac.limits.limit_template_disk_size = 0
                bsz_ac.limits.limit_template = 0
                assert bsz_ac.edit(), bsz_ac.error

            self.storage_disk_size_ac = ac.ComputeResourceStoringAC(
                parent_obj=self.bucket
            )

            self.backups = []
            self.isos = []

            if test.onapp_settings.get().allow_incremental_backups:
                assert test.onapp_settings.set(allow_incremental_backups=False)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        self.user.delete()
        self.bucket.delete()

    def test_set_0_max_limit_for_storage_disk_size(self):
        assert self.storage_disk_size_ac.get(), self.storage_disk_size_ac.error
        self.storage_disk_size_ac.limits.limit = 0
        assert self.storage_disk_size_ac.edit(), self.storage_disk_size_ac.error

    def test_you_can_not_create_a_backup_if_storage_disk_size_limit_is_0(self):
        if test.cp_version >= 5.7:
            pytest.skip('Bucket has a different behaviour')
        backup = Backup(self.vs)
        assert not backup.create()
        assert EM in backup.error['base']

    # SIZE LIMITATION FOR AUTO BACKUPS
    def test_you_can_not_create_auto_backups_if_storage_disk_size_limit_is_0(self):
        backups = self.primary_disk.enable_auto_backups()
        assert len(backups) == 4  # but schedule transactions should be failed

        for b in backups:
            assert REACHED_BACKUP_CREATION_LIMIT_MSG in b.transaction.log_output
            assert b.delete(), b.error

        schedules = self.vs.get_primary_disk().schedule.get_all()
        for s in schedules:
            assert s.delete(), s.error

    # def test_you_can_not_create_manual_backup_if_storage_disk_size_limit_is_0(self):
    #     b = Backup(parent_obj=self.vs)
    #     assert not b.create()
    #
    #     if test.cp_version >= 5.9:
    #         assert REACHED_BACKUP_CREATION_LIMIT_MSG in b.error['base']
    #     elif test.cp_version >= 5.7:
    #         assert REACHED_BACKUP_CREATION_LIMIT_MSG in b.transaction.log_output
    #         b.delete()
    #     else:
    #         assert REACHED_BACKUP_CREATION_LIMIT_MSG in b.error['base']

    def test_you_can_create_auto_backups_if_storage_disk_size_limit_is_1(self):
        self.storage_disk_size_ac.limits.limit = 1
        assert self.storage_disk_size_ac.edit()

        self.primary_disk.enable_auto_backups()
        assert self.vs.get_auto_backups_count() == 4

    def test_check_storage_disk_size_limit_for_manual_backup(self):
        """
        You can not create manual backup if total backups disk size is more
        than 1GB.
        :return:
        """
        while self.vs.get_backups_size() < 1048576:
            b = Backup(parent_obj=self.vs)
            assert b.create(), b.error

        b = Backup(parent_obj=self.vs)
        assert not b.create()
        # pytest.set_trace()

    def test_you_can_create_manual_backup_if_storage_disk_size_limit_is_2(self):
        self.storage_disk_size_ac.limits.limit_backup_disk_size = 2
        assert self.storage_disk_size_ac.edit()

        b = Backup(parent_obj=self.vs)
        assert b.create(), b.error

    def test_remove_schedules_after_size_limitation(self):
        for s in self.schedule.get_all():
            assert s.delete(), s.error

    def test_remove_all_existed_backups_after_size_limitation(self):
        for b in self.vs.get_backups():
            assert b.delete(), b.error
    ############################################################################

    def test_you_can_create_one_backup_if_storage_disk_size_limit_is_0(self):
        self.storage_disk_size_ac.limits.limit = 0
        assert self.storage_disk_size_ac.edit(), self.storage_disk_size_ac.error

        if test.cp_version < 5.7:
            pytest.skip('Billing has a different behaviour')
        backup = Backup(self.vs)
        assert backup.create(), backup.create()
        self.backups.append(backup)
        assert not backup.create()
        assert EM in backup.error['base']

    def test_change_max_limit_for_storage_disk_size(self):
        self.storage_disk_size_ac.limits.limit = STORAGE_DISK_SIZE_LIMIT
        assert self.storage_disk_size_ac.edit()

    def test_create_one_backup(self):
        backup = Backup(self.vs)
        assert backup.create(), backup.error
        self.backups.append(backup)

    def test_create_one_template(self):
        assert self.backups[0].convert(
            label=self.__class__.__name__
        ), self.backups[0].template.error
        self.template.__dict__.update(self.backups[0].template.__dict__)

    def test_exceeding_your_storage_disk_size_limit(self):
        """ CORE-5554. In some cases it is impossible. We reserve 0.1GB of disk space during backup creation, for example:
            Set limit 1GB:
            1) total disk size = 800MB, add 100MB reserved 900 < 1000 so we can create one more backup/template and
                exceed the limit;
            2) total disk size = 990MB, add 100MB reserved 1100 > 1000 so we can not create one more backup/template and
                exceed the limit in real;

        """
        while True:
            backup = Backup(self.vs)
            # Stop doing backups if size > STORAGE_DISK_SIZE_LIMIT + 1
            if not backup.create() or sum(
                    self.vs.get_backups_size(),
                    self.template.template_size,
                    RESERVED_STORAGE_SIZE
            ) > (STORAGE_DISK_SIZE_LIMIT + 1) * 1048576:
                assert EM in backup.error['base']
                break
            self.backups.append(backup)
        total_disk_size = self.vs.get_backups_size() + self.template.template_size + RESERVED_STORAGE_SIZE
        test.log.info(
            'Total backups/templates disk size - {}'.format(total_disk_size)
        )

    ####################################################################################################################
    # Add code to covering both of this cases
    def test_you_can_not_restore_last_backup_if_total_storage_disk_size_more_than_limit(self):
        total_size = (
            self.vs.get_backups_size() +
            self.template.template_size +
            RESERVED_STORAGE_SIZE
        )
        if total_size > STORAGE_DISK_SIZE_LIMIT * 1048576:
            assert not self.backups[-1].restore()
            assert "You have reached disk size limit on backup server" in self.backups[-1].error['base']
        else:
            test.log.info("Total size - {}".format(total_size))

    def test_you_can_restore_last_backup_if_total_storage_disk_size_less_than_or_equal_to_limit(self):
        # assert self.template.delete(), self.template.error
        total_size = (
            self.vs.get_backups_size() +
            self.template.template_size +
            RESERVED_STORAGE_SIZE
        )
        if total_size <= STORAGE_DISK_SIZE_LIMIT * 1048576:
            assert self.backups[-1].restore()
        else:
            test.log.info("Total size - {}".format(total_size))
    ####################################################################################################################

    def test_you_can_not_create_one_more_backup(self):
        backup = Backup(self.vs)
        assert not backup.create()
        assert EM in backup.error['base']

    def test_you_can_not_convert_backup_to_template(self):
        assert not self.backups[0].convert()
        assert EM in self.backups[0].template.error['base']

    def test_check_limits_for_iso_template(self):
        while sum(
            [
                self.total_size(self.backups, 'backup_size'),
                self.template.template_size,
                self.total_size(self.isos, 'template_size')
            ]
        ) <= STORAGE_DISK_SIZE_LIMIT * 1048576:
            self.iso.label = "{}{}_{}".format(
                self.__class__.__name__, 'ISO', test.time_stamp()
            )
            self.iso.make_public = False
            self.iso.min_memory_size = 512
            self.iso.operating_system = 'Linux'
            self.iso.version = 13
            self.iso.file_url = 'http://artfiles.org/linuxmint.com/linuxmint.com/stable/13/linuxmint-13-xfce-dvd-64bit.iso'
            self.iso.operating_system_distro = 'Mint'
            if self.iso.create():
                self.isos.append(self.iso)
            else:
                test.log.error(
                    "ISO has not been uploaded: {}".format(self.iso.error)
                )
                break

        self.iso.label = "{}{}_{}".format(
            self.__class__.__name__, 'ISO', test.time_stamp()
        )
        assert not self.iso.create()
        assert 'Disk size limit has been exceeded.' in self.iso.error['base']

    @staticmethod
    def total_size(objects, key):
        return sum([o.__dict__[key] for o in objects])
