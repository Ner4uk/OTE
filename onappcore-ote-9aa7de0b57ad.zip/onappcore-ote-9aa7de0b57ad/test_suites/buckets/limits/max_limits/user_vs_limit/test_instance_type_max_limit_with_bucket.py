# ignore
__author__ = ''
__doc__ = """"""
__since__ = None  # Describe version since this functional available

import pytest

from onapp_helper import test
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.bucket import access_controls as ac
from onapp_helper.instance_package import InstancePackage
from onapp_helper.user import User
from onapp_helper.server import VirtualServer


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.limits
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
@pytest.mark.skipif(
    test.cp_version < 4.1,
    reason="Current CP version ({0}) does not support this functionality ".format(test.cp_version)
)
@pytest.mark.verbose
# @pytest.mark.incremental
class TestInstanceTypeMaxLimitWithBucket:
    def setup_class(self):
        test.load_env()

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        try:
            self.bucket = Bucket()
            self.bucket.label = self.__name__
            assert self.bucket.create()

            ac.add_env_to_bucket(self.bucket)

            self.instance_type = InstancePackage()
            self.instance_type.label = self.__name__
            self.instance_type.cpus = 2
            self.instance_type.disk_size = 7
            self.instance_type.bandwidth = 1
            assert self.instance_type.create(), self.instance_type.error

            # Get targets
            self.hvz_id = test.env.hvz.id
            self.ntz_id = test.env.netz.id
            self.dsz_id = test.env.dsz.id

            self.instance_type_ac = ac.InstancePackageAC(
                parent_obj=self.bucket,
                target_id=self.instance_type.id
            )
            # Set IT preferences
            self.instance_type_ac.preferences.hypervisor_group_ids.append(self.hvz_id)
            self.instance_type_ac.preferences.data_store_group_ids.append(self.dsz_id)
            self.instance_type_ac.preferences.network_group_ids.append(self.ntz_id)
            assert self.instance_type_ac.create(), self.instance_type_ac.error

            self.hvz_ac = ac.ComputeZoneAC(
                parent_obj=self.bucket,
                target_id=self.hvz_id
            )
            assert self.hvz_ac.get()

            self.dsz_ac = ac.DataStoreZoneAC(
                parent_obj=self.bucket,
                target_id=self.dsz_id
            )
            assert self.dsz_ac.get()

            self.netz_ac = ac.NetworkZoneAC(
                parent_obj=self.bucket,
                target_id=self.ntz_id
            )
            assert self.netz_ac.get()

            self.vs = VirtualServer()
            self.vs.label = self.__name__
            self.vs.instance_package_id = self.instance_type.id
            self.vs.set_template()

            self.instance_type.memory = self.vs.template.min_memory_size
            assert self.instance_type.edit(), self.instance_type.error

            self.user = User(bucket=self.bucket)
            self.user.login = 'instancetypehourlyprice'
            self.user.password = test.generate_password()
            self.user.email = 'user@instancetypehourlyprice.test'
            assert self.user.create(), self.user.error

            test.execute_as(self.user.login, self.user.password)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        attributes = (
            'user',
            'bucket',
            'instance_type'
        )
        test.clean_up_resources(attributes, self)

    def test_should_be_impossible_to_create_vs_without_resources_in_ac(self):
        """
        Remove HV,DS,Net zones from AC and try to create a new VS

        Expected result: Should be impossible, appropriate error messages
        should be in response
        :return:
        """
        pytest.mark.skip('Not realised!')

    #  Negative tests, you can not create a VS if resources exceed access
    # control limits
    def test_check_validation_for_cpus_limits(self):
        self.set_ac_to_unlimited()
        if self.vs.id and self.vs.get():
            self.vs.delete()
        self.hvz_ac.limits.limit_cpu = self.instance_type.cpus - 1
        self.hvz_ac.limits.limit_default_cpu = self.hvz_ac.limits.limit_cpu
        assert self.hvz_ac.edit(), self.hvz_ac.error

        assert not self.vs.create()
        assert f'CPUs must be less than or equal ' \
               f'to {float(self.hvz_ac.limits.limit_cpu)} to ' \
               f'meet billing requirements' in self.vs.error['cpus']

    def test_check_validation_for_max_memory_limits(self):
        self.set_ac_to_unlimited()
        if self.vs.id and self.vs.get():
            self.vs.delete()
        self.hvz_ac.limits.limit_memory = self.instance_type.memory - 1
        self.hvz_ac.limits.limit_min_memory = self.hvz_ac.limits.limit_memory
        assert self.hvz_ac.edit(), self.hvz_ac.error

        assert not self.vs.create()
        assert f'Memory must be less than or equal ' \
               f'to {float(self.hvz_ac.limits.limit_memory)} MB to meet ' \
               f'billing requirements' in self.vs.error['memory']

    def test_check_validation_for_disk_size_limits(self):
        self.set_ac_to_unlimited()
        if self.vs.id and self.vs.get():
            self.vs.delete()
        self.dsz_ac.limits.limit = self.instance_type.disk_size - 1
        assert self.dsz_ac.edit(), self.dsz_ac.error

        assert not self.vs.create()
        assert 'em' in self.vs.error  # Validation in transaction???

    def test_you_can_create_vs_if_resources_allows_ac_limits(self):
        self.set_ac_to_unlimited()
        self.hvz_ac.limits.limit_cpu = self.instance_type.cpus + 1
        self.hvz_ac.limits.limit_default_cpu = self.hvz_ac.limits.limit_cpu
        # self.hvz_ac.limits.limit_cpu_share = 100  # Not works
        self.hvz_ac.limits.limit_memory = self.instance_type.memory + 1
        assert self.hvz_ac.edit(), self.hvz_ac.error

        self.dsz_ac.limits.limit = self.instance_type.disk_size + 10
        assert self.dsz_ac.edit(), self.dsz_ac.error

        assert self.vs.create(), self.vs.error

    def set_ac_to_unlimited(self):
        self.hvz_ac.limits.__init__(ac.SERVER_TYPE.virtual)
        assert self.hvz_ac.edit(), self.hvz_ac.error

        self.dsz_ac.limits.__init__(ac.SERVER_TYPE.virtual)
        assert self.dsz_ac.edit(), self.hvz_ac.error