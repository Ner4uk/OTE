
from onapp_helper.bucket import access_controls as ac
from onapp_helper.bsz import BSZ
from onapp_helper.backup import Backup
from onapp_helper.iso import ISO
from onapp_helper.user import User
from onapp_helper.bucket.bucket import Bucket
from onapp_helper import test
from onapp_helper.server import VirtualServer
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.limits
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
@pytest.mark.incremental
@pytest.mark.verbose
class TestTemplateMaxLimit:
    def setup_class(self):
        test.load_env()

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        try:
            self.bucket = Bucket()
            self.bucket.label = self.__name__
            assert self.bucket.create()

            self.vs = VirtualServer()
            self.iso = ISO()
            self.user = User(bucket=self.bucket)
            self.backup = Backup(self.vs)

            ac.add_all_resources_to_bucket(bucket=self.bucket)

            self.template_ac = ac.TemplatesAC(parent_obj=self.bucket)

            self.bsz_acs = []
            for bsz_id in BSZ().get_key_values('id'):
                self.bsz_acs.append(
                    ac.BackupServerZoneAC(
                        parent_obj=self.bucket,
                        target_id=bsz_id
                    )
                )

            self.user.login = 'templatemaxlimitstest'
            self.user.password = test.generate_password()
            self.user.email = 'user@templatemaxlimits.test'
            assert self.user.create(), self.user.error
            test.execute_as(self.user.login, self.user.password)
            self.vs.label = self.__name__
            assert self.vs.create(), self.vs.error

            for bsz_ac in self.bsz_acs:
                bsz_ac.get()
                bsz_ac.limits.limit_template = 0
                bsz_ac.limits.limit_backup = 0
                assert bsz_ac.edit(), bsz_ac.error

            assert self.backup.create(), self.backup.error
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        self.user.delete()
        self.bucket.delete()

    def test_set_template_max_limit_as_0(self):
        # Add 0 limit for all possible ways for backup creation. (HV, BSZ)
        assert self.template_ac.get(), self.template_ac.error
        self.template_ac.limits.limit = 0
        assert self.template_ac.edit(), self.template_ac.error

    def test_should_be_impossible_to_create_a_template(self):
        assert not self.backup.convert()
        # The error message depends on backup type.
        # https://onappdev.atlassian.net/browse/CORE-7379
        assert 'You have reached your template creation limit' in \
               self.backup.template.error['base'][0]

    def test_set_template_max_limit_as_1(self):
        assert self.template_ac.get(), self.template_ac.error
        self.template_ac.limits.limit = 1
        assert self.template_ac.edit(), self.template_ac.error

    def test_should_be_impossible_to_create_two_templates(self):
        t = self.backup.convert(label=self.__class__.__name__)
        assert not self.backup.convert()
        # The error message depends on backup type.
        # https://onappdev.atlassian.net/browse/CORE-7379
        assert 'You have reached your template creation limit' in \
               self.backup.template.error['base'][0]

        t.delete()
        self.backup.template.delete()