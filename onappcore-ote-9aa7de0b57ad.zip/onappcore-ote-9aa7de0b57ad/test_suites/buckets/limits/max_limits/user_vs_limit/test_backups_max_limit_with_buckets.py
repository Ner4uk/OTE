#  Use any backup type.

import pytest

from onapp_helper import test
from onapp_helper.server import VirtualServer, ApplicationServer
from onapp_helper.backup import Backup
from onapp_helper.bucket import access_controls as ac
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.schedule import Schedule
from onapp_helper.user import User

BASE_LIMIT_MSG = "You have reached your {} creation limit"
REACHED_BACKUP_CREATION_LIMIT_MSG = BASE_LIMIT_MSG.format('Backup')
REACHED_TEMPLATE_CREATION_LIMIT_MSG = BASE_LIMIT_MSG.format('template')
REACHED_OVA_CREATION_LIMIT_MSG = BASE_LIMIT_MSG.format('OVA')

BASE_DISK_SIZE_MSG = "You have reached your {} Disk Size Max limit"
REACHED_OVA_DISK_SIZE_MSG = BASE_DISK_SIZE_MSG.format("OVA")


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.limits
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
@pytest.mark.verbose
class TestBackupMaxLimit:
    __doc__ = """
    1. Configure Bucket:
        - deny storing backups on BSZ
        - set limits
    2. Create backups (auto, manual), templates
    3. Waiting for statistics
    4. Compare expected value with actual. Check that for onapp >= 5.9 auto 
    backups count limit/price also works
    """

    def setup_class(self):
        test.load_env()

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        try:
            self.bucket = Bucket()
            self.bucket.label = self.__name__
            assert self.bucket.create()

            ac.add_env_to_bucket(self.bucket)

            # Remove all BSZs
            for bs in test.env.backup_servers:
                ac.BackupServerZoneAC(
                    parent_obj=self.bucket,
                    target_id=bs.backup_server_group_id
                ).delete()

            self.vs = VirtualServer()
            self.apps = ApplicationServer()
            self.user = User(bucket=self.bucket)

            self.backup_ac = ac.BackupsAC(parent_obj=self.bucket)
            self.backup_ac.get()

            self.user.login = 'backupmaxlimitstest'
            self.user.password = test.generate_password()
            self.user.email = 'user@backupmaxlimits.test'
            assert self.user.create()
            test.execute_as(self.user.login, self.user.password)
            self.vs.label = self.__name__
            assert self.vs.create(), self.vs.error
            self.primary_disk = self.vs.get_primary_disk()

            if test.onapp_settings.allow_incremental_backups:
                self.bu_source = self.vs
            else:
                self.bu_source = self.vs.get_primary_disk()

            self.schedule = Schedule(target=self.bu_source)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        self.user.delete()
        self.bucket.delete()

    def test_set_backup_max_limit_as_0(self):
        # Add 0 limit for all possible ways for backup creation. (HV, BSZ)
        self.backup_ac.limits.limit = 0
        assert self.backup_ac.edit()

    def test_should_be_impossible_to_create_a_manual_backup(self):
        b = Backup(self.vs)
        assert not b.create()

        if test.cp_version >= 5.7:
            assert REACHED_BACKUP_CREATION_LIMIT_MSG in b.transaction.log_output
            b.delete()
        else:
            assert REACHED_BACKUP_CREATION_LIMIT_MSG in b.error['base']

    # Billing Backups count limits does not work with autobackups
    # https://onappdev.atlassian.net/browse/CORE-5467
    @pytest.mark.skipif(
        test.cp_version >= 5.9,
        reason="Limitation for auto backups supported since 5.9, (CORE-12200)"
    )
    def test_you_can_take_autobackups_for_limit_0(self):
        self.bu_source.enable_auto_backups()
        assert self.vs.get_auto_backups_count() == 4

    ############################################################################
    # Auto backups limitation supported since 5.9 ##############################
    # https://onappdev.atlassian.net/browse/CORE-12200
    # COUNT LIMITATION
    @pytest.mark.skipif(
        test.cp_version < 5.9,
        reason="Limitation for auto backups supported since 5.9, (CORE-12200)"
    )
    @pytest.mark.parametrize('limit', [0, 3])
    def test_you_can_not_take_disk_auto_backups_for_limit_less_than_4(self, limit):
        self.backup_ac.limits.limit = limit
        assert self.backup_ac.edit()

        backups = self.bu_source.enable_auto_backups()
        assert len(backups) == 4  # but schedule transactions should be failed

        for b in backups:
            assert REACHED_BACKUP_CREATION_LIMIT_MSG in b.transaction.log_output
            assert b.delete(), b.error

        schedules = self.schedule.get_all()
        for s in schedules:
            assert s.delete(), s.error

    # https://onappdev.atlassian.net/browse/CORE-12200
    @pytest.mark.skipif(
        test.cp_version < 5.9,
        reason="Limitation for auto backups supported since 5.9, (CORE-12200)"
    )
    def test_you_can_take_disk_auto_backups_for_limit_4(self):
        self.backup_ac.limits.limit = 4
        assert self.backup_ac.edit()

        backups = self.bu_source.enable_auto_backups()
        assert len(backups) == 4

    @pytest.mark.skipif(
        test.cp_version < 5.9,
        reason="Limitation for auto backups supported since 5.9, (CORE-12200)"
    )
    def test_you_can_not_add_manual_backup_if_limit_4_and_4_auto_backups_is_present(self):
        if self.vs.get_auto_backups_count() != 4:
            pytest.skip("Backups count is not equal to 4th")
        b = Backup(self.vs)
        assert not b.create()

        if test.cp_version >= 5.7:
            assert REACHED_BACKUP_CREATION_LIMIT_MSG in b.transaction.log_output
            b.delete()
        else:
            assert REACHED_BACKUP_CREATION_LIMIT_MSG in b.error['base']

    @pytest.mark.skipif(
        test.cp_version < 5.9,
        reason="Limitation for auto backups supported since 5.9, (CORE-12200)"
    )
    def test_you_can_add_manual_backup_if_limit_5_and_4_auto_backups_is_present(self):
        self.backup_ac.limits.limit = 5
        assert self.backup_ac.edit()

        if self.vs.get_backups_count() != 4:
            pytest.skip("Backups count is not equal to 4th")
        b = Backup(self.vs)
        assert b.create(), b.error

    @pytest.mark.skipif(
        test.cp_version < 5.9,
        reason="Limitation for auto backups supported since 5.9, (CORE-12200)"
    )
    def test_schedules_should_works_if_count_limit_reached(self):
        # Get daily schedule
        daily_schedule = [
            s for s in self.schedule.get_all()
            if s.period == s.PERIOD.days
        ][0]

        # Change daily schedule start time to get auto backup running
        daily_schedule.start_at = test.get_time_str(shift=30, utc=True)
        assert daily_schedule.edit(), daily_schedule.error
        test.wait_for_action(
            lambda: self.vs.get_auto_backups_count() == 5, timeout=180, step=5
        )

        auto_backups = [
            b for b in self.vs.get_backups() if b.initiated == 'days'
        ]

        old_daily_backup = [b for b in auto_backups if b.built][0]
        rotated_daily_backup = [b for b in auto_backups if not b.built][0]

        if rotated_daily_backup.backup_type == rotated_daily_backup.TYPE.normal:
            action = 'take_backup'
        elif rotated_daily_backup.backup_type == rotated_daily_backup.TYPE.incremental:
            action = 'take_incremental_backup'

        assert rotated_daily_backup.transaction_handler(
            action=action
        )
        assert old_daily_backup.transaction_handler(
            action='destroy_backup'
        )
        assert self.vs.get_auto_backups_count() == 4

    @pytest.mark.skipif(
        test.cp_version < 5.9,
        reason="Limitation for auto backups supported since 5.9, (CORE-12200)"
    )
    def test_remove_schedules_after_count_limitation(self):
        for s in self.schedule.get_all():
            assert s.delete(), s.error

    @pytest.mark.skipif(
        test.cp_version < 5.9,
        reason="Limitation for auto backups supported since 5.9, (CORE-12200)"
    )
    def test_remove_all_existed_backups_after_count_limitation(self):
        for b in self.vs.get_backups():
            assert b.delete(), b.error
