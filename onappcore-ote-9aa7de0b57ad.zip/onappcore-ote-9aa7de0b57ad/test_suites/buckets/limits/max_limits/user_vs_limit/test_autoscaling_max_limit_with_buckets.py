
from onapp_helper.bucket import access_controls as ac
from onapp_helper.autoscaling import MemoryUp
from onapp_helper.user import User
from onapp_helper.bucket.bucket import Bucket
from onapp_helper import test
from onapp_helper.server import VirtualServer
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.limits
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
@pytest.mark.incremental
class TestAutoscalingMaxLimit:
    def setup_class(self):
        test.load_env()

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        try:
            self.bucket = Bucket()
            self.bucket.label = self.__name__
            assert self.bucket.create()

            ac.add_env_to_bucket(self.bucket)

            self.vs1 = VirtualServer()
            self.vs2 = VirtualServer()
            #self.apps = app_server.ApplicationServer()
            self.user = User(bucket=self.bucket)

            self.autoscaling_ac = ac.AutoscaledServersAC(
                parent_obj=self.bucket
            )
            assert self.autoscaling_ac.get(), self.autoscaling_ac.error

            self.user.login = 'autoscalingmaxlimitstest'
            self.user.password = test.generate_password()
            self.user.email = 'user@autoscalingmaxlimits.test'
            assert self.user.create(), self.user.error
            test.execute_as(self.user.login, self.user.password)
            self.vs1.label = self.__name__
            self.memory_autoscaling_up = MemoryUp(self.vs1)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        self.user.delete()
        self.bucket.delete()

    def test_set_autoscaling_max_limit_as_0(self):
        self.autoscaling_ac.limits.limit = 0
        assert self.autoscaling_ac.edit(), self.autoscaling_ac.error

    def test_should_be_impossible_to_create_a_vs_with_enable_autoscaling(self):
        self.vs1.enable_autoscale = True
        assert not self.vs1.create()
        assert 'Virtual server with autoscale limit exceeded' in self.vs1.error['base']

    def test_vs_should_be_created_with_disable_autoscale(self):
        self.vs1.enable_autoscale = False
        assert self.vs1.create(), self.vs1.error

    def test_should_be_impossible_to_enable_autoscale(self):
        assert not self.vs1.autoscale_enable()
        assert 'Autoscale is not allowed by bucket' in self.vs1.error['enable_autoscale']

    def test_set_autoscaling_max_limit_as_1(self):
        self.autoscaling_ac.limits.limit = 1
        assert self.autoscaling_ac.edit(), self.autoscaling_ac.error

    def test_should_be_possible_to_enable_autoscale(self):
        assert self.vs1.autoscale_enable(), self.vs1.error

    def test_should_be_possible_to_disable_autoscale(self):
        assert self.vs1.autoscale_disable(), self.vs1.error

    def test_should_be_possible_to_create_one_more_vs_with_enable_autoscale(self):
        """ Try to create vs2 with enable autoscale
        Should be possible"""
        self.vs2.label = '{0}2'.format(self.__class__.__name__)
        self.vs2.enable_autoscale = True
        assert self.vs2.create(), self.vs2.error

    def test_disable_autoscale_on_second_vs(self):
        assert self.vs2.autoscale_disable(), self.vs2.error

    def test_enable_autoscale_on_second_vs(self):
        assert self.vs2.autoscale_enable(), self.vs2.error