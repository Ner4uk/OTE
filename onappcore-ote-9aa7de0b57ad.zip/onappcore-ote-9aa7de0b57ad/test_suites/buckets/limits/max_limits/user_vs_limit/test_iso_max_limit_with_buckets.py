import pytest
from onapp_helper.bucket import access_controls as ac
from onapp_helper.iso import ISO
from onapp_helper.user import User

from onapp_helper.bucket.bucket import Bucket
from onapp_helper import test


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.limits
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
class TestISOMaxLimit():
    def setup_class(self):
        try:
            self.bucket = Bucket()
            self.bucket.label = self.__name__
            assert self.bucket.create(), self.bucket.error

            self.iso = ISO()
            self.user = User(bucket=self.bucket)

            self.iso_ac = ac.ISOTemplatesAC(parent_obj=self.bucket)
            assert self.iso_ac.create(), self.iso_ac.error

            self.user.login = 'isomaxlimitstest'
            self.user.password = test.generate_password()
            self.user.email = 'user@isomaxlimits.test'
            assert self.user.create(), self.user.error
            test.execute_as(self.user.login, self.user.password)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        self.user.delete()
        self.bucket.delete()

    def test_set_iso_max_limit_as_0(self):
        self.iso_ac.limits.limit = 0
        assert self.iso_ac.edit(), self.iso_ac.error

    def test_should_be_impossible_to_upload_iso(self):
        self.iso.label = self.__class__.__name__
        self.iso.make_public = False
        self.iso.min_memory_size = 512
        self.iso.operating_system = 'Linux'
        self.iso.version = 13
        self.iso.file_url = 'http://templates.repo.onapp.com/Linux-iso/CentOS-6.9-x86_64-minimal.iso'
        self.iso.operating_system_distro = 'Centos'
        assert not self.iso.create()
        assert 'You have reached your ISO creation limit' in self.iso.error['base']