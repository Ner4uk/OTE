import pytest
from onapp_helper import test

from onapp_helper.bucket import access_controls as ac
from onapp_helper.server import VirtualServer
from onapp_helper.user import User
from onapp_helper.bucket.bucket import Bucket


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.limits
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
class TestHVZMaxLimits:
    def setup_class(self):
        test.load_env()

        try:
            # Setup
            self.bucket = Bucket()
            self.bucket.label = self.__name__
            assert self.bucket.create()

            ac.add_env_to_bucket(bucket=self.bucket)

            # Setup for base resources
            self.hvz_ac = ac.ComputeZoneAC(
                parent_obj=self.bucket,
                target_id=test.env.hvz.id
            )
            assert self.hvz_ac.get()

            # Create User and VS
            self.user = User(bucket=self.bucket)
            self.user.login = "hvzmaxlimitstest"
            self.user.password = test.generate_password()
            self.user.email = 'user@hvzmaxlimitstest.test'
            assert self.user.create()
            # Login as new user
            test.execute_as(self.user.login, self.user.password)

            self.vs = VirtualServer()
            self.vs.rate_limit = 0  #  Unlimited
            self.vs.label = self.__name__
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        self.user.delete()
        self.bucket.delete()

    def test_set_cpu_cores_max_limit_as_1_cpus(self):
        self.hvz_ac.reset()
        self.hvz_ac.limits.limit_cpu = 1
        assert self.hvz_ac.edit(), self.hvz_ac.error

    def test_should_be_impossible_to_create_vs_with_2_cores(self):
        self.vs.cpus = 2
        assert not self.vs.create()
        assert 'CPUs must be less than or equal to 1.0 to meet billing ' \
               'requirements' in self.vs.error['cpus'], self.vs.error

    def test_set_cpu_shares_max_limit_as_1_percent(self):
        self.hvz_ac.reset()
        self.hvz_ac.limits.limit_cpu_share = 1
        self.hvz_ac.limits.limit_default_cpu_share = 1
        assert self.hvz_ac.edit(), self.hvz_ac.error

    def test_should_be_impossible_to_create_vs_with_2_percent(self):
        self.vs.cpu_shares = 2
        assert not self.vs.create()
        assert 'CPU shares must be less than or equal to 1.0 to meet billing ' \
               'requirements' in self.vs.error['cpu_shares'], self.vs.error

    def test_set_memory_max_limit_as_512MB(self):
        self.hvz_ac.reset()
        self.hvz_ac.limits.limit_memory = 512
        assert self.hvz_ac.edit(), self.hvz_ac.error

    def test_should_be_impossible_to_create_vs_with_more_than_513MB_of_RAM(self):
        self.vs.memory = 513
        assert not self.vs.create()
        assert 'Memory must be less than or equal to 512.0 MB to meet ' \
               'billing requirements' in self.vs.error['memory'], self.vs.error

    def test_create_a_vs(self):
        self.hvz_ac.reset()
        assert self.hvz_ac.edit(), self.hvz_ac.error
        self.vs.cpus = 1
        self.vs.cpu_shares = 1
        self.vs.memory = 512
        assert self.vs.create(), self.vs.error

    def test_set_max_cpus_as_2(self):
        self.hvz_ac.limits.limit_cpu = 2
        assert self.hvz_ac.edit(), self.hvz_ac.error

    def test_should_be_impossible_to_set_3_cores(self):
        self.vs.cpus = 3
        assert not self.vs.edit()
        assert "CPUs must be less than or equal to 2.0 to meet billing " \
               "requirements" in self.vs.error['cpus'], self.vs.error
        if test.cp_version < 5.8:
            assert "User resources reach limits" in self.vs.error['base'], self.vs.error

    def test_set_max_cpu_share_as_2(self):
        self.hvz_ac.reset()
        self.hvz_ac.limits.limit_cpu_share = 2
        self.hvz_ac.limits.limit_default_cpu_share = self.hvz_ac.limits.limit_cpu_share
        assert self.hvz_ac.edit(), self.hvz_ac.error

    def test_should_be_impossible_to_set_3_cpu_shares(self):
        self.vs.cpus = 1
        self.vs.cpu_shares = 3
        assert not self.vs.edit()
        assert "CPU shares must be less than or equal to 2.0 to meet " \
               "billing requirements" in self.vs.error['cpu_shares'], self.vs.error
        if test.cp_version < 5.8:
            assert "User resources reach limits" in self.vs.error['base'], self.vs.error

    def test_set_max_memory_as_512(self):
        self.hvz_ac.reset()
        self.hvz_ac.limits.limit_memory = 512
        assert self.hvz_ac.edit(), self.hvz_ac.error

    def test_should_be_impossible_to_set_513_for_ram(self):
        self.vs.cpu_shares = 1
        self.vs.memory = 513
        assert not self.vs.edit()
        assert "Memory must be less than or equal to 512 MB to meet billing " \
               "requirements" in self.vs.error['memory'], self.vs.error
        if test.cp_version < 5.8:
            assert "User resources reach limits" in self.vs.error['base'], self.vs.error
