#! /usr/bin/env python

__author__ = 'zhuk'
import pytest
from onapp_helper.vcloud.orchestration_model import OrchestrationModel
from onapp_helper.user_group import UserGroup
from onapp_helper.hypervisor import Hypervisor
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.bucket import access_controls as ac
from test_helper import errorsTH
from onapp_helper import test


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.limits
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
class TestDeployOrchestrationModelsPayAsYouGoMaxLimits():
    def setup_class(self):
        try:
            self.less_cpu_message = 'is [0-9.]+GHz, but must be [0-9.]+GHz or less, according to the company plan and template limits'
            self.less_memory_message = 'is [0-9.]+GB, but must be [0-9.]+GB or less, according to the company plan and template limits'

            self.hv = Hypervisor()
            hvs = self.hv.get_vcloud()
            if hvs:
                self.hv = hvs[0]
            else:
                raise ValueError("There is no vcloud HV on this cloud.")

            self.user_group = UserGroup()
            # self.user_group = UserGroup(id=3198)
            self.user_group = [
                ug for ug in self.user_group.get_all() if ug.label == 'onapp'
                ][0]

            # Get user group company plan
            self.bucket = Bucket(
                id=self.user_group.company_billing_plan_id
            )

            # ac.add_all_resources_to_bucket(self.bucket)

            # Set up Company Plan limits
            self.hvz_ac = ac.ComputeZoneAC(
                parent_obj=self.bucket,
                target_id=self.hv.hypervisor_group_id,
                server_type=ac.SERVER_TYPE.vpc
            )
            if not self.hvz_ac.get():
                assert self.hvz_ac.create(), self.hvz_ac.error

            # OM
            self.om = OrchestrationModel(self.hv.id)

            #  Add missing data store zones to company base resources
            for ds in self.om.provider_vdc.storage_policies:
                dsz_ac = ac.DataStoreZoneAC(
                        parent_obj=self.bucket,
                        target_id=ds["storage_policy"]["id"],
                        server_type=ac.SERVER_TYPE.vpc
                    )

                if not dsz_ac.get():
                    dsz_ac.create()

            # Add missing network zones to company base resources
            for np in self.om.provider_vdc.network_pools:
                ntz_ac = ac.NetworkZoneAC(
                        parent_obj=self.bucket,
                        target_id=np["network_pool"]["id"],
                        server_type=ac.SERVER_TYPE.vpc
                    )
                if not ntz_ac.get():
                    ntz_ac.create()

            # Set limits
            self.hvz_ac.limits.limit_pay_as_you_go_cpu_limit = (
                (self.om.provider_vdc.cpu_used / 1000.0) - 1
            )
            self.hvz_ac.limits.limit_pay_as_you_go_memory_limit = (
                (self.om.provider_vdc.memory_used / 1000.0) - 1
            )
            self.hvz_ac.edit()

            self.om.network_to_create = [
                {
                    "name": "Network-1",
                    "type": "routed",
                    "network_address": "11.11.1.1/24",
                    "dns": "9.9.9.9"
                },
                {
                    "name": "Network-2",
                    "type": "routed",
                    "network_address": "11.11.2.1/24",
                    "dns": "9.9.4.4"
                }
            ]
            self.om.label = self.__name__
            self.om.vdc_model_type = 'pay_as_you_go'
            assert self.om.create()
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        self.om.delete()
        self.hvz_ac.limits.limit_pay_as_you_go_cpu_limit = None
        self.hvz_ac.limits.limit_pay_as_you_go_memory_limit = None
        assert self.hvz_ac.edit(), self.hvz_ac.error

    def test_should_be_impossible_to_deploy_om_with_cpu_limit_more_than_max(self):
        self.om.cpu_quota = \
            self.hvz_ac.limits.limit_pay_as_you_go_cpu_limit + 1
        # self.om.memory_quota = \
        #     self.company_hvz_br.limits.limit_pay_as_you_go_memory_limit + 1
        assert not self.om.deploy(self.user_group.id)
        assert errorsTH.check_if_error_in_error_list_by_reg_exp(
            self.less_cpu_message, self.om.error['cpu_quota']
        )

    def test_should_be_impossible_to_deploy_om_with_memory_limit_more_than_max(self):
        # self.om.cpu_quota = self.company_hvz_br.limits.limit_pay_as_you_go_cpu_limit
        self.om.memory_quota = \
            self.hvz_ac.limits.limit_pay_as_you_go_memory_limit + 1
        assert not self.om.deploy(self.user_group.id)
        assert errorsTH.check_if_error_in_error_list_by_reg_exp(
            self.less_memory_message, self.om.error['memory_quota']
        )
