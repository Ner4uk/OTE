from onapp_helper import test

from onapp_helper.bucket import access_controls as ac
from onapp_helper.server import VirtualServer
from onapp_helper.network_interface import NetworkInterface
from onapp_helper.ip_address_join import IpAddressJoin
from onapp_helper.user import User
from onapp_helper.bucket.bucket import Bucket
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.limits
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.verbose
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
class TestNetZMaxLimits:
    def setup_class(self):
        test.load_env(use_two_network_joins=True)

        if not test.env.netz.id:
            pytest.skip("No available network zones.")

        try:
            # Setup
            self.bucket = Bucket()
            self.bucket.label = self.__name__
            assert self.bucket.create(), self.bucket.error

            ac.add_all_resources_to_bucket(self.bucket)

            # Setup for base resources
            self.ntz_ac = ac.NetworkZoneAC(
                parent_obj=self.bucket,
                target_id=test.env.netz.id
            )
            assert self.ntz_ac.get(), self.ntz_br.error

            # Create User and VS
            self.user = User(bucket=self.bucket)
            self.user.login = "ntzmaxlimitstest"
            self.user.password = test.generate_password()
            self.user.email = 'user@ntzmaxlimitstest.test'
            assert self.user.create(), self.user.error
            # Login as new user
            test.execute_as(self.user.login, self.user.password)

            self.vs_1 = VirtualServer()
            self.vs_1.rate_limit = 0  #  Unlimited
            self.vs_1.label = self.__name__ + '1'

            self.vs_2 = VirtualServer()
            self.vs_2.rate_limit = 0  #  Unlimited
            self.vs_2.label = self.__name__ + '2'

            self.second_ip_address_join = IpAddressJoin(self.vs_1)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        test.clean_up_resources(('user', 'bucket'), self)

    def test_set_max_ip_address_limit_as_0(self):
        self.ntz_ac.reset()
        self.ntz_ac.limits.limit_ip = 0
        assert self.ntz_ac.edit(), self.ntz_ac.error

    def test_should_be_impossible_to_create_vs(self):
        #  https://onappdev.atlassian.net/browse/CORE-11383 - Done
        #time.sleep(10)
        # Actually in this case we have created vs without IP address
        assert not self.vs_1.create()
        # Expected Error Message - eem
        if test.cp_version >= 5.8:
            eem = "IP address can't be assigned, because you have reached your IP address limit"
            key = 'base'
        else:
            eem = "can't be assigned, because you have reached your billing IP address limit"
            key = 'selected_ip_address'
        assert [e for e in self.vs_1.error[key] if eem in e]

        # Delete all test VS without IP by label
        [vs.delete() for vs in VirtualServer().search(query=self.vs_1.label)]

    def test_set_max_port_speed_as_4(self):
        self.ntz_ac.reset()
        self.ntz_ac.limits.limit_rate = 4
        assert self.ntz_ac.edit(), self.ntz_ac.error

    def test_should_be_impossible_to_create_vs_with_port_speed_equal_5(self):
        self.vs_1.rate_limit = 5
        #time.sleep(10)
        assert not self.vs_1.create()
        eem1 = 'Port Speed Limit set in Billing Plan exceeded'
        assert [e for e in self.vs_1.error['network_interfaces'] if eem1 in e]
        eem2 = 'billing limit exceeded'
        assert [
            e for e in self.vs_1.error['primary_network_group_id'] if eem2 in e
        ]

    def test_set_max_port_speed_as_1(self):
        self.ntz_ac.reset()
        self.ntz_ac.limits.limit_rate = 1
        assert self.ntz_ac.edit(), self.ntz_ac.error

    def test_should_be_impossible_to_create_vs_with_unlimited_port_speed(self):
        self.vs_1.rate_limit = 0
        #time.sleep(10)
        assert not self.vs_1.create()
        eem1 = 'Port Speed Limit set in Billing Plan exceeded'
        assert [e for e in self.vs_1.error['network_interfaces'] if eem1 in e]
        eem2 = 'billing limit exceeded'
        assert [
            e for e in self.vs_1.error['primary_network_group_id'] if eem2 in e
        ]

    def test_set_max_port_speed_as_90(self):
        self.ntz_ac.reset()
        self.ntz_ac.limits.limit_ip = 2
        self.ntz_ac.limits.limit_rate = 90
        assert self.ntz_ac.edit(), self.ntz_ac.error

    def test_should_be_possible_to_create_2_vs_with_port_speed_90_for_each(self):
        self.vs_2.rate_limit = 90

        if test.cp_version < 6.0:
            self.vs_1.rate_limit = 90
        else:
            self.vs_1.network_interfaces_attributes[0].rate_limit = 90

        assert self.vs_1.create(), self.vs_1.error
        assert self.vs_2.create(), self.vs_2.error

        assert self.vs_1.network_interface.get_primary().rate_limit == 90
        assert self.vs_2.network_interface.get_primary().rate_limit == 90

    def test_add_second_network_interface_with_the_same_rate_limit(self):
        # ToDo - network joins should be from the same Network Zone
        servers_nics = NetworkInterface(parent_obj=self.vs_1).get_all()

        self.primary_network_join_id = [
            nic.network_join_id for nic in servers_nics if nic.primary
            ][0]
        self.secondary_network_join = [
            nj for nj in test.env.network_joins if
            nj.id != self.primary_network_join_id
            ][0]

        self.nic = NetworkInterface(parent_obj=self.vs_1)

        self.nic.primary = False
        self.nic.rate_limit = 90
        self.nic.network_join_id = self.secondary_network_join.id

        assert self.nic.add(), self.nic.error
        assert self.nic.rate_limit == 90

    def test_should_be_impossible_to_exceed_port_speed_limit(self):
        primary_nic = self.vs_1.network_interface.get_primary()
        assert not primary_nic.edit(rate_limit=9090)
        assert 'Limit set in Billing Plan exceeded' in primary_nic.error['rate_limit']

    def test_should_be_impossible_to_exceed_ip_address_limit(self):
        primary_nic = self.vs_1.network_interface.get_primary()
        assert not self.second_ip_address_join.assign_to_server(
            network_interface_id=primary_nic.id
        )
        assert "IP address can't be used, because you have reached your billing IP address limit"\
               in self.second_ip_address_join.error['selected_ip_address']
        #  IP address has not been assigned. IP address can't be used, because you have reached your billing IP address limit