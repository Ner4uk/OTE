import pytest
from onapp_helper import test
from onapp_helper.service_addon.service_addon import ServiceAddon
from onapp_helper.service_addon.service_addon import ServiceAddonEvent
from onapp_helper.service_addon.service_addon_group import ServiceAddonGroup
from onapp_helper.service_addon.service_addon_group import RelationGroupAddon
from onapp_helper.bucket import access_controls as ac
from onapp_helper.bucket import rate_cards as rc
from onapp_helper.user import User
from onapp_helper.server import VirtualServer
from onapp_helper.recipe.recipe import Recipe
from onapp_helper.recipe.recipe_step import RecipeStep
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.stats.user_stats import UserStats
from onapp_helper.stats.vm_stat import VmStat
from test_helper import billingTH

ADDON_PRICE = 100
PRICE_CPU = 10.1
PRICE_MEMORY = 11.2
PRICE_DISK_SIZE = 12.3


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.limits
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version < 5.6,
    reason="{0} CP version does not support buckets".format(
        test.cp_version
    )
)
class TestBucketForServiceAddon:
    def setup_class(self):
        test.load_env()
        # test.run_at(minutes=40)

        try:
            # Create a ServiceAddonGroup
            self.service_addon_group = ServiceAddonGroup()
            self.service_addon_group.label = self.__name__
            assert self.service_addon_group.create(), self.service_addon_group.error

            # Create a Bucket
            self.bucket = Bucket()
            self.bucket.label = self.__name__
            assert self.bucket.create()

            ac.add_all_resources_to_bucket(self.bucket)

            # Create a Recipe on add action
            self.recipe_on_add = Recipe()
            self.recipe_on_add.label = self.__name__ + 'OnAdd'
            self.recipe_on_add.compatible_with = Recipe.COMPATIBLE_WITH.unix
            assert self.recipe_on_add.create(), self.recipe_on_add.error

            # Add recipe step
            self.recipe_on_add_step1 = RecipeStep(self.recipe_on_add)
            self.recipe_on_add_step1.script = 'echo "assigned" > /tmp/service_addon_test'
            self.recipe_on_add_step1.on_success = RecipeStep.ON_SUCCESS.proceed
            self.recipe_on_add_step1.on_failure = RecipeStep.ON_FAILURE.fail
            self.recipe_on_add_step1.result_source = RecipeStep.RESULT_SOURCE.exit_code
            assert self.recipe_on_add_step1.create(), self.recipe_on_add_step1.error

            # Create a Recipe on remove action
            self.recipe_on_remove = Recipe()
            self.recipe_on_remove.label = self.__name__ + 'OnRemove'
            self.recipe_on_remove.compatible_with = Recipe.COMPATIBLE_WITH.unix
            assert self.recipe_on_remove.create(), self.recipe_on_remove.error

            # Add recipe step
            self.recipe_on_remove_step1 = RecipeStep(self.recipe_on_remove)
            self.recipe_on_remove_step1.script = 'echo "unassigned" > /tmp/service_addon_test'
            self.recipe_on_remove_step1.on_success = RecipeStep.ON_SUCCESS.proceed
            self.recipe_on_remove_step1.on_failure = RecipeStep.ON_FAILURE.fail
            self.recipe_on_remove_step1.result_source = RecipeStep.RESULT_SOURCE.exit_code
            assert self.recipe_on_remove_step1.create(), \
                self.recipe_on_remove_step1.error

            # Create a ServiceAddon
            self.service_addon = ServiceAddon()
            self.service_addon.label = self.__name__
            self.service_addon.compatible_with.append(
                ServiceAddon.COMPATIBLE_WITH.unix
            )
            assert self.service_addon.create(), self.service_addon.error

            # Add on add event
            self.on_add_event = ServiceAddonEvent(self.service_addon)
            assert self.on_add_event.add_recipe(
                self.recipe_on_add.id,
                ServiceAddonEvent.EVENT_TYPE.on_add_event
            ), self.on_add_event.error

            # Add on remove event
            self.on_remove_event = ServiceAddonEvent(self.service_addon)
            assert self.on_remove_event.add_recipe(
                self.recipe_on_remove.id,
                ServiceAddonEvent.EVENT_TYPE.on_remove_event
            ), self.on_remove_event.error

            # Add service addon to RelationGroupAddon (Group)
            self.relation_group_addon = RelationGroupAddon(
                self.service_addon_group
            )
            assert self.relation_group_addon.attach_addon_to_group(
                service_addon_id=self.service_addon.id
            ), self.relation_group_addon.error

            # Create a ServiceAddonStoreRC
            self.service_addon_group_rc = rc.ServiceAddonRC(
                parent_obj=self.bucket,
                target_id=self.service_addon.id,
                server_type=rc.SERVER_TYPE.other
            )
            self.service_addon_group_rc.prices.price = ADDON_PRICE
            self.service_addon_group_rc.prices.price_cpu = PRICE_CPU
            self.service_addon_group_rc.prices.price_memory = PRICE_MEMORY
            self.service_addon_group_rc.prices.price_disk_size = PRICE_DISK_SIZE
            assert self.service_addon_group_rc.create(), \
                self.service_addon_group_rc.error

            # Create a user
            self.user = User(bucket=self.bucket)
            self.user.login = self.__name__.lower()
            self.user.password = test.generate_password()
            self.user.email = '{}@test.com'.format(self.__name__.lower())
            self.user.role_ids = [1]
            assert self.user.create(), self.user.error

            test.execute_as(self.user.login, self.user.password)

            # Create a server
            self.vs = VirtualServer()
            self.vs.label = self.__name__
            assert self.vs.create(), self.vs.error

            self.vm_stat = VmStat(parent_obj=self.vs)
            self.user_stats = UserStats(self.user)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        attributes = (
            'vs',
            'user',
            'bucket',
            'service_addon',
            'service_addon_group',
            'recipe_on_add',
            'recipe_on_remove'
        )
        test.clean_up_resources(attributes, self)

    def test_add_service_addon_to_server(self):
        assert self.service_addon.assign_to_server(self.vs), \
            self.service_addon.error
        assert test.wait_for_action(
            lambda: 'assigned' in self.vs.execute(
                'cat /tmp/service_addon_test'
            ), timeout=5, step=2
        )

    def test_should_be_impossible_add_already_added_service_addon_to_server(self):
        assert not self.service_addon.assign_to_server(self.vs)
        assert "Add-on is already assigned" in self.service_addon.error['base']

    def test_hourly_price_on(self):
        self.vs.get()
        expected_price = sum(
            [
                ADDON_PRICE,
                PRICE_CPU * self.vs.cpus,
                PRICE_MEMORY * self.vs.memory,
                PRICE_DISK_SIZE * self.vs.total_disk_size
            ]
        )
        assert self.vs.price_per_hour == expected_price

    def test_hourly_price_off(self):
        self.vs.get()
        expected_price = sum(
            [
                ADDON_PRICE,
                PRICE_CPU * self.vs.cpus,
                PRICE_MEMORY * self.vs.memory,
                PRICE_DISK_SIZE * self.vs.total_disk_size
            ]
        )
        assert self.vs.price_per_hour_powered_off == expected_price

    def test_wait_for_stat(self):
        self.vm_stat.stats_waiter()
        self.vm_stat.get_hourly_stat_for_the_last_hour()

    def test_check_service_addon_cost(self):
        # last_hour_stat = self.vm_stat.vm_last_hour_stat
        expected_price = ADDON_PRICE * self.vm_stat.get_service_addons_count_value()
        test.log.info(
            "Actual Service Addon Cost - {}".format(
                self.vm_stat.get_service_addons_count_cost()
            )
        )
        test.log.info(
            "Expected Service Addon Cost - {}".format(expected_price)
        )
        test.log.info(
            "Actual Service Addon Value - {}".format(
                self.vm_stat.get_service_addons_count_value()
            )
        )
        test.log.info(
            "Expected Service Addon Value - {}".format(1)
        )
        assert billingTH.price_comparator_with_round(
            self.vm_stat.get_service_addons_count_cost(),
            expected_price,
            2
        )
        assert self.vm_stat.get_service_addons_count_value() == 1

    def test_check_service_addon_cpu_cost(self):
        # last_hour_stat = self.vm_stat.vm_last_hour_stat
        expected_price = PRICE_CPU * self.vm_stat.get_service_addons_cpus_value()
        test.log.info(
            "Actual Service Addon CPU Cost - {}".format(
                self.vm_stat.get_service_addons_cpus_cost()
            )
        )
        test.log.info(
            "Expected Service Addon CPU Cost - {}".format(expected_price)
        )
        test.log.info(
            "Actual Service Addon CPU Value - {}".format(
                self.vm_stat.get_service_addons_cpus_value()
            )
        )
        test.log.info(
            "Expected Service Addon Value - {}".format(self.vs.cpus)
        )

        assert billingTH.price_comparator_with_round(
            self.vm_stat.get_service_addons_cpus_cost(),
            expected_price,
            2
        )
        assert self.vm_stat.get_service_addons_cpus_value() == self.vs.cpus

    def test_check_service_addon_memory_cost(self):
        # last_hour_stat = self.vm_stat.vm_last_hour_stat
        expected_price = PRICE_MEMORY * self.vm_stat.get_service_addons_memory_value()
        test.log.info(
            "Actual Service Addon Memory Cost - {}".format(
                self.vm_stat.get_service_addons_memory_cost()
            )
        )
        test.log.info(
            "Expected Service Addon Memory Cost - {}".format(expected_price)
        )
        test.log.info(
            "Actual Service Addon Memory Value - {}".format(
                self.vm_stat.get_service_addons_memory_value()
            )
        )
        test.log.info(
            "Expected Service Addon Memory Value - {}".format(self.vs.memory)
        )

        assert billingTH.price_comparator_with_round(
            self.vm_stat.get_service_addons_memory_cost(),
            expected_price,
            2
        )
        assert self.vm_stat.get_service_addons_memory_value() == self.vs.memory

    def test_check_service_addon_disk_size_cost(self):
        # last_hour_stat = self.vm_stat.vm_last_hour_stat
        expected_price = PRICE_DISK_SIZE * \
                         self.vm_stat.get_service_addons_disk_size_value()
        test.log.info(
            "Actual Service Addon Disk Size Cost - {}".format(
                self.vm_stat.get_service_addons_disk_size_cost()
            )
        )
        test.log.info(
            "Expected Service Addon Disk Size Cost - {}".format(expected_price)
        )
        test.log.info(
            "Actual Service Addon Disk Size Value - {}".format(
                self.vm_stat.get_service_addons_disk_size_value()
            )
        )
        test.log.info(
            "Expected Service Addon Disk Size Value - {}".format(self.vs.total_disk_size)
        )

        assert billingTH.price_comparator_with_round(
            self.vm_stat.get_service_addons_disk_size_cost(),
            expected_price,
            2
        )
        assert self.vm_stat.get_service_addons_disk_size_value() == self.vs.total_disk_size

    def test_remove_service_addon_from_server(self):
        # To get 0 price for second hour
        assert self.service_addon.unassign_from_server(self.vs), \
            self.service_addon.error
        assert test.wait_for_action(
            lambda: 'unassigned' in self.vs.execute(
                'cat /tmp/service_addon_test'
            ), timeout=5, step=2
        )

    def test_wait_for_a_new_stat(self):
        self.vm_stat.stats_waiter()
        self.vm_stat.get_hourly_stat_for_the_last_hour()

    # def test_check_price_for_removed_service_addon(self):
    #     last_hour_stat = self.vm_stat.vm_last_hour_stat
    #     expected_price = 0
    #     test.log.info(
    #         "Actual Service Addon Cost - {}".format(
    #         last_hour_stat.service_addon.cost
    #         )
    #     )
    #     test.log.info(
    #         "Expected Service Addon Cost - {}".format(
    #             0 * expected_price
    #         )
    #     )
    #     test.log.info(
    #         "Actual Service Addon Value - {}".format(
    #         last_hour_stat.service_addon.value
    #         )
    #     )
    #     test.log.info(
    #         "Expected Service Addon Value - {}".format(0)
    #     )
    #     assert last_hour_stat.service_addon.cost == 0 * ADDON_PRICE
    #     assert last_hour_stat.service_addon.value == 0

    def test_check_service_addon_cost_for_removed_service_addon(self):
        # last_hour_stat = self.vm_stat.vm_last_hour_stat
        # expected_price = ADDON_PRICE * self.vm_stat.get_service_addons_count_value()
        test.log.info(
            "Actual Service Addon Cost - {}".format(
                self.vm_stat.get_service_addons_count_cost()
            )
        )
        test.log.info(
            "Expected Service Addon Cost - {}".format(0)
        )
        test.log.info(
            "Actual Service Addon Value - {}".format(
                self.vm_stat.get_service_addons_count_value()
            )
        )
        test.log.info(
            "Expected Service Addon Value - {}".format(0)
        )
        assert self.vm_stat.get_service_addons_count_cost() == 0
        assert self.vm_stat.get_service_addons_count_value() == 0

    def test_check_service_addon_cpu_cost_for_removed_service_addon(self):
        # last_hour_stat = self.vm_stat.vm_last_hour_stat
        # expected_price = PRICE_CPU * self.vm_stat.get_service_addons_cpus_value()
        test.log.info(
            "Actual Service Addon CPU Cost - {}".format(
                self.vm_stat.get_service_addons_cpus_cost()
            )
        )
        test.log.info(
            "Expected Service Addon CPU Cost - {}".format(0)
        )
        test.log.info(
            "Actual Service Addon CPU Value - {}".format(
                self.vm_stat.get_service_addons_cpus_value()
            )
        )
        test.log.info(
            "Expected Service Addon Value - {}".format(0)
        )
        assert self.vm_stat.get_service_addons_cpus_cost() == 0
        assert self.vm_stat.get_service_addons_cpus_value() == 0

    def test_check_service_addon_memory_cost_for_removed_service_addon(self):
        # last_hour_stat = self.vm_stat.vm_last_hour_stat
        # expected_price = PRICE_MEMORY * self.vm_stat.get_service_addons_memory_value()
        test.log.info(
            "Actual Service Addon Memory Cost - {}".format(
                self.vm_stat.get_service_addons_memory_cost()
            )
        )
        test.log.info(
            "Expected Service Addon Memory Cost - {}".format(0)
        )
        test.log.info(
            "Actual Service Addon Memory Value - {}".format(
                self.vm_stat.get_service_addons_memory_value()
            )
        )
        test.log.info(
            "Expected Service Addon Memory Value - {}".format(0)
        )
        assert self.vm_stat.get_service_addons_memory_cost() == 0
        assert self.vm_stat.get_service_addons_memory_value() == 0

    def test_check_service_addon_disk_size_cost_for_removed_service_addon(self):
        # last_hour_stat = self.vm_stat.vm_last_hour_stat
        # expected_price = PRICE_DISK_SIZE * \
        #                  self.vm_stat.get_service_addons_disk_size_value()
        test.log.info(
            "Actual Service Addon Disk Size Cost - {}".format(
                self.vm_stat.get_service_addons_disk_size_cost()
            )
        )
        test.log.info(
            "Expected Service Addon Disk Size Cost - {}".format(0)
        )
        test.log.info(
            "Actual Service Addon Disk Size Value - {}".format(
                self.vm_stat.get_service_addons_disk_size_value()
            )
        )
        test.log.info(
            "Expected Service Addon Disk Size Value - {}".format(0)
        )
        assert self.vm_stat.get_service_addons_disk_size_cost() == 0
        assert self.vm_stat.get_service_addons_disk_size_value() == 0
