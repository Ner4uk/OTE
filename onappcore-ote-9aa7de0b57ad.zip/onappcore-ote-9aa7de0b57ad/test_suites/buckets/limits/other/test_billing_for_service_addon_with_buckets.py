from onapp_helper.service_addon.service_addon import ServiceAddon
from onapp_helper.service_addon.service_addon import ServiceAddonEvent
from onapp_helper.service_addon.service_addon_group import ServiceAddonGroup
from onapp_helper.service_addon.service_addon_group import RelationGroupAddon
from onapp_helper.br_helper.service_addon_store import ServiceAddonStoreBR
from onapp_helper.user import User
from onapp_helper.server import VirtualServer
from onapp_helper.recipe.recipe import Recipe
from onapp_helper.recipe.recipe_step import RecipeStep
from onapp_helper.billing_plan import BillingPlan
from onapp_helper.stats.user_stats import UserStats
from onapp_helper.stats.vm_stat import VmStat
import pytest

from onapp_helper import test


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.limits
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version < 5.3,
    reason="{0} CP version does not support this functionality".format(
        test.cp_version
    )
)
@pytest.mark.skipif(
    test.cp_version >= 5.6,
    reason="{0} CP version does not support old billing functionality".format(
        test.cp_version
    )
)
class TestBillingForServiceAddon:
    ADDON_PRICE = 100

    def setup_class(self):
        test.load_env()
        test.run_at(minutes=40)

        try:
            # Create a ServiceAddonGroup
            self.service_addon_group = ServiceAddonGroup()
            self.service_addon_group.label = self.__name__
            assert self.service_addon_group.create(), self.service_addon_group.error

            # Create a BillingPlan
            self.billing_plan = BillingPlan()
            self.billing_plan.label = self.__name__
            assert self.billing_plan.create()

            # Create a ServiceAddonStoreBR
            self.service_addon_group_br = ServiceAddonStoreBR(
                billing_plan=self.billing_plan
            )
            self.service_addon_group_br.target_id = self.service_addon_group.id
            assert self.service_addon_group_br.create()

            # Create a Recipe on add action
            self.recipe_on_add = Recipe()
            self.recipe_on_add.label = self.__name__ + 'OnAdd'
            self.recipe_on_add.compatible_with = Recipe.COMPATIBLE_WITH.unix
            assert self.recipe_on_add.create(), self.recipe_on_add.error

            # Add recipe step
            self.recipe_on_add_step1 = RecipeStep(self.recipe_on_add)
            self.recipe_on_add_step1.script = 'echo "assigned" > /tmp/service_addon_test'
            self.recipe_on_add_step1.on_success = RecipeStep.ON_SUCCESS.proceed
            self.recipe_on_add_step1.on_failure = RecipeStep.ON_FAILURE.fail
            self.recipe_on_add_step1.result_source = RecipeStep.RESULT_SOURCE.exit_code
            assert self.recipe_on_add_step1.create(), self.recipe_on_add_step1.error

            # Create a Recipe on remove action
            self.recipe_on_remove = Recipe()
            self.recipe_on_remove.label = self.__name__ + 'OnRemove'
            self.recipe_on_remove.compatible_with = Recipe.COMPATIBLE_WITH.unix
            assert self.recipe_on_remove.create(), self.recipe_on_remove.error

            # Add recipe step
            self.recipe_on_remove_step1 = RecipeStep(self.recipe_on_remove)
            self.recipe_on_remove_step1.script = 'echo "unassigned" > /tmp/service_addon_test'
            self.recipe_on_remove_step1.on_success = RecipeStep.ON_SUCCESS.proceed
            self.recipe_on_remove_step1.on_failure = RecipeStep.ON_FAILURE.fail
            self.recipe_on_remove_step1.result_source = RecipeStep.RESULT_SOURCE.exit_code
            assert self.recipe_on_remove_step1.create(), \
                self.recipe_on_remove_step1.error

            # Create a ServiceAddon
            self.service_addon = ServiceAddon()
            self.service_addon.label = self.__name__
            self.service_addon.compatible_with.append(
                ServiceAddon.COMPATIBLE_WITH.unix
            )
            assert self.service_addon.create(), self.service_addon.error

            # Add on add event
            self.on_add_event = ServiceAddonEvent(self.service_addon)
            assert self.on_add_event.add_recipe(
                self.recipe_on_add.id,
                ServiceAddonEvent.EVENT_TYPE.on_add_event
            ), self.on_add_event.error

            # Add on remove event
            self.on_remove_event = ServiceAddonEvent(self.service_addon)
            assert self.on_remove_event.add_recipe(
                self.recipe_on_remove.id,
                ServiceAddonEvent.EVENT_TYPE.on_remove_event
            ), self.on_remove_event.error

            # Add service addon to RelationGroupAddon (Group)
            self.relation_group_addon = RelationGroupAddon(
                self.service_addon_group
            )
            assert self.relation_group_addon.attach_addon_to_group(
                service_addon_id=self.service_addon.id,
                price=self.ADDON_PRICE
            ), self.relation_group_addon.error

            # Create a user
            self.user = User(bp=self.billing_plan)
            self.user.login = self.__name__.lower()
            self.user.password = test.generate_password()
            self.user.email = '{}@test.com'.format(self.__name__.lower())
            self.user.role_ids = [1]
            assert self.user.create(), self.user.error

            test.execute_as(self.user.login, self.user.password)

            # Create a server
            self.vs = VirtualServer()
            self.vs.label = self.__name__
            assert self.vs.create(), self.vs.error

            self.vm_stat = VmStat(parent_obj=self.vs)
            self.user_stats = UserStats(self.user)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        attributes = (
            'vs',
            'user',
            'billing_plan',
            'service_addon',
            'service_addon_group',
            'recipe_on_add',
            'recipe_on_remove'
        )
        test.clean_up_resources(attributes, self)

    def test_add_service_addon_to_server(self):
        assert self.service_addon.assign_to_server(self.vs), \
            self.service_addon.error
        assert 'assigned' in self.vs.execute('cat /tmp/service_addon_test')

    def test_should_be_impossible_add_already_added_service_addon_to_server(self):
        assert not self.service_addon.assign_to_server(self.vs)
        assert "Add-on is already assigned" in self.service_addon.error['base']

    def test_check_price_for_added_service_addon(self):
        self.vm_stat.stats_waiter()
        self.vm_stat.get_hourly_stat_for_the_last_hour()
        last_hour_stat = self.vm_stat.vm_last_hour_stat
        test.log.info(
            "Actual Service Addon Cost - {}".format(
            last_hour_stat.service_addon.cost
            )
        )
        test.log.info(
            "Expected Service Addon Cost - {}".format(
                1 * self.ADDON_PRICE
            )
        )
        test.log.info(
            "Actual Service Addon Value - {}".format(
            last_hour_stat.service_addon.value
            )
        )
        test.log.info(
            "Expected Service Addon Value - {}".format(1)
        )
        assert last_hour_stat.service_addon.cost == 1 * self.ADDON_PRICE
        assert last_hour_stat.service_addon.value == 1

    def test_remove_service_addon_from_server(self):
        # To get 0 price for second hour
        assert self.service_addon.unassign_from_server(self.vs), \
            self.service_addon.error
        assert 'unassigned' in self.vs.execute('cat /tmp/service_addon_test')

    def test_check_price_for_removed_service_addon(self):
        self.vm_stat.stats_waiter()
        self.vm_stat.get_hourly_stat_for_the_last_hour()
        last_hour_stat = self.vm_stat.vm_last_hour_stat
        test.log.info(
            "Actual Service Addon Cost - {}".format(
            last_hour_stat.service_addon.cost
            )
        )
        test.log.info(
            "Expected Service Addon Cost - {}".format(
                0 * self.ADDON_PRICE
            )
        )
        test.log.info(
            "Actual Service Addon Value - {}".format(
            last_hour_stat.service_addon.value
            )
        )
        test.log.info(
            "Expected Service Addon Value - {}".format(0)
        )
        assert last_hour_stat.service_addon.cost == 0 * self.ADDON_PRICE
        assert last_hour_stat.service_addon.value == 0
