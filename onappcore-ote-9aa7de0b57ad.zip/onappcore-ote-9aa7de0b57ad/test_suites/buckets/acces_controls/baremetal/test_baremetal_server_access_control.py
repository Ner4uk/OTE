import pytest
from onapp_helper import test
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.bucket.access_controls import BaremetalServerAC
from test_helper import ac_base_test


#################################### Marks #####################################
# Component
@pytest.mark.access_controls
@pytest.mark.bucket
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.verbose
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
class TestBaremetalServerAccessControl(ac_base_test.BaseTest):
    def setup_class(self):
        self.bucket = Bucket()
        self.bucket.label = self.__name__
        assert self.bucket.create(), self.bucket.error

        self.ac = BaremetalServerAC(
            parent_obj=self.bucket,
            server_type=BaremetalServerAC.SERVER_TYPE.baremetal
        )

        self.limits = {
            'limit': 12
        }
