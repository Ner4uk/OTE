import pytest
from onapp_helper import test
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.bucket import access_controls as ac
from onapp_helper.bucket import rate_cards as rc
from onapp_helper.network_zone import NetworkZone
from test_helper import ac_base_test


#################################### Marks #####################################
# Component
@pytest.mark.access_controls
@pytest.mark.bucket
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.verbose
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
class TestBaremetalNetworkZoneAccessControl(ac_base_test.BaseTest):
    def setup_class(self):
        self.bucket = Bucket()
        self.bucket.label = self.__name__
        assert self.bucket.create(), self.bucket.error

        self.target = NetworkZone()
        self.target.server_type = NetworkZone.SERVER_TYPE.baremetal
        assert self.target.create(), self.target.error

        self.target_apply_to_all_resources = NetworkZone()
        self.target_apply_to_all_resources.server_type = NetworkZone.SERVER_TYPE.baremetal
        assert self.target_apply_to_all_resources.create(), self.target_apply_to_all_resources.error

        self.incorrect_target = NetworkZone()
        self.incorrect_target.server_type = NetworkZone.SERVER_TYPE.virtual
        assert self.incorrect_target.create(), self.incorrect_target.error

        self.ac = ac.NetworkZoneAC(
            parent_obj=self.bucket,
            target_id=self.target.id,
            server_type=ac.SERVER_TYPE.baremetal
        )

        self.ac_with_apply_to_all_resources = ac.NetworkZoneAC(
            parent_obj=self.bucket,
            target_id=self.target_apply_to_all_resources.id,
            server_type=ac.SERVER_TYPE.baremetal
        )
        self.ac_with_apply_to_all_resources.apply_to_all_resources_in_the_bucket = True

        self.incorrect_ac = ac.NetworkZoneAC(
            parent_obj=self.bucket,
            target_id=self.incorrect_target.id,
            server_type=ac.SERVER_TYPE.baremetal
        )

        self.rc = rc.NetworkZoneRC(
            parent_obj=self.bucket,
            target_id=self.target.id,
            server_type=rc.SERVER_TYPE.baremetal
        )

        self.limits = {
            'limit_ip': 12
        }

    def teardown_class(self):
        attributes = (
            'target',
            'incorrect_target',
            'target_apply_to_all_resources',
            'bucket'
        )
        test.clean_up_resources(attributes, self)

    def test_create_ac_with_incorrect_target(self):
        assert not self.incorrect_ac.create()
        assert self.ac.E_INCORRECT_TARGET in self.incorrect_ac.error['server_type']

    @pytest.mark.skipif(test.cp_version < 5.9, reason="Not supported until 5.9")
    def test_add_ac_with_apply_to_all_resources_option(self):
        if not self.ac.get():
            assert self.ac.create(), self.ac.error
        self._set_limits(self.ac_with_apply_to_all_resources, multiplier=3)
        assert self.ac_with_apply_to_all_resources.create(), self.ac_with_apply_to_all_resources.error

    @pytest.mark.skipif(test.cp_version < 5.9, reason="Not supported until 5.9")
    def test_check_limits_after_create(self):
        assert self.ac.get(), self.ac.error
        self._check_limits(self.ac)
        self._check_limits(self.ac_with_apply_to_all_resources)

    @pytest.mark.skipif(test.cp_version < 5.9, reason="Not supported until 5.9")
    def test_edit_ac_with_apply_to_all_resources_option(self):
        self.ac_with_apply_to_all_resources.reset()
        self.ac_with_apply_to_all_resources.apply_to_all_resources_in_the_bucket = True
        assert self.ac_with_apply_to_all_resources.edit(), self.ac_with_apply_to_all_resources.error

    @pytest.mark.skipif(test.cp_version < 5.9, reason="Not supported until 5.9")
    def test_check_ac_limits_after_edit(self):
        assert self.ac.get(), self.ac.error
        self._check_limits(self.ac, unlimited=True)
        self._check_limits(self.ac_with_apply_to_all_resources, unlimited=True)