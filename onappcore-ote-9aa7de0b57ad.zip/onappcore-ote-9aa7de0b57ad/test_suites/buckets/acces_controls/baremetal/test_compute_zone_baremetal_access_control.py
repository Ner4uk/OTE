import pytest
from onapp_helper import test
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.bucket.access_controls import ComputeZoneAC
from onapp_helper.bucket.rate_cards import ComputeZoneRC
from onapp_helper.hypervisor_zone import HypervisorZone


#################################### Marks #####################################
# Component
@pytest.mark.access_controls
@pytest.mark.bucket
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.verbose
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
class TestBaremetalComputeZoneAccessControl:
    def setup_class(self):
        self.bucket = Bucket()
        self.bucket.label = self.__name__
        assert self.bucket.create(), self.bucket.error

        self.compute_zone = HypervisorZone()
        self.compute_zone.label = self.__name__
        self.compute_zone.server_type = HypervisorZone.SERVER_TYPE.baremetal
        assert self.compute_zone.create(), self.compute_zone.error

        self.incorrect_target = HypervisorZone()
        self.incorrect_target.label = f'{self.__name__}IncorrectTarget'
        self.incorrect_target.server_type = HypervisorZone.SERVER_TYPE.virtual
        assert self.incorrect_target.create(), self.target.error

        self.compute_zone_ac = ComputeZoneAC(
            parent_obj=self.bucket,
            target_id=self.compute_zone.id,
            server_type=ComputeZoneAC.SERVER_TYPE.baremetal
        )

        self.incorrect_ac = ComputeZoneAC(
            parent_obj=self.bucket,
            target_id=self.incorrect_target.id,
            server_type=ComputeZoneAC.SERVER_TYPE.baremetal
        )

        self.compute_zone_rc = ComputeZoneRC(
            parent_obj=self.bucket,
            target_id=self.compute_zone.id,
            server_type=ComputeZoneRC.SERVER_TYPE.baremetal
        )

    def teardown_class(self):
        attributes = (
            'compute_zone',
            'incorrect_target',
            'bucket'
        )
        test.clean_up_resources(attributes, self)

    # Negative tests for create
    def test_validate_negative_target_id(self):
        self.compute_zone_ac.reset()
        self.compute_zone_ac.target_id = -2
        assert not self.compute_zone_ac.create()
        assert 'could not be found' in self.compute_zone_ac.error['target_id']

    def test_validate_invalid_target_id(self):
        self.compute_zone_ac.reset()
        self.compute_zone_ac.target_id = 0
        assert not self.compute_zone_ac.create()
        assert 'could not be found' in self.compute_zone_ac.error['target_id']

    # Positive test for create
    def test_create_compute_zone_access_control(self):
        self.compute_zone_ac.reset()
        self.compute_zone_ac.target_id = self.compute_zone.id
        test.gen_api_doc = "Create Baremetal Compute Zone Access Control"
        assert self.compute_zone_ac.create(), self.compute_zone_ac.error

    def test_rate_card_has_not_been_created(self):
        assert not self.compute_zone_rc.get()

    # def test_check_target_type(self):
    #     assert self.compute_zone_ac.target_type == 'compute_zone'

    # Negative tests for edit

    # Positive test for edit
    def test_edit_compute_zone_access_control(self):
        test.gen_api_doc = "Edit Baremetal Compute Zone Access Control"
        assert self.compute_zone_ac.edit(), self.compute_zone_ac.error

    def test_delete_compute_zone_access_control(self):
        test.gen_api_doc = "Delete Baremetal Compute Zone Access Control"
        assert self.compute_zone_ac.delete(), self.compute_zone_ac.error

    def test_check_create_rate_card_parameter(self):
        """
        Rate Cards is not supported for Compute Zone with baremetal server type
        """
        self.compute_zone_ac.create_rate_card = True
        assert self.compute_zone_ac.create(), self.compute_zone_ac.error
        assert not self.compute_zone_rc.get()

    def test_create_ac_with_incorrect_target(self):
        assert not self.incorrect_ac.create()
        assert ComputeZoneAC.E_INCORRECT_TARGET in self.incorrect_ac.error['server_type']