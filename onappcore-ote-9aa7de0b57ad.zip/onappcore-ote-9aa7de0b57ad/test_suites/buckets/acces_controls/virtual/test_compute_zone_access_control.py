import pytest
from onapp_helper import test
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.bucket import access_controls as ac
from onapp_helper.bucket import rate_cards as rc
from test_helper import ac_base_test
from onapp_helper.hypervisor_zone import HypervisorZone


#################################### Marks #####################################
# Component
@pytest.mark.access_controls
@pytest.mark.bucket
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
@pytest.mark.verbose
class TestComputeZoneAccessControl(ac_base_test.BaseTest):
    def setup_class(self):
        self.bucket = Bucket()
        self.bucket.label = self.__name__
        assert self.bucket.create(), self.bucket.error

        self.target = HypervisorZone()
        self.target.label = self.__name__
        self.target.server_type = 'virtual'
        assert self.target.create(), self.target.error

        self.target_apply_to_all_resources = HypervisorZone()
        self.target_apply_to_all_resources.label = f"{self.__name__}ToAllResources"
        self.target_apply_to_all_resources.server_type = HypervisorZone.SERVER_TYPE.virtual
        assert self.target_apply_to_all_resources.create(), self.target.error

        self.incorrect_target = HypervisorZone()
        self.incorrect_target.label = f"{self.__name__}IncorrectTarget"
        self.incorrect_target.server_type = HypervisorZone.SERVER_TYPE.vpc
        assert self.incorrect_target.create(), self.incorrect_target.error

        self.ac = ac.ComputeZoneAC(
            parent_obj=self.bucket,
            target_id=self.target.id
        )

        self.ac_with_apply_to_all_resources = ac.ComputeZoneAC(
            parent_obj=self.bucket,
            target_id=self.target_apply_to_all_resources.id,
            server_type=ac.SERVER_TYPE.virtual
        )
        self.ac_with_apply_to_all_resources.apply_to_all_resources_in_the_bucket = True

        self.incorrect_ac = ac.ComputeZoneAC(
            parent_obj=self.bucket,
            target_id=self.incorrect_target.id
        )

        self.rc = rc.ComputeZoneRC(
            parent_obj=self.bucket,
            target_id=self.target.id
        )

        self.limits = {
            'limit_cpu': 12,
            'limit_cpu_share': 23,
            'limit_cpu_units': 34,
            'limit_default_cpu': 10,
            'limit_default_cpu_share': 6,
            'limit_min_cpu_priority': 6,
            'limit_min_cpu': 2,
            'limit_min_memory': 8,
            'limit_memory': 90
        }

    def teardown_class(self):
        attributes = (
            'target',
            'incorrect_target',
            'target_apply_to_all_resources',
            'bucket'
        )
        test.clean_up_resources(attributes, self)

    # Validation for current values does not works correctly
    # https://onappdev.atlassian.net/browse/CORE-11104
    # '-1' - false
    # '1' - true
    # '0' - false
    # true - true
    # false - false
    # def test_validate_negative_use_cpu_units(self):
    #     self.compute_zone_ac.reset()
    #     self.compute_zone_ac.limits.use_cpu_units = -2
    #     assert not self.compute_zone_ac.create()
    #     assert self.compute_zone_ac.E_GREATER_OR_EQUAL_TO_0 in \
    #            self.compute_zone_ac.error['use_cpu_units']
    #
    # def test_validate_negative_use_default_cpu(self):
    #     self.compute_zone_ac.reset()
    #     self.compute_zone_ac.limits.use_default_cpu = -2
    #     assert not self.compute_zone_ac.create()
    #     assert self.compute_zone_ac.E_GREATER_OR_EQUAL_TO_0 in \
    #            self.compute_zone_ac.error['use_default_cpu']
    #
    # def test_validate_negative_use_default_cpu_share(self):
    #     self.compute_zone_ac.reset()
    #     self.compute_zone_ac.limits.use_default_cpu_share = -2
    #     assert not self.compute_zone_ac.create()
    #     assert self.compute_zone_ac.E_GREATER_OR_EQUAL_TO_0 in \
    #            self.compute_zone_ac.error['use_default_cpu_share']

    # Validate default value https://onappdev.atlassian.net/browse/CORE-11026
    def test_default_cpu_values(self):
        self._set_limits(self.ac)
        self.ac.limits.limit_cpu = 4
        self.ac.limits.limit_min_cpu = 2
        self.ac.limits.limit_default_cpu = 1
        assert not self.ac.create()
        assert f'default value must be greater or equal to ' \
               f'{self.ac.limits.limit_min_cpu:.1f} and less or equal to ' \
               f'{self.ac.limits.limit_cpu:.1f}' in self.ac.error['cpu']

    def test_default_cpu_share_values(self):
        self._set_limits(self.ac)
        self.ac.limits.limit_cpu_share = 100
        self.ac.limits.limit_min_cpu_priority = 50
        self.ac.limits.limit_default_cpu = 10
        assert not self.ac.create()
        assert f'default value must be greater or equal to ' \
               f'{self.ac.limits.limit_min_cpu_priority:.1f} and less or equal to ' \
               f'{self.ac.limits.limit_cpu_share:.1f}' in self.ac.error['cpu_share']

    # min value can't be more than max https://onappdev.atlassian.net/browse/CORE-11026
    def test_validate_min_max_cpu_values(self):
        self._set_limits(self.ac)
        self.ac.limits.limit_cpu = 4
        self.ac.limits.limit_min_cpu = 22
        assert not self.ac.create()
        assert f'min value {self.ac.limits.limit_min_cpu:.1f} ' \
               f'must be less then max {self.ac.limits.limit_cpu:.1f}' in self.ac.error['cpu']

    def test_validate_min_max_cpu_share_values(self):
        self._set_limits(self.ac)
        self.ac.limits.limit_cpu_share = 100
        self.ac.limits.limit_min_cpu_priority = 500
        assert not self.ac.create()
        assert f'min value {self.ac.limits.limit_min_cpu_priority:.1f} ' \
               f'must be less then max {self.ac.limits.limit_cpu_share:.1f}' in self.ac.error['cpu_share']

    def test_validate_min_max_memory_values(self):
        self._set_limits(self.ac)
        self.ac.limits.limit_memory = 4
        self.ac.limits.limit_min_memory = 22
        assert not self.ac.create()
        assert f'min value {self.ac.limits.limit_min_memory:.1f} ' \
               f'must be less then max {self.ac.limits.limit_memory:.1f}' in \
               self.ac.error['memory']

    def test_create_ac_with_incorrect_target(self):
        assert not self.incorrect_ac.create()
        assert self.ac.E_INCORRECT_TARGET in self.incorrect_ac.error['server_type']

    @pytest.mark.skipif(test.cp_version < 5.9, reason="Not supported until 5.9")
    def test_add_ac_with_apply_to_all_resources_option(self):
        if not self.ac.get():
            assert self.ac.create(), self.ac.error
        self._set_limits(self.ac_with_apply_to_all_resources, multiplier=3)
        assert self.ac_with_apply_to_all_resources.create(), self.ac_with_apply_to_all_resources.error

    @pytest.mark.skipif(test.cp_version < 5.9, reason="Not supported until 5.9")
    def test_check_limits_after_create(self):
        assert self.ac.get(), self.ac.error
        self._check_limits(self.ac)
        self._check_limits(self.ac_with_apply_to_all_resources)

    @pytest.mark.skipif(test.cp_version < 5.9, reason="Not supported until 5.9")
    def test_edit_ac_with_apply_to_all_resources_option(self):
        self.ac_with_apply_to_all_resources.reset()
        self.ac_with_apply_to_all_resources.apply_to_all_resources_in_the_bucket = True
        assert self.ac_with_apply_to_all_resources.edit(), self.ac_with_apply_to_all_resources.error

    @pytest.mark.skipif(test.cp_version < 5.9, reason="Not supported until 5.9")
    def test_check_ac_limits_after_edit(self):
        assert self.ac.get(), self.ac.error
        self._check_limits(self.ac, unlimited=True)
        self._check_limits(self.ac_with_apply_to_all_resources, unlimited=True)

    def test_core_11104_edit_ac(self):
        """
        Change type from decimal to boolean for some parameters in compute_zone_resource. API
        '-1' - false
        '1' - true
        '0' - false
        true - true
        false - false
        """
        if not self.ac.get():
            assert self.ac.create(), self.ac.error
        self.ac.reset()

        data = (
            (-1, False),  # (passed, expected)
            (1, True),
            (0, False),
            (True, True),
            (False, False)
        )

        for value in data:
            self.ac.limits.use_default_cpu = value[0]
            self.ac.limits.use_cpu_units = value[0]
            self.ac.limits.use_default_cpu_share = value[0]
            assert self.ac.edit(), self.ac.error

            assert self.ac.limits.use_default_cpu == value[1]
            assert self.ac.limits.use_cpu_units == value[1]
            assert self.ac.limits.use_default_cpu_share == value[1]

    def test_core_11104_create_ac(self):
        """
        Change type from decimal to boolean for some parameters in compute_zone_resource. API
        '-1' - false
        '1' - true
        '0' - false
        true - true
        false - false
        """

        if self.ac.get():
            assert self.ac.delete(), self.ac.error
        self.ac.reset()

        data = (
            (-1, False),  # (passed, expected)
            (1, True),
            (0, False),
            (True, True),
            (False, False)
        )

        for value in data:
            self.ac.limits.use_default_cpu = value[0]
            self.ac.limits.use_cpu_units = value[0]
            self.ac.limits.use_default_cpu_share = value[0]
            assert self.ac.create(), self.ac.error

            assert self.ac.limits.use_default_cpu == value[1]
            assert self.ac.limits.use_cpu_units == value[1]
            assert self.ac.limits.use_default_cpu_share == value[1]
            assert self.ac.delete(), self.ac.error