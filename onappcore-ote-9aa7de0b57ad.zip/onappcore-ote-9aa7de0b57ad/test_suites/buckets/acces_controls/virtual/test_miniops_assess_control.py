import pytest
from onapp_helper import test
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.bucket import access_controls as ac
from onapp_helper.bucket import rate_cards as rc
from test_helper import ac_base_test
from onapp_helper.data_store_zone import DataStoreZone
from onapp_helper.data_store import DataStore


#################################### Marks #####################################
# Component
@pytest.mark.access_controls
@pytest.mark.bucket
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
class TestSolidfireDatastoreZoneAccessControl(ac_base_test.BaseTest):
    def setup_class(self):
        # https://onappdev.atlassian.net/browse/CORE-10856
        sf_ds = DataStore().get_solid_fire()

        if not sf_ds:
            pytest.skip('No Solid Fire Data Store found')

        self.target = DataStoreZone(id=sf_ds[0].data_store_group_id)
        assert self.target.get(), self.target.error

        self.bucket = Bucket()
        self.bucket.label = self.__name__
        assert self.bucket.create(), self.bucket.error

        self.ac = ac.SolidfireDataStoreZoneAC(
            parent_obj=self.bucket,
            target_id=self.target.id
        )

        self.rc = rc.SolidfireDataStoreZoneRC(
            parent_obj=self.bucket,
            target_id=self.target.id
        )

        self.limits = {
            'limit': 12
        }
