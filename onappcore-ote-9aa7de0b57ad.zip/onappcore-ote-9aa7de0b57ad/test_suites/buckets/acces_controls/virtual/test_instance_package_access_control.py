import pytest
from onapp_helper import test
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.bucket import access_controls as ac
from onapp_helper.bucket.access_controls import InstancePackageAC
from onapp_helper.bucket.rate_cards import InstancePackageRC
from onapp_helper.instance_package import InstancePackage
from onapp_helper.hypervisor_zone import HypervisorZone
from onapp_helper.network_zone import NetworkZone
from onapp_helper.data_store_zone import DataStoreZone


#################################### Marks #####################################
# Component
@pytest.mark.access_controls
@pytest.mark.bucket
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
@pytest.mark.skipif(
    test.cp_version < 4.2,
    reason="Current CP version ({0}) does not support this functionality ".format(test.cp_version)
)
@pytest.mark.verbose
class TestInstanceTypesLimits():
    def setup_class(self):
        self.bucket = Bucket()
        self.bucket.create()

        # Create InsType
        self.instance_package = InstancePackage()
        self.instance_package.label = self.__name__
        assert self.instance_package.create()

        # Get targets
        self.hvz = HypervisorZone()
        self.hvz.label = self.__name__
        assert self.hvz.create()

        self.ntz = NetworkZone()
        self.ntz.label = self.__name__
        assert self.ntz.create()

        self.dsz = DataStoreZone()
        self.dsz.label = self.__name__
        assert self.dsz.create()

        hvz_ac = ac.ComputeZoneAC(
            parent_obj=self.bucket,
            target_id=self.hvz.id
        )
        hvz_ac.create()

        dsz_ac = ac.DataStoreZoneAC(
            parent_obj=self.bucket,
            target_id=self.dsz.id
        )
        dsz_ac.create()

        ntz_ac = ac.NetworkZoneAC(
            parent_obj=self.bucket,
            target_id=self.ntz.id
        )
        ntz_ac.create()

        self.instance_package_ac = InstancePackageAC(
            parent_obj=self.bucket,
            target_id=self.instance_package.id
        )

        self.instance_package_rc = InstancePackageRC(
            parent_obj=self.bucket,
            target_id=self.instance_package.id
        )

    def teardown_class(self):
        self.bucket.delete()
        self.instance_package.delete()
        self.hvz.delete()
        self.dsz.delete()
        self.ntz.delete()

    # def test_validation_for_incorrect_hypervisor_group_ids(self):
    #     self.instance_package_ac.reset()
    #     self.instance_package_ac.preferences.hypervisor_group_ids = [-2]
    #     # Create IT limit
    #     assert not self.instance_package_ac.create(), \
    #         '' in self.instance_package_ac.error
    #
    # def test_validation_for_incorrect_data_store_group_ids(self):
    #     self.instance_package_ac.reset()
    #     self.instance_package_ac.preferences.data_store_group_ids = [-2]
    #     # Create IT limit
    #     assert not self.instance_package_ac.create(), \
    #         '' in self.instance_package_ac.error
    #
    # def test_validation_for_incorrect_network_group_ids(self):
    #     self.instance_package_ac.reset()
    #     self.instance_package_ac.preferences.network_group_ids = [-2]
    #     # Create IT limit
    #     assert not self.instance_package_ac.create(), \
    #         '' in self.instance_package_ac.error

    def test_create_instance_package_ac(self):
        self.instance_package_ac.reset()
        # Set IT preferences
        self.instance_package_ac.preferences.hypervisor_group_ids.append(
            self.hvz.id
        )
        self.instance_package_ac.preferences.data_store_group_ids.append(
            self.dsz.id
        )
        self.instance_package_ac.preferences.network_group_ids.append(
            self.ntz.id
        )
        # Create IT limit
        test.gen_api_doc = "Create Instance Type Access Control"
        assert self.instance_package_ac.create()

    # def test_check_target_type(self):
    #     assert self.instance_package_ac.target_type == 'instance_package'

    def test_check_instance_package_ac_hypervisor_group_ids(self):
        # Check preferences
        assert self.hvz.id in self.instance_package_ac.preferences.hypervisor_group_ids

    def test_check_instance_package_ac_data_store_group_ids(self):
        assert self.dsz.id in self.instance_package_ac.preferences.data_store_group_ids

    def test_check_instance_package_ac_network_group_ids(self):
        assert self.ntz.id in self.instance_package_ac.preferences.network_group_ids

    def test_rate_card_has_not_been_created(self):
        assert not self.instance_package_rc.get()

    def test_edit_instance_package_ac(self):
        # EDIT
        # Remove HVZ id
        self.instance_package_ac.preferences.hypervisor_group_ids.remove(
            self.hvz.id
        )
        self.instance_package_ac.preferences.data_store_group_ids.remove(
            self.dsz.id
        )
        self.instance_package_ac.preferences.network_group_ids.remove(self.ntz.id)
        test.gen_api_doc = "Edit Instance Type Access Control"
        assert self.instance_package_ac.edit()

    def test_check_instance_package_ac_new_hypervisor_group_ids(self):
        # Check preferences
        assert not self.instance_package_ac.preferences.hypervisor_group_ids

    def test_check_instance_package_ac_new_data_store_group_ids(self):
        assert not self.instance_package_ac.preferences.data_store_group_ids

    def test_check_instance_package_ac_new_network_group_ids(self):
        assert not self.instance_package_ac.preferences.network_group_ids

    def test_delete_instance_package_ac(self):
        test.gen_api_doc = "Delete Instance Type Access Control"
        assert self.instance_package_ac.delete()

    def test_check_create_rate_card_parameter(self):
        self.instance_package_ac.reset()
        self.instance_package_ac.create_rate_card = True
        assert self.instance_package_ac.create(), self.instance_package_ac.error
        assert self.instance_package_rc.get(), self.instance_package_rc.error