__maintainer__ = 'QAOH'
import pytest

from onapp_helper import test
from onapp_helper.server import VirtualServer
from onapp_helper.bucket.access_controls import VirtualServerAC
from onapp_helper.bucket.access_controls import add_all_resources_to_bucket
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.user import User
from onapp_helper.user_group import UserGroup


#################################### Marks #####################################
# Component
@pytest.mark.access_controls
@pytest.mark.bucket
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.incremental
class TestGroupVsMaxLimits:
    def setup_class(self):
        test.load_env(use_cloud_boot_hv=True)

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        try:
            self.user_bucket = Bucket()
            self.group_bucket = Bucket()
            self.group_bucket1 = Bucket()
            self.user_bucket.label = self.__name__ + '_UserBucket_' + __maintainer__
            self.group_bucket.label = self.__name__ + '_GroupBucket_' + __maintainer__
            self.group_bucket1.label = self.__name__ + '_GroupBucket_' + __maintainer__

            assert self.user_bucket.create(), self.user_bucket.error
            assert self.group_bucket.create(), self.group_bucket.error
            assert self.group_bucket1.create(), self.group_bucket1.error

            self.vs = VirtualServer()
            self.vs.label = self.__name__ + __maintainer__
            self.user = User(bucket=self.user_bucket)
            self.user_group = UserGroup()
            self.user_group.label = self.__name__ + '_Group_' + __maintainer__
            self.user_group.bucket_id = self.group_bucket.id

            self.user_group1 = UserGroup()
            self.user_group1.label = self.__name__ + '_Group_' + __maintainer__
            self.user_group1.bucket_id = self.group_bucket1.id

            add_all_resources_to_bucket(bucket=self.user_bucket)
            add_all_resources_to_bucket(bucket=self.group_bucket)

            self.user_vs_ac = VirtualServerAC(parent_obj=self.user_bucket)
            self.group_vs_ac = VirtualServerAC(parent_obj=self.group_bucket)
            self.group_vs_ac1 = VirtualServerAC(parent_obj=self.group_bucket1)

            self.user.login = __maintainer__ + '_vsmaxlimitstest'
            self.user.password = test.generate_password()
            self.user.email = 'user@vsmaxlimits.test'
            assert self.user_group.create(), self.user_group.error
            self.user.user_group_id = self.user_group.id
            assert self.user_group1.create(), self.user_group1.error
            assert self.user.create(), self.user.error
            test.execute_as(self.user.login, self.user.password)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        self.user.delete()
        self.user_bucket.delete()
        self.user_group.delete()
        self.group_bucket.delete()
        self.user_group1.delete()
        self.group_bucket1.delete()

    def test_should_be_impossible_to_create_vs_if_groups_limit_exceeded(self):
        self.user_vs_ac.limits.limit = 1
        assert self.user_vs_ac.edit()
        self.group_vs_ac.limits.limit = 0
        assert self.group_vs_ac.edit(), self.group_vs_ac.error
        assert not self.vs.create()
        assert 'Virtual server limit exceeded for your group' in self.vs.error['base']

    def test_should_be_possible_to_create_vs_if_groups_limit_allows(self):
        self.user_vs_ac.limits.limit = 1
        assert self.user_vs_ac.edit(), self.user_vs_ac.error
        self.group_vs_ac.limits.limit = 1
        assert self.group_vs_ac.edit(), self.group_vs_ac.error
        assert self.vs.create(), self.vs.error

    def test_should_be_impossible_to_add_vs_owner_to_group_if_groups_bucket_empty(self):
        assert not self.user.edit(user_group_id=self.user_group1.id)
        assert 'Virtual server limit exceeded for your group' in \
               self.user.error['user_group_id']
