import pytest

from onapp_helper import test
from onapp_helper.bucket.access_controls import EdgeGroupsAC
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.bucket.rate_cards import EdgeGroupsRC
from onapp_helper.cdn.edge_group import EdgeGroup


#################################### Marks #####################################
# Component
@pytest.mark.access_controls
@pytest.mark.bucket
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.verbose
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
class TestEdgeGroupAccessControl:
    def setup_class(self):
        self.bucket = Bucket()
        self.bucket.label = self.__name__
        assert self.bucket.create(), self.bucket.error

        self.edge_group = EdgeGroup()
        self.edge_group.server_type = 'other'
        assert self.edge_group.create(), self.edge_group.error

        self.edge_group_ac = EdgeGroupsAC(
            parent_obj=self.bucket,
            target_id=self.edge_group.id,
            server_type=EdgeGroupsAC.SERVER_TYPE.other
        )

        self.edge_group_rc = EdgeGroupsRC(
            parent_obj=self.bucket,
            target_id=self.edge_group.id,
            server_type=EdgeGroupsRC.SERVER_TYPE.other
        )

    def teardown_class(self):
        assert self.edge_group.delete(), self.edge_group.error
        assert self.bucket.delete(), self.bucket.error

    # Negative tests for create
    def test_validate_wrong_target_id(self):
        self.edge_group_ac.target_id = 0
        assert not self.edge_group_ac.create()
        assert self.edge_group_ac.E_WRONG_TARGET_ID in self.edge_group_ac.error['target_id']

    # Positive test for create
    def test_create_edge_group_access_control(self):
        self.edge_group_ac.target_id = self.edge_group.id
        test.gen_api_doc = "Create Edge Group Access Control"
        assert self.edge_group_ac.create(), self.edge_group_ac.error

    def test_rate_card_has_not_been_created(self):
        assert not self.edge_group_rc.get()

    # def test_check_target_type(self):
    #     assert self.edge_group_ac.target_type == 'edge_group'

    # Negative tests for edit

    # # Positive test for edit
    # def test_edit_edge_group_access_control(self):
    #     test.gen_api_doc = "Edit Edge Group Access Control"
    #     assert self.edge_group_ac.edit(), self.edge_group_ac.error

    def test_delete_edge_group_access_control(self):
        test.gen_api_doc = "Delete Edge Group Access Control"
        assert self.edge_group_ac.delete(), self.edge_group_ac.error

    def test_check_create_rate_card_parameter(self):
        self.edge_group_ac.create_rate_card = True
        assert self.edge_group_ac.create(), self.edge_group_ac.error
        assert self.edge_group_rc.get(), self.edge_group_rc.error