import pytest
from onapp_helper import test
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.bucket.access_controls import ServiceAddonsGroupsAC
from onapp_helper.bucket.rate_cards import ServiceAddonRC
from onapp_helper.service_addon.service_addon_group import ServiceAddonGroup, RelationGroupAddon
from onapp_helper.service_addon.service_addon import ServiceAddon


#################################### Marks #####################################
# Component
@pytest.mark.access_controls
@pytest.mark.bucket
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.verbose
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
class TestServiceAddonAccessControl:
    def setup_class(self):
        self.bucket = Bucket()
        self.bucket.label = self.__name__
        assert self.bucket.create(), self.bucket.error

        self.service_addon_group = ServiceAddonGroup()
        self.service_addon_group.label = self.__name__
        assert self.service_addon_group.create(), \
            self.service_addon_group.error

        self.service_addon = ServiceAddon()
        self.service_addon.label = self.__name__
        self.service_addon.compatible_with.append(ServiceAddon.COMPATIBLE_WITH.unix)
        self.service_addon.description = self.__name__
        test.gen_api_doc = 'Create Service Addon'
        assert self.service_addon.create(), self.service_addon.error

        self.relation = RelationGroupAddon(self.service_addon_group)
        assert self.relation.attach_addon_to_group(
            service_addon_id=self.service_addon.id
        ), self.relation.error

        self.service_addon_group_ac = ServiceAddonsGroupsAC(
            parent_obj=self.bucket,
            target_id=self.service_addon_group.id,
            server_type=ServiceAddonsGroupsAC.SERVER_TYPE.other
        )

        self.service_addon_rc = ServiceAddonRC(
            parent_obj=self.bucket,
            target_id=self.service_addon.id,
            server_type=ServiceAddonRC.SERVER_TYPE.other
        )

    def teardown_class(self):
        attributes = (
            'relation',
            'service_addon',
            'service_addon_group',
            'bucket'
        )
        test.clean_up_resources(attributes, self)

    # Negative tests for create
    def test_validate_wrong_target_id(self):
        self.service_addon_group_ac.target_id = 0
        assert not self.service_addon_group_ac.create()
        assert self.service_addon_group_ac.E_WRONG_TARGET_ID in self.service_addon_group_ac.error['target_id']

    # Positive test for create
    def test_create_service_addon_group_access_control(self):
        test.gen_api_doc = "Create Service Addon Group Access Control"
        self.service_addon_group_ac.target_id = self.service_addon_group.id
        assert self.service_addon_group_ac.create(), self.service_addon_group_ac.error
        assert self.service_addon_group_ac.target_id == \
               self.service_addon_group.id

    def test_rate_card_has_not_been_created(self):
        assert not self.service_addon_rc.get()

    # def test_check_target_type(self):
    #     assert self.service_addon_group_ac.target_type == 'service_addon_group'

    # Negative tests for edit

    #!!! Edit does not works !!!
    # Positive test for edit
    # def test_edit_service_addon_group_access_control(self):
    #     self.service_addon_group_ac.target_id = self.service_addon_group_2.id
    #     assert self.service_addon_group_ac.edit(), self.service_addon_group_ac.error
    #     assert self.service_addon_group_ac.target_id == \
    #            self.service_addon_group_2.id

    def test_delete_service_addon_group_access_control(self):
        test.gen_api_doc = "Delete Service Addon Group Access Control"
        assert self.service_addon_group_ac.delete(), self.service_addon_group_ac.error

    def test_check_create_rate_card_parameter(self):
        self.service_addon_group_ac.create_rate_card = True
        assert self.service_addon_group_ac.create(), self.service_addon_group_ac.error
        assert self.service_addon_rc.get(), self.service_addon_rc.error