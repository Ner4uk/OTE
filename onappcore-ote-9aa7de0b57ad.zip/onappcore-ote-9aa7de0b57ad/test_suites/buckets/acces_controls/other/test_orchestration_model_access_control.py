import pytest
from onapp_helper import test
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.hypervisor import Hypervisor
from onapp_helper.bucket.access_controls import OrchestrationModelAC
from onapp_helper.bucket.rate_cards import OrchestrationModelRC
from onapp_helper.vcloud.orchestration_model import OrchestrationModel


#################################### Marks #####################################
# Component
@pytest.mark.access_controls
@pytest.mark.bucket
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.verbose
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
class TestOrchestrationModelAccessControl:
    def setup_class(self):
        vcloud_hv_ids = [
            hv.id for hv in Hypervisor().get_all() if
            hv.hypervisor_type == 'vcloud'
        ]
        vcloud_hv_id = vcloud_hv_ids[0] if vcloud_hv_ids else None
        if not vcloud_hv_id:
            pytest.skip('No available vCloud HV')

        self.bucket = Bucket()
        self.bucket.label = self.__name__
        assert self.bucket.create(), self.bucket.error

        self.om = OrchestrationModel(vcloud_hv_id)
        self.om.vdc_model_type = "allocation"
        self.om.vm_number_min = 1
        self.om.vm_number_max = 2
        self.om.vm_number_default = 1
        assert self.om.create(), self.om.error

        self.om_ac = OrchestrationModelAC(
            parent_obj=self.bucket,
            target_id=self.om.id,
            server_type=OrchestrationModelAC.SERVER_TYPE.other
        )

        self.om_rc = OrchestrationModelRC(
            parent_obj=self.bucket,
            target_id=self.om.id,
            server_type=OrchestrationModelRC.SERVER_TYPE.other
        )

    def teardown_class(self):
        assert self.om.delete(), self.om.error
        assert self.bucket.delete(), self.bucket.error

    # Negative tests for create
    def test_validate_wrong_target_id(self):
        self.om_ac.target_id = 0
        assert not self.om_ac.create()
        assert self.om_ac.E_WRONG_TARGET_ID in self.om_ac.error['target_id']

    # Positive test for create
    def test_create_orchestration_model_access_control(self):
        self.om_ac.target_id = self.om.id
        test.gen_api_doc = "Create Orchestration Model Access Control"
        assert self.om_ac.create(), self.om_ac.error
        assert self.om_ac.target_id == self.om.id

    def test_rate_card_has_not_been_created(self):
        assert not self.om_rc.get()

    # def test_check_target_type(self):
    #     assert self.om_ac.target_type == 'orchestration_model'

    # Negative tests for edit

    # # Positive test for edit
    # def test_edit_edge_group_access_control(self):
    #     assert self.om_ac.edit(), self.om_ac.error

    def test_delete_edge_group_access_control(self):
        test.gen_api_doc = "Delete Orchestration Model Access Control"
        assert self.om_ac.delete(), self.om_ac.error

    def test_check_create_rate_card_parameter(self):
        self.om_ac.create_rate_card = True
        assert self.om_ac.create(), self.om_ac.error
        assert not self.om_rc.get()