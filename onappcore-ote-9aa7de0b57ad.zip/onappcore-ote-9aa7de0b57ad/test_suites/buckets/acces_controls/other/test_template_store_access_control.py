import pytest
from onapp_helper import test
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.bucket.access_controls import TemplateGroupsAC
from onapp_helper.bucket.rate_cards import TemplateRC
from onapp_helper.template import Template
from onapp_helper.template_store import TemplateStore, RelationGroupTemplate


#################################### Marks #####################################
# Component
@pytest.mark.access_controls
@pytest.mark.bucket
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
@pytest.mark.verbose
class TestTemplateStoreAccessControl:
    def setup_class(self):
        self.bucket = Bucket()
        self.bucket.label = self.__name__
        assert self.bucket.create(), self.bucket.error

        self.template = Template().get_not_system()
        assert self.template, "Please download not system template"

        self.template_store = TemplateStore()
        self.template_store.label = self.__name__
        assert self.template_store.create(), self.template_store.error

        self.relation = RelationGroupTemplate(self.template_store)
        self.relation.attach_template_to_group(template_id=self.template.id)

        self.template_store_ac = TemplateGroupsAC(
            parent_obj=self.bucket,
            target_id=self.template_store.id,
            server_type=TemplateGroupsAC.SERVER_TYPE.other
        )

        self.template_rc = TemplateRC(
            parent_obj=self.bucket,
            target_id=self.template.id,
            server_type=TemplateRC.SERVER_TYPE.other
        )

    def teardown_class(self):
        assert self.relation.delete(), self.relation.error
        assert self.template_store.delete(), self.template_store.error
        assert self.bucket.delete(), self.bucket.error

    # Negative tests for create
    def test_validate_wrong_target_id(self):
        self.template_store_ac.target_id = 0
        assert not self.template_store_ac.create()
        assert self.template_store_ac.E_WRONG_TARGET_ID in self.template_store_ac.error['target_id']

    # Positive test for create
    def test_create_template_store_access_control(self):
        self.template_store_ac.target_id = self.template_store.id
        test.gen_api_doc = "Create Template Group Access Control"
        assert self.template_store_ac.create(), self.template_store_ac.error

    def test_rate_card_has_not_been_created(self):
        assert not self.template_rc.get()

    # def test_check_target_type(self):
    #     assert self.template_store_ac.target_type == 'template_group'

    # Negative tests for edit

    # # Positive test for edit
    # def test_edit_template_store_access_control(self):
    #     assert self.template_store_ac.edit(), self.template_store_ac.error

    def test_delete_template_store_access_control(self):
        test.gen_api_doc = "Delete Template Group Access Control"
        assert self.template_store_ac.delete(), self.template_store_ac.error

    def test_check_create_rate_card_parameter(self):
        self.template_store_ac.create_rate_card = True
        assert self.template_store_ac.create(), self.template_store_ac.error
        assert self.template_rc.get(), self.template_rc.error