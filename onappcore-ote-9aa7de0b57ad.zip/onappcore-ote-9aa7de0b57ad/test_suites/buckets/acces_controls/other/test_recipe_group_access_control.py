import pytest
from onapp_helper import test
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.bucket.access_controls import RecipeGroupsAC
from onapp_helper.bucket.rate_cards import RecipeGroupsRC
from onapp_helper.recipe.recipe_groups import RecipeGroup


#################################### Marks #####################################
# Component
@pytest.mark.access_controls
@pytest.mark.bucket
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.verbose
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
class TestRecipeGroupAccessControl:
    def setup_class(self):
        self.bucket = Bucket()
        self.bucket.label = self.__name__
        assert self.bucket.create(), self.bucket.error

        self.recipe_group = RecipeGroup()
        self.recipe_group.label = self.__name__
        assert self.recipe_group.create(), self.recipe_group.error

        self.recipe_group_ac = RecipeGroupsAC(
            parent_obj=self.bucket,
            server_type=RecipeGroupsAC.SERVER_TYPE.other
        )

        self.recipe_group_rc = RecipeGroupsRC(
            parent_obj=self.bucket,
            server_type=RecipeGroupsRC.SERVER_TYPE.other
        )

    def teardown_class(self):
        assert self.bucket.delete()
        assert self.recipe_group.delete()

    # Negative tests for create
    def test_validate_wrong_target_id(self):
        self.recipe_group_ac.target_id = 0
        assert not self.recipe_group_ac.create()
        assert self.recipe_group_ac.E_WRONG_TARGET_ID in self.recipe_group_ac.error['target_id']

    # Positive test for create
    def test_create_recipe_group_access_control(self):
        self.recipe_group_ac.target_id = self.recipe_group.id
        test.gen_api_doc = "Create Recipe Group Access Control"
        assert self.recipe_group_ac.create(), self.recipe_group_ac.error
        assert self.recipe_group_ac.target_id == self.recipe_group.id

    def test_rate_card_has_not_been_created(self):
        assert not self.recipe_group_rc.get()

    # def test_check_target_type(self):
    #     assert self.recipe_group_ac.target_type == 'recipe_group'

    # Negative tests for edit

    # # Positive test for edit
    # def test_edit_recipe_group_access_control(self):
    #     assert self.recipe_group_ac.edit(), self.recipe_group_ac.error

    def test_delete_recipe_group_access_control(self):
        test.gen_api_doc = "Delete Recipe Group Access Control"
        assert self.recipe_group_ac.delete(), self.recipe_group_ac.error

    def test_check_create_rate_card_parameter(self):
        self.recipe_group_ac.create_rate_card = True
        assert self.recipe_group_ac.create(), self.recipe_group_ac.error
        assert not self.recipe_group_rc.get()