import pytest
from engine.tools import str_generator
from onapp_helper import test
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.user import User


#################################### Marks #####################################
# Component
@pytest.mark.bucket
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.verbose
@pytest.mark.skipif(test.cp_version < 5.7, reason='Not supported')
class TestBucket:
    def setup_class(self):
        self.bucket = Bucket()
        self.bucket_cloned = Bucket()

    def teardown_class(self):
        self.bucket.delete()
        self.bucket_cloned.delete()

    def test_create_bucket(self):
        test.gen_api_doc = "Bucket creation"
        self.bucket.label = self.__class__.__name__
        self.bucket.currency_code = "GBP"
        self.bucket.monthly_price = 0.23
        self.bucket.allows_kms = "True"
        self.bucket.allows_mak = "False"
        self.bucket.allows_own = "False"
        self.bucket.show_price = None
        self.bucket.type = None
        self.bucket.associated_with_users = 1
        assert self.bucket.create(), self.bucket.error

    def test_clone_bucket(self):
        self.bucket_cloned.__dict__.update(self.bucket.clone().__dict__)
        assert self.bucket_cloned.currency_code == self.bucket.currency_code
        assert self.bucket_cloned.monthly_price == self.bucket.monthly_price
        assert self.bucket_cloned.id != self.bucket.id

    def test_edit_cloned_bucket(self):
        test.gen_api_doc = "Edit Bucket"
        self.bucket_cloned.label = "Edited"
        assert self.bucket_cloned.edit(), self.bucket_cloned.error
        assert self.bucket_cloned.label == "Edited"

    def test_assign_bucket_to_user(self):
        user1 = User(bucket=self.bucket)
        user1.login = '{}1'.format(self.__class__.__name__.lower())
        user1.password = test.generate_password()
        user1.email = str_generator.mail()
        assert user1.create(), user1.error

        self.bucket.get()
        assert self.bucket.associated_with_users

        user1.delete()

    def test_associated_with_users(self):
        user2 = User(bucket=self.bucket_cloned)
        user2.login = '{}2'.format(self.__class__.__name__.lower())
        user2.password = test.generate_password()
        user2.email = str_generator.mail()
        assert user2.create(), user2.error

        self.bucket_cloned.get()
        if test.cp_version < 5.9:
            assert self.bucket_cloned.associated_with_users
        else:
            test.log.warning("Bucket does not have associated_with_users parameter")

        user2.delete()

#should be written 
    # def test_associated_with_group(self):
    #     group = UserGroup()

    def test_delete_bucket(self):
        test.gen_api_doc = "Delete bucket"
        assert self.bucket.delete(), self.bucket.error
        assert self.bucket_cloned.delete(), self.bucket_cloned.error