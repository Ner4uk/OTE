import time
import pytest
from onapp_helper import test
from onapp_helper.backup import Backup
from onapp_helper.template import Template
from onapp_helper.bucket.bucket import Bucket

from onapp_helper.bucket import access_controls as ac
from onapp_helper.bucket import rate_cards as rc

from onapp_helper.bsz import BSZ
from onapp_helper.stats.user_stats import UserStats
from onapp_helper.stats.vm_stat import VmStat
from onapp_helper.user import User
from onapp_helper.server import VirtualServer
from test_helper import billingTH

#TODO Add ISO, Autoscaling


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.hourly_price
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
@pytest.mark.incremental
@pytest.mark.verbose
class TestHourlyPriceChecker():
    KB_IN_1GB = 1048576.0

    def setup_class(self):
        test.load_env()

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        test.cp.generate_10MB_test_file()
        test.run_at(minutes=40)

        try:
            self.bucket = Bucket()
            self.bucket.label = 'HourlyPriceChecker'
            self.bucket.monthly_price = 100.0
            self.bucket.currency_code = 'USD'
            assert self.bucket.create(), self.bucket.error

            ac.add_env_to_bucket(self.bucket)

            # Access Controls
            self.template_ac = ac.TemplatesAC(parent_obj=self.bucket)
            self.backup_ac = ac.BackupsAC(parent_obj=self.bucket)
            self.storage_disk_size_ac = ac.ComputeResourceStoringAC(
                parent_obj=self.bucket
            )
            self.hvz_ac = ac.ComputeZoneAC(parent_obj=self.bucket)
            self.dsz_ac = ac.DataStoreZoneAC(parent_obj=self.bucket)
            self.ntz_ac = ac.NetworkZoneAC(parent_obj=self.bucket)
            self.bsz_ac = ac.BackupServerZoneAC(parent_obj=self.bucket)

            # Rate Cards
            self.template_rc = rc.TemplatesRC(parent_obj=self.bucket)
            self.backup_rc = rc.BackupsRC(parent_obj=self.bucket)
            self.storage_disk_size_rc = rc.ComputeResourceStoringRC(
                parent_obj=self.bucket
            )
            self.hvz_rc = rc.ComputeZoneRC(parent_obj=self.bucket)
            self.dsz_rc = rc.DataStoreZoneRC(parent_obj=self.bucket)
            self.ntz_rc = rc.NetworkZoneRC(parent_obj=self.bucket)
            self.bsz_rc = rc.BackupServerZoneRC(parent_obj=self.bucket)

            self.user = User(bucket=self.bucket)
            self.user.login = 'hourlypricechecker'
            self.user.email = 'hourlypricechecker@user.test'
            self.user.password = test.generate_password()
            self.user.role_ids = [1]
            assert self.user.create(), self.user.error

            # Get already created BSZ AC with BSZ
            if test.env.backup_servers:
                for bs in test.env.backup_servers:
                    self.bsz_ac.target_id = bs.backup_server_group_id
                    if self.bsz_ac.get():
                        self.bsz = BSZ(id=self.bsz_ac.target_id)
                        break
            else:
                self.bsz = BSZ()

            test.execute_as(self.user.login, self.user.password)

            self.vs = VirtualServer()
            self.vs.label = self.__name__
            self.vs.set_template()
            self.vs.rate_limit = 0

            # Set price for template
            self.template_store_rc = rc.TemplateRC(
                parent_obj=self.bucket,
                target_id=self.vs.template.id,
                server_type=rc.SERVER_TYPE.other
            )
            assert self.template_store_rc.create(), self.template_store_rc.error

            self.template_store_rc.prices.price = 90.34
            assert self.template_store_rc.edit(), self.template_store_rc.error

            self.backup = Backup(self.vs)
            self.template = Template()

            self.vm_stat = VmStat(parent_obj=self.vs)
            self.user_stats = UserStats(self.user)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)

        attributes = (
            'vs',
            'user',
            'bucket'
        )
        test.clean_up_resources(attributes, self)

    def test_edit_template_access_control(self):
        # Add base resources to template
        self.template_ac.limits.limit = 1
        assert self.template_ac.edit(), self.template_ac.error

    def test_create_template_rate_card(self):
        self.template_rc.prices.price = 0.00000243
        self.template_rc.prices.limit_free = 0
        assert self.template_rc.create(), self.template_rc.error

    def test_edit_backup_access_control(self):
        # Add base resources to Backups
        self.backup_ac.limits.limit = 1
        assert self.backup_ac.edit(), self.backup_ac.error

    def test_create_backup_rate_card(self):
        self.backup_rc.prices.limit_free = 0
        self.backup_rc.prices.price = 0.00000234
        assert self.backup_rc.create(), self.backup_rc.error

    def test_edit_storage_disk_size_access_control(self):
        # Add base resources to storage_disk_size
        self.storage_disk_size_ac.limits.limit = None
        assert self.storage_disk_size_ac.edit(), self.storage_disk_size_ac.error

    def test_create_storage_disk_size_rate_card(self):
        self.storage_disk_size_rc.prices.limit_free = 0
        self.storage_disk_size_rc.prices.price = 0.00004531
        assert self.storage_disk_size_rc.create(), self.storage_disk_size_rc.error

    def test_edit_hypervisor_zone_access_control(self):
        # Add base resource to HVZ
        self.hvz_ac.target_id = test.env.hvz.id
        self.hvz_ac.limits.limit_cpu = 2
        self.hvz_ac.limits.limit_cpu_share = None
        self.hvz_ac.limits.limit_memory = 1024
        assert self.hvz_ac.edit(), self.hvz_ac.error

    def test_create_hypervisor_zone_rate_card(self):
        self.hvz_rc.target_id = test.env.hvz.id
        self.hvz_rc.prices.limit_free_cpu = 1
        self.hvz_rc.prices.limit_free_cpu_share = 1
        self.hvz_rc.prices.limit_free_memory = self.vs.template.min_memory_size
        self.hvz_rc.prices.price_on_cpu = 0.00002315
        self.hvz_rc.prices.price_off_cpu = 0.00000123
        self.hvz_rc.prices.price_on_cpu_share = 0.012215
        self.hvz_rc.prices.price_off_cpu_share = 0.0000957
        self.hvz_rc.prices.price_on_memory = 0.054637
        self.hvz_rc.prices.price_off_memory = 0.00054392
        assert self.hvz_rc.create(), self.hvz_rc.error

    def test_edit_data_store_zone_access_control(self):
        # Add base resources to DSZ
        self.dsz_ac.target_id = test.env.dsz.id
        self.dsz_ac.limits.limit = 20
        assert self.dsz_ac.edit(), self.dsz_ac.error

    def test_create_data_store_zone_rate_card(self):
        self.dsz_rc.target_id = test.env.dsz.id
        self.dsz_rc.prices.limit_free = 6
        self.dsz_rc.prices.limit_reads_completed_free = 1
        self.dsz_rc.prices.limit_writes_completed_free = 1
        self.dsz_rc.prices.limit_data_written_free = 1
        self.dsz_rc.prices.limit_data_read_free = 1
        self.dsz_rc.prices.price_data_written = 0.090123
        self.dsz_rc.prices.price_off = 0.12468765
        self.dsz_rc.prices.price_on = 0.00265243
        self.dsz_rc.prices.price_data_read = 0.0001224
        self.dsz_rc.prices.price_writes_completed = 0.00013421
        self.dsz_rc.prices.price_reads_completed = 0.00162346
        assert self.dsz_rc.create(), self.dsz_rc.error

    def test_edit_network_zone_access_control(self):
        # Add base resources to NTZ
        self.ntz_ac.target_id = test.env.netz.id
        self.ntz_ac.limits.limit_ip = 2
        self.ntz_ac.limits.limit_rate = None
        assert self.ntz_ac.edit(), self.ntz_ac.error

    def test_create_network_zone_rate_card(self):
        self.ntz_rc.target_id = test.env.netz.id
        self.ntz_rc.prices.limit_data_sent_free = 1
        if not self.vs.rate_limit:
            self.ntz_rc.prices.limit_rate_free = None
        else:
            self.ntz_rc.prices.limit_rate_free = self.vs.rate_limit
        self.ntz_rc.prices.limit_ip_free = 1
        self.ntz_rc.prices.limit_data_received_free = 1
        self.ntz_rc.prices.price_ip_on = 0.01235186
        self.ntz_rc.prices.price_ip_off = 0.00095634
        self.ntz_rc.prices.price_rate_on = 0.4134135
        self.ntz_rc.prices.price_rate_off = 0.14322534
        self.ntz_rc.prices.price_data_sent = 0.0412346
        self.ntz_rc.prices.price_data_received = 0.0234568
        assert self.ntz_rc.create(), self.ntz_rc.error

    def test_edit_backup_server_zone_access_control(self):
        # Add base resources to BSZ
        if self.bsz.id:
            self.bsz_ac.target_id = self.bsz.id
            self.bsz_ac.limits.limit_backup = 1
            self.bsz_ac.limits.limit_backup_disk_size = None
            self.bsz_ac.limits.limit_template_disk_size = None
            self.bsz_ac.limits.limit_template = 1
            assert self.bsz_ac.edit(), self.bsz_ac.error

    def test_create_backup_server_zone_rate_card(self):
        # Add base resources to BSZ
        if self.bsz.id:
            self.bsz_rc.target_id = self.bsz.id
            self.bsz_rc.prices.limit_backup_free = 0
            self.bsz_rc.prices.limit_backup_disk_size_free = 0
            self.bsz_rc.prices.limit_template_disk_size_free = 0
            self.bsz_rc.prices.limit_template_free = 0
            self.bsz_rc.prices.price_backup = 0.00042523
            self.bsz_rc.prices.price_backup_disk_size = 0.00000034
            self.bsz_rc.prices.price_template = 0.00123463
            self.bsz_rc.prices.price_template_disk_size = 0.00643562
            assert self.bsz_rc.create(), self.bsz_rc.error

    def test_create_server(self):
        # Create VS with 0 price/hr
        assert self.vs.create(), self.vs.error

    def test_free_prices_is_not_included_in_vs_hourly_price(self):
        price_on = self.vs.price_on_calculated(
            hvz_rc=self.hvz_rc,
            dsz_rc=self.dsz_rc,
            ntz_rc=self.ntz_rc
        )
        price_on += self.template_store_rc.prices.price
        assert round(price_on, 6) == round(
            self.vs.get_price_per_hour(), 6
        ) != 0.0
        price_off = self.vs.price_off_calculated(
            hvz_rc=self.hvz_rc,
            dsz_rc=self.dsz_rc,
            ntz_rc=self.ntz_rc
        )
        price_off += self.template_store_rc.prices.price
        assert round(price_off, 6) == round(
            self.vs.get_price_per_hour_powered_off(), 6
        ) != 0.0

    # https://onappdev.atlassian.net/browse/CORE-6321
    def test_get_users_vs(self):
        users_servers = self.user.get_own_virtual_servers()
        test.log.info("Users Virtual Servers list - \n{0}".format(users_servers))
        assert len(users_servers) == 1

    def test_change_billing_to_get_not_0_price_per_hour(self):
        # Change Billing
        # HV
        self.hvz_ac.limits.limit_cpu = 2
        self.hvz_ac.limits.limit_cpu_share = None
        self.hvz_ac.limits.limit_memory = 1024
        assert self.hvz_ac.edit()

        self.hvz_rc.prices.limit_free_cpu = 0
        self.hvz_rc.prices.limit_free_cpu_share = 0
        self.hvz_rc.prices.limit_free_memory = 0
        assert self.hvz_rc.edit()
        # DS
        self.dsz_ac.limits.limit = 20
        assert self.dsz_ac.edit()

        self.dsz_rc.prices.limit_free = 0
        self.dsz_rc.prices.limit_reads_completed_free = 0
        self.dsz_rc.prices.limit_data_written_free = 0
        self.dsz_rc.prices.limit_data_read_free = 0
        self.dsz_rc.prices.limit_writes_completed_free = 0
        assert self.dsz_rc.edit()
        # NW
        self.ntz_ac.limits.limit_ip = 2
        self.ntz_ac.limits.limit_rate = None
        assert self.ntz_ac.edit()

        self.ntz_rc.prices.limit_data_sent_free = 0
        self.ntz_rc.prices.limit_rate_free = 0
        self.ntz_rc.prices.limit_ip_free = 0
        self.ntz_rc.prices.limit_data_received_free = 0
        assert self.ntz_rc.edit()

    def test_new_price(self):
        price_on = self.vs.price_on_calculated(
            hvz_rc=self.hvz_rc, dsz_rc=self.dsz_rc, ntz_rc=self.ntz_rc
        )
        price_on += self.template_store_rc.prices.price
        assert round(price_on, 6) == round(
            self.vs.get_price_per_hour(), 6
        ) != 0.0
        price_off = self.vs.price_off_calculated(
            hvz_rc=self.hvz_rc, dsz_rc=self.dsz_rc, ntz_rc=self.ntz_rc
        )
        price_off += self.template_store_rc.prices.price
        assert round(price_off, 6) == round(
            self.vs.get_price_per_hour_powered_off(), 6
        ) != 0.0

    def test_download_100MB_of_data(self):
        # Add sleep to fix some issue I think.
        # Before sleep the data in redis for network after downloading 100MB looks like:
        # redis/var/run/redis/redis.sock > ZRANGE net:7242 0 38
        # 1) "1470745623,3131,86034,0,0,1470745623"
        # 2) "1470745684,4171,107599,1040,21565,61"
        # 3) "1470745742,4171,107600,0,1,58"
        # ...
        #
        # and
        # redis/var/run/redis/redis.sock > ZRANGE net:7244 0 30
        # 1) "1470818079,1962,64445,0,0,1470818079"
        # 2) "1470818137,3441,107463,1479,43018,58"
        # 3) "1470818199,3442,107464,1,1,62"
        # ...
        #
        # After fix:
        # redis/var/run/redis/redis.sock > ZRANGE net:7245 0 30
        # 1) "1470821857,3,7,0,0,1470821857"
        # 2) "1470821918,4,8,1,1,61"
        # 3) "1470821977,3293,107409,3289,107401,59"
        # 4) "1470822046,3321,107444,28,35,69"

        time.sleep(120)

        # Download 1GB of data
        assert self.vs.download_100MB_of_data()

    def test_write_100MB_of_data(self):
        # Write 1GB of data
        assert self.vs.copy_100MB_of_data()

    def test_create_backup(self):
        # Create BU
        assert self.backup.create(), self.backup.error

    def test_convert_to_template(self):
        # Convert to template
        if self.backup:
            assert self.backup.convert(label=self.__class__.__name__), self.backup.template.error
            self.template.__dict__.update(self.backup.template.__dict__)

    # def test_create_cpu_usage(self):
    #     self.vs.execute('python -c "while True: pass" &')

    def test_get_server_and_user_stats(self):
        # Check Usage Statistics
        self.vm_stat.stats_waiter()
        self.vm_stat.get_hourly_stat_for_the_last_hour()
        self.user_stats.get_user_stat_for_the_last_hour()

    def test_check_template_usage_cost(self):
        assert self.vm_stat.get_template_cost() == self.template_store_rc.prices.price
        assert self.vm_stat.get_template_id() == self.vs.template.id

    def test_check_template_cost(self):
        # Check template cost
        expected_price = 0.0
        if not self.template.backup_server_id:
            expected_price = self.template_rc.prices.price
        test.log.info('\nTemplate Cost:')
        assert billingTH.price_comparator(
            expected_price,
            self.user_stats.template_cost
        )

    def test_check_template_count_cost(self):
        # Check template count cost
        expected_price = 0.0
        if self.template.backup_server_id:
            expected_price = self.bsz_rc.prices.price_template
        test.log.info('\nTemplate Count Cost:')
        assert billingTH.price_comparator(
            expected_price,
            self.user_stats.template_count_cost
        )

    def test_check_template_disk_size_cost(self):
        # Check template disk size cost
        expected_price = 0.0
        if self.template.backup_server_id:
            expected_price = (
                self.template.template_size /
                self.KB_IN_1GB *
                self.bsz_rc.prices.price_template_disk_size
            )
        test.log.info('\nTemplate Disk Size Cost:')
        assert billingTH.price_comparator(
            expected_price,
            self.user_stats.template_disk_size_cost
        )

    def test_check_backup_cost(self):
        # Check backup cost
        expected_price = 0.0
        if not self.backup.backup_server_id:
            expected_price = self.backup_rc.prices.price
        test.log.info('\nBackup Cost:')
        assert billingTH.price_comparator(
            expected_price,
            self.user_stats.backup_cost
        )

    def test_check_backup_count_cost(self):
        # Check backup count cost
        expected_price = 0.0
        if self.backup.backup_server_id:
            expected_price = self.bsz_rc.prices.price_backup
        test.log.info('\nBackup Count Cost:')
        assert billingTH.price_comparator(
            expected_price,
            self.user_stats.backup_count_cost
        )

    def test_backup_disk_size_cost(self):
        # Check backup disk size cost
        expected_price = 0.0
        if self.backup.backup_server_id:
            expected_price = (
                self.backup.backup_size /
                self.KB_IN_1GB *
                self.bsz_rc.prices.price_backup_disk_size
            )
        test.log.info('\nBackup Disk Size Cost:')
        assert billingTH.price_comparator(
            expected_price,
            self.user_stats.backup_disk_size_cost
        )

    def test_check_storage_disk_size_cost(self):
        # Check Storage Disk Size cost
        # if template/backup is located on HV
        total_size = 0
        if not self.backup.backup_server_id:
            total_size += self.backup.backup_size
        if not self.template.backup_server_id:
            total_size += self.template.template_size
        expected_price = (total_size / self.KB_IN_1GB) * \
                         self.storage_disk_size_rc.prices.price
        test.log.info('\nStorage Disk Size Cost:')
        assert billingTH.price_comparator(
            expected_price,
            self.user_stats.storage_disk_size_cost
        )

        # Check Usage Statistics ???

    def test_check_disk_size_cost(self):
        # Check Disk size cost
        test.log.info('\nDisk Size Cost:')
        assert billingTH.price_comparator(
            self.vs.disks_price_on,
            self.vm_stat.get_disks_disk_size_cost()
        )

    def test_check_data_read_cost(self):
        # Check Data Read cost
        expected_price = (
            self.dsz_rc.prices.price_data_read *
            self.vm_stat.get_disks_data_read_value()  # value in GB
        )
        test.log.info('\nData Read Cost:')
        assert billingTH.price_comparator(
            expected_price,
            self.vm_stat.get_disks_data_read_cost()
        )

    def test_check_data_written_cost(self):
        # Check Data Written cost
        expected_price = (
            self.dsz_rc.prices.price_data_written *
            self.vm_stat.get_disks_data_written_value()  # value in GB
        )
        test.log.info('\nData Written Cost:')
        assert billingTH.price_comparator(
            expected_price,
            self.vm_stat.get_disks_data_written_cost()
        )

    def test_check_reads_completed_cost(self):
        # Check Reads Completed cost
        expected_price = (
            self.dsz_rc.prices.price_reads_completed *
            self.vm_stat.get_disks_input_requests_value()
        )
        test.log.info('Reads Completed Cost:')
        assert billingTH.price_comparator(
            expected_price,
            self.vm_stat.get_disks_input_requests_cost()
        )

    def test_check_writes_completed_cost(self):
        # Check Writes Completed cost
        expected_price = (
            self.dsz_rc.prices.price_writes_completed *
            self.vm_stat.get_disks_output_requests_value()
        )
        test.log.info('Writes Completed Cost:')
        assert billingTH.price_comparator(
            expected_price,
            self.vm_stat.get_disks_output_requests_cost(),
            precision=0.6
        )

    def test_check_ip_address_cost(self):
        # Check IP Address cost
        test.log.info('IP address Cost:')
        assert billingTH.price_comparator(
            self.vs.ip_price_on,
            self.vm_stat.get_networks_ip_addresses_cost()
        )

    def test_check_rate_cost(self):
        # Check Rate cost
        test.log.info('Rate Cost:')
        assert billingTH.price_comparator(
            self.vs.rate_limit_price_on,
            self.vm_stat.get_networks_port_speed_cost()
        )

    def test_check_data_received_cost(self):
        # Check Data Received cost
        expected_price = (
            self.ntz_rc.prices.price_data_received *
            self.vm_stat.get_networks_data_received_value()
        )
        test.log.info('Data Received Cost:')
        assert billingTH.price_comparator(
            expected_price, self.vm_stat.get_networks_data_received_cost()
        )

    def test_check_data_sent_cost(self):
        # Check Data Sent cost
        expected_price = (
            self.ntz_rc.prices.price_data_sent *
            self.vm_stat.get_networks_data_sent_value()
        )
        test.log.info('Data Sent Cost:')
        assert billingTH.price_comparator(
            expected_price, self.vm_stat.get_networks_data_sent_cost()
        )

    def test_check_cpu_share_cost(self):
        # Check CPU Shares cost
        test.log.info('CPU share Cost:')
        assert billingTH.price_comparator(
            self.vs.cpu_shares_price_on,
            self.vm_stat.get_vm_cpu_shares_cost()
        )

    def test_check_cpu_cost(self):
        # Check CPUs cost
        test.log.info('CPU Cost:')
        assert billingTH.price_comparator(
            self.vs.cpu_price_on,
            self.vm_stat.get_vm_cpus_cost()
        )

    def test_check_memory_cost(self):
        # Check Memory cost
        test.log.info('Memory Cost:')
        assert billingTH.price_comparator(
            self.vs.memory_price_on,
            self.vm_stat.get_vm_memory_cost()
        )

    # Check CPU Usage cost

        # Check Total cost

        # Check VM Resources cost

        # Check Usage cost

    def test_check_hourly_price_for_turned_off_server_from_ui(self):
        # Turn Off VS from UI, check hourly price and booted value - should be 0.
        # Check hourly price for shut downed VS.
        self.vs.shutdown()
        if not self.vs.booted:
            self.vm_stat.stats_waiter()
            self.vm_stat.get_hourly_stat_for_the_last_hour()
            test.log.info('Hourly price for turned off server from UI:')
            assert billingTH.price_comparator(
                self.vs.get_price_per_hour_powered_off(),
                self.vm_stat.vm_resources_cost
            )

        # https://onappdev.atlassian.net/browse/CORE-11324
        assert not self.vm_stat.booted

    def test_check_hourly_price_for_turned_on_server_from_ui(self):
        # Turn On VS from UI, check hourly price and booted value - should be 1.
        # Check hourly price for booted VS.
        self.vs.start()
        if self.vs.booted:
            self.vm_stat.stats_waiter()
            self.vm_stat.get_hourly_stat_for_the_last_hour()
            test.log.info('Hourly price for turned on server from UI:')
            assert billingTH.price_comparator(
                self.vs.get_price_per_hour(),
                self.vm_stat.vm_resources_cost
            )
        assert self.vm_stat.booted

    def test_check_hourly_price_for_turned_off_server_from_inside(self):
        # Shutdown VS from inside, check hourly price and booted value - should be 0.
        # Check hourly price for shut downed VS from inside.
        self.vs.execute('init 0')
        assert self.vs.wait_for_action(
            lambda: test.update_object(self.vs) and not self.vs.booted,
            timeout=60,
            step=5
        )
        self.vm_stat.stats_waiter()
        self.vm_stat.get_hourly_stat_for_the_last_hour()
        test.log.info('Hourly price for turned off server from inside:')
        assert billingTH.price_comparator(
            self.vs.get_price_per_hour_powered_off(),
            self.vm_stat.vm_resources_cost
        )
        assert not self.vm_stat.booted

    def test_check_hourly_price_for_changed_price(self):
        if not self.vs.booted:
            self.vs.start()

        # Change prices for HVZ
        self.hvz_rc.prices.price_on_cpu = 0.03214356
        self.hvz_rc.prices.price_off_cpu = 0.1543135
        self.hvz_rc.prices.price_on_cpu_share = 0.00001465
        self.hvz_rc.prices.price_off_cpu_share = 0.46733451
        self.hvz_rc.prices.price_on_memory = 0.1004225
        self.hvz_rc.prices.price_off_memory = 0.12340745
        assert self.hvz_rc.edit()

        self.vm_stat.stats_waiter()
        self.vm_stat.get_hourly_stat_for_the_last_hour()
        test.log.info('Hourly price for changed prices:')
        assert billingTH.price_comparator(
            self.vs.get_price_per_hour(),
            self.vm_stat.vm_resources_cost
        )
