import pytest
from onapp_helper import test
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.bucket import access_controls as ac
from onapp_helper.bucket import rate_cards as rc
from onapp_helper.data_store_zone import DataStoreZone
from test_helper import rc_base_test


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.rate_cards
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
class TestDataStoreZoneRateCard(rc_base_test.BaseTest):
    def setup_class(self):
        self.bucket = Bucket()
        self.bucket.label = self.__name__
        assert self.bucket.create(), self.bucket.error

        self.target = DataStoreZone()
        self.target.label = self.__name__
        self.target.server_type = DataStoreZone.SERVER_TYPE.vpc
        assert self.target.create(), self.target.error

        self.target_apply_to_all_resources = DataStoreZone()
        self.target_apply_to_all_resources.label = self.__name__
        self.target_apply_to_all_resources.server_type = DataStoreZone.SERVER_TYPE.vpc
        assert self.target_apply_to_all_resources.create(), self.target_apply_to_all_resources.error

        self.incorrect_target = DataStoreZone()
        self.incorrect_target.label = self.__name__
        self.incorrect_target.server_type = DataStoreZone.SERVER_TYPE.smart
        assert self.incorrect_target.create(), self.incorrect_target.error

        self.ac = ac.DataStoreZoneAC(
            parent_obj=self.bucket,
            target_id=self.target.id,
            server_type=ac.SERVER_TYPE.vpc
        )

        self.rc_with_apply_to_all_resources = rc.DataStoreZoneRC(
            parent_obj=self.bucket,
            target_id=self.target_apply_to_all_resources.id,
            server_type=rc.SERVER_TYPE.vpc
        )
        self.rc_with_apply_to_all_resources.apply_to_all_resources_in_the_bucket = True

        self.rc = rc.DataStoreZoneRC(
            parent_obj=self.bucket,
            target_id=self.target.id,
            server_type=rc.SERVER_TYPE.vpc
        )

        self.incorrect_rc = rc.DataStoreZoneRC(
            parent_obj=self.bucket,
            target_id=self.incorrect_target.id,
            server_type=rc.SERVER_TYPE.vpc
        )

        self.prices = {
            "limit_free_disk_size": 1.01,
            "limit_free_disk_size_used": 2.02,
            "limit_free_vs_disk_size": 3.03,
            "limit_free_vs_data_read": 4.04,
            "limit_free_vs_data_written": 5.05,
            "limit_free_vs_reads_completed": 6.06,
            "limit_free_vs_writes_completed": 7.07,
            "price_disk_size": 8.08,
            "price_disk_size_used": 9.09,
            "price_disk_size_unlimited": 10.10,
            "price_vs_disk_size_on": 11.11,
            "price_vs_disk_size_off": 12.12,
            "price_vs_data_read": 56.0,
            "price_vs_data_written": 67.0,
            "price_vs_reads_completed": 78.0,
            "price_vs_writes_completed": 89.0
        }

    def test_create_rc_with_incorrect_target(self):
        assert not self.incorrect_rc.create()
        assert self.rc.E_INCORRECT_TARGET in self.incorrect_rc.error['server_type']

    @pytest.mark.skipif(test.cp_version < 5.9, reason="Not supported until 5.9")
    def test_add_rc_with_apply_to_all_resources_option(self):
        if not self.rc.get():
            assert self.rc.create(), self.rc.error
        self._set_prices(self.rc_with_apply_to_all_resources, multiplier=3)
        assert self.rc_with_apply_to_all_resources.create(), self.rc_with_apply_to_all_resources.error

    @pytest.mark.skipif(test.cp_version < 5.9, reason="Not supported until 5.9")
    def test_check_limits_after_create(self):
        assert self.rc.get(), self.rc.error
        self._check_prices(self.rc)
        self._check_prices(self.rc_with_apply_to_all_resources)

    @pytest.mark.skipif(test.cp_version < 5.9, reason="Not supported until 5.9")
    def test_edit_rc_with_apply_to_all_resources_option(self):
        self.rc_with_apply_to_all_resources.reset()
        self.rc_with_apply_to_all_resources.apply_to_all_resources_in_the_bucket = True
        assert self.rc_with_apply_to_all_resources.edit(), self.rc_with_apply_to_all_resources.error

    @pytest.mark.skipif(test.cp_version < 5.9, reason="Not supported until 5.9")
    def test_check_rc_limits_after_edit(self):
        assert self.rc.get(), self.rc.error
        self._check_prices(self.rc, zero=True)
        self._check_prices(self.rc_with_apply_to_all_resources, zero=True)