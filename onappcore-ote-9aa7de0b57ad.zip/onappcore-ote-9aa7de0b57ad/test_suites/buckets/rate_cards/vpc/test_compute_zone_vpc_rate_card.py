import pytest
from onapp_helper import test
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.bucket import access_controls as ac
from onapp_helper.bucket import rate_cards as rc
from onapp_helper.hypervisor_zone import HypervisorZone
from test_helper import rc_base_test


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.rate_cards
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
class TestComputeZoneRateCard(rc_base_test.BaseTest):
    def setup_class(self):
        self.bucket = Bucket()
        self.bucket.label = self.__name__
        assert self.bucket.create(), self.bucket.error

        self.target = HypervisorZone()
        self.target.label = self.__name__
        self.target.server_type = HypervisorZone.SERVER_TYPE.vpc
        assert self.target.create(), self.target.error

        self.target_apply_to_all_resources = HypervisorZone()
        self.target_apply_to_all_resources.label = f'{self.__name__}ApplyToAll'
        self.target_apply_to_all_resources.server_type = HypervisorZone.SERVER_TYPE.vpc
        assert self.target_apply_to_all_resources.create(), self.target_apply_to_all_resources.error

        self.incorrect_target = HypervisorZone()
        self.incorrect_target.label = f'{self.__name__}IncorrectTarget'
        self.incorrect_target.server_type = HypervisorZone.SERVER_TYPE.smart
        assert self.incorrect_target.create(), self.incorrect_target.error

        self.rc = rc.ComputeZoneRC(
            parent_obj=self.bucket,
            target_id=self.target.id,
            server_type=rc.SERVER_TYPE.vpc
        )

        self.incorrect_rc = rc.ComputeZoneRC(
            parent_obj=self.bucket,
            target_id=self.incorrect_target.id,
            server_type=rc.SERVER_TYPE.vpc
        )

        self.rc_with_apply_to_all_resources = rc.ComputeZoneRC(
            parent_obj=self.bucket,
            target_id=self.target_apply_to_all_resources.id,
            server_type=rc.SERVER_TYPE.vpc
        )
        self.rc_with_apply_to_all_resources.apply_to_all_resources_in_the_bucket = True

        self.ac = ac.ComputeZoneAC(
            parent_obj=self.bucket,
            target_id=self.target.id,
            server_type=ac.SERVER_TYPE.vpc
        )

        self.prices = {
            "limit_free_allocation_cpu_allocation": 0.0,
            "limit_free_allocation_memory_allocation": 0.0,
            "limit_free_allocation_cpu_used": 0.0,
            "limit_free_allocation_memory_used": 0.0,
            "limit_free_allocation_cpu_resources_guaranteed": 0.0,
            "limit_free_allocation_memory_resources_guaranteed": 0.0,
            "limit_free_allocation_vcpu_speed": 0.0,
            "limit_free_reservation_cpu_allocation": 0.0,
            "limit_free_reservation_memory_allocation": 0.0,
            "limit_free_pay_as_you_go_cpu_limit": 0.0,
            "limit_free_pay_as_you_go_memory_limit": 0.0,
            "limit_free_pay_as_you_go_cpu_used": 0.0,
            "limit_free_pay_as_you_go_memory_used": 0.0,
            "limit_free_vs_cpu": 0.0,
            "limit_free_vs_memory": 0.0,
            "price_allocation_cpu_allocation": 0.0,
            "price_allocation_memory_allocation": 0.0,
            "price_allocation_cpu_resources_guaranteed": 0.0,
            "price_allocation_memory_resources_guaranteed": 0.0,
            "price_allocation_cpu_used": 0.0,
            "price_allocation_memory_used": 0.0,
            "price_allocation_vcpu_speed": 0.0,
            "price_reservation_cpu_allocation": 0.0,
            "price_reservation_memory_allocation": 0.0,
            "price_pay_as_you_go_cpu_limit": 0.0,
            "price_pay_as_you_go_memory_limit": 0.0,
            "price_pay_as_you_go_cpu_limit_unlimited": 0.0,
            "price_pay_as_you_go_memory_limit_unlimited": 0.0,
            "price_pay_as_you_go_cpu_used": 0.0,
            "price_pay_as_you_go_memory_used": 0.0,
            "price_on_vs_cpu": 0.0,
            "price_off_vs_cpu": 0.0,
            "price_on_vs_memory": 0.0,
            "price_off_vs_memory": 0.0
        }

        price = 1
        for key in self.prices.keys():
            self.prices[key] = price
            price += 1

    def teardown_class(self):
        attributes = (
            'target',
            'incorrect_target',
            'target_apply_to_all_resources',
            'bucket'
        )
        test.clean_up_resources(attributes, self)

    def test_create_rc_with_incorrect_target(self):
        assert not self.incorrect_rc.create()
        assert self.rc.E_INCORRECT_TARGET in self.incorrect_rc.error['server_type']

    @pytest.mark.skipif(test.cp_version < 5.9, reason="Not supported until 5.9")
    def test_add_rc_with_apply_to_all_resources_option(self):
        if not self.rc.get():
            assert self.rc.create(), self.rc.error
        self._set_prices(self.rc_with_apply_to_all_resources, multiplier=3)
        assert self.rc_with_apply_to_all_resources.create(), self.rc_with_apply_to_all_resources.error

    @pytest.mark.skipif(test.cp_version < 5.9, reason="Not supported until 5.9")
    def test_check_limits_after_create(self):
        assert self.rc.get(), self.rc.error
        self._check_prices(self.rc)
        self._check_prices(self.rc_with_apply_to_all_resources)

    @pytest.mark.skipif(test.cp_version < 5.9, reason="Not supported until 5.9")
    def test_edit_rc_with_apply_to_all_resources_option(self):
        self.rc_with_apply_to_all_resources.reset()
        self.rc_with_apply_to_all_resources.apply_to_all_resources_in_the_bucket = True
        assert self.rc_with_apply_to_all_resources.edit(), self.rc_with_apply_to_all_resources.error

    @pytest.mark.skipif(test.cp_version < 5.9, reason="Not supported until 5.9")
    def test_check_rc_limits_after_edit(self):
        assert self.rc.get(), self.rc.error
        self._check_prices(self.rc, zero=True)
        self._check_prices(self.rc_with_apply_to_all_resources, zero=True)
