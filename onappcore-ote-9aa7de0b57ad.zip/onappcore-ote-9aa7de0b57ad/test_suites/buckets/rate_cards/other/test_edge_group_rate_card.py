import pytest

from onapp_helper import test
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.bucket.rate_cards import EdgeGroupsRC
from onapp_helper.cdn.edge_group import EdgeGroup


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.rate_cards
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
class TestBackupServerZoneRateCard:
    def setup_class(self):
        self.bucket = Bucket()
        self.bucket.label = self.__name__
        assert self.bucket.create(), self.bucket.error

        self.edge_group = EdgeGroup()
        self.edge_group.server_type = 'other'
        assert self.edge_group.create(), self.edge_group.error

        self.edge_group_rc = EdgeGroupsRC(
            parent_obj=self.bucket,
            target_id=self.edge_group.id,
            server_type=EdgeGroupsRC.SERVER_TYPE.other
        )

    def teardown_class(self):
        assert self.edge_group.delete(), self.edge_group.error
        assert self.bucket.delete(), self.bucket.error

    # Negative tests for create

    def test_validate_negative_price(self):
        self.edge_group_rc.reset()
        self.edge_group_rc.prices.price = -2.22
        assert not self.edge_group_rc.create()
        assert self.edge_group_rc.E_GREATER_OR_EQUAL_TO_0 in \
               self.edge_group_rc.error['price']

    # Positive test for create
    def test_create_backup_server_zone_rate_card(self):
        self.edge_group_rc.reset()
        test.gen_api_doc = "Create Edge Group Rate Card"
        assert self.edge_group_rc.create(), self.edge_group_rc.error

    # Negative tests for edit

    # Positive test for edit
    def test_edit_backup_server_zone_rate_card(self):
        test.gen_api_doc = "Edit Edge Group Rate Card"
        assert self.edge_group_rc.edit(), self.edge_group_rc.error

    def test_delete_backup_server_zone_rate_card(self):
        test.gen_api_doc = "Delete Edge Group Rate Card"
        assert self.edge_group_rc.delete(), self.edge_group_rc.error