import pytest
from onapp_helper import test
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.bucket.rate_cards import ServiceAddonRC
from onapp_helper.service_addon.service_addon_group import ServiceAddonGroup, RelationGroupAddon
from onapp_helper.service_addon.service_addon import ServiceAddon


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.rate_cards
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
class TestServiceAddonGroupRateCard:
    def setup_class(self):
        try:
            self.bucket = Bucket()
            self.bucket.label = self.__name__
            assert self.bucket.create(), self.bucket.error

            self.service_addon = ServiceAddon()
            self.service_addon.label = self.__name__
            self.service_addon.compatible_with.append(
                ServiceAddon.COMPATIBLE_WITH.unix
            )
            assert self.service_addon.create(), self.service_addon.error

            self.service_addon_group = ServiceAddonGroup()
            self.service_addon_group.label = self.__name__
            assert self.service_addon_group.create(), self.service_addon_group.error

            self.relation_sa = RelationGroupAddon(self.service_addon_group)
            assert self.relation_sa.attach_addon_to_group(
                service_addon_id=self.service_addon.id
            ), self.relation_sa.error

            self.service_addon_group_rc = ServiceAddonRC(
                parent_obj=self.bucket,
                target_id=self.service_addon.id,
                server_type=ServiceAddonRC.SERVER_TYPE.other
            )
        except AssertionError:
            self.teardown_class(self)

    def teardown_class(self):
        assert self.service_addon_group.delete()
        assert self.service_addon.delete()
        assert self.bucket.delete()

    # Negative tests for create
    def test_validate_wrong_target_id(self):
        self.service_addon_group_rc.target_id = 0
        assert not self.service_addon_group_rc.create()
        assert self.service_addon_group_rc.E_WRONG_TARGET_ID in \
               self.service_addon_group_rc.error['target_id']

    def test_create_service_addon_group_rate_card(self):
        self.service_addon_group_rc.target_id = self.service_addon.id
        self.service_addon_group_rc.prices.price = 12
        self.service_addon_group_rc.prices.price_cpu = 23
        self.service_addon_group_rc.prices.price_memory = 34
        self.service_addon_group_rc.prices.price_disk_size = 45
        test.gen_api_doc = "Create Service Addon Store Rate Card"
        assert self.service_addon_group_rc.create(), self.service_addon_group_rc.error
        assert self.service_addon_group_rc.prices.price == 12
        assert self.service_addon_group_rc.prices.price_cpu == 23
        assert self.service_addon_group_rc.prices.price_memory == 34
        assert self.service_addon_group_rc.prices.price_disk_size == 45

    # Positive test for edit
    def test_edit_service_addon_group_rate_card(self):
        self.service_addon_group_rc.prices.price = 54
        self.service_addon_group_rc.prices.price_cpu = 43
        self.service_addon_group_rc.prices.price_memory = 32
        self.service_addon_group_rc.prices.price_disk_size = 21
        test.gen_api_doc = "Edit Service Addon Store Rate Card"
        assert self.service_addon_group_rc.edit(), self.service_addon_group_rc.error
        assert self.service_addon_group_rc.prices.price == 54
        assert self.service_addon_group_rc.prices.price_cpu == 43
        assert self.service_addon_group_rc.prices.price_memory == 32
        assert self.service_addon_group_rc.prices.price_disk_size == 21

    def test_delete_service_addon_group_rate_card(self):
        test.gen_api_doc = "Delete Service Addon Store Rate Card"
        assert self.service_addon_group_rc.delete(), self.service_addon_group_rc.error