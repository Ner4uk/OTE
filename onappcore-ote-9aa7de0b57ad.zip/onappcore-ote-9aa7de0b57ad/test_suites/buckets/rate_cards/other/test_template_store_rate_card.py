import pytest
from onapp_helper import test
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.bucket.rate_cards import TemplateRC
from onapp_helper.template import Template
from onapp_helper.template_store import TemplateStore
from onapp_helper.template_store import RelationGroupTemplate


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.rate_cards
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
class TestTemplateStoreRateCard:
    def setup_class(self):
        self.bucket = Bucket()
        self.bucket.label = self.__name__
        assert self.bucket.create(), self.bucket.error

        self.template = Template().get_not_system()

        self.template_store = TemplateStore()
        self.template_store.label = self.__name__
        assert self.template_store.create(), self.template_store.error

        self.relation_group_template = RelationGroupTemplate(self.template_store)
        assert self.relation_group_template.attach_template_to_group(
            self.template.id
        ), self.relation_group_template.error

        self.template_store_rc = TemplateRC(
            parent_obj=self.bucket,
            target_id=self.template.id,
            server_type=TemplateRC.SERVER_TYPE.other
        )

    def teardown_class(self):
        # assert self.relation_group_template.detach_template_from_group(
        #     self.template.id
        # ), self.relation_group_template.error
        assert self.template_store.delete(), self.template_store.error
        assert self.bucket.delete(), self.bucket.error

    # Negative tests for create
    def test_validate_wrong_target_id(self):
        self.template_store_rc.target_id = 0
        assert not self.template_store_rc.create()
        assert self.template_store_rc.E_WRONG_TARGET_ID in \
               self.template_store_rc.error['target_id']

    def test_validate_negative_price(self):
        self.template_store_rc.reset()
        # self.template_store_rc.target_id = self.template.id
        self.template_store_rc.prices.price = -2.22
        assert not self.template_store_rc.create()
        assert self.template_store_rc.E_GREATER_OR_EQUAL_TO_0 in \
               self.template_store_rc.error['price']

    # Positive test for create
    def test_create_template_store_rate_card(self):
        self.template_store_rc.reset()
        test.gen_api_doc = "Create Template Store Rate Card"
        self.template_store_rc.target_id = self.template.id
        self.template_store_rc.prices.price = 90
        assert self.template_store_rc.create(), self.template_store_rc.error
        assert self.template_store_rc.prices.price == 90

    # Negative tests for edit

    # Positive test for edit
    def test_edit_template_store_rate_card(self):
        test.gen_api_doc = "Edit Template Store Rate Card"
        assert self.template_store_rc.edit(), self.template_store_rc.error

    def test_delete_template_store_rate_card(self):
        test.gen_api_doc = "Delete Template Store Rate Card"
        assert self.template_store_rc.delete(), self.template_store_rc.error