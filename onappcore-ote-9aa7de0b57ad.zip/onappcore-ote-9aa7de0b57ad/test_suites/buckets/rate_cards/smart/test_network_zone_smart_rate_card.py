import pytest
from onapp_helper import test
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.bucket import access_controls as ac
from onapp_helper.bucket import rate_cards as rc
from test_helper import rc_base_test
from onapp_helper.network_zone import NetworkZone


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.rate_cards
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
class TestNetworkZoneRateCard(rc_base_test.BaseTest):
    def setup_class(self):
        self.bucket = Bucket()
        self.bucket.label = self.__name__
        assert self.bucket.create(), self.bucket.error

        self.target = NetworkZone()
        self.target.server_type = NetworkZone.SERVER_TYPE.smart
        assert self.target.create(), self.target.error

        self.target_apply_to_all_resources = NetworkZone()
        self.target_apply_to_all_resources.server_type = NetworkZone.SERVER_TYPE.smart
        assert self.target_apply_to_all_resources.create(), self.target_apply_to_all_resources.error

        self.incorrect_target = NetworkZone()
        self.incorrect_target.server_type = NetworkZone.SERVER_TYPE.virtual
        assert self.incorrect_target.create(), self.incorrect_target.error

        self.ac = ac.NetworkZoneAC(
            parent_obj=self.bucket,
            target_id=self.target.id,
            server_type=ac.SERVER_TYPE.smart
        )

        self.rc = rc.NetworkZoneRC(
            parent_obj=self.bucket,
            target_id=self.target.id,
            server_type=rc.SERVER_TYPE.smart
        )

        self.rc_with_apply_to_all_resources = rc.NetworkZoneRC(
            parent_obj=self.bucket,
            target_id=self.target_apply_to_all_resources.id,
            server_type=rc.SERVER_TYPE.smart
        )
        self.rc_with_apply_to_all_resources.apply_to_all_resources_in_the_bucket = True

        self.incorrect_rc = rc.NetworkZoneRC(
            parent_obj=self.bucket,
            target_id=self.incorrect_target.id,
            server_type=rc.SERVER_TYPE.smart
        )

        self.prices = {
            'limit_rate_free': 12,
            'limit_ip_free': 23,
            'limit_data_sent_free': 34,
            'limit_data_received_free': 45,
            'price_ip_on': 56,
            'price_ip_off': 67,
            'price_rate_on': 78,
            'price_rate_off': 89,
            'price_data_sent': 90,
            'price_data_received': 100
        }

    def test_create_rc_with_incorrect_target(self):
        assert not self.incorrect_rc.create()
        assert self.rc.E_INCORRECT_TARGET in self.incorrect_rc.error['server_type']

    @pytest.mark.skipif(test.cp_version < 5.9, reason="Not supported until 5.9")
    def test_add_rc_with_apply_to_all_resources_option(self):
        if not self.rc.get():
            assert self.rc.create(), self.rc.error
        self._set_prices(self.rc_with_apply_to_all_resources, multiplier=3)
        assert self.rc_with_apply_to_all_resources.create(), self.rc_with_apply_to_all_resources.error

    @pytest.mark.skipif(test.cp_version < 5.9, reason="Not supported until 5.9")
    def test_check_limits_after_create(self):
        assert self.rc.get(), self.rc.error
        self._check_prices(self.rc)
        self._check_prices(self.rc_with_apply_to_all_resources)

    @pytest.mark.skipif(test.cp_version < 5.9, reason="Not supported until 5.9")
    def test_edit_rc_with_apply_to_all_resources_option(self):
        self.rc_with_apply_to_all_resources.reset()
        self.rc_with_apply_to_all_resources.apply_to_all_resources_in_the_bucket = True
        assert self.rc_with_apply_to_all_resources.edit(), self.rc_with_apply_to_all_resources.error

    @pytest.mark.skipif(test.cp_version < 5.9, reason="Not supported until 5.9")
    def test_check_rc_limits_after_edit(self):
        assert self.rc.get(), self.rc.error
        self._check_prices(self.rc, zero=True)
        self._check_prices(self.rc_with_apply_to_all_resources, zero=True)