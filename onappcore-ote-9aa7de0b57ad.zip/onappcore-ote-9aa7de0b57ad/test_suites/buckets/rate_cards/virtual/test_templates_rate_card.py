import pytest
from onapp_helper import test
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.bucket import access_controls as ac
from onapp_helper.bucket import rate_cards as rc
from test_helper import rc_base_test


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.rate_cards
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
class TestTemplatesRateCard(rc_base_test.BaseTest):
    def setup_class(self):
        self.bucket = Bucket()
        self.bucket.label = self.__name__
        assert self.bucket.create(), self.bucket.error

        # !!! Add some template to Template RC as target_id

        self.ac = ac.TemplatesAC(parent_obj=self.bucket)
        self.rc = rc.TemplatesRC(parent_obj=self.bucket)

        self.prices = {
            'limit_free': 12,
            'price': 23
        }
