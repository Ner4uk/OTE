import pytest
from onapp_helper import test
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.bucket.rate_cards import InstancePackageRC
from onapp_helper.bucket.access_controls import InstancePackageAC
from onapp_helper.instance_package import InstancePackage


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.rate_cards
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.6, reason='Not supported')
@pytest.mark.skipif(
    test.cp_version < 4.2,
    reason="Current CP version ({0}) does not support this functionality ".format(test.cp_version)
)
class TestInstanceTypesLimits():
    def setup_class(self):
        self.bucket = Bucket()
        self.bucket.create()
        # Create InsType
        self.instance_package = InstancePackage()
        self.instance_package.label = self.__name__
        assert self.instance_package.create()

        self.instance_package_rc = InstancePackageRC(
            parent_obj=self.bucket,
            target_id=self.instance_package.id
        )

        self.instance_package_ac = InstancePackageAC(
            parent_obj=self.bucket,
            target_id=self.instance_package.id
        )

    def teardown_class(self):
        self.bucket.delete()
        self.instance_package.delete()

    def test_create_instance_package_rc_with_negative_price_on(self):
        # Set IT prices
        self.instance_package_rc.prices.price_on = -1
        assert not self.instance_package_rc.create()
        assert self.instance_package_rc.E_GREATER_OR_EQUAL_TO_0 in self.instance_package_rc.error['price_on']

    def test_create_instance_package_rc_with_negative_price_off(self):
        # Set IT prices
        self.instance_package_rc.reset()
        self.instance_package_rc.prices.price_off = -20
        assert not self.instance_package_rc.create()
        assert self.instance_package_rc.E_GREATER_OR_EQUAL_TO_0 in self.instance_package_rc.error['price_off']

    def test_create_instance_package_rc_with_negative_price_for_overused_bandwidth(self):
        # Set IT prices
        self.instance_package_rc.reset()
        self.instance_package_rc.prices.price_overused_bandwidth = -99
        assert not self.instance_package_rc.create()
        assert self.instance_package_rc.E_GREATER_OR_EQUAL_TO_0 in self.instance_package_rc.error['price_overused_bandwidth']

    def test_create_instance_package_rc(self):
        # Set IT prices
        self.instance_package_rc.prices.price_on = 100
        self.instance_package_rc.prices.price_off = 20
        self.instance_package_rc.prices.price_overused_bandwidth = 99
        # Create IT limit
        test.gen_api_doc = "Create Instance Package Rate Card"
        assert self.instance_package_rc.create()

    def test_rate_card_has_not_been_created(self):
        assert not self.instance_package_ac.get()

    def test_check_instance_package_rc_price_on(self):
        # Check prices
        assert self.instance_package_rc.prices.price_on == 100

    def test_check_instance_package_rc_price_off(self):
        assert self.instance_package_rc.prices.price_off == 20

    def test_check_instance_package_rc_price_overused_bandwidth(self):
        assert self.instance_package_rc.prices.price_overused_bandwidth == 99

    def test_edit_instance_package_rc(self):
        # EDIT
        # Edit prices
        self.instance_package_rc.prices.price_on = 101
        self.instance_package_rc.prices.price_off = 21
        self.instance_package_rc.prices.price_overused_bandwidth = 991
        test.gen_api_doc = "Edit Instance Package Rate Card"
        assert self.instance_package_rc.edit()

    def test_check_instance_package_rc_new_price_on(self):
        # Check prices
        assert self.instance_package_rc.prices.price_on == 101

    def test_check_instance_package_rc_new_price_off(self):
        assert self.instance_package_rc.prices.price_off == 21

    def test_check_instance_package_rc_new_price_overused_bandwidth(self):
        assert self.instance_package_rc.prices.price_overused_bandwidth == 991

    def test_delete_instance_package_rc(self):
        test.gen_api_doc = "Delete Instance Package Rate Card"
        assert self.instance_package_rc.delete()