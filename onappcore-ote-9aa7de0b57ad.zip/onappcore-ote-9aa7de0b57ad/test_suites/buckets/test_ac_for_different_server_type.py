import pytest
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.bucket import access_controls as ac
from onapp_helper import test


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.access_controls
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version < 5.6,
    reason='Buckets is not supported yet!')
@pytest.mark.verbose
class TestACForDifferentServerTypes:
    def setup_class(self):
        try:
            self.bucket = Bucket()
            self.bucket.label = self.__name__
            assert self.bucket.create()

            self.vs_ac = ac.VirtualServerAC(parent_obj=self.bucket)
            self.vs_vpc_ac = ac.VirtualServerAC(
                parent_obj=self.bucket,
                server_type=ac.SERVER_TYPE.vpc
            )

        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        attributes = (
            'bucket'
        )
        test.clean_up_resources(attributes, self)

    def test_check_that_ac_does_not_exists(self):
        assert not self.vs_ac.get()
        assert not self.vs_vpc_ac.get()

    def test_create_virtual_ac(self):
        assert self.vs_ac.create()

    def test_you_can_get_virtual_ac(self):
        assert self.vs_ac.get()

    def test_you_should_not_get_vpc_ac(self):
        assert not self.vs_vpc_ac.get()

    def test_create_vpc_ac(self):
        if self.vs_vpc_ac.server_type != ac.SERVER_TYPE.vpc:
            self.vs_vpc_ac.server_type = ac.SERVER_TYPE.vpc
        assert self.vs_vpc_ac.create()

    def test_you_can_get_vpc_ac(self):
        assert self.vs_vpc_ac.get()
