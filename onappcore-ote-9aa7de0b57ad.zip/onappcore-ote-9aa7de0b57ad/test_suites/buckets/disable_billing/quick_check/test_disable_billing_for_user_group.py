# ignore
__doc__ = """
User Group 
Remove price per hour
Remove price per month
Bucket and User bucket should direct to Access Control
Remove monthly fee, paid amount, total amount, discount due to free, 
  total amount with discount, outstanding amount, payments, monthly bills, 
  service addons stats, billing report
"""

import pytest

from onapp_helper import test
from onapp_helper.user_group import UserGroup
from onapp_helper.payment import Payment
# from onapp_helper.stats.user_stats import UserStats
# from onapp_helper.stats.vm_stat import VmStat


@pytest.fixture(scope='class', autouse=True)
def user_group(request):
    group = None

    # Simple way to get correct user group
    group_ids = test.cp.mysql_execute(
        'select user_group_id from vcloud_organizations where user_group_id '
        'is not NULL limit 1'
    )
    if group_ids:
        group = UserGroup(id=group_ids[0])
    else:
        pytest.skip("vCloud user group not found")

    return group


@pytest.fixture(scope='class', autouse=True)
def payment(request):
    p = Payment()
    return p


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.disable_billing
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.sequentially
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.9, reason='Not supported')
@pytest.mark.verbose
class TestDisableBillingForUserGroup:
    __doc__ = """
    1. Before disabling billing check that stats available and costs are 
    present.
    2. Disable billing
    3. Check that stats available and costs were removed
    4. Enable billing and check that costs are present
    """

    def teardown_class(self):
        test.onapp_settings.get()
        if test.onapp_settings.disable_billing:
            test.onapp_settings.set(disable_billing=False)

    def test_enable_billing(self):
        test.load_onapp_settings()
        if test.onapp_settings.disable_billing:
            test.onapp_settings.set(disable_billing=False)

        assert test.wait_for_action(
            lambda: test.onapp_settings.get() and test.onapp_settings.disable_billing is False,
            timeout=5
        )

    def test_get_user_group_details(self, user_group: UserGroup):
        assert user_group.get()

    @pytest.mark.parametrize('attribute', [
        "monthly_price",
        "paid_amount",
        "total_amount",
        "outstanding_amount",
        "discount_due_to_free",
        "total_amount_with_discount"
    ])
    def test_billing_details_should_be_displayed_on_user_group_details_page(
            self, user_group, attribute
    ):
        # assert hasattr(user, attribute)
        assert attribute in user_group.response[user_group.root_tag]

    def test_possible_to_get_payments(self, user_group, payment: Payment):
        payment.get_all(
            payer_type=Payment.PAYER_TYPE.user_group, payer_id=user_group.id
        )
        assert payment.status_code == 200
        assert not payment.error

    def test_possible_to_get_monthly_bills(self, user_group: UserGroup):
        user_group.monthly_bills.get_all()
        assert user_group.monthly_bills.status_code == 200
        assert not user_group.monthly_bills.error

    def test_possible_to_get_service_addons_stats(self, user_group: UserGroup):
        user_group.service_addons_stats.get()
        assert user_group.service_addons_stats.status_code == 200
        assert not user_group.service_addons_stats.error

    def test_possible_to_get_billing_report(self, user_group: UserGroup):
        user_group.report.get_all()
        assert user_group.report.status_code == 200
        assert not user_group.report.error
    ############################################################################
    ############################################################################
    ############################################################################

    def test_disable_billing(self):
        if not test.onapp_settings.disable_billing:
            test.onapp_settings.set(disable_billing=True)

        assert test.wait_for_action(
            lambda: test.onapp_settings.get() and test.onapp_settings.disable_billing is True,
            timeout=5
        )

    def test_get_user_group_details_for_disabled_billing(
            self, user_group: UserGroup
    ):
        """
            Remove monthly fee, paid amount, total amount, discount due to free,
        total amount with discount, outstanding amount
        """
        assert user_group.get()

    @pytest.mark.parametrize('attribute', [
        "monthly_price",
        "paid_amount",
        "total_amount",
        "outstanding_amount",
        "discount_due_to_free",
        "total_amount_with_discount"
    ])
    def test_billing_details_should_not_be_displayed_on_user_group_page_for_disabled_billing(
            self, user_group, attribute
    ):
        # assert not hasattr(user, attribute)
        assert attribute not in user_group.response[user_group.root_tag]

    # Remove payments, monthly bills, service addons stats, billing report
    def test_impossible_to_get_payments_for_disabled_billing(
            self, user_group, payment: Payment
    ):
        payment.get_all(
            payer_type=Payment.PAYER_TYPE.user_group, payer_id=user_group.id
        )
        assert payment.status_code == 403
        assert 'You do not have permissions for this action' in payment.error

    def test_impossible_to_get_monthly_bills_for_disabled_billing(
            self, user_group: UserGroup
    ):
        user_group.monthly_bills.get_all()
        assert user_group.monthly_bills.status_code == 403
        assert 'You do not have permissions for this action' in user_group.monthly_bills.error

    def test_impossible_to_get_service_addons_stats_for_disabled_billing(
            self, user_group: UserGroup
    ):
        user_group.service_addons_stats.get()
        assert user_group.service_addons_stats.status_code == 403
        assert 'You do not have permissions for this action' in user_group.service_addons_stats.error

    def test_impossible_to_get_billing_report_for_disabled_billing(
            self, user_group: UserGroup
    ):
        user_group.report.get_all()
        assert user_group.report.status_code == 403
        assert 'You do not have permissions for this action' in user_group.report.error

    ############################################################################
    ############################################################################
    ############################################################################

    def test_enable_billing_again(self):
        if test.onapp_settings.disable_billing:
            test.onapp_settings.set(disable_billing=False)

        assert test.wait_for_action(
            lambda: test.onapp_settings.get() and test.onapp_settings.disable_billing is False,
            timeout=5
        )

    def test_get_user_group_details_for_enabled_billing(
            self, user_group: UserGroup
    ):
        assert user_group.get()

    @pytest.mark.parametrize('attribute', [
        "monthly_price",
        "paid_amount",
        "total_amount",
        "outstanding_amount",
        "discount_due_to_free",
        "total_amount_with_discount"
    ])
    def test_billing_details_should_be_displayed_on_user_group_page_for_enabled_billing(
            self, user_group, attribute
    ):
        # assert hasattr(user, attribute)
        assert attribute in user_group.response[user_group.root_tag]

    def test_possible_to_get_payments_for_enabled_billing(
            self, user_group, payment: Payment
    ):
        payment.get_all(
            payer_type=Payment.PAYER_TYPE.user_group, payer_id=user_group.id
        )
        assert payment.status_code == 200
        assert not payment.error

    def test_possible_to_get_monthly_bills_for_enabled_billing(
            self, user_group: UserGroup
    ):
        user_group.monthly_bills.get_all()
        assert user_group.monthly_bills.status_code == 200
        assert not user_group.monthly_bills.error

    def test_possible_to_get_service_addons_stats_for_enabled_billing(
            self, user_group: UserGroup
    ):
        user_group.service_addons_stats.get()
        assert user_group.service_addons_stats.status_code == 200
        assert not user_group.service_addons_stats.error

    def test_possible_to_get_billing_report_for_enabled_billing(
            self, user_group: UserGroup
    ):
        user_group.report.get_all()
        assert user_group.report.status_code == 200
        assert not user_group.report.error