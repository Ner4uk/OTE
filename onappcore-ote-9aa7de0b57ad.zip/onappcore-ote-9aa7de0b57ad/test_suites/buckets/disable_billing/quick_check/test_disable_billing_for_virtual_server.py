# ignore
__doc__ = """
Virtual Servers
Remove the billing details from the following:

VM Creation Wizard: remove the price calculators, 
and also remove the price per service add-on in case the 
service add-ons replace the recipes.

VM Overview - 
hide the billing stats tab

virtual_machines/identifier/vm_stats 
-hide at all the whole page from UI, leave API without prices 

service add-ons
/virtual_machines/identifier/service_addons
TODO - move this case to one of the service addons test

Edit disk virtual_machines/id/disks
Migration screen

!!!

Application servers/container servers/baremetal servers/smart servers/:
Remove the prices from all the same routes as in virtual servers menu

"""

import pytest

from onapp_helper import test
from onapp_helper.server import VirtualServer
from onapp_helper.stats.vm_stat import VmStat

COST_STR = '"cost":'


@pytest.fixture(scope='class', autouse=True)
def vm_stat(request):
    """
    Return vm_stat obj with statistics for the last hour
    :param request:
    :param user:
    :return:
    """
    # Looking for a virtual server with available statistics
    for s in VirtualServer().get_all():
        if VmStat(parent_obj=s).get_hourly_stat_for_the_last_hour():
            return VmStat(parent_obj=s)

    return None


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.disable_billing
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.sequentially
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.9, reason='Not supported')
@pytest.mark.verbose
class TestDisableBillingForVirtualServer:
    def teardown_class(self):
        test.onapp_settings.get()
        if test.onapp_settings.disable_billing:
            test.onapp_settings.set(disable_billing=False)

    def test_enable_billing(self):
        test.load_onapp_settings()
        if test.onapp_settings.disable_billing:
            test.onapp_settings.set(disable_billing=False)

        assert test.onapp_settings.disable_billing is False

    def test_virtual_server_costs_should_be_displayed(self, vm_stat: VmStat):
        assert vm_stat.get_hourly_stat_for_the_last_hour()
        assert COST_STR in vm_stat.raw_response

    def test_virtual_server_price_power_on_off_should_be_displayed(self, vm_stat: VmStat):
        assert vm_stat.parent_obj.get()
        assert "price_per_hour" in vm_stat.parent_obj.raw_response
        assert "price_per_hour_powered_off" in vm_stat.parent_obj.raw_response

    def test_disable_billing(self):
        if not test.onapp_settings.disable_billing:
            test.onapp_settings.set(disable_billing=True)

        assert test.onapp_settings.disable_billing is True

    def test_virtual_server_costs_should_not_be_displayed_for_disabled_billing(
            self, vm_stat: VmStat
    ):
        assert vm_stat.get_hourly_stat_for_the_last_hour()
        assert COST_STR not in vm_stat.raw_response

    def test_virtual_server_price_power_on_off_should_be_displayed_for_disabled_billing(
            self, vm_stat: VmStat
    ):
        assert vm_stat.parent_obj.get()
        assert "price_per_hour" not in vm_stat.parent_obj.raw_response
        assert "price_per_hour_powered_off" not in vm_stat.parent_obj.raw_response

    def test_enable_billing_again(self):
        if test.onapp_settings.disable_billing:
            test.onapp_settings.set(disable_billing=False)

        assert test.onapp_settings.disable_billing is False

    def test_virtual_server_costs_should_be_displayed_for_enabled_billing(
            self, vm_stat: VmStat
    ):
        assert vm_stat.get_hourly_stat_for_the_last_hour()
        assert COST_STR in vm_stat.raw_response

    def test_virtual_server_price_power_on_off_should_be_displayed_for_enabled_billing(
            self, vm_stat: VmStat
    ):
        assert vm_stat.parent_obj.get()
        assert "price_per_hour" in vm_stat.parent_obj.raw_response
        assert "price_per_hour_powered_off" in vm_stat.parent_obj.raw_response



        # "total_cost": 0.0,
        # "vm_resources_cost": 0.0,
        # "usage_cost": 0.0