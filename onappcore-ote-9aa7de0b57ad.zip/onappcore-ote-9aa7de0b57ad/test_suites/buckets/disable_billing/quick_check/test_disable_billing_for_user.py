# ignore
__doc__ = """
Users
User profile:
 hide all billing details (Monthly fee, payments, outstanding amount, 
   total cost, discount due to free, total cost with discount, monthly bills)
   
virtual server hourly statistics: 
  link should be removed, though API should be available and show the usage 
    stats. The costs shouldn't be displayed.
    
user statistics: 
  the link should be removed. 
  
The Prices should be removed
the Buckets section should be removed
The tab Buckets should direct to Access Control
User Details screen -  the same as User profile
"""

import pytest

from onapp_helper import test
from onapp_helper.user import User
from onapp_helper.stats.user_stats import UserStats
from onapp_helper.stats.vm_stat import VmStat

COST_STR = '"cost":'


@pytest.fixture(scope='class', autouse=True)
def user(request):
    user = None
    for u in User().get_all():
        if u.login != 'system_owner' \
                and not u.white_list.get_all() \
                and u.get_own_virtual_servers():
            user = u
            user.generate_api_key()
            # Login as vcloud user
            test.execute_as(user.email, user.api_key)
            break
    if not user:
        pytest.skip("User with virtual servers not found")

    return user


@pytest.fixture(scope='class', autouse=True)
def user_stat(request, user):
    return UserStats(parent_obj=user)


@pytest.fixture(scope='class', autouse=True)
def vm_stat(request, user):
    """
    Return vm_stat obj with statistics for the last hour
    :param request:
    :param user:
    :return:
    """
    return VmStat(parent_obj=user)


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.disable_billing
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.sequentially
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.9, reason='Not supported')
@pytest.mark.verbose
class TestDisableBillingForUser:
    __doc__ = """
    1. Before disabling billing check that stats available and costs are 
    present.
    2. Disable billing
    3. Check that stats available and costs were removed
    4. Enable billing and check that costs are present
    """

    def teardown_class(self):
        test.onapp_settings.get()
        if test.onapp_settings.disable_billing:
            test.onapp_settings.set(disable_billing=False)

    def test_enable_billing(self):
        test.load_onapp_settings()
        if test.onapp_settings.disable_billing:
            test.onapp_settings.set(disable_billing=False)

        assert test.wait_for_action(
            lambda: test.onapp_settings.get() and test.onapp_settings.disable_billing is False,
            timeout=5
        )

    def test_get_user_details_from_profile_page(self, user: User):
        """
            User profile:
            hide all billing details (Monthly fee, payments, outstanding amount,
            total cost, discount due to free, total cost with discount, monthly bills)
        """
        assert user.profile()

    @pytest.mark.parametrize('attribute', [
        'monthly_price',
        'payment_amount',
        'outstanding_amount',
        'total_amount',
        'discount_due_to_free',
        'total_amount_with_discount'
    ])
    def test_billing_details_should_be_displayed_on_user_profile_page(
            self, user, attribute
    ):
        # assert hasattr(user, attribute)
        assert attribute in user.response[user.root_tag]

    def test_get_user_details(self, user: User):
        """
            User profile:
            hide all billing details (Monthly fee, payments, outstanding amount,
            total cost, discount due to free, total cost with discount, monthly bills)
        """
        assert user.get()

    @pytest.mark.parametrize('attribute', [
        'monthly_price',
        'payment_amount',
        'outstanding_amount',
        'total_amount',
        'discount_due_to_free',
        'total_amount_with_discount'
    ])
    def test_billing_details_should_be_displayed_on_user_details_page(
            self, user, attribute
    ):
        # assert hasattr(user, attribute)
        assert attribute in user.response[user.root_tag]

    ############################################################################
    def test_get_virtual_server_hourly_stat(self, vm_stat: VmStat):
        """
            virtual server hourly statistics:
            link should be removed, though API should be available and show the usage
            stats. The costs shouldn't be displayed.
        """
        assert vm_stat.get_hourly_stat_for_the_last_hour()

    def test_virtual_server_costs_should_be_displayed(self, vm_stat: VmStat):
        assert COST_STR in vm_stat.raw_response

    ############################################################################
    def test_check_user_stat(self, user_stat: UserStats):
        """
            user statistics:
            the link should be removed.
        """
        assert user_stat.get_last_hour_stats()
    ############################################################################
    ############################################################################
    ############################################################################

    def test_disable_billing(self):
        if not test.onapp_settings.disable_billing:
            test.onapp_settings.set(disable_billing=True)

        assert test.wait_for_action(
            lambda: test.onapp_settings.get() and test.onapp_settings.disable_billing is True,
            timeout=5
        )

    def test_get_user_details_from_profile_page_for_disabled_billing(
            self, user: User
    ):
        """
            User profile:
            hide all billing details (Monthly fee, payments, outstanding amount,
            total cost, discount due to free, total cost with discount, monthly bills)
        """
        assert user.profile()

    @pytest.mark.parametrize('attribute', [
        'monthly_price',
        'payment_amount',
        'outstanding_amount',
        'total_amount',
        'discount_due_to_free',
        'total_amount_with_discount'
    ])
    def test_billing_details_should_not_be_displayed_on_user_profile_page_for_disabled_billing(
            self, user, attribute
    ):
        # assert not hasattr(user, attribute)
        assert attribute not in user.response[user.root_tag]

    def test_get_user_details_for_disabled_billing(self, user: User):
        """
            User profile:
            hide all billing details (Monthly fee, payments, outstanding amount,
            total cost, discount due to free, total cost with discount, monthly bills)
        """
        assert user.get()

    @pytest.mark.parametrize('attribute', [
        'monthly_price',
        'payment_amount',
        'outstanding_amount',
        'total_amount',
        'discount_due_to_free',
        'total_amount_with_discount'
    ])
    def test_billing_details_should_not_be_displayed_on_user_details_page_for_disabled_billing(
            self, user, attribute
    ):
        # assert not hasattr(user, attribute)
        assert attribute not in user.response[user.root_tag]

    ############################################################################
    def test_get_virtual_server_hourly_stat_for_disabled_billing(self, vm_stat: VmStat):
        """
            virtual server hourly statistics:
            link should be removed, though API should be available and show the usage
            stats. The costs shouldn't be displayed.
        """
        assert vm_stat.get_hourly_stat_for_the_last_hour()

    def test_virtual_server_costs_should_not_be_displayed_for_disabled_billing(
            self, vm_stat: VmStat
    ):
        assert COST_STR not in vm_stat.raw_response

    ############################################################################
    def test_check_user_stat_for_disabled_billing(self, user_stat: UserStats):
        """
            user statistics:
            the link should be removed.
        """
        assert not user_stat.get_last_hour_stats()
        assert 'You do not have permissions for this action' in user_stat.error
    ############################################################################
    ############################################################################
    ############################################################################

    def test_enable_billing_again(self):
        if test.onapp_settings.disable_billing:
            test.onapp_settings.set(disable_billing=False)

        assert test.wait_for_action(
            lambda: test.onapp_settings.get() and test.onapp_settings.disable_billing is False,
            timeout=5
        )

    def test_get_user_details_from_profile_page_for_enabled_billing(
            self, user: User
    ):
        """
            User profile:
            hide all billing details (Monthly fee, payments, outstanding amount,
            total cost, discount due to free, total cost with discount, monthly bills)
        """
        assert user.profile()

    @pytest.mark.parametrize('attribute', [
        'monthly_price',
        'payment_amount',
        'outstanding_amount',
        'total_amount',
        'discount_due_to_free',
        'total_amount_with_discount'
    ])
    def test_billing_details_should_be_displayed_on_user_profile_page_for_enabled_billing(
            self, user, attribute
    ):
        # assert hasattr(user, attribute)
        assert attribute in user.response[user.root_tag]

    def test_get_user_details_for_enabled_billing(self, user: User):
        """
            User profile:
            hide all billing details (Monthly fee, payments, outstanding amount,
            total cost, discount due to free, total cost with discount, monthly bills)
        """
        assert user.get()

    @pytest.mark.parametrize('attribute', [
        'monthly_price',
        'payment_amount',
        'outstanding_amount',
        'total_amount',
        'discount_due_to_free',
        'total_amount_with_discount'
    ])
    def test_billing_details_should_be_displayed_on_user_details_page_for_enabled_billing(
            self, user, attribute
    ):
        # assert hasattr(user, attribute)
        assert attribute in user.response[user.root_tag]

    ############################################################################
    def test_get_virtual_server_hourly_stat_for_enabled_billing(self, vm_stat: VmStat):
        """
            virtual server hourly statistics:
            link should be removed, though API should be available and show the usage
            stats. The costs shouldn't be displayed.
        """
        assert vm_stat.get_hourly_stat_for_the_last_hour()

    def test_virtual_server_costs_should_be_displayed_for_enabled_billing(self, vm_stat: VmStat):
        assert COST_STR in vm_stat.raw_response

    ############################################################################
    def test_check_user_stat_for_enabled_billing(self, user_stat: UserStats):
        """
            user statistics:
            the link should be removed.
        """
        assert user_stat.get_last_hour_stats()