# ignore
__doc__ = """
Resource Pools
At the Resource pools details page, the tab Billing Statistics 
should be removed. (+)
The API still should be available (+), though the costs should be removed (+).
"""

import pytest

from onapp_helper import test
from onapp_helper.vcloud.resource_pool import ResourcePool
from onapp_helper.stats.vdc_stat import VDCStat


@pytest.fixture(scope='class', autouse=True)
def resource_pool_stat(request):
    for rp in ResourcePool().get_all():
        stat = VDCStat(parent_obj=rp)
        if stat.get_hourly_stat_for_the_last_hour():
            return stat

    pytest.skip("Resource pool with available statistics not found")
    return None


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.disable_billing
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.sequentially
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.9, reason='Not supported')
@pytest.mark.verbose
class TestDisableBillingForResourcePool:
    __doc__ = """
    1. Before disabling billing check that stats available and costs are 
    present.
    2. Disable billing
    3. Check that stats available and costs were removed
    4. Enable billing and check that costs are present
    """

    def teardown_class(self):
        test.onapp_settings.get()
        if test.onapp_settings.disable_billing:
            test.onapp_settings.set(disable_billing=False)

    def test_enable_billing(self, resource_pool_stat):
        test.load_onapp_settings()
        if test.onapp_settings.disable_billing:
            test.onapp_settings.set(disable_billing=False)

        assert test.onapp_settings.disable_billing is False

    def test_get_statistics(self, resource_pool_stat):
        assert resource_pool_stat.get_hourly_stat_for_the_last_hour(), resource_pool_stat.error

    def test_that_total_cost_per_hour_is_present(self, resource_pool_stat):
        assert hasattr(resource_pool_stat.vdc_last_hour_stat, 'cost')

    def test_that_resource_elements_cost_is_present(self, resource_pool_stat):
        assert 'cost' in resource_pool_stat.vdc_last_hour_stat.resource_elements

    def test_that_data_store_cost_is_present(self, resource_pool_stat):
        if not resource_pool_stat.vdc_last_hour_stat.data_stores:
            pytest.skip('No disk statistics available')
        assert 'cost' in resource_pool_stat.vdc_last_hour_stat.data_stores[0]

    def test_that_network_interface_is_present(self, resource_pool_stat):
        if not resource_pool_stat.vdc_last_hour_stat.network_interfaces:
            pytest.skip('No network statistics available')
        assert 'cost' in resource_pool_stat.vdc_last_hour_stat.network_interfaces[0]

    def test_disable_billing(self, resource_pool_stat):
        if not test.onapp_settings.disable_billing:
            test.onapp_settings.set(disable_billing=True)

        assert test.onapp_settings.disable_billing is True

    def test_check_that_stats_available_for_disabled_billing(self, resource_pool_stat):
        assert resource_pool_stat.get_hourly_stat_for_the_last_hour(), self.stat.error

    def test_that_total_cost_per_hour_is_not_present_for_disabled_billing(self, resource_pool_stat):
        assert not hasattr(resource_pool_stat.vdc_last_hour_stat, 'cost')

    def test_that_resource_elements_cost_is_not_present_for_disabled_billing(self, resource_pool_stat):
        assert 'cost' not in resource_pool_stat.vdc_last_hour_stat.resource_elements

    def test_that_data_store_cost_is_not_present_for_disabled_billing(self, resource_pool_stat):
        if not resource_pool_stat.vdc_last_hour_stat.data_stores:
            pytest.skip('No disk statistics available')
        assert 'cost' not in resource_pool_stat.vdc_last_hour_stat.data_stores[0]

    def test_that_network_interface_is_not_present_for_disabled_billing(self, resource_pool_stat):
        if not resource_pool_stat.vdc_last_hour_stat.network_interfaces:
            pytest.skip('No network statistics available')
        assert 'cost' not in resource_pool_stat.vdc_last_hour_stat.network_interfaces[0]

    def test_enable_billing_again(self, resource_pool_stat):
        if test.onapp_settings.disable_billing:
            test.onapp_settings.set(disable_billing=False)

        assert test.onapp_settings.disable_billing is False

    def test_check_that_stats_available_for_enabled_billing(self, resource_pool_stat):
        assert resource_pool_stat.get_hourly_stat_for_the_last_hour(), self.stat.error

    def test_that_total_cost_per_hour_is_present_for_enabled_billing(self, resource_pool_stat):
        assert hasattr(resource_pool_stat.vdc_last_hour_stat, 'cost')

    def test_that_resource_elements_cost_is_present_for_enabled_billing(self, resource_pool_stat):
        assert 'cost' in resource_pool_stat.vdc_last_hour_stat.resource_elements

    def test_that_data_store_cost_is_present_for_enabled_billing(self, resource_pool_stat):
        if not resource_pool_stat.vdc_last_hour_stat.data_stores:
            pytest.skip('No disk statistics available')
        assert 'cost' in resource_pool_stat.vdc_last_hour_stat.data_stores[0]

    def test_that_network_interface_is_present_for_enabled_billing(self, resource_pool_stat):
        if not resource_pool_stat.vdc_last_hour_stat.network_interfaces:
            pytest.skip('No network statistics available')
        assert 'cost' in resource_pool_stat.vdc_last_hour_stat.network_interfaces[0]

    # def test_that_cost_has_not_been_changed(self, resource_pool_stat):
    #     if not self.total_cost_per_hour:
    #         pytest.skip("Can not find not empty cost")
    #
    #     cost_is_correct = False
    #     for stat in self.stat.get_all():
    #         if stat.cost == self.total_cost_per_hour:
    #             cost_is_correct = True
    #             break
    #
    #     assert cost_is_correct, 'Can not find origin cost'
