# ignore
__doc__ = """
Buckets
  At the Buckets menu, the Rate Card should be removed, only Access Control 
should be available. If the billing is enabled again, the rate cards should 
be empty!!! 
  Remove the Access Control tab at the Bucket details screen. The page should 
look like one screen. (+)
  The monthly price when adding a Bucket should be hidden
  The currency - (TBD,  If we just hide it, then what to do if we enable 
billing again)
"""

import pytest

from onapp_helper import test
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.bucket import access_controls as ac
from onapp_helper.bucket import rate_cards as rc
from onapp_helper.hypervisor_zone import HypervisorZone


prices = {
    'limit_free_cpu': 12,
    'limit_free_cpu_share': 23,
    'limit_free_cpu_units': 34,
    'limit_free_memory': 45,
    'price_on_cpu': 56,
    'price_off_cpu': 67,
    'price_on_cpu_share': 78,
    'price_off_cpu_share': 89,
    'price_on_memory': 90,
    'price_off_memory': 100,
    'price_on_cpu_units': 101,
    'price_off_cpu_units': 102
}

limits = {
    'limit_cpu': 12,
    'limit_cpu_share': 23,
    'limit_cpu_units': 34,
    'limit_default_cpu': 45,
    'limit_default_cpu_share': 56,
    'limit_min_cpu_priority': 67,
    'limit_min_cpu': 78,
    'limit_min_memory': 89,
    'limit_memory': 90
}


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.disable_billing
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.sequentially
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version < 5.9, reason='Not supported')
@pytest.mark.verbose
class TestDisableBillingForBucket:
    __doc__ = """
    1. Check bucket before disabling billing
    2. Disable billing
    3. Check bucket after disabling billing
    4. Check clone 
    5. Check create_rate_card option for new AC
    6. Check database
    7. Enable billing
    8. RC for all buckets should be empty.
    """

    def setup_class(self):
        test.load_onapp_settings()
        self.bucket = Bucket()
        self.bucket.label = self.__name__
        self.bucket.currency_code = "EUR"
        self.bucket.monthly_price = 90
        assert self.bucket.create(), self.bucket.error

        self.cloned_bucket = Bucket()
        self.bucket_with_disable_billing = Bucket()

        self.hvz_id = [hvz.id for hvz in HypervisorZone().get_all()][0]

        # AC
        self.hvz_ac = ac.ComputeZoneAC(
            parent_obj=self.bucket,
            target_id=self.hvz_id
        )
        for key, value in limits.items():
            self.hvz_ac.limits.__dict__[key] = value
        self.hvz_ac.create()

        # RC
        self.hvz_rc = rc.ComputeZoneRC(
            parent_obj=self.bucket,
            target_id=self.hvz_id
        )
        for key, value in prices.items():
            self.hvz_rc.prices.__dict__[key] = value
        self.hvz_rc.create()

        if test.onapp_settings.disable_billing:
            test.onapp_settings.set(disable_billing=False)

    def teardown_class(self):
        self.bucket.delete()
        self.cloned_bucket.delete()
        self.bucket_with_disable_billing.delete()
        test.onapp_settings.get()
        if test.onapp_settings.disable_billing:
            test.onapp_settings.set(disable_billing=False)

    def test_prices_before_disabling_billing(self):
        # Get HVZ prices for example

        self.hvz_rc.get()
        for key, value in self.hvz_rc.prices.__dict__.items():
            if 'price' in key:
                assert value
            elif 'free' in key:
                assert value

    def test_disable_billing(self):
        assert test.onapp_settings.set(disable_billing=True)

    def test_you_have_not_permissions_to_get_rate_cards(self):
        rc_base = rc.RateCardBase(parent_obj=self.bucket)
        assert not rc_base.get_all()
        assert 'You do not have permissions for this action' in rc_base.error

    def test_should_be_possible_to_clone_bucket(self):
        self.bucket.clone(self.cloned_bucket)
        assert self.cloned_bucket.id, self.cloned_bucket.error

    def test_you_have_not_permissions_to_get_cloned_bucket_rate_cards(self):
        rc_base = rc.RateCardBase(parent_obj=self.cloned_bucket)
        assert not rc_base.get_all()
        assert 'You do not have permissions for this action' in rc_base.error

    def test_create_bucket_when_billing_disable(self):
        self.bucket_with_disable_billing.label = f"{self.__class__.__name__}DB"
        self.bucket_with_disable_billing.monthly_price = 123
        assert self.bucket_with_disable_billing.create(), \
            self.bucket_with_disable_billing.error

    def test_monthly_price_for_bucket_with_disabled_billing(self):
        #  Expected result - ?
        assert self.bucket_with_disable_billing.monthly_price == 123

    def test_add_ac_with_create_rate_card_option(self):
        #  Expected result - ?
        hvz_ac = ac.ComputeZoneAC(
            parent_obj=self.bucket_with_disable_billing,
            target_id=self.hvz_id
        )
        hvz_ac.create_rate_card = True

        assert hvz_ac.create(), hvz_ac.error

    def test_database(self):
        buckets = [
            self.bucket, self.cloned_bucket, self.bucket_with_disable_billing
        ]
        for bucket in buckets:
            assert not test.cp.mysql_execute(
                f"SELECT * FROM billing_rate_cards_roots where bucket_id = {bucket.id};"
            )

    def test_enable_billing(self):
        test.onapp_settings.get()
        if test.onapp_settings.disable_billing:
            test.onapp_settings.set(disable_billing=False)

    def test_can_get_rate_cards_and_they_are_empty(self):
        buckets = [
            self.bucket, self.cloned_bucket, self.bucket_with_disable_billing
        ]
        for bucket in buckets:
            rc_base = rc.RateCardBase(parent_obj=bucket)
            rcs = rc_base.get_all()
            assert rc_base.status_code == 200
            assert rcs == []
