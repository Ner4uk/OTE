# https://onappdev.atlassian.net/browse/CORE-6395

__doc__ = """
1. Create User1 and User2
2. Create BP1 and BP2
3. Set for BP2 Backups - 0GB (User VS limit) and Backup Disk Size(Limits & Pricing for Backup server Zones) - 1GB
4. Enable normal backups.
5. Create under User1 a new VS, take one backup.
6. Try to change owner for VS with backups to User2.

There is no sense do it for templates...
"""

from onapp_helper.bucket import access_controls as ac
from onapp_helper.backup import Backup
from onapp_helper.user import User
from onapp_helper.bucket.bucket import Bucket
from onapp_helper import test
from onapp_helper.server import VirtualServer
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.change_owner
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version < 5.6,
    reason="Buckets is not supported yet..."
)
@pytest.mark.incremental
class TestChangingOwnerForBSZLimits:
    def setup_class(self):
        test.load_env()

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")
        if not test.env.backup_servers:
            pytest.skip("No available Backup Servers")

        try:
            self.bucket_1 = Bucket()
            self.bucket_1.label = "{0}1".format(self.__name__)
            assert self.bucket_1.create()

            ac.add_env_to_bucket(self.bucket_1)

            self.bucket_2 = Bucket()
            self.bucket_2.label = "{0}2".format(self.__name__)
            assert self.bucket_2.create()

            ac.add_env_to_bucket(self.bucket_2)

            # to prevent executing backups and templates on hypervisor
            self.backup_ac_1 = ac.BackupsAC(parent_obj=self.bucket_1)
            self.backup_ac_1.limits.limit = 0
            assert self.backup_ac_1.edit()

            self.template_ac_1 = ac.TemplatesAC(parent_obj=self.bucket_1)
            self.template_ac_1.limits.limit = 0
            assert self.template_ac_1.edit()

            self.storage_disk_size_ac_1 = ac.ComputeResourceStoringAC(
                parent_obj=self.bucket_1
            )
            self.storage_disk_size_ac_1.limits.limit = 0
            assert self.storage_disk_size_ac_1.edit()

            self.backup_ac_2 = ac.BackupsAC(parent_obj=self.bucket_2)
            self.backup_ac_2.limits.limit = 0
            assert self.backup_ac_2.edit()

            #self.bsz_br_1 = BSZBR(billing_plan=self.billing_plan_2, target_id=test.env.backup_servers.backup_server_zone_id)

            self.bsz_acs_2 = []
            bsz_ids = list(
                {bs.backup_server_group_id for bs in test.env.backup_servers}
            )
            # Remove another bsz from bucket
            for bsz_id in bsz_ids:
                bsz_ac = ac.BackupServerZoneAC(
                    parent_obj=self.bucket_2,
                    target_id=bsz_id
                )
                bsz_ac.get()
                self.bsz_acs_2.append(bsz_ac)

            self.user_1 = User(bucket=self.bucket_1)
            self.user_1.login = "{0}1".format(self.__name__).lower()
            self.user_1.password = test.generate_password()
            self.user_1.email = 'chown1@for.bsz'
            assert self.user_1.create()

            self.user_2 = User(bucket=self.bucket_2)
            self.user_2.login = "{0}2".format(self.__name__).lower()
            self.user_2.password = test.generate_password()
            self.user_2.email = 'chown2@for.bsz'
            assert self.user_2.create()

            test.execute_as(self.user_1.login, self.user_1.password)

            self.vs = VirtualServer()
            self.vs.label = self.__name__
            assert self.vs.create(), self.vs.error

            if test.onapp_settings.get().allow_incremental_backups:
                assert test.onapp_settings.set(allow_incremental_backups=False)

            self.backups = []
            self.templates = []
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        attributes = (
            'user_1',
            'bucket_1',
            'user_2',
            'bucket_2',
        )
        test.clean_up_resources(attributes, self)

    def test_should_be_impossible_to_change_owner_to_user2_with_backup_limit_exceeded(self):
        # Set limits
        for bsz_ac in self.bsz_acs_2:
            bsz_ac.limits.limit_backup = 0
            bsz_ac.edit()
        # Create a backup
        backup = Backup(self.vs)
        assert backup.create(), backup.error
        self.backups.append(backup)
        # Try to change owner, should be impossible
        assert not self.vs.change_owner(self.user_2.id, backups_action='move')

        # if possible do rollback
        for bsz_ac in self.bsz_acs_2:
            bsz_ac.limits.limit_backup = None
            bsz_ac.edit()
        test.update_object(self.vs)
        if self.vs.user_id == self.user_2.id:
            self.vs.change_owner(self.user_1.id, backups_action='move')

    # https://onappdev.atlassian.net/browse/CORE-6578  - actually error message works incorrect till 5.2
    def test_should_be_impossible_to_change_owner_to_user2_with_limit_backup_disk_size_exceeded(self):
        # Set limits
        for bsz_ac in self.bsz_acs_2:
            bsz_ac.limits.limit_backup_disk_size = 1
            bsz_ac.edit()
        # exceed_limit_backup_disk_size_for_user1
        while True:
            backup = Backup(self.vs)
            assert backup.create(), backup.error
            self.backups.append(backup)
            total_backups_size = self.vs.get_backups_size()
            print('Total backups size - {}'.format(total_backups_size))
            if total_backups_size > 1572864:
                break
        # Try to change owner, should be impossible
        assert not self.vs.change_owner(self.user_2.id, backups_action='move')
        assert "New owner has reached his backup creation limit or doesn't have enough disk space." in self.vs.error['base']

        # if possible do rollback
        for bsz_ac in self.bsz_acs_2:
            bsz_ac.limits.limit_backup_disk_size = None
            bsz_ac.edit()
        test.update_object(self.vs)
        if self.vs.user_id == self.user_2.id:
            self.vs.change_owner(self.user_1.id, backups_action='move')

    def test_should_be_possible_to_change_owner_to_user2_if_limit_has_not_been_exceeded_for_backups(self):
        # Set limits
        for bsz_ac in self.bsz_acs_2:
            bsz_ac.limits.limit_backup = len(self.backups)
            bsz_ac.limits.limit_backup_disk_size = 1
            bsz_ac.edit()
        # remove_last_backup_to_meet_backup_disk_size_limit(self):
        while self.vs.get_backups_size() > 1048576:
            backup = self.backups[-1]
            if backup.delete():
                self.backups.pop(-1)
        # Try to change owner, should be possible
        assert self.vs.change_owner(self.user_2.id, backups_action='move')
        test.update_object(self.vs)
        assert self.vs.user_id == self.user_2.id
        for backup in self.backups:
            test.update_object(backup)
            assert backup.user_id == self.user_2.id


