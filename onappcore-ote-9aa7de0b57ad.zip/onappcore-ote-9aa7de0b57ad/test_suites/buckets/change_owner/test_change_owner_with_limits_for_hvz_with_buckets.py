from onapp_helper.bucket import access_controls as ac
from onapp_helper.user import User
from onapp_helper.bucket.bucket import Bucket
from onapp_helper import test
from onapp_helper.server import VirtualServer
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.change_owner
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version < 5.6,
    reason="Buckets is not supported yet..."
)
@pytest.mark.incremental
class TestChangingOwnerForHVZLimits:
    def setup_class(self):
        test.load_env()

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        try:
            self.bucket_1 = Bucket()
            self.bucket_1.label = "{0}1".format(self.__name__)
            assert self.bucket_1.create()

            ac.add_env_to_bucket(self.bucket_1)

            self.bucket_2 = Bucket()
            self.bucket_2.label = "{0}2".format(self.__name__)
            assert self.bucket_2.create()

            ac.add_env_to_bucket(self.bucket_2)

            self.hvz_ac_2 = ac.ComputeZoneAC(
                parent_obj=self.bucket_2,
                target_id=test.env.hvz.id
            )

            self.user_1 = User(bucket=self.bucket_1)
            self.user_1.login = "{0}1".format(self.__name__).lower()
            self.user_1.password = test.generate_password()
            self.user_1.email = 'chown1@for.hvz'
            assert self.user_1.create()

            self.user_2 = User(bucket=self.bucket_2)
            self.user_2.login = "{0}2".format(self.__name__).lower()
            self.user_2.password = test.generate_password()
            self.user_2.email = 'chown2@for.hvz'
            assert self.user_2.create()

            test.execute_as(self.user_1.login, self.user_1.password)

            self.vs = VirtualServer()
            self.vs.label = self.__name__
            self.vs.cpus = 2
            assert self.vs.create(), self.vs.error
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        attributes = (
            'user_1',
            'bucket_1',
            'user_2',
            'bucket_2',
        )
        test.clean_up_resources(attributes, self)

    def test_cant_change_owner_with_cpu_limit_less_than_used(self):
        self.hvz_ac_2.limits.limit_min_cpu = 0
        self.hvz_ac_2.limits.limit_cpu = self.vs.cpus - 1
        assert self.hvz_ac_2.edit(), self.hvz_ac_2.error
        assert not self.vs.change_owner(self.user_2.id)
        assert f'CPUs must be less than or equal to ' \
               f'{self.hvz_ac_2.limits.limit_cpu} to meet billing ' \
               f'requirements' in self.vs.error['cpus']
        assert 'Failed to change owner' in self.vs.error['base']

    def test_can_change_owner_with_cpu_limit_eq_or_more_than_used(self):
        self.hvz_ac_2.limits.limit_cpu = self.vs.cpus
        self.hvz_ac_2.edit()
        assert self.vs.change_owner(self.user_2.id)
        # Change user back
        assert self.vs.change_owner(self.user_1.id)
        self.hvz_ac_2.reset()
        assert self.hvz_ac_2.edit(), self.hvz_ac_2.error

    def test_cant_change_owner_with_cpu_share_limit_less_than_used(self):
        self.hvz_ac_2.limits.limit_cpu_share = (self.vs.cpus * self.vs.cpu_shares) - 1
        self.hvz_ac_2.limits.limit_default_cpu_share = self.hvz_ac_2.limits.limit_cpu_share
        assert self.hvz_ac_2.edit(), self.hvz_ac_2.error
        assert not self.vs.change_owner(self.user_2.id)
        assert f'CPU shares must be less than or equal to ' \
               f'{self.hvz_ac_2.limits.limit_cpu_share} to meet billing ' \
               'requirements' in self.vs.error['cpu_shares']
        assert 'Failed to change owner' in self.vs.error['base']

    def test_can_change_owner_with_cpu_shares_limit_eq_or_more_than_used(self):
        self.hvz_ac_2.limits.limit_cpu_share = self.vs.cpus * self.vs.cpu_shares
        assert self.hvz_ac_2.edit(), self.hvz_ac_2.error
        assert self.vs.change_owner(self.user_2.id), self.vs.error
        # Change user back
        assert self.vs.change_owner(self.user_1.id), self.vs.error
        self.hvz_ac_2.reset()
        assert self.hvz_ac_2.edit(), self.hvz_ac_2.error

    def test_cant_change_owner_with_memory_limit_less_than_used(self):
        self.hvz_ac_2.limits.limit_memory = self.vs.memory - 1
        assert self.hvz_ac_2.edit(), self.hvz_ac_2.error
        assert not self.vs.change_owner(self.user_2.id)
        assert f'Memory must be less than or equal to ' \
               f'{self.hvz_ac_2.limits.limit_memory} MB to meet billing ' \
               f'requirements' in self.vs.error['memory']
        assert 'Failed to change owner' in self.vs.error['base']

    def test_can_change_owner_with_memory_limit_eq_or_more_than_used(self):
        self.hvz_ac_2.limits.limit_memory = self.vs.memory
        assert self.hvz_ac_2.edit(), self.hvz_ac_2.error
        assert self.vs.change_owner(self.user_2.id), self.vs.error
        # Change user back
        assert self.vs.change_owner(self.user_1.id)
        self.hvz_ac_2.reset()
        assert self.hvz_ac_2.edit(), self.hvz_ac_2.error

