
__doc__ = """ Test user vs limits excluding:
    Auto scaling - zabix server should be available;
    Customer network limits - vmware should be available;
    ISO limits, Acceleration, Application Server, DRaaS, Templates (no reason for templates)"""

from onapp_helper.bucket import access_controls as ac
from onapp_helper.backup import Backup
from onapp_helper.user import User
from onapp_helper.bucket.bucket import Bucket
from onapp_helper import test
from onapp_helper.server import VirtualServer
import pytest
from time import sleep


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.change_owner
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version < 5.6,
    reason="Buckets is not supported yet..."
)
@pytest.mark.incremental
class TestChangingOwnerForUserVSLimits:
    def setup_class(self):
        test.load_env()

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        try:
            self.bucket_1 = Bucket()
            self.bucket_1.label = "{0}1".format(self.__name__)
            assert self.bucket_1.create()

            ac.add_all_resources_to_bucket(self.bucket_1)

            self.bucket_2 = Bucket()
            self.bucket_2.label = "{0}2".format(self.__name__)
            assert self.bucket_2.create()

            ac.add_all_resources_to_bucket(self.bucket_2)

            #self.backup_br_1 = BackupBR(self.billing_plan_1)
            #self.backup_br_1.own_limits.limit = 0
            #self.backup_br_1.create()

            self.backup_ac_2 = ac.BackupsAC(parent_obj=self.bucket_2)
            self.backup_ac_2.limits.limit = 0
            assert self.backup_ac_2.edit()

            self.template_ac_2 = ac.TemplatesAC(parent_obj=self.bucket_2)
            self.template_ac_2.limits.limit = 0
            assert self.template_ac_2.edit()

            self.storage_disk_size_ac_2 = ac.ComputeResourceStoringAC(
                parent_obj=self.bucket_2
            )
            # self.storage_disk_size_br_2.own_limits.limit = 0
            # assert self.storage_disk_size_ac_2.edit()

            self.vm_limit_ac_2 = ac.VirtualServerAC(
                parent_obj=self.bucket_2
            )
            # assert self.vm_limit_ac_2.edit()

            # Deny ability to create backups on BS
            for bs in test.env.backup_servers:
                bsz_ac = ac.BackupServerZoneAC(
                    parent_obj=self.bucket_1,
                    target_id=bs.backup_server_group_id
                )
                if bsz_ac.get():
                    bsz_ac.delete()

            self.user_1 = User(bucket=self.bucket_1)
            self.user_1.login = "{0}1".format(self.__name__).lower()
            self.user_1.password = test.generate_password()
            self.user_1.email = 'chown1@for.uservslimits'
            assert self.user_1.create()

            self.user_2 = User(bucket=self.bucket_2)
            self.user_2.login = "{0}2".format(self.__name__).lower()
            self.user_2.password = test.generate_password()
            self.user_2.email = 'chown2@for.uservslimits'
            assert self.user_2.create()

            test.execute_as(self.user_1.login, self.user_1.password)

            self.vs = VirtualServer()
            self.vs.label = self.__name__
            assert self.vs.create(), self.vs.error
            if self.vs.locked:
                assert self.vs.unlock()

            if test.onapp_settings.get().allow_incremental_backups:
                assert test.onapp_settings.set(allow_incremental_backups=False)

            self.backups = []
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        attributes = (
            'user_1',
            'bucket_1',
            'user_2',
            'bucket_2',
        )
        test.clean_up_resources(attributes, self)

    def test_should_be_impossible_change_owner_to_0_vm_limit(self):
        self.vm_limit_ac_2.limits.limit = 0
        self.vm_limit_ac_2.edit()
        assert not self.vs.change_owner(self.user_2.id)
        assert "Virtual server limit exceeded" in self.vs.error['base']

    def test_should_be_possible_change_owner_to_1_vm_limit(self):
        self.vm_limit_ac_2.limits.limit = 1
        self.vm_limit_ac_2.edit()
        assert self.vs.change_owner(self.user_2.id)
        # change owner back
        sleep(5)
        assert self.vs.change_owner(self.user_1.id)

    def test_should_be_impossible_change_owner_to_0_backups_with_available_1(self):
        self.backup_ac_2.limits.limit = 0
        self.backup_ac_2.edit()
        backup = Backup(self.vs)
        assert backup.create()
        self.backups.append(backup)
        assert not self.vs.change_owner(self.user_2.id, backups_action='move')

    def test_should_be_possible_change_owner_to_1_backups_with_available_1(self):
        self.backup_ac_2.limits.limit = 1
        assert self.backup_ac_2.edit()
        assert self.vs.change_owner(self.user_2.id, backups_action='move')
        # change owner back
        sleep(5)
        assert self.vs.change_owner(self.user_1.id, backups_action='move')
        # reset backup limits
        self.backup_ac_2.limits.limit = None
        self.backup_ac_2.edit()

    def test_should_be_impossible_change_owner_to_1_storage_disk_size_br_2_with_exceeding_1(self):
        self.storage_disk_size_ac_2.limits.limit = 0
        self.storage_disk_size_ac_2.edit()
        # increase storage disk size
        while True:
            backup = Backup(self.vs)
            backup.create()
            self.backups.append(backup)
            total_vs_storage_disk_size = self.vs.get_backups_size()
            if total_vs_storage_disk_size > (1 * 1048576):
                break
        assert not self.vs.change_owner(self.user_2.id, backups_action='move')

    def test_should_be_possible_change_owner_to_2_storage_disk_size_br_2_with_available_1(self):
        self.storage_disk_size_ac_2.limits.limit = 2
        self.storage_disk_size_ac_2.edit()
        assert self.vs.change_owner(self.user_2.id, backups_action='move')
        # change owner back
        sleep(5)
        assert self.vs.change_owner(self.user_1.id, backups_action='move')
