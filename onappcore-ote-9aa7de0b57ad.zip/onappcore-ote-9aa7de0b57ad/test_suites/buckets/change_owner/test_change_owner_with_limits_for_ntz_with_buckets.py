# https://onappdev.atlassian.net/browse/CORE-1790

__doc__ = """
1. Create bucket1 and set all resources as unlimited.
2. Create User1 with bucket1
3. Create bucket2 with limit for ip address 2
4. Create User2 with bucket2
5. Under User1 create a new server.
6. Add one more IP address.
7. Try to change owner for the server from User1 to User2 - Success. Change owner back - Success.
8. Set limit for ip address 0 on bucket2.
9. Try to change owner for the server from User1 to User2 - Unsuccessful.
10. Delete Network Zone which server is using from bucket2
11. Try to change owner for the server from User1 to User2 - Unsuccessful.

There is no sense do it for templates...
"""

import pytest

from onapp_helper import test
from onapp_helper.bucket import access_controls as ac
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.server import VirtualServer
from onapp_helper.user import User


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.change_owner
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version < 6.0,
    reason="Fix available since 6.0..."
)
@pytest.mark.skipif(
    test.cp_version < 5.6,
    reason="Buckets is not supported yet..."
)
class TestChangingOwnerForNTZLimits:
    def setup_class(self):
        test.load_env()

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        try:
            self.bucket_1 = Bucket()
            self.bucket_1.label = "{0}1".format(self.__name__)
            assert self.bucket_1.create()

            ac.add_env_to_bucket(self.bucket_1)

            self.bucket_2 = Bucket()
            self.bucket_2.label = "{0}2".format(self.__name__)
            assert self.bucket_2.create()

            ac.add_env_to_bucket(self.bucket_2)

            self.netz_ac_2 = ac.NetworkZoneAC(
                parent_obj=self.bucket_2,
                target_id=test.env.netz.id
            )
            self.netz_ac_2.get()
            self.netz_ac_2.limits.limit_ip = 2
            self.netz_ac_2.limits.limit_rate = 90
            assert self.netz_ac_2.edit(), self.netz_ac_2.error

            self.user_1 = User(bucket=self.bucket_1)
            self.user_1.login = "{0}1".format(self.__name__).lower()
            self.user_1.password = test.generate_password()
            self.user_1.email = 'chown1@for.bsz'
            assert self.user_1.create()

            self.user_2 = User(bucket=self.bucket_2)
            self.user_2.login = "{0}2".format(self.__name__).lower()
            self.user_2.password = test.generate_password()
            self.user_2.email = 'chown2@for.bsz'
            assert self.user_2.create()

            test.execute_as(self.user_1.login, self.user_1.password)

            self.vs = VirtualServer()
            self.vs.label = self.__name__
            self.vs.rate_limit = 90
            assert self.vs.create(), self.vs.error
            assert self.vs.port_speed() == 90

            test.execute_as(test.login, test.password)

        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        attributes = (
            'user_1',
            'bucket_1',
            'user_2',
            'bucket_2',
        )
        test.clean_up_resources(attributes, self)

    def test_should_be_possible_to_change_vs_owner_to_user2_with_ip_address_limit_2_and_rate_limit_90(self):
        if self.vs.change_owner(self.user_2.id):
            assert self.vs.get(), self.vs.error
            assert self.vs.user_id == self.user_2.id

            # Change user back
            assert self.vs.change_owner(self.user_1.id), self.vs.error
            assert self.vs.get(), self.vs.error
            assert self.vs.user_id == self.user_1.id
        else:
            assert False, self.vs.error

    def test_should_be_impossible_to_change_vs_owner_to_user2_with_ip_address_limit_0(self):
        self.reset_limits()

        self.netz_ac_2.limits.limit_ip = 0
        assert self.netz_ac_2.edit(), self.netz_ac_2.error

        if not self.vs.change_owner(self.user_2.id):
            # check error message
            assert "Network interfaces can't be used, because you have " \
                   "reached your IP address limit" in self.vs.error['base']
            assert "Failed to change owner" in self.vs.error['base']
            assert self.vs.get(), self.vs.error
            assert self.vs.user_id != self.user_2.id
        else:
            assert self.vs.change_owner(self.user_1.id), self.vs.error
            assert self.vs.get(), self.vs.error
            assert self.vs.user_id == self.user_1.id
            assert False, 'User has been changed by unknown reason'

    def test_should_be_impossible_to_change_vs_owner_to_user2_with_rate_limit_89(self):
        self.reset_limits()

        self.netz_ac_2.limits.limit_rate = 89
        assert self.netz_ac_2.edit(), self.netz_ac_2.error

        if not self.vs.change_owner(self.user_2.id):
            # check error message
            assert "Network interfaces can't be used, because you have " \
                   "reached your port speed limit" in self.vs.error['base']
            assert "Failed to change owner" in self.vs.error['base']
            assert self.vs.get(), self.vs.error
            assert self.vs.user_id != self.user_2.id
        else:
            assert self.vs.change_owner(self.user_1.id), self.vs.error
            assert self.vs.get(), self.vs.error
            assert self.vs.user_id == self.user_1.id
            assert False, 'User has been changed by unknown reason'

    def test_should_be_impossible_to_change_vs_owner_to_user2_if_resource_not_allowed_by_bucket(self):
        assert self.netz_ac_2.delete(), self.netz_ac_2.error
        if not self.vs.change_owner(self.user_2.id):
            # check error message
            assert "Network interfaces can't be used, because you have " \
                   "reached your port speed limit" in self.vs.error['base']
            assert "Network interfaces can't be used, because you have " \
                   "reached your IP address limit" in self.vs.error['base']
            assert "Failed to change owner" in self.vs.error['base']

            assert self.vs.get(), self.vs.error
            assert self.vs.user_id != self.user_2.id
        else:
            assert self.vs.change_owner(self.user_1.id), self.vs.error
            assert self.vs.get(), self.vs.error
            assert self.vs.user_id == self.user_1.id
            assert False, 'User has been changed by unknown reason'

    def reset_limits(self):
        self.netz_ac_2.limits.limit_ip = None
        self.netz_ac_2.limits.limit_rate = None
        assert self.netz_ac_2.edit(), self.netz_ac_2.error