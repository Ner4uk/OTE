from onapp_helper.bucket import access_controls as ac
from onapp_helper.instance_package import InstancePackage
from onapp_helper.user import User
from onapp_helper.role import Role
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.hypervisor import Hypervisor
from onapp_helper.data_store import DataStore
from onapp_helper.networks import Network
from onapp_helper.hypervisor_zone import HypervisorZone
from onapp_helper.network_zone import NetworkZone
from onapp_helper.data_store_zone import DataStoreZone
from onapp_helper.permissions import Permissions
from onapp_helper import test
from onapp_helper.server import VirtualServer
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.bucket
@pytest.mark.change_owner
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version < 5.6,
    reason="Buckets is not supported yet..."
)
@pytest.mark.incremental
@pytest.mark.verbose
class TestChangingOwnerForInstancePackageVS():
    def setup_class(self):
        test.load_env()

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        try:
            self.bucket = Bucket()
            self.bucket.label = self.__name__
            assert self.bucket.create()

            ac.add_all_resources_to_bucket(self.bucket)

            self.vs = VirtualServer()
            self.vs.set_template()

            self.instance_package = InstancePackage()
            self.instance_package.label = self.__name__
            self.instance_package.cpus = 1
            self.instance_package.memory = self.vs.template.min_memory_size
            self.instance_package.disk_size = self.vs.template.min_disk_size + 1
            self.instance_package.bandwidth = 0
            assert self.instance_package.create()

            self.incorrect_instance_package = InstancePackage()
            self.incorrect_instance_package.label = "incorrect_instance_package"
            self.incorrect_instance_package.cpus = 1
            self.incorrect_instance_package.memory = self.vs.template.min_memory_size
            self.incorrect_instance_package.disk_size = self.vs.template.min_disk_size + 1
            self.incorrect_instance_package.bandwidth = 0
            assert self.incorrect_instance_package.create()

            self.instance_package_ac = ac.InstancePackageAC(
                parent_obj=self.bucket,
                target_id=self.instance_package.id
            )
            if not self.instance_package_ac.get():
                assert self.instance_package_ac.create(), self.instance_package_ac.error

            self.user_role = Role(id=2).clone()
            self.permissions = Permissions()
            self.permissions.load(
                'virtual_machines.select_instance_package_on_creation'
            )
            self.user_role.permission_ids.append(
                self.permissions.virtual_machines_select_instance_package_on_creation.id
            )
            self.user_role.edit()

            self.user = User(bucket=self.bucket)
            self.user.login = self.__name__.lower()
            self.user.password = test.generate_password()
            self.user.email = 'chown1@for.instancepackagevs'
            self.user.role_ids = [self.user_role.id]
            assert self.user.create()

            admin = [
                user for user in User().get_all()
                if user.login == test.login
                ][0]
            admin_bucket = Bucket(id=admin.bucket_id)
            self.admin_instance_package_ac = ac.InstancePackageAC(
                parent_obj=admin_bucket,
                target_id=self.instance_package.id
            )
            if not self.admin_instance_package_ac.get():
                self.admin_instance_package_ac.create()

            ac.add_all_resources_to_bucket(admin_bucket)

            self.vs.label = self.__name__
            self.vs.instance_package_id = self.instance_package.id
            assert self.vs.create(), self.vs.error

            self.hvz_id = Hypervisor(id=self.vs.hypervisor_id).hypervisor_group_id
            network_id = self.vs.ip_address_join.get_primary().ip_address['network_id']
            self.ntz_id = Network(id=network_id).network_group_id
            self.dsz_id = DataStore(id=self.vs.get_primary_disk().data_store_id).data_store_group_id

            self.wrong_hvz_id = [
                hvz.id for hvz in HypervisorZone().get_all()
                if hvz.id != self.hvz_id and hvz.server_type == 'virtual'
                ][0]
            self.wrong_ntz_id = [
                ntz.id for ntz in NetworkZone().get_all()
                if ntz.id != self.ntz_id and ntz.server_type == 'virtual'
                ][0]
            self.wrong_dsz_id = [
                dsz.id for dsz in DataStoreZone().get_all()
                if dsz.id != self.dsz_id and dsz.server_type == 'virtual'
                ][0]

        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_method(self, test_method):
        self.instance_package_ac.reset()
        self.instance_package_ac.edit()

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        attributes = (
            'vs',
            'admin_instance_package_ac',
            'user',
            'user_role',
            'bucket',
            'instance_package',
            'incorrect_instance_package'
        )
        test.clean_up_resources(attributes, self)

    def test_vs_owner_should_not_be_changed_if_incorrect_HVZ_set_for_Instance_Package_limits(self):
        self.instance_package_ac.preferences.hypervisor_group_ids = [self.wrong_hvz_id]
        self.instance_package_ac.edit()
        assert not self.vs.change_owner(self.user.id)
        assert self.vs.status_code == 422
        assert "Failed to change owner" in self.vs.error['base']
        assert "Compute Zone is unavailable in the instance package according to your bucket settings" in \
                   self.vs.error['instance_package_id']

    def test_vs_owner_should_not_be_changed_if_incorrect_NTZ_set_for_Instance_Package_limits(self):
        self.instance_package_ac.preferences.network_group_ids = [self.wrong_ntz_id]
        assert self.instance_package_ac.edit()
        assert not self.vs.change_owner(self.user.id)
        assert "Failed to change owner" in self.vs.error['base']
        assert "Network Zone is unavailable in the instance package according to your bucket settings" in \
                   self.vs.error['instance_package_id']

    def test_vs_owner_should_not_be_changed_if_incorrect_DSZ_set_for_Instance_Package_limits(self):
        self.instance_package_ac.preferences.data_store_group_ids = [self.wrong_dsz_id]
        self.instance_package_ac.edit()
        assert not self.vs.change_owner(self.user.id)
        assert self.vs.status_code == 422
        assert "Failed to change owner" in self.vs.error['base']
        assert "Data Store Zone is unavailable in the instance package according to your bucket settings" in \
                   self.vs.error['instance_package_id']

    def test_vs_owner_should_not_be_changed_if_all_zones_are_set_incorrectly_for_Instance_Package_limits(self):
        self.instance_package_ac.preferences.hypervisor_group_ids = [self.wrong_hvz_id]
        self.instance_package_ac.preferences.data_store_group_ids = [self.wrong_dsz_id]
        self.instance_package_ac.preferences.network_group_ids = [self.wrong_ntz_id]
        self.instance_package_ac.edit()
        assert not self.vs.change_owner(self.user.id)
        assert self.vs.status_code == 422
        assert "Failed to change owner" in self.vs.error['base']

    def test_vs_owner_should_not_be_changed_if_cpu_share_set_less_than_100_for_HVZ(self):
        self.users_hvz_ac = ac.ComputeZoneAC(
            parent_obj=self.bucket,
            target_id=self.hvz_id
        )
        assert self.users_hvz_ac.get(), self.users_hvz_ac.error
        self.users_hvz_ac.limits.limit_cpu_share = 99
        self.users_hvz_ac.limits.limit_default_cpu_share = 50
        assert self.users_hvz_ac.edit(), self.users_hvz_ac.error
        assert not self.vs.change_owner(self.user.id)
        assert self.vs.status_code == 422
        if test.cp_version >= 6.1:
            msg = 'The remaining CPU shares amount is not sufficient to create ' \
                  'a VS. At least 100% are required to be available taking ' \
                  'into account the usage of other VSs.'
        else:
            msg = "It is required to have at least 100% CPU shares in the bucket"
        assert msg in self.vs.error['cpu_shares']
        assert "Failed to change owner" in self.vs.error['base']
        self.users_hvz_ac.reset()
        self.users_hvz_ac.edit()

    def test_vs_owner_should_not_be_changed_if_incorrect_HVZ(self):
        self.users_hvz_ac = ac.ComputeZoneAC(
            parent_obj=self.bucket,
            target_id=self.hvz_id
        )
        self.users_hvz_ac.delete()
        assert not self.vs.change_owner(self.user.id)
        assert self.vs.status_code == 422
        assert "Compute Zone is unavailable in the instance package according to your bucket settings" in \
               self.vs.error['instance_package_id']
        assert "Failed to change owner" in self.vs.error['base']
        self.users_hvz_ac.create()

    def test_vs_owner_should_not_be_changed_if_incorrect_DSZ(self):
        self.users_dsz_ac = ac.DataStoreZoneAC(
            parent_obj=self.bucket,
            target_id=self.dsz_id
        )
        self.users_dsz_ac.delete()
        assert not self.vs.change_owner(self.user.id)
        assert self.vs.status_code == 422
        assert "Data Store Zone is unavailable in the instance package according to your bucket settings" in \
               self.vs.error['instance_package_id']
        assert "Failed to change owner" in self.vs.error['base']
        self.users_dsz_ac.create()

    def test_vs_owner_should_not_be_changed_if_incorrect_NTZ(self):
        self.users_ntz_ac = ac.NetworkZoneAC(
            parent_obj=self.bucket,
            target_id=self.ntz_id
        )
        self.users_ntz_ac.delete()
        assert not self.vs.change_owner(self.user.id)
        assert self.vs.status_code == 422
        assert "Network Zone is unavailable in the instance package according to your bucket settings" in self.vs.error[
            'instance_package_id']
        assert "Failed to change owner" in self.vs.error['base']
        self.users_ntz_ac.create()

    def test_vs_owner_should_not_be_changed_if_user_has_no_instance_packages_in_bucket(self):
        self.instance_package_ac.delete()
        assert not self.vs.change_owner(self.user.id)
        assert self.vs.status_code == 422
        assert "Failed to change owner" in self.vs.error['base']
        assert "InstancePackage#{} is not added to the bucket".format(self.instance_package.id) in self.vs.error['base']

    def test_vs_owner_should_not_be_changed_if_user_has_select_instance_package_on_creation_permission_disabled(self):
        self.user_role.permission_ids.remove(
            self.permissions.virtual_machines_select_instance_package_on_creation.id
        )
        self.user_role.edit()
        assert not self.vs.change_owner(self.user.id)
        assert self.vs.status_code == 422
        assert "InstancePackage#{} is not added to the bucket".format(self.instance_package.id) in self.vs.error['base']
        assert "Failed to change owner" in self.vs.error['base']

    def test_vs_owner_should_not_be_changed_if_user_has_select_instance_package_on_creation_permission_disabled_and_correct_instance_package(self):
        self.instance_package_ac = ac.InstancePackageAC(
            parent_obj=self.bucket,
            target_id=self.instance_package.id
        )
        self.instance_package_ac.create()
        assert not self.vs.change_owner(self.user.id)
        assert self.vs.status_code == 422
        assert "User is not permitted to own Virtual Servers with Instance Packages" in self.vs.error['base']
        self.instance_package_ac.delete()

    def test_vs_owner_should_not_be_changed_if_user_has_select_instance_package_on_creation_permission_disabled_and_incorrect_instance_package(self):
        self.incorrect_instance_package_ac = ac.InstancePackageAC(
            parent_obj=self.bucket,
            target_id=self.incorrect_instance_package.id
        )
        self.incorrect_instance_package_ac.create()
        assert not self.vs.change_owner(self.user.id)
        assert self.vs.status_code == 422
        assert "InstancePackage#{} is not added to the bucket".format(self.instance_package.id) in self.vs.error['base']
        assert "Failed to change owner" in self.vs.error['base']

    def test_vs_owner_should_not_be_changed_if_user_has_incorrect_instance_package_in_bucket(self):
        self.user_role.permission_ids.append(
            self.permissions.virtual_machines_select_instance_package_on_creation.id
        )
        self.user_role.edit()
        assert not self.vs.change_owner(self.user.id)
        assert self.vs.status_code == 422
        assert "Failed to change owner" in self.vs.error['base']
        assert "InstancePackage#{} is not added to the bucket".format(self.instance_package.id) in self.vs.error['base']

    def test_vs_owner_should_be_changed_if_user_has_correct_instance_package_in_bucket_and_appropriate_permission_enabled(self):
        self.instance_package_ac.create()
        assert self.vs.change_owner(self.user.id)
        assert self.vs.status_code == 201
        assert self.vs.user_id == self.user.id
