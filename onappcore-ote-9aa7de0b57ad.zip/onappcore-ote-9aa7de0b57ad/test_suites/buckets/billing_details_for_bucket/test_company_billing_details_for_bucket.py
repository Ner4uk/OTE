# ignore
__author__ = "Zhuk"

from onapp_helper import test
from onapp_helper.user_group import UserGroup
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.company_plan import CompanyPlan
# from onapp_helper.company_payment import CompanyPayment
from onapp_helper.payment import Payment
from onapp_helper.hypervisor import Hypervisor
import time
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.bucket
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.verbose
@pytest.mark.skipif(test.cp_version < 5.7, reason="Not implemented")
class TestCompanyBillingDetailsForBucket:
    def setup_class(self):
        try:
            self.bucket = Bucket()
            self.bucket.label = self.__name__
            assert self.bucket.create(), self.bucket.error

            self.company_plan = CompanyPlan()
            self.company_plan.label = self.__name__
            assert self.company_plan.create(), self.company_plan.error

            self.usergroup = UserGroup()
            self.usergroup.label = self.__name__
            self.usergroup.assign_to_vcloud = True
            self.usergroup.hypervisor_id = Hypervisor().get_vcloud()[0].id
            self.usergroup.company_billing_plan_id = self.company_plan.id
            self.usergroup.billing_plan_ids = [self.bucket.id]
            assert self.usergroup.create(), self.usergroup.error

        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

        self.company_payment = Payment()

    def teardown_class(self):
        attributes = (
            'usergroup',
            'bucket',
            'company_plan',
            'company_payment'
        )
        test.clean_up_resources(attributes, self)

    def test_check_total_amount_into_billing_details_of_new_company(self):
        assert 0 == self.usergroup.total_amount

    def test_check_paid_amount_into_billing_details_of_new_company(self):
        assert 0 == self.usergroup.paid_amount

    def test_check_outstanding_amount_into_billing_details_of_new_company(self):
        assert 0 == self.usergroup.outstanding_amount

    def test_create_new_company_payment(self):
        self.company_payment.payer_id = self.usergroup.id
        self.company_payment.invoice_number = '09022017/02'
        self.company_payment.amount = 100.00
        assert self.company_payment.create(), self.company_payment.error
        assert test.update_object(self.usergroup), self.usergroup.error

    def test_check_if_company_payment_shown_in_company_billing_details(self):
        assert 100.00 == self.usergroup.paid_amount

    def test_check_outstanding_amount_in_company_billing_details_after_payment(self):
        assert -100.00 == self.usergroup.outstanding_amount

    def test_check_total_amount_in_company_billing_details_after_payment(self):
        assert 0 == self.usergroup.total_amount

    def test_set_monthly_price_to_company_billing_plan(self):
        self.company_plan.monthly_price = 20.00
        assert self.company_plan.edit(), self.company_plan.error
        assert test.update_object(self.usergroup), self.usergroup.error

    def test_check_monthly_fee_in_company_billing_details_after_setting_monthly_price_to_company_billing_plan(self):
        assert 20.00 == self.company_plan.monthly_price

    def test_wait_for_company_billing_statistics(self):
        test.wait_for_action(
            lambda : test.update_object(self.usergroup) and
                     self.usergroup.total_amount,
            timeout=7200, step=60
        )
        assert self.usergroup.total_amount, self.usergroup.error

        # attempts = 120
        # while not self.usergroup.total_amount:
        #     if not attempts:
        #         test.log.error("Test is FAILED! Time is out. (2 hours)")
        #         break
        #     time.sleep(60)
        #     attempts -= 1
        #     assert test.update_object(self.usergroup), self.usergroup.error

    def test_check_total_amount_in_company_billing_details_after_setting_monthly_price_to_company_billing_plan(self):
        assert 20.00 == self.usergroup.total_amount

    def test_check_outstanding_amount_in_company_billing_details_after_setting_monthly_price_to_company_billing_plan(self):
        assert self.usergroup.total_amount - self.usergroup.paid_amount == self.usergroup.outstanding_amount
