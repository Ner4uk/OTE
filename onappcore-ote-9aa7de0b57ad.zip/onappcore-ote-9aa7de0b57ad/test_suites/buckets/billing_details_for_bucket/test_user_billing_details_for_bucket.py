__author__ = "Zhuk"

from onapp_helper import test
from onapp_helper.user import User
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.payment import Payment
from onapp_helper.stats.user_stats import UserStats
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.bucket
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.verbose
@pytest.mark.skipif(test.cp_version < 5.7, reason="Not implemented")
class TestUserBillingDetailsForBucket:
    def setup_class(self):
        try:
            self.bucket = Bucket()
            self.bucket.label = self.__name__
            assert self.bucket.create(), self.bucket.error

            self.user = User(bucket=self.bucket)
            self.user.login = self.__name__
            self.user.password = test.generate_password()
            self.user.email = self.user.login + "@autotest.net"
            assert self.user.create(), self.user.error

        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

        self.payment = Payment()

    def teardown_class(self):
        attributes = (
            'user',
            'bucket',
            'payment'
        )
        test.clean_up_resources(attributes, self)

    def test_check_total_amount_into_billing_details_of_new_user(self):
        assert 0 == self.user.total_amount

    def test_check_payment_amount_into_billing_details_of_new_user(self):
        assert 0 == self.user.payment_amount

    def test_check_outstanding_amount_into_billing_details_of_new_user(self):
        assert 0 == self.user.outstanding_amount

    def test_create_user_payment(self):
        self.payment.payer_id = self.user.id
        self.payment.invoice_number = '09022017/01'
        self.payment.amount = 100.0
        self.payment.payer_type = Payment.PAYER_TYPE.user
        assert self.payment.create(), self.payment.error
        assert test.update_object(self.user), self.user.error

    def test_check_if_user_payment_shown_in_user_account_details(self):
        assert 100.0 == self.user.payment_amount

    def test_check_outstanding_amount_in_user_account_details_after_payment(self):
        assert -100.0 == self.user.outstanding_amount

    def test_check_total_amount_in_user_account_details_aster_payment(self):
        assert 0 == self.user.total_amount

    def test_set_monthly_price_to_user_billing_plan(self):
        self.bucket.monthly_price = 20.0
        assert self.bucket.edit(), self.bucket.error
        assert test.update_object(self.user), self.user.error

    def test_wait_for_user_statistics(self):
        assert UserStats.stats_waiter(self.user)
        assert self.user.get()

    def test_check_monthly_fee_in_user_account_details_after_setting_monthly_price_to_user_billing_plan(self):
        assert 20.0 == self.bucket.monthly_price

    def test_check_total_amount_in_user_account_details_after_setting_monthly_price_to_user_billing_plan(self):
        assert 20.0 == self.user.total_amount

    def test_check_outstanding_amount_in_user_account_details_after_setting_monthly_price_to_user_billing_plan(self):
        assert self.user.total_amount - self.user.payment_amount == self.user.outstanding_amount

    def test_check_total_amount_with_discount(self):
        assert self.user.total_amount_with_discount == 20.0
