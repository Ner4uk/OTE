# ignore
import pytest
from onapp_helper.dashboard_statistics import DashboardStatistics
from onapp_helper import test
import datetime


#################################### Marks #####################################
# Component
@pytest.mark.bucket
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
class TestDashboardStatistics():
    def setup_class(self):
        #self.dbs = DashboardStatistics()
        self.utc_time = datetime.datetime.utcnow()

    def teardown_class(self):
        pass

    def test_compare_virtual_servers(self):
        # get ids of available statistics vs.
        if test.cp_version < 5.6:
            available_stats_vs_ids_query = "select virtual_machines.id from vm_hourly_stats " \
                    "left join virtual_machines on vm_hourly_stats.virtual_machine_id = virtual_machines.id " \
                    "where virtual_machines.type is NULL and vm_hourly_stats.stat_time = '{0}-{1}-{2} {3}:00:00'".format(
                self.utc_time.year, self.utc_time.month, self.utc_time.day, self.utc_time.hour
            )
        else:
            available_stats_vs_ids_query = "select DISTINCT(virtual_machines.id) from billing_statistics_hourly " \
                                           "left join virtual_machines on billing_statistics_hourly.origin_id = virtual_machines.id " \
                                           "where virtual_machines.type is NULL and billing_statistics_hourly.origin_type = 1 and " \
                                           "billing_statistics_hourly.stat_time = '{0}-{1}-{2} {3}:00:00'".format(
                self.utc_time.year, self.utc_time.month, self.utc_time.day,
                self.utc_time.hour
            )
        available_stats_vs_ids = test.cp.mysql_execute(query=available_stats_vs_ids_query)
        available_stats_vs = set(available_stats_vs_ids)
        vs_ids_from_data_base_query = "select id from virtual_machines where type is NULL and deleted_at is NULL"
        vs_ids_from_data_base = test.cp.mysql_execute(query=vs_ids_from_data_base_query)
        vs_from_data_base = set(vs_ids_from_data_base)
        diff = vs_from_data_base.difference(available_stats_vs)
        print(diff)
        print('Chart VS - {0} \nDB VS - {1}'.format(len(available_stats_vs_ids), len(vs_ids_from_data_base)))
        if diff:
            get_server_identifier_query = 'select identifier from virtual_machines where id in ({0})'.format(', '.join(diff))
            [print(identifier) for identifier in (test.cp.mysql_execute(query=get_server_identifier_query))]
            assert False
        assert True

    def test_compare_cpu_usage(self):
        chart_cpu_usage = DashboardStatistics()
        chart_cpu_usage.get(
            stats_for=['cpus'],
            startdate='{0}-{1}-{2}'.format(
                self.utc_time.year, self.utc_time.month, self.utc_time.day
            )
        )
        chart_cpu = int(chart_cpu_usage.cpus[-1][-1])

        cpus_from_data_base_query = 'select SUM(cpus) from virtual_machines where deleted_at is NULL and type is NULL'
        cpus_from_data_base = test.cp.mysql_execute(query=cpus_from_data_base_query)[0]
        db_cpus = int(cpus_from_data_base)

        print('Chart cpu - {0} \nDB cpu - {1}'.format(chart_cpu, db_cpus))

    def test_compare_memory_usage(self):
        chart_memory_usage = DashboardStatistics()
        chart_memory_usage.get(
            stats_for=['memory'],
            startdate='{0}-{1}-{2}'.format(
                self.utc_time.year, self.utc_time.month, self.utc_time.day
            )
        )
        chart_memory = int(chart_memory_usage.memory[-1][-1])

        memory_from_data_base_query = 'select SUM(memory) from virtual_machines where deleted_at is NULL and type is NULL'
        memory_from_data_base = test.cp.mysql_execute(query=memory_from_data_base_query)[0]
        db_memory = int(memory_from_data_base)

        print('Chart memory - {0} \nDB memory - {1}'.format(chart_memory, db_memory))

    def test_compare_disk_size_usage(self):
        chart_usage = DashboardStatistics()
        chart_usage.get(
            stats_for=['disk_size'],
            startdate='{0}-{1}-{2}'.format(
                self.utc_time.year, self.utc_time.month, self.utc_time.day
            )
        )
        chart = int(chart_usage.disk_size[-1][-1])

        from_data_base_query = 'select SUM(disks.disk_size) from disks ' \
                               'left join virtual_machines on disks.virtual_machine_id = virtual_machines.id ' \
                               'where virtual_machines.type is NULL and virtual_machines.deleted_at is NULL'
        from_data_base = test.cp.mysql_execute(query=from_data_base_query)[0]
        db = int(from_data_base)

        print('Chart disk_size - {0} \nDB disk_size - {1}'.format(chart, db))
