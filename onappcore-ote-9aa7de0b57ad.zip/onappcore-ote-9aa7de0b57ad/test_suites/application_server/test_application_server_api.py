# daily

__author__ = 'zhuk'
import pytest

from onapp_helper import test

from onapp_helper.server import ApplicationServer
from onapp_helper.disk import Disk
from onapp_helper.backup import Backup
import time

if test.cp_version >= 5.4:
    from onapp_helper.ip_address import IpAddress


#################################### Marks #####################################
# Component
@pytest.mark.application_server
@pytest.mark.applications
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.sequentially
################################## End of marks ################################
@pytest.mark.verbose
class TestApplicationServer:
    def setup_class(self):
        test.load_env(use_public_network=True)

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        self.app_s = ApplicationServer()
        self.additional_disk = Disk(self.app_s)
        self.backup = Backup(self.app_s)
        self.DOMAIN = 'tesT24.za-7-z.a.ua'

    def teardown_class(self):
        attributes = (
            'app_s',
        )
        test.clean_up_resources(attributes, self)

    def test_create_application_server(self):
        # Create ApplicationServer

        if test.cp_version >= 5.4:
            self.app_s.selected_ip_address = test.env.ip_address.address
            self.app_s.domain = self.DOMAIN
        else:
            self.app_s.selected_ip_address_id = test.env.ip_address.id

        data = {
            "label": self.__class__.__name__,
            "hostname": self.app_s.hostname,
            "domain": self.DOMAIN,
            "hypervisor_group_id": test.env.hvz.id,
            "hypervisor_id": test.env.hv.id,
            "memory": self.app_s.template.min_memory_size,
            "cpus": 2,
            "cpu_shares": 90,
            "data_store_group_primary_id": test.env.dsz.id,
            "primary_disk_size": self.app_s.template.min_disk_size,
            "data_store_group_swap_id": test.env.dsz.id,
            "swap_disk_size": 1,
            "primary_network_group_id": test.env.netz.id,
            "required_ip_address_assignment": True,
            "rate_limit": 90,
            "required_virtual_machine_build": True,
            # "primary_disk_min_iops": self.primary_disk_min_iops,
            # "swap_disk_min_iops": self.swap_disk_min_iops,
            # "enable_autoscale": self.enable_autoscale
            "initial_root_password": test.generate_password(),
            "initial_root_password_encryption_key": 'zaza_en_key',
        }

        assert self.app_s.create(**data), self.app_s.error
        # Waiting ~1 min, while webuzo service will be restarted
        test.log.info('Waiting ~1 min, while webuzo service will be restarted')
        time.sleep(80)

    @pytest.mark.skipif(
        test.cp_version <= 5.3,
        reason='Domains is not supported yet.'
    )
    def test_that_domain_is_correct(self):
        self.app_s.ssh.password = self.app_s.get_initial_root_password()
        assert self.DOMAIN in self.app_s.execute('cat /etc/resolv.conf')

    def test_initial_root_password_is_not_editable(self):
        tmp_var = self.app_s.initial_root_password
        assert not self.app_s.edit(initial_root_password=test.generate_password())
        assert tmp_var == self.app_s.get_initial_root_password()

    def test_initial_root_password_encryption_key_is_not_editable(self):
        assert not self.app_s.initial_root_password_encrypted
        assert not self.app_s.edit(
            initial_root_password_encryption_key='password_encryption_key'
        )
        assert not self.app_s.initial_root_password_encrypted

    def test_initial_root_password_should_be_hidden(self):
        self.app_s.get()
        assert 'initial_root_password' not in self.app_s.response[self.app_s.root_tag]

    def test_create_additional_disk(self):
        assert self.additional_disk.create(), self.additional_disk.error

    def test_delete_additional_disk(self):
        time.sleep(30)
        assert self.additional_disk.delete(), self.additional_disk.error

    def test_additional_disk_should_be_deleted(self):
        assert not self.additional_disk.get()

    def test_take_backup(self):
        self.app_s.shutdown()
        assert self.backup.create(note='AppS Backup'), self.backup.error

    def test_convert_to_template_should_be_impossible(self):
        assert not self.backup.convert()
        assert "Conversion to template isn't supported by the backup's target." in self.backup.template.error['base']

    def test_restore_backup(self):
        assert self.backup.restore(), self.backup.error

    def test_delete_backup(self):
        assert self.backup.delete(), self.backup.error

    def test_allocate_a_new_ip_address(self):
        ip_address = IpAddress(parent_obj=test.env.net).get_free()

        if test.cp_version >= 5.4:
            assert self.app_s.ip_address_join.assign_to_server(
                address=ip_address.address
            ), self.app_s.ip_address_join.error
        else:
            assert self.app_s.ip_address_join.assign_to_server(
                ip_address_id=ip_address.id
            ), self.app_s.ip_address_join.error

        assert self.app_s.rebuild_network(force=True), self.app_s.error
        assert self.app_s.ping(target=ip_address.address), self.app_s.error
        assert self.app_s.ping(), self.app_s.error
        assert self.app_s.ip_address_join.unassign_from_server(), \
            self.app_s.ip_address_join.error
        assert self.app_s.rebuild_network(force=True), self.app_s.error
        assert not self.app_s.ping(target=ip_address.address), self.app_s.error
        assert self.app_s.ping(), self.app_s.error

        if test.cp_version > 5.3:
            used_ip_addresses = IpAddress(test.env.net).get_key_values('address')
            assert ip_address.address not in used_ip_addresses

    def test_you_can_not_edit_initial_root_password(self):
        assert not self.app_s.reset_root_password(
            initial_root_password=test.generate_password()
        )

    def test_you_can_not_edit_initial_root_password_encryption_key(self):
        assert not self.app_s.reset_root_password(
            initial_root_password_encryption_key='zzazazazazazaza'
        )

    @pytest.mark.skipif(test.cp_version < 6.1, reason='Not supported')
    def test_you_can_not_enable_virsh_console(self):
        assert not self.app_s.enable_virsh_console()
        assert "Virtual Server doesn't support Virsh Console" in \
               self.app_s.error['base']
        assert not self.app_s.virsh_console

    def test_delete_application_server(self):
        assert self.app_s.delete(), self.app_s.error

    @pytest.mark.skipif(test.cp_version <= 5.3, reason='Not supported yet.')
    def test_that_ip_address_is_not_present_in_ip_range(self):
        used_ip_addresses = IpAddress(test.env.net).get_key_values('address')
        assert self.app_s.ip_address not in used_ip_addresses
