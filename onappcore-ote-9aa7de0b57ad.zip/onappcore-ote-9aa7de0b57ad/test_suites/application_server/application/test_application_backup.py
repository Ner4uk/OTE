from onapp_helper import test
from onapp_helper.server import ApplicationServer
from onapp_helper.application_server.application import Application
from onapp_helper.application_server.application_backup import AppBackup
import time
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.applications
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.sequentially
################################## End of marks ################################
@pytest.mark.incremental
class TestApplicationBackup:
    def setup_class(self):
        test.load_env(use_public_network=True)

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        try:
            self.app_s = ApplicationServer()
            self.app_s.label = self.__name__

            if test.cp_version >= 5.4:
                self.app_s.selected_ip_address = test.env.ip_address.address
            else:
                self.app_s.selected_ip_address_id = test.env.ip_address.id

            assert self.app_s.create(), self.app_s.error
            self.app_s.connected()
            if not self.app_s.error:
                #Waiting ~1 min, while webuzo service will be restarted
                test.log.info(
                    'Waiting ~1 min, while webuzo service will be restarted'
                )
                time.sleep(80)
            self.application = Application(self.app_s)
            assert self.application.get_by_name('Zikula 1.5'), self.application.error
            assert self.application.get_script_attributes(), \
                self.application.error

            if not self.application.add_application(force=True):  # Zikula by default
                if 'Required PHP version greater than equal to' in self.application.error['base'][0]:
                    # Install different version PHP if required
                    import re
                    from onapp_helper.application_server.system_app import SystemApp
                    # Get '5.4.1' from 'Required PHP version greater than equal to 5.4.1 AND found version is : 5.3.29'
                    required_php_version = re.findall('[0-9.]+', self.application.error['base'][0])[0]

                    time.sleep(20)
                    required_sys_app = [
                        app for app in SystemApp(self.app_s).get_all()
                        if required_php_version.rsplit('.', 1)[0] in app.version and  #  search '5.4' in "5.4.45"
                        'php' in app.api_name
                    ][0]
                    #  Install App
                    assert required_sys_app.install(), required_sys_app.error
                    #  Switch to installed
                    assert required_sys_app.switch_php_version(), required_sys_app.error
                    #  Try to create application one more time
                    assert self.application.add_application(force=True), \
                        self.application.error
                else:
                    assert False, self.application.error

            time.sleep(20)
            self.application_backup = AppBackup(self.application)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        attributes = (
            'app_s',
        )
        test.clean_up_resources(attributes, self)

    def test_create_application_backup(self):
        self.application_backup.backup_note = self.__class__.__name__
        time.sleep(20)
        assert self.application_backup.take_application_backup(), \
            self.application_backup.error

    def test_check_if_application_backup_present(self):
        assert self.application_backup.find_by_backup_note_type(), \
            self.application_backup.error

    def test_restore_application_backup(self):
        assert self.application_backup.restore_application_backup(), \
            self.application_backup.error

    def test_delete_application_backup(self):
        assert self.application_backup.delete_application_backup(), \
            self.application_backup.error