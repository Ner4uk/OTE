# ignore
from onapp_helper import test
from onapp_helper.server import ApplicationServer
from onapp_helper.application_server.application import Application
from onapp_helper.application_server.system_app import SystemApp
from multiprocessing import Pool  # http://toly.github.io/blog/2014/02/13/parallelism-in-one-line/
import time
import os
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.ignore
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.sequentially
################################## End of marks ################################
@pytest.mark.incremental
class TestDeployingOfAllApplications:
    def setup_class(self):
        test.load_env(use_public_network=True)

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        try:
            self.app_s = ApplicationServer()
            self.app_s.memory = test.env.hv.free_memory * 0.9
            self.app_s.cpus = test.env.hv.cpus
            self.app_s.cpu_shares = 100
            self.app_s.primary_disk_size = 20
            if not self.app_s.id:
                self.app_s.label = self.__name__

            if test.cp_version >= 5.4:
                self.app_s.selected_ip_address = test.env.ip_address.address
            else:
                self.app_s.selected_ip_address_id = test.env.ip_address.id

                assert self.app_s.create(), self.app_s.error
                # Waiting ~1 min, while webuzo service will be restarted
                test.log.info(
                    'Waiting ~1 min, while webuzo service will be restarted'
                )
                time.sleep(80)

            self.application = Application(self.app_s)
            self.system_apps = SystemApp(self.app_s).get_all()

            self.file_name = os.path.join(
                test.wd, "doc/{}".format('deploying_applications_report_{}.txt'.format(time.ctime().replace(' ', '_')))
            )
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        attributes = (
            'app_s',
        )
        test.clean_up_resources(attributes, self)

    def test_deploying_all_available_applications(self):
        assert self.app_s.booted and self.app_s.built
        available_apps = self.application.get_available_applications()
        test.log.info('Total applications - {}'.format(len(available_apps)))
        with open(self.file_name, 'w') as dar:
            dar.write('Template: {}\n'.format(self.app_s.template.file_name))
            dar.write('Total applications: {}\n'.format(len(available_apps)))
            dar.write('\nInstalled system apps:\n')
            for sys_app in self.system_apps:
                if sys_app.installed:
                    dar.write("\tName - {}, version - {}\n".format(sys_app.name, sys_app.version))

            dar.write('\nAvailable system apps:\n')
            for sys_app in self.system_apps:
                dar.write("\tName - {}, version - {}\n".format(sys_app.name, sys_app.version))

            dar.write("\n+{}+\n".format('-' * 78))
            dar.write(
                "|{:.^30}|{:.^15}|{:.^15}|{:.^15}|\n".format(
                    'Name', 'Soft directory', 'Status', 'Is responsible?'
                )
            )
            dar.write("+{}+\n".format('-' * 78))

        pool = Pool(5)
        pool.map(self.check_app_deploy, available_apps)
        pool.close()
        pool.join()

        with open(self.file_name, 'a') as dar:
            dar.write("+{}+\n".format('-' * 78))

    def check_app_deploy(self, app):
        try:
            app.apps.connected()
            is_responsible = '-'
            status = ''
            if app.get_script_attributes():
                app.apps.connected()
                if app.add_application(force=True):
                    status = 'SUCCESS'
                    app.apps.connected()
                    if app._is_responsible(timeout=5):
                        is_responsible = '+'
                    app.apps.connected()
                    app.delete_application()

            if app.error:
                test.log.error(app.error)
                #  In case 500 status code.
                if type(app.error) == dict:
                    status = '. '.join(app.error['base']) if 'base' in app.error \
                        else '"base" key error'
                elif type(app.error) == list:
                    status = app.error[0] if len(app.error) else 'No error message'
                else:
                    status = 'Undefined error obj.'

            with open(self.file_name, 'a') as dar:
                test.log.info('Write report for {}'.format(app.name))
                if status == 'SUCCESS':
                    result = "|{:.<30}|{:.<15}|{:.^15}|{:.^15}|\n".format(
                        app.name,
                        app.softdirectory,
                        status, is_responsible
                    )
                else:
                    result = "|{:.<30}|{:.<15}|{:.<15}|\n".format(
                        app.name,
                        app.softdirectory,
                        status
                    )
                dar.write(result)
        except Exception as e:
            test.log.exception(e, app.name)

