from onapp_helper import test
from onapp_helper.server import ApplicationServer
from onapp_helper.application_server import email_account
from onapp_helper.application_server.application import Application
from onapp_helper.application_server.domain import Domain
from onapp_helper.application_server.system_app import SystemApp
import pytest
import time


#################################### Marks #####################################
# Component
@pytest.mark.applications
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.sequentially
################################## End of marks ################################
@pytest.mark.incremental
class TestEmailAccount:
    def setup_class(self):
        test.load_env(use_public_network=True)

        if test.api_version < 5.1:
            pytest.skip("This is supporting since 5.1")
        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        try:
            self.app_s = ApplicationServer()
            if not self.app_s.id:
                self.app_s.label = self.__name__

            if test.cp_version >= 5.4:
                self.app_s.selected_ip_address = test.env.ip_address.address
            else:
                self.app_s.selected_ip_address_id = test.env.ip_address.id

            assert self.app_s.create(), self.app_s.error
            # Waiting ~1 min, while webuzo service will be restarted
            test.log.info(
                'Waiting ~1 min, while webuzo service will be restarted'
            )
            time.sleep(80)

            self.application = Application(self.app_s).get_by_name('Zikula 1.5')
            assert self.application.get_script_attributes(), self.application.error

            # install exim
            exim_app = SystemApp(self.app_s)
            assert exim_app.get_by_api_name(api_name='exim')
            if not exim_app.installed:
                assert exim_app.install(), exim_app.error
            # install dovecot
            dovecot_app = SystemApp(self.app_s)
            assert dovecot_app.get_by_api_name(api_name='dovecot')
            if not dovecot_app.installed:
                assert dovecot_app.install(), dovecot_app.error

            if not self.application.add_application(force=True):  # Zikula by default
                if 'Required PHP version greater than equal to' in self.application.error['base'][0]:
                    # Install different version PHP if required
                    import re
                    # Get '5.4.1' from 'Required PHP version greater than equal to 5.4.1 AND found version is : 5.3.29'
                    required_php_version = re.findall('[0-9.]+', self.application.error['base'][0])[0]

                    time.sleep(20)
                    required_sys_app = [
                        app for app in SystemApp(self.app_s).get_all()
                        if required_php_version.rsplit('.', 1)[0] in app.version and  #  search '5.4' in "5.4.45"
                        'php' in app.api_name
                    ][0]
                    #  Install App
                    assert required_sys_app.install(), required_sys_app.error
                    #  Switch to installed
                    assert required_sys_app.switch_php_version(), \
                        required_sys_app.error
                    #  Try to create one more time
                    self.app_s.ping(timeout=60)
                    assert self.application.add_application(force=True), \
                        self.application.error
                else:
                    assert False, self.application.error

            self.domain = Domain(self.app_s)
            assert self.domain.add_domain_to_an_existed_app(
                domain='existed.com',
                application_id=self.application.id
            ), self.domain.error
            assert self.application._is_responsible()
            self.email_account_dd = email_account.EmailAccount(self.app_s)  # for default domain
            self.email_account_ad = email_account.EmailAccount(self.app_s)  # for application domain
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        attributes = (
            'app_s',
        )
        test.clean_up_resources(attributes, self)

    # TODO add negative tests
    # def test(self):
    #     pass

    def test_create_email_account_with_default_domain(self):
        test.gen_api_doc = 'Create an email account.'
        self.email_account_dd.user = 'dd'  # after creation it is going to change to 'dd@ip_address'
        self.email_account_dd.password = test.generate_password()
        assert self.email_account_dd.create(), self.email_account_dd.error

    def test_create_email_account_with_applicatin_domain(self):
        self.email_account_ad.user = 'ad'  # after creation it is going to change to 'ad@domain'
        self.email_account_ad.domain = self.domain.name
        self.email_account_ad.password = test.generate_password()
        assert self.email_account_ad.create(), self.email_account_ad.error

    def test_send_email_to_account_with_default_domain(self):
        default_domain_account = test.init_mail(
            message='Test message',
            msg_from='ote@test.com',
            msg_to=self.email_account_dd.user,
            subject='dd test message'
        )
        assert not default_domain_account.send(self.app_s.ip_address)  # send return empty dict if success

    def test_send_email_to_account_with_application_domain(self):
        application_domain_account = test.init_mail(
            message='Test message',
            msg_from='ote@test.com',
            msg_to=self.email_account_ad.user,
            subject='ad test message'
        )
        assert not application_domain_account.send(self.app_s.ip_address)  # send return empty dict if success

    def test_get_email_accounts_for_default_domain(self):
        test.gen_api_doc = 'Get the email accounts for domain.'
        assert self.email_account_dd.get_for_domain(self.app_s.ip_address)

    def test_get_email_accounts_for_application_domain(self):
        assert self.email_account_ad.get_for_domain(self.domain.name)

    def test_delete_email_account_with_default_domain(self):
        test.gen_api_doc = 'Delete the email account for default domain.'
        assert self.email_account_dd.delete()

    def test_delete_email_account_with_application_domain(self):
        test.gen_api_doc = 'Delete the email account for specific domain.'
        assert self.email_account_ad.delete()

    def test_email_accounts_for_default_domain_should_be_deleted(self):
        assert not self.email_account_dd.get_for_domain(self.app_s.ip_address)

    def test_email_accounts_for_application_domain_should_be_deleted(self):
        assert not self.email_account_ad.get_for_domain(self.domain.name)
