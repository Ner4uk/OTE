from onapp_helper import test
from onapp_helper.server import ApplicationServer
from onapp_helper.application_server import service
import pytest
import time


#################################### Marks #####################################
# Component
@pytest.mark.applications
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.sequentially
################################## End of marks ################################
@pytest.mark.incremental
class TestServices:
    def setup_class(self):
        test.load_env(use_public_network=True)

        if test.api_version < 5.1:
            pytest.skip("This is supporting since 5.1")
        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        try:
            self.app_s = ApplicationServer()
            if not self.app_s.id:
                self.app_s.label = self.__name__

            if test.cp_version >= 5.4:
                self.app_s.selected_ip_address = test.env.ip_address.address
            else:
                self.app_s.selected_ip_address_id = test.env.ip_address.id

            assert self.app_s.create(), self.app_s.error
            # Waiting ~1 min, while webuzo service will be restarted
            test.log.info(
                'Waiting ~1 min, while webuzo service will be restarted'
            )
            time.sleep(80)
            self.service = service.Service(self.app_s)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        attributes = (
            'app_s',
        )
        test.clean_up_resources(attributes, self)

    def test_get_all_services(self):
        test.gen_api_doc = True
        assert self.service.get_all(), self.service.error

    def test_check_that_all_services_is_running(self):
        for service in self.service.get_all():
            test.log.info(
                'The {0} has {1} status...'.format(service.name, service.status)
            )
            assert service.status == 'running'

    def test_restart_all_services(self):
        for service in self.service.get_all():
            if service.name == "MySQL":
                test.gen_api_doc = True
            assert service.restart(), service.error

    def test_after_restarting_all_services_should_be_running(self):
        for service in self.service.get_all():
            test.log.info(
                'The {0} has {1} status...'.format(service.name, service.status)
            )
            assert service.status == 'running'

    def test_stop_all_services(self):
        for service in self.service.get_all():
            if service.name == "MySQL":
                test.gen_api_doc = True
            assert service.stop(), service.error

    def test_after_stopping_all_services_should_be_stopped(self):
        for service in self.service.get_all():
            test.log.info(
                'The {0} has {1} status...'.format(service.name, service.status)
            )
            assert service.status == 'stop'

    def test_start_all_services(self):
        for service in self.service.get_all():
            if service.name == "MySQL":
                test.gen_api_doc = True
            assert service.start(), service.error

    def test_after_starting_all_services_should_be_started(self):
        for service in self.service.get_all():
            test.log.info(
                'The {0} has {1} status...'.format(service.name, service.status)
            )
            assert service.status == 'running'
