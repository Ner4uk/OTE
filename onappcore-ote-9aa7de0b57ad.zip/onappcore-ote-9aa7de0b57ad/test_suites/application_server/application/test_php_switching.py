from onapp_helper import test
from onapp_helper.server import ApplicationServer
from onapp_helper.application_server import system_app
import pytest
import time


#################################### Marks #####################################
# Component
@pytest.mark.applications
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.sequentially
################################## End of marks ################################
@pytest.mark.incremental
class TestPHPSwitching:
    def setup_class(self):
        test.load_env(use_public_network=True)

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        try:
            self.app_s = ApplicationServer()
            self.app_s.label = self.__name__

            if test.cp_version >= 5.4:
                self.app_s.selected_ip_address = test.env.ip_address.address
            else:
                self.app_s.selected_ip_address_id = test.env.ip_address.id

            assert self.app_s.create(), self.app_s.error
            # Waiting ~1 min, while webuzo service will be restarted
            test.log.info(
                'Waiting ~1 min, while webuzo service will be restarted'
            )
            time.sleep(80)
            self.system_app = system_app.SystemApp(self.app_s)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        attributes = (
            'app_s',
        )
        test.clean_up_resources(attributes, self)

    def test_get_all_available_php_apps(self):
        assert self.app_s.booted and self.app_s.built
        test.gen_api_doc = True
        assert self.system_app.get_all(filter='php'), self.system_app.error

    def test_install_all_php_apps_from_list(self):
        test.gen_api_doc = True
        for app in self.system_app.get_all(filter='php'):
            if not app.installed:
                assert app.install(), app.error

    def test_check_if_all_php_apps_has_been_installed(self):
        for app in self.system_app.get_all(filter='php'):
            assert app.installed, "{} has not been installed".format(
                app.name
            )

    def test_setting_up_a_new_default_version(self):
        not_defaults = [app for app in self.system_app.get_all(filter='php') if not app.default]
        test.gen_api_doc = True
        for not_default in not_defaults:
            time.sleep(10)
            # Fixed with https://onappdev.atlassian.net/browse/CORE-7184
            # if not_default['api_name'] == u'php70':  # Currently works incorrect with php 7.0
            #     break
            assert self.system_app.switch_php_version(not_default.api_name), \
                self.system_app.error
            assert [
                app.default
                for app in self.system_app.get_all(filter='php') if app.api_name == not_default.api_name
            ][0]

    def test_uninstall_all_installed_php_apps(self):
        test.gen_api_doc = True
        for app in self.system_app.get_all(filter='php'):
            if app.installed:
                assert app.uninstall(), app.error

    def test_check_if_all_installed_php_apps_has_been_uninstalled(self):
        for app in self.system_app.get_all(filter='php'):
            assert not app.installed

