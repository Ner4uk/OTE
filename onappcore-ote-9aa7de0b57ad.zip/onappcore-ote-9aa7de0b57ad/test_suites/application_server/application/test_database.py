# https://onappdev.atlassian.net/browse/CORE-7073

import time
from packaging import version

import pytest

from onapp_helper import test
from onapp_helper.application_server.database import DataBase
from onapp_helper.application_server.database_user import DataBaseUser
from onapp_helper.server import ApplicationServer


#################################### Marks #####################################
# Component
@pytest.mark.applications
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.sequentially
################################## End of marks ################################
class TestDatabase:
    def setup_class(self):
        test.load_env(use_public_network=True)

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        try:
            self.app_s = ApplicationServer()
            self.app_s.label = self.__name__

            if test.cp_version >= 5.4:
                self.app_s.selected_ip_address = test.env.ip_address.address
            else:
                self.app_s.selected_ip_address_id = test.env.ip_address.id

            self.app_s.rate_limit = 0
            #self.app_s.initial_root_password = '~!@#$*_-+=`\\{}[]:;\',.?/'
            assert self.app_s.create(), self.app_s.error

            # Waiting ~1 min, while webuzo service will be restarted
            test.log.info('Waiting ~1 min, while webuzo service will be restarted')
            time.sleep(80)

            self.database = DataBase(self.app_s)
            self.database_user = DataBaseUser(self.app_s)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        attributes = (
            'app_s',
        )
        test.clean_up_resources(attributes, self)

    def test_create_database(self):
        self.database.db = 'zaza_db_test'
        test.gen_api_doc = True
        assert self.database.create(), self.database.error
        assert [
            db for db in self.database.get_databases()
            if db[self.database.root_tag]['db'] == self.database.db
        ]

    def test_get_list_of_databases(self):
        test.gen_api_doc = True
        assert self.database.get_databases(), self.database.error

    def test_should_not_create_database_user_with_name_longer_than_11_characters(self):
        if version.parse(self.app_s.template.version) >= version.parse('1.17'):
            self.database_user.name = 'zaza_dbtest_zaza'  # 16 characters
        else:
            self.database_user.name = 'zaza_dbtest'  # 11 characters

        self.database_user.password = test.generate_password()
        assert not self.database_user.create()
        msg = f'Username cannot be longer than {len(self.database_user.name)} characters.'
        assert msg in self.database_user.error['base']

    def test_create_database_user(self):
        self.database_user.name = 'zaza_db'
        self.database_user.password = test.generate_password()
        test.gen_api_doc = True
        assert self.database_user.create(), self.database_user.error
        assert [
            db_user for db_user in self.database_user.get_database_users()
            if db_user[self.database_user.root_tag]['name'] == self.database_user.name
            ]

    def test_get_list_of_database_users(self):
        test.gen_api_doc = True
        assert self.database_user.get_database_users(), self.database_user.error

    def test_assign_user_to_database(self):
        self.database.prilist['SELECT'] = True
        test.gen_api_doc = True
        assert self.database.assign_user(self.database_user), self.database.error

    def test_getting_a_list_of_users_assigned_to_database(self):
        test.gen_api_doc = True
        assert self.database.get_users_assigned_to_db(), self.database.error

    def test_check_db_user_privileges(self):
        self.assigned_users = self.database.get_users_assigned_to_db()
        assert [
            user for user in self.assigned_users
            if user['database_user']['name'] == self.database_user.name
            ]
        assert [
            user for user in self.assigned_users
            if user['database_user']['prilist']['SELECT'] == True
            ]

    def test_update_database_user_privileges(self):
        self.database.prilist['DELETE'] = True
        test.gen_api_doc = True
        assert self.database_user.update_db_user_privileges(self.database), \
            self.database_user.error

    def test_check_updated_db_user_privileges(self):
        self.assigned_users = self.database.get_users_assigned_to_db()
        assert [
            user for user in self.assigned_users
            if user['database_user']['name'] == self.database_user.name
            ]
        assert [
            user for user in self.assigned_users
            if user['database_user']['prilist']['SELECT'] == True
            ]
        assert [
            user for user in self.assigned_users
            if user['database_user']['prilist']['DELETE'] == True
            ]

    def test_change_database_user_password(self):
        self.database_user.password = test.generate_password()
        test.gen_api_doc = True
        assert self.database_user.change_db_user_password(), self.database_user.error

    def test_unassign_user_from_database(self):
        test.gen_api_doc = True
        assert self.database_user.unassign_user_from_database(self.database),\
            self.database_user.error

    def test_delete_database_user(self):
        test.gen_api_doc = True
        assert self.database_user.delete(), self.database_user.error
        assert not [
            db_user for db_user in self.database_user.get_database_users()
            if db_user[self.database_user.root_tag]['name'] == self.database_user.name
            ]

    def test_delete_database(self):
        test.gen_api_doc = True
        assert self.database.delete(), self.database.error
        assert not [
            db for db in self.database.get_databases() if
            db[self.database.root_tag]['db'] == self.database.db
            ]
