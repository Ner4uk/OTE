# https://onappdev.atlassian.net/browse/CORE-4404
from onapp_helper.server import ApplicationServer
from onapp_helper.application_server.application import Application
from onapp_helper.application_server.domain import Domain
from onapp_helper import test
import time
import pytest

#   Domain structure
#{
#
#    "domain":
#
#    {
#        "identifier": "d76078995b66b9f34841872612f2ee11",
#        "name": "69.168.237.48",
#        "path": "/home/onapp/public_html",
#        "type": "primary"
#    }
#
#}


#################################### Marks #####################################
# Component
@pytest.mark.applications
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.sequentially
################################## End of marks ################################
@pytest.mark.incremental
class TestManagingDomain:
    def setup_class(self):
        test.load_env(use_public_network=True)

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        self.DOMAIN = 'tesT24.za-7-z.a.ua'
        try:
            self.app_s = ApplicationServer()
            self.app_s.label = self.__name__
            self.app_s.domain = self.DOMAIN

            if test.cp_version >= 5.4:
                self.app_s.selected_ip_address = test.env.ip_address.address
            else:
                self.app_s.selected_ip_address_id = test.env.ip_address.id

            assert self.app_s.create(), self.app_s.error
            # Waiting ~1 min, while webuzo service will be restarted
            test.log.info(
                'Waiting ~1 min, while webuzo service will be restarted'
            )
            time.sleep(80)
            self.application = Application(self.app_s)
            assert self.application.get_by_name('Zikula 1.5')
            assert self.application.get_script_attributes()

            if not self.application.add_application(force=True):  # Zikula by default
                if 'Required PHP version greater than equal to' in self.application.error['base'][0]:
                    # Install different version PHP if required
                    import re
                    from onapp_helper.application_server.system_app import SystemApp
                    # Get '5.4.1' from 'Required PHP version greater than equal to 5.4.1 AND found version is : 5.3.29'
                    required_php_version = re.findall('[0-9.]+', self.application.error['base'][0])[0]

                    time.sleep(20)
                    required_sys_app = [
                        app for app in SystemApp(self.app_s).get_all()
                        if required_php_version.rsplit('.', 1)[0] in app.version and  #  search '5.4' in "5.4.45"
                        'php' in app.api_name
                    ][0]
                    #  Install App
                    assert required_sys_app.install(), required_sys_app.error
                    #  Switch to installed
                    assert required_sys_app.switch_php_version(), \
                        required_sys_app.error
                    #  Try to create one more time
                    self.app_s.ping(timeout=60)
                    assert self.application.add_application(force=True), \
                        self.application.error
                else:
                    assert False, self.application.error

            self.domain = Domain(self.app_s)

            self.addon_domain_name = 'addon.com'
            self.existed_domain_name = 'existed.com'
            self.parked_domain_name = 'parked.com'
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        attributes = (
            'app_s',
        )
        test.clean_up_resources(attributes, self)

    def test_create_addon_domain(self):
        test.gen_api_doc = True
        assert self.domain.add_addon_domain_with_custom_path(
            domain=self.addon_domain_name,
            path='ZikulaTest'
        ), self.domain.error
        assert self.application._is_responsible()
        assert [
            domain for domain in self.domain.all_domains()
            if domain.name == self.addon_domain_name
            ][0]

    def test_delete_addon_domain(self):
        domain_identifier = [
            domain.identifier for domain in self.domain.all_domains()
            if domain.name == self.addon_domain_name
            ][0]
        assert self.domain.delete(domain_identifier), self.domain.error
        assert not [
            domain.identifier for domain in self.domain.all_domains()
            if domain.name == self.addon_domain_name]

    def test_create_domain_for_existed_application(self):
        test.gen_api_doc = True
        assert self.domain.add_domain_to_an_existed_app(
            domain=self.existed_domain_name,
            application_id=self.application.id
        ), self.domain.error
        assert self.application._is_responsible()
        assert [
            domain for domain in self.domain.all_domains()
            if domain.name == self.existed_domain_name
            ][0]

    def test_delete_domain_for_existed_application(self):
        domain_identifier = [
            domain.identifier for domain in self.domain.all_domains()
            if domain.name == self.existed_domain_name
            ][0]
        assert self.domain.delete(domain_identifier), self.domain.error
        assert not [
            domain.identifier for domain in self.domain.all_domains()
            if domain.name == self.existed_domain_name
            ]

    def test_create_parked_domain(self):
        test.gen_api_doc = True
        assert self.domain.add_domain_to_an_existed_app(
            domain=self.parked_domain_name,
            application_id=self.application.id
        ), self.domain.error
        test.gen_api_doc = True
        assert self.application._is_responsible()
        assert [
            domain for domain in self.domain.all_domains()
            if domain.name == self.parked_domain_name
            ][0]

    def test_delete_parked_domain(self):
        domain_identifier = [
            domain.identifier for domain in self.domain.all_domains()
            if domain.name == self.parked_domain_name
            ][0]
        test.gen_api_doc = True
        assert self.domain.delete(domain_identifier), self.domain.error
        assert not [
            domain.identifier for domain in self.domain.all_domains()
            if domain.name == self.parked_domain_name
            ]

    @pytest.mark.skipif(
        test.cp_version <= 5.3,
        reason='Domains is not supported yet.'
    )
    def test_that_main_domain_is_correct(self):
        self.app_s.ssh.password = self.app_s.get_initial_root_password()
        assert self.DOMAIN in self.app_s.execute('cat /etc/resolv.conf')
