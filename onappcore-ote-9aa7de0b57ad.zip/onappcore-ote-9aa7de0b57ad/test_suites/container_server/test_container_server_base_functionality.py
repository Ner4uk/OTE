# daily

__author__ = 'zhuk'

import pytest
from onapp_helper.server import ContainerServer
from onapp_helper.ip_address import IpAddress
from onapp_helper.disk import Disk
from onapp_helper import test


#################################### Marks #####################################
# Component
@pytest.mark.container_servers
# Depth
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
# @pytest.mark.incremental
@pytest.mark.verbose
class TestContainerServer:
    def setup_class(self):
        test.load_env()

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        try:
            self.DOMAIN = 'tesT24.za-7-z.a.ua'
            self.cs = ContainerServer()
            self.cs.label = self.__name__
            #self.cs.domain = self.DOMAIN
            self.additional_d = Disk(self.cs)
            self.additional_swap = Disk(self.cs)
            self.root_password = "1q2w3e4r5t!Q@W"
            self.new_pass = '1qaz2wsx3edc$R'
            self.encrypt_phrase = 'Vsqgfhjkm'
        except ValueError:
            test.log.exception("Opps something wrong during Setup")
            self.cs.delete()
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        if self.cs.id:
            if self.cs.locked:
                self.cs.unlock()
            self.cs.delete()

    def test_create_cs_with_cloud_config(self):
        assert self.cs.create(), self.cs.error

    def test_check_if_cloud_config_is_present(self):
        #https://onappdev.atlassian.net/browse/CORE-10116
        self.cs.get_cloud_config()
        assert self.cs.cloud_config == self.cs.read_cloud_config_from_origin()

    # @pytest.mark.skipif(
    #     test.cp_version <= 5.3,
    #     reason='Domains is not supported yet.'
    # )
    # def test_that_domain_is_correct(self):
    #     assert self.DOMAIN in self.cs.execute(
    #         'cat /etc/resolv.conf',
    #         user='core'
    #     )

    def test_stop_cs(self):
        assert self.cs.shutdown(), self.cs.error

    def test_start_cs(self):
        assert self.cs.start(), self.cs.error

    def test_reboot_cs(self):
        assert self.cs.reboot(), self.cs.error

    def test_cs_rebuild(self):
        assert self.cs.rebuild(), self.cs.error

    def test_check_cs_parameters(self):
        assert 2.4 <= round(
            self.cs.native_disk_size('/'), 1
        ) <= 2.6, self.cs.error

    # #  Can not create (permission denied)
    # def test_create_file_on_primary_disk(self):
    #     self.cs.execute('echo "cs test" > /cs_test')
    #     assert "cs test" in self.cs.execute('cat /cs_test')

    def test_increase_primary_disk_size(self):
        primary_disk = self.cs.get_primary_disk()
        new_size = primary_disk.disk_size + 1
        primary_disk.disk_size = new_size
        assert primary_disk.edit(), primary_disk.error
        assert primary_disk.disk_size == new_size
        assert 3.4 <= round(self.cs.native_disk_size('/'), 1) <= 3.6

    # def test_check_file_after_increase_primary_disk(self):
    #     assert "cs test" in self.cs.execute('cat /cs_test')

    def test_decrease_primary_disk_size(self):
        primary_disk = self.cs.get_primary_disk()
        new_size = primary_disk.disk_size - 1
        primary_disk.disk_size = new_size
        assert not primary_disk.edit(), primary_disk.error
        if test.cp_version >= 6.1:
            msg = "Disk's current filesystem 'fat16' is unsupported. " \
                  "The resize has been aborted to protect your data."
        else:
            msg = "Fatal: GPT partition table isn't supported"
        assert msg in primary_disk.transaction.log_output
        self.cs.get()
        if not self.cs.booted:
            self.cs.start()

    # def test_check_file_after_decrease_primary_disk(self):
    #     assert "cs test" in self.cs.execute('cat /cs_test')

    def test_increase_swap_size(self):
        swap = self.cs.get_swap_disk()
        new_disk_size = swap.disk_size + 1
        swap.disk_size = new_disk_size
        assert swap.edit(), swap.error
        assert swap.disk_size == new_disk_size
        assert 1.9 <= round(self.cs.native_swap_size(), 1) <= 2.1

    def test_decrease_swap_size(self):
        swap = self.cs.get_swap_disk()
        new_disk_size = swap.disk_size - 1
        swap.disk_size = new_disk_size
        assert swap.edit(), swap.error
        assert swap.disk_size == new_disk_size
        assert 0.9 <= round(self.cs.native_swap_size(), 1) <= 1.1

    # Check Additional Disk
    def test_additional_disk_create(self):
        self.additional_d.disk_size = 1
        self.additional_d.mount_point = '/mnt/disk1'
        self.additional_d.mounted = True
        self.additional_d.file_system = 'ext4'
        self.additional_d.require_format_disk = True
        assert self.additional_d.create(), self.additional_d.error
        assert 0.8 <= round(self.cs.native_disk_size('/mnt/disk1'), 1) <= 1.0

    # def test_create_file_on_additional_disk(self):
    #     self.cs.execute('echo "cs test" > /mnt/disk1/cs_test')
    #     assert "cs test" in self.cs.execute('cat /mnt/disk1/cs_test')

    def test_increase_additional_disk(self):
        new_size = self.additional_d.disk_size + 1
        self.additional_d.disk_size = new_size
        assert self.additional_d.edit(), self.additional_d.error
        assert self.additional_d.disk_size == new_size
        assert 1.8 <= round(self.cs.native_disk_size('/mnt/disk1'), 1) <= 2.0

    # def test_check_file_after_increase_additional_disk(self):
    #     assert "cs test" in self.cs.execute('cat /mnt/disk1/cs_test')

    def test_decrease_additional_disk(self):
        new_size = self.additional_d.disk_size - 1
        self.additional_d.disk_size = new_size
        assert self.additional_d.edit(), self.additional_d.error
        assert self.additional_d.disk_size == new_size
        assert 0.8 <= round(self.cs.native_disk_size('/mnt/disk1'), 1) <= 1.0

    # def test_check_file_after_decrease_additional_disk(self):
    #     assert "cs test" in self.cs.execute('cat /mnt/disk1/cs_test')

    def test_additional_disk_delete(self):
        assert self.additional_d.delete(), self.additional_d.error
        assert not self.cs.native_disk_size('/mnt/disk1')

    # Check Additional Swap
    def test_additional_swap_create(self):
        self.additional_swap.disk_size = 1
        self.additional_swap.is_swap = True
        self.additional_swap.require_format_disk = True
        assert self.additional_swap.create(), self.additional_swap.error
        assert 1.8 <= round(self.cs.native_swap_size(), 1) <= 2.0

    def test_edit_additional_swap(self):
        new_size = self.additional_swap.disk_size + 1
        self.additional_swap.disk_size = new_size
        assert self.additional_swap.edit(), self.additional_swap.error
        assert self.additional_swap.disk_size == new_size
        assert 2.8 <= round(self.cs.native_swap_size(), 1) <= 3.0

    def test_additional_swap_delete(self):
        assert self.additional_swap.delete(), self.additional_swap.error
        if self.additional_swap.transaction.action == 'detach_disk':
            assert self.cs.reboot(), self.cs.error
        assert 0.8 <= round(self.cs.native_swap_size(), 1) <= 1.0

    def test_edit_memory_cs(self):
        new_memory = self.cs.memory * 2
        self.cs.memory = new_memory
        assert self.cs.edit(), self.cs.error
        assert self.cs.memory == new_memory

    def test_edit_cpu_cores(self):
        new_cpus = self.cs.cpus * 2
        self.cs.cpus = new_cpus
        assert self.cs.edit(), self.cs.error
        assert self.cs.cpus == new_cpus

    def test_edit_network_cs(self):
        primary_iface = self.cs.network_interface.get_primary()
        assert primary_iface.edit(
            label="eth3", rate_limit=50), primary_iface.error
        assert primary_iface.label == "eth3"

    def test_delete_and_add_network_interface(self):
        primary_iface = self.cs.network_interface.get_primary()
        assert primary_iface.delete(), primary_iface.error
        assert primary_iface.add(), primary_iface.error
        primary_iface_new = self.cs.network_interface.get_primary()
        assert primary_iface_new.label == "eth3"

    def test_add_an_ip_address_to_cs(self):
        ip_address = IpAddress(parent_obj=test.env.net).get_free()
        assert ip_address.assign_to_server(self.cs), ip_address.error

    def test_change_root_passwd(self):
        assert self.cs.reset_root_password(self.new_pass), self.cs.error
        assert self.cs.initial_root_password == self.new_pass
        if self.cs.ping(timeout=3):
            assert "Hello" in self.cs.execute("echo Hello")

    def test_should_be_impossible_to_ssh_with_old_password(self):
        self.cs.ssh.password = self.root_password
        if self.cs.ping(timeout=3):
            assert "hello" not in self.cs.execute("echo hello")
        self.cs.ssh.password = self.cs.initial_root_password
        if self.cs.ping(timeout=3):
            assert "hello" in self.cs.execute("echo hello")

    def test_encrypt_password(self):
        assert self.cs.reset_root_password(
            initial_root_password=self.new_pass,
            initial_root_password_encryption_key=self.encrypt_phrase
        )
        assert self.cs.initial_root_password != self.new_pass

    def test_decrypt_password(self):
        assert self.cs.decrypt_password(
            initial_root_password_encryption_key=self.encrypt_phrase
        )
        if self.cs.ping(timeout=3):
            assert "hello" in self.cs.execute("echo hello")

    @pytest.mark.skipif(test.cp_version < 6.1, reason='Not supported')
    def test_you_can_not_enable_virsh_console(self):
        assert not self.cs.enable_virsh_console()
        assert "Virtual Server doesn't support Virsh Console" in \
               self.cs.error['base']
        assert not self.cs.virsh_console
