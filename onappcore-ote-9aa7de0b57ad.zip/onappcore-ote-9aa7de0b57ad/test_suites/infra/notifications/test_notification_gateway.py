from onapp_helper.infra.notifications.gateways import Gateway
from test_helper.generatorTH import generate_name
from onapp_helper import test
import pytest


@pytest.mark.infra
class TestGateway(object):

    def setup_class(self):
        test.load_env()

        self.gateway = Gateway()

    def teardown_class(self):
        assert self.gateway.delete(), self.gateway.error

    def test_create_internal_gateway(self):
        self.gateway.name = generate_name()
        self.gateway.delivery_method = Gateway.DELIVERY_METHOD.internal
        assert self.gateway.create(), self.gateway.error

    def test_create_sendmail_gateway(self):
        self.gateway.name = generate_name()
        self.gateway.delivery_method = Gateway.DELIVERY_METHOD.sendmail
        self.gateway.email = "test@onapp.com"
        self.gateway.host = "localhost.bak"
        assert self.gateway.create(), self.gateway.error

    def test_create_snmp_gateway(self):
        self.gateway.name = generate_name()
        self.gateway.delivery_method = Gateway.DELIVERY_METHOD.smtp
        self.gateway.email = "test@onapp.com"
        self.gateway.host = "localhost.bak"
        self.gateway.smtp_address = "smpt.host.com"
        self.gateway.smtp_port = "22"
        self.gateway.smtp_domain = "localhost"
        self.gateway.smtp_user_name = "smtp"
        self.gateway.smtp_password = "testdsffff"
        self.gateway.smtp_authentication = Gateway.SMTP_AUTH.plain
        self.gateway.smtp_enable_starttls_auto = "0"
        assert self.gateway.create(), self.gateway.error


#
#
