from onapp_helper.infra.notifications.external_user import ExternalUser
from onapp_helper.infra.notifications.template_list import TemplateList
from onapp_helper.infra.notifications.recipient_list import RecipientList
from onapp_helper.infra.notifications.subscriptions import Subscriptions
from onapp_helper.infra.notifications.gateways import Gateway
import pytest


from onapp_helper.permissions import Permissions
from test_helper.generatorTH import generate_name
from onapp_helper.role import Role
from onapp_helper.user import User
from onapp_helper import test
import pytest


@pytest.mark.infra
@pytest.mark.skipif(
    test.cp_version < 5.0,
    reason="Current CP version ({0}) does not support this functionality ".format(test.cp_version)
)
class TestNotificationPermissions:
    def setup_class(self):
        test.load_env()

        try:

            self.permissions = Permissions()

            self.role = Role(id=2)
            self.role.label = self.__name__
            assert self.role.create(), self.role.error

            self.user = User()
            self.user.login = self.__name__.lower()
            self.user.password = test.generate_password()
            self.user.email = '{}@test.com'.format(self.__name__.lower())
            self.user.role_ids = [self.role.id]
            assert self.user.create(), self.user.error

            self.external_user = ExternalUser()
            self.external_user.name = self.__name__.lower()
            self.external_user.email = "{}@test.com".format(generate_name())
            self.external_user.phone = ""

            self.templates_list = TemplateList()
            self.templates_list.name = self.__name__.lower()
            self.templates_list.template = self.__name__.lower()

            self.recipient_list = RecipientList()
            self.recipient_list.name = self.__name__.lower()
            self.recipient_list.user_ids = ["User|1"]

            self.gateway = Gateway()
            self.gateway.name = self.__name__.lower()
            self.gateway.delivery_method = Gateway.DELIVERY_METHOD.internal

            self.permissions.load()
            self.role.permission_ids.append(self.permissions.roles.id)
            self.role.edit()

            test.execute_as(self.user.login, self.user.password)


        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        attributes = (
            'user',
            'role',
            'external_user',
            'templates_list',
            'recipient_list',
            'gateway'
        )
        test.clean_up_resources(attributes, self)

    # external user permissions
    def test_should_be_possible_to_create_external_user(self):
        self.role.permission_ids.append(self.permissions.messaging_external_users_create.id)
        self.role.edit()
        assert self.external_user.create(), self.external_user.error

    def test_should_be_impossible_to_create_external_user(self):
        if self.permissions.messaging_external_users_create.id in self.role.permission_ids:
            self.role.permission_ids.remove(self.permissions.messaging_external_users_create.id)
        self.role.edit()
        assert not self.external_user.create(), self.external_user.error
        assert 'You do not have permissions for this action' in self.external_user.error

    def test_should_be_possible_to_get_external_user(self):
        self.role.permission_ids.append(self.permissions.messaging_external_users_read.id)
        self.role.edit()
        assert self.external_user.get(), self.external_user.error

    def test_should_be_impossible_to_get_external_user(self):
        if self.permissions.messaging_external_users_read.id in self.role.permission_ids:
            self.role.permission_ids.remove(self.permissions.messaging_external_users_read.id)
        self.role.edit()
        assert not self.external_user.get(), self.external_user.error
        assert 'You do not have permissions for this action' in self.external_user.error

    def test_should_be_possible_to_update_external_user(self):
        self.role.permission_ids.append(self.permissions.messaging_external_users_update.id)
        self.role.edit()
        self.external_user.name = 'updated'
        self.external_user.email = 'updated@email.com'
        assert self.external_user.update(), self.external_user.error

    def test_should_be_impossible_to_update_external_user(self):
        if self.permissions.messaging_external_users_update.id in self.role.permission_ids:
            self.role.permission_ids.remove(self.permissions.messaging_external_users_update.id)
        self.role.edit()
        assert not self.external_user.update(), self.external_user.error
        assert 'You do not have permissions for this action' in self.external_user.error

    # notification templates list permissions
    def test_should_be_possible_to_create_template(self):
        self.role.permission_ids.append(self.permissions.messaging_notification_templates_create.id)
        self.role.edit()
        assert self.templates_list.create(), self.templates_list.error

    def test_should_be_impossible_to_create_template(self):
        if self.permissions.messaging_notification_templates_create.id in self.role.permission_ids:
            self.role.permission_ids.remove(self.permissions.messaging_notification_templates_create.id)
        self.role.edit()
        assert not self.templates_list.create(), self.templates_list.error
        assert 'You do not have permissions for this action' in self.templates_list.error

    def test_should_be_possible_to_update_template(self):
        self.role.permission_ids.append(self.permissions.messaging_notification_templates_update.id)
        self.role.edit()
        assert self.templates_list.update(), self.templates_list.error

    def test_should_be_impossible_to_update_template(self):
        if self.permissions.messaging_notification_templates_update.id in self.role.permission_ids:
            self.role.permission_ids.remove(self.permissions.messaging_notification_templates_update.id)
        self.role.edit()
        assert not self.templates_list.update(), self.templates_list.error
        assert 'You do not have permissions for this action' in self.templates_list.error

    def test_should_be_possible_to_get_template(self):
        self.role.permission_ids.append(self.permissions.messaging_notification_templates_read.id)
        self.role.edit()
        assert self.templates_list.get(), self.templates_list.error

    def test_should_be_impossible_to_get_template(self):
        if self.permissions.messaging_notification_templates_read.id in self.role.permission_ids:
            self.role.permission_ids.remove(self.permissions.messaging_notification_templates_read.id)
        self.role.edit()
        assert not self.templates_list.get(), self.templates_list.error
        assert 'You do not have permissions for this action' in self.templates_list.error

    # RecipientList permissions
    def test_should_be_possible_to_create_recipient_list(self):
        self.role.permission_ids.append(self.permissions.messaging_recipients_lists_create.id)
        self.role.edit()
        assert self.recipient_list.create(), self.recipient_list.error

    def test_should_be_impossible_to_create_recipient_list(self):
        if self.permissions.messaging_recipients_lists_create.id in self.role.permission_ids:
            self.role.permission_ids.remove(self.permissions.messaging_recipients_lists_create.id)
        self.role.edit()
        assert not self.recipient_list.create(), self.recipient_list.error
        assert 'You do not have permissions for this action' in self.recipient_list.error

    def test_should_be_possible_to_update_recipient_list(self):
        self.role.permission_ids.append(self.permissions.messaging_recipients_lists_update.id)
        self.role.edit()
        if not self.recipient_list.get():
            self.role.permission_ids.append(self.permissions.messaging_recipients_lists_create.id)
            self.role.edit()
            assert self.recipient_list.create(), self.recipient_list.error
        assert self.recipient_list.update(), self.recipient_list.error

    # TODO add response about permissions, return {}
    def test_should_be_impossible_to_update_recipient_list(self):
        if self.permissions.messaging_recipients_lists_update.id in self.role.permission_ids:
            self.role.permission_ids.remove(self.permissions.messaging_recipients_lists_update.id)
            self.role.edit()
        assert not self.recipient_list.update(), self.recipient_list.error
        assert 'You do not have permissions for this action' in self.recipient_list.error

    # Gateway permissions
    def test_should_be_possible_to_create_gateway(self):
        self.role.permission_ids.append(self.permissions.messaging_gateways_create.id)
        self.role.edit()
        assert self.gateway.create(), self.gateway.error

    def test_should_be_impossible_to_create_gateway(self):
        if self.permissions.messaging_gateways_create.id in self.role.permission_ids:
            self.role.permission_ids.remove(self.permissions.messaging_gateways_create.id)
        self.role.edit()
        assert not self.gateway.create(), self.gateway.error
        assert 'You do not have permissions for this action' in self.gateway.error

    def test_should_be_possible_to_update_gateway(self):
        self.role.permission_ids.append(self.permissions.messaging_gateways_update.id)
        self.role.edit()
        assert self.gateway.update(), self.gateway.error

    def test_should_be_impossible_to_updte_gateway(self):
        if self.permissions.messaging_gateways_update.id in self.role.permission_ids:
            self.role.permission_ids.remove(self.permissions.messaging_gateways_update.id)
        self.role.edit()
        assert not self.gateway.update(), self.recipient_list.error
        assert 'You do not have permissions for this action' in self.gateway.error
