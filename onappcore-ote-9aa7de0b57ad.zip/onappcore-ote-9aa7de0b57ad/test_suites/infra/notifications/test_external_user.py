import pytest
from onapp_helper.infra.notifications.external_user import ExternalUser
from test_helper.generatorTH import generate_name
from onapp_helper import test


@pytest.mark.infra
class TestExternalUser(object):

    def setup_class(self):
        test.load_env()

        self.external_user = ExternalUser()

    def teardown_class(self):
        assert self.external_user.delete(), self.external_user.error

    def test_create_external_user(self):
        self.external_user.name = generate_name()
        self.external_user.email = "{}@test.com".format(generate_name())
        self.external_user.phone = ""
        assert self.external_user.create(), self.external_user.error

    def test_update_external_user(self):
        self.external_user.name = generate_name()
        self.external_user.email = "{}@test.com".format(generate_name())
        assert self.external_user.update(), self.external_user.error


