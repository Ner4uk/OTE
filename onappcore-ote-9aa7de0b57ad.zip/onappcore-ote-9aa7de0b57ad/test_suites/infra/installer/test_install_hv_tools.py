# ignore
import pytest
from onapp_helper.server import VirtualServer
from onapp_helper import test


@pytest.mark.infra
class TestInstallHvTools(object):

    def setup_class(self):
        test.load_ha_env()

        try:
            self.vs = VirtualServer(server_id='iswnyrrwtdjomb')
            self.hv_type='kvm'

        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        self.vs.rebuild()

    def test_install_hv_install(self):
        if test.cp_version > 5.0:
            self.vs.execute(f"rpm -Uvh http://rpm.repo.onapp.com/repo/onapp-repo-{test.cp_version}.noarch.rpm")
        else:
            self.vs.execute("rpm -Uvh http://rpm.repo.onapp.com/repo/onapp-repo.noarch.rpm")
        self.vs.execute("yum install onapp-hv-install -y")
        self.vs.execute(f"/onapp/onapp-hv-install/onapp-hv-{self.hv_type}-install.sh -a")
        self.vs.execute(f"/onapp/onapp-hv-install/onapp-hv-config.sh -h {test.host} -p {self.vs.ip_address}")
        self.vs.execute("yum install gdisk lsblk-wrapper -y")
        test.log.warning('VM is going to reboot')
        self.vs.execute("shutdown -r now")
        if self.vs.ping():
            test.log.warning('VM is working')
            self.vs.execute("hostname")


