# ignore
import time
import pytest
from engine.lib.cp import CP
from onapp_helper import test
from onapp_helper.settings import Settings


@pytest.mark.infra
class TestHAPostConfigure(object):
    """
    Configuring services after HA deployment
    """

    def setup_class(self):
        test.load_ha_env()

        self.cps = [CP(host=host.ip,
                       user=test.ha_credentials.ssh_user,
                       password=test.ha_credentials.ssh_password
                       ) for host in test.ha_hosts]

    def test_configure_redis(self):
        master_cp = self.cps[0]
        password = master_cp.execute("grep 'requirepass' /etc/redis.conf").split()[1]
        redis_conf = """
production:
    :host: 127.0.0.1
    :port: 6479
    :password: {password} \n
staging:
    :host: 127.0.0.1
    :port: 6479
    :password: {password}
    """.format(password=password)
        for cp in self.cps:
            cp.execute("echo '%s' > %s" % (redis_conf, "/onapp/interface/config/redis.yml"))

    def test_configure_rabbitmq_port(self):
        test.load_onapp_settings()
        test.onapp_settings.set(rabbitmq_port=5772)
        assert test.onapp_settings.get().rabbitmq_port == 5772

    def test_configure_database_cluster(self):
        for idx, cp in enumerate(self.cps):
            cp.execute("sed -i s/127.0.0.1/localhost/g /onapp/interface/config/database.yml")
            cp.execute("sed -i s/#socket/socket/g /onapp/interface/config/database.yml")
            cp.execute("sed -i s/3406/3306/g /onapp/interface/config/database.yml")
            if idx == 0:
                cp.execute("/etc/init.d/mysql restart-bootstrap")
                time.sleep(30)
            else:
                cp.execute("/etc/init.d/mysql restart")
                time.sleep(30)
            cluster_size = int(cp.mysql_execute("show status like 'wsrep_cluster_size'")[-1])
            assert cluster_size == 3





