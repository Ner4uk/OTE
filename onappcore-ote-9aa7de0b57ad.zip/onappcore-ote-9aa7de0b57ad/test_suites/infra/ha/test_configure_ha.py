# ignore
import time
import pytest

from onapp_helper.infra.ha.cluster import Cluster
from onapp_helper.infra.ha.communication_interface import CommunicationInterface
from onapp_helper.infra.ha.ha import HA
from onapp_helper.infra.ha.host import Host

from onapp_helper import test
from onapp_helper.infra.ha.node import Node

@pytest.mark.infra
class TestHAConfigure:
    def setup_class(self):
        test.load_ha_env()

        self.hostnames = [host.hostname for host in test.ha_hosts]


    def test_configure_hosts(self):
        #  Edit 2 existed hosts
        preinstalled_hosts = Host().get_all()
        for key, host in enumerate(preinstalled_hosts):
            host.hostname = test.ha_hosts[key].hostname
            print(host.hostname)
            host.edit()
        #  Add third host
        Host(hostname=test.ha_hosts[-1].hostname).add()

        #  Check that all 3 hosts are present
        assert len(Host().get_all()) == 3

    def test_configure_clusters(self):
        #  Get preinstalled clusters
        preinstalled_clusters = Cluster().get_all()
        preinstalled_cluster_names = []
        #  If cluster exist - edit
        for cluster in preinstalled_clusters:
            preinstalled_cluster_names.append(cluster.name)
            cluster.__init__(id=cluster.id, name=cluster.name)
            cluster.edit()

        #  if not exist - create
        for cluster_name in test.ha_cluster_names:
            if cluster_name not in preinstalled_cluster_names:
                Cluster(name=cluster_name).add()

    def test_add_nodes_to_clusters(self):
        #  Get list of installed clusters
        installed_clusters = Cluster().get_all()
        #  Load cluster nodes from config file
        [cluster.load_nodes() for cluster in installed_clusters]
        for cluster in installed_clusters:
            for hostname in self.hostnames:
                #  Get installed cluster node by node hostname
                installed_node = [node for node in cluster.get_cluster_nodes() if node.hostname == hostname]
                key = self.hostnames.index(hostname)
                #  Update node if exist otherwise add a new node
                if installed_node:
                    #  Update node
                    node = installed_node[0]
                    # ToDo - check if node host_id the same as host id.
                    node.ip_address = cluster.nodes[key].ip_address
                    node.interface = cluster.nodes[key].interface
                    node.priority = cluster.nodes[key].priority
                    node.edit()
                else:
                    #  Add new node
                    node = Node(cluster=cluster)
                    node.host_id = [host.id for host in Host().get_all() if host.hostname == hostname][0]
                    node.ip_address = cluster.nodes[key].ip_address
                    node.interface = cluster.nodes[key].interface
                    node.priority = cluster.nodes[key].priority
                    node.add()

    def test_configure_communication_ring(self):
        #  Get communication rings
        communication_rings = CommunicationInterface().get_all()
        #  If exist - edit, otherwise - add new
        if communication_rings:
            communication_ring = communication_rings[0]
            #  Update attributes from config file
            communication_ring._load_from_config(test.ha_config)
            communication_ring.edit()
        else:
            communication_ring = CommunicationInterface()
            #  Update attributes from config file
            communication_ring._load_from_config(test.ha_config)
            communication_ring.add()

        communication_ring = communication_rings[0]
        communication_ring.switch_to_unicast()
        communication_ring.set_members()

    def test_enable_ha(self):
        host = Host().get_all()[0]
        ha = HA(host)
        assert ha.enable()

    def test_activate_inactive_clusters(self):
        for cluster_name in test.ha_cluster_names:
            #  Get inactive cluster from all clusters by cluster name, here 'test.ha_cluster_names' is a list of
            #  cluster names in specific order.
            clusters = [
                cluster for cluster in Cluster().get_all()
                if cluster.name == cluster_name and cluster.state == 'inactive'
                ]
            #  If cluster has been found, activate him and apply changes.
            if clusters:
                cluster = clusters[0]
                cluster.activate()
                HA(Host().get_all()[0]).apply_changes()
                #  Wait for httpd restart
                if cluster_name == "UI":
                    time.sleep(120)
                # Change connection port after LB will be installed
                if cluster_name == "LOAD_BALANCER":
                    test.session.port = 10080
                    time.sleep(120)
                    test.cp.ssh.execute("crm_resource -P")
                    time.sleep(60)
                if cluster_name == "CLOUD_BOOT":
                    time.sleep(60)
                    test.cp.ssh.execute("crm resource unmanage  cloudboot-group")

                #  wait for cluster installation.
                attempts = 60
                while not [
                    cluster for cluster in Cluster().get_all()
                    if cluster.name == cluster_name and cluster.state == "stable"
                    ]:
                    time.sleep(10)
                    attempts -= 1
                    if not attempts:
                        break
                assert attempts, 'Waiting timed out!'
        #  Return 80 port back
        test.session.port = 80

