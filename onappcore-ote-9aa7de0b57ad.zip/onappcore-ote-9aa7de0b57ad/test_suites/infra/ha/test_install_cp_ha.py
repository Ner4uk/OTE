# ignore
import pytest
from multiprocessing import Pool  # http://toly.github.io/blog/2014/02/13/parallelism-in-one-line/
from engine.lib.cp import CP
from onapp_helper import test
from onapp_helper.settings import Settings


@pytest.mark.infra
class TestInstallControlPanel(object):
    """
    Install Control Panels for HA deployment
    """

    def setup_class(self):
        test.load_ha_env()

        self.LICENSE = test.ha_credentials.license_key
        self.version = test.ha_credentials.cp_version
        self.etc_hosts = [
            '\n{} {} {}'.format(
                host.ip,
                host.hostname,
                str(host.hostname).split('.')[0]
            ) for host in test.ha_hosts
        ]
        self.security_limits = """root soft nofile 2048\n
                                  root hard nofile 4096\n
                                  onapp soft nofile 2048\n
                                  onapp hard nofile 4096\n"""
        self.install_sh = "/onapp/onapp-cp-install/onapp-cp-install.sh --ha-install --percona-cluster -a"
        # env.hosts = [host.ip for host in test.ha_hosts]
        # env.user = test.ha_credentials.ssh_user
        # env.password = test.ha_credentials.ssh_password
        # env.ssh_key_path = test.ha_credentials.ssh_key_path

        self.cps = [
            CP(host=host.ip,
               user=test.ha_credentials.ssh_user,
               password=test.ha_credentials.ssh_password) for host in test.ha_hosts
        ]

    # def test_collected_cp(self):
    #     assert len(self.cps) == 3

    def install_cps(self, cp):
        test.log.debug("Starting CP install on host: {}".format(cp.host))
        cp.execute("yum update -y")
        if "5.0" in self.version:
            cp.execute("rpm -Uvh http://rpm.repo.onapp.com/repo/onapp-repo.noarch.rpm")
        else:
            cp.execute("rpm -Uvh http://rpm.repo.onapp.com/repo/onapp-repo-{}.noarch.rpm".format(self.version))
        cp.execute('touch /etc/yum.repos.d/OnApp.repo')
        cp.execute("sed -i s/'cdn.'/''/g /etc/yum.repos.d/OnApp.repo")
        cp.execute("echo '%s' >> /etc/hosts" % ''.join(self.etc_hosts))
        cp.execute("echo '%s' >> /etc/security/limits.conf" % self.security_limits)
        cp.execute("yum install onapp-cp-install -y")
        if "CentOS release 6.9 (Final)" in cp.execute("cat /etc/redhat-release"):
            cp.execute("export OPENSSL_ENABLE_MD5_VERIFY=1 && {}".format(self.install_sh))
        else:
            cp.execute(self.install_sh)
        if test.ha_credentials.license_server in "staging":
            cp.execute("sed -i 's/licensing.onapp.com/staging-dashboard.onapp.com/g' /onapp/interface/config/environments/production.rb")
            cp.execute("service onapp-licensing restart")

    def test_install_cp(self):
        pool = Pool()
        pool.map(self.install_cps, self.cps)
        pool.close()
        pool.join()

        assert True

    def test_license_set(self):
        test.load_onapp_settings()
        test.onapp_settings.set(license_key=self.LICENSE)
        assert test.onapp_settings.get().license_key, self.LICENSE

    def test_successfully_install(self):
        for cp in self.cps:
            msg = f"Finished Control Panel version '{self.version}' install"
            assert msg in cp.execute('tail -n 1 /root/onapp-cp-install.log')

    def test_configure_ssh(self):
        keys = []
        for cp in self.cps:
            if 'id_rsa.pub' not in cp.execute('ls -l /home/onapp/.ssh/'):
                cp.execute("ssh-keygen -f /home/onapp/.ssh/id_rsa -t rsa -N ''")
            keys.append(cp.execute('cat /home/onapp/.ssh/id_rsa.pub'))
            if 'id_rsa.pub' not in cp.execute('ls -l /root/.ssh/'):
                cp.execute("ssh-keygen -f /root/.ssh/id_rsa -t rsa -N ''")
            keys.append(cp.execute('cat /root/.ssh/id_rsa.pub'))

        for cp in self.cps:
            commands = [
                "touch /root/.ssh/known_hosts",
                "touch /home/onapp/.ssh/known_hosts; chown onapp:onapp /home/onapp/.ssh/known_hosts",
                "echo '{key}\n ' >> /root/.ssh/authorized_keys".format(key="\n".join(keys)),
                "yes | cp -rf /root/.ssh/known_hosts /home/onapp/.ssh/known_hosts; chown onapp:onapp /home/onapp/.ssh/known_hosts"
            ]
            for cmd in commands:
                cp.execute(cmd)

    def test_distribute_keys(self):
        for cp in self.cps:
            for host in test.ha_hosts:
                assert host.hostname in cp.execute('hostname', host.hostname)
