# ignore
import pytest
from onapp_helper import test
from test_helper.generatorTH import generate_number_string


@pytest.mark.infra
class TestInfraSettings(object):
    def setup_class(self):
        test.load_env()
        test.load_onapp_settings()

    def test_snmp_stats_settings(self):
        test.onapp_settings.set(snmp_stats_level1_period=generate_number_string(),
                                snmp_stats_level2_period=generate_number_string(),
                                snmp_stats_level3_period=generate_number_string())
