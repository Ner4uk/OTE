# daily
import pytest
from onapp_helper import test
from onapp_helper.company_plan import CompanyPlan


#################################### Marks #####################################
# Component
@pytest.mark.billing
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
class TestCompanyBillingPlan:
    def setup_class(self):
        self.company_billing_plan = CompanyPlan()

    def teardown_class(self):
        pass

    def test_create_company_billing_plan(self):
        if test.cp_version == 4.2:
            test.gen_api_doc = True
        self.company_billing_plan.label = 'CompanyPlan1'
        self.company_billing_plan.currency_code = "GBP"
        self.company_billing_plan.monthly_price = 666.0
        self.company_billing_plan.create()

    def test_check_company_billing_plan_label(self):
        assert 'CompanyPlan1' == self.company_billing_plan.label

    def test_check_company_billing_plan_currency_code(self):
        assert "GBP" == self.company_billing_plan.currency_code

    def test_check_company_billing_plan_monthly_price(self):
        assert 666.0 == self.company_billing_plan.monthly_price

    def test_edit_company_billing_plan_label(self):
        self.company_billing_plan.label = 'CompanyPlan2'
        self.company_billing_plan.edit()

    def test_check_new_company_billing_plan_label(self):
        assert 'CompanyPlan2' == self.company_billing_plan.label

    def test_edit_company_billing_plan_currency_code(self):
        if test.cp_version == 4.2:
            test.gen_api_doc = True
        self.company_billing_plan.currency_code = 'USD'
        self.company_billing_plan.edit()

    def test_check_new_company_billing_plan_currency_code(self):
        assert 'USD' == self.company_billing_plan.currency_code

    def test_edit_company_billing_plan_monthly_price(self):
        self.company_billing_plan.monthly_price = 777.0
        self.company_billing_plan.edit()

    def test_check_new_company_billing_plan_monthly_price(self):
        assert 777.0 == self.company_billing_plan.monthly_price

    def test_get_all_company_billing_plans(self):
        if test.cp_version == 4.2:
            test.gen_api_doc = True
        assert self.company_billing_plan.get_all()

    def test_delete_company_billing_plan(self):
        if test.cp_version == 4.2:
            test.gen_api_doc = True
        assert self.company_billing_plan.delete()