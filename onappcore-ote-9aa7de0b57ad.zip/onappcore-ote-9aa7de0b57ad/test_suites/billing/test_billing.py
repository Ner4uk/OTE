# daily
import pytest
from onapp_helper.billing_plan import BillingPlan
from onapp_helper.user import User
from onapp_helper import test


#################################### Marks #####################################
# Component
@pytest.mark.billing
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.sequentially
################################## End of marks ################################
@pytest.mark.verbose
@pytest.mark.skipif(test.cp_version >= 6.1, reason=test.not_supported_msg(BillingPlan))
class TestBillingPlan():
    """
    Check billing plan functionality.
    """
    def setup_class(self):
        if test.cp_version >= 5.8:
            test.api_version.set(5.5)

        """
        1
        :return:
        """
        self.billing_plan = BillingPlan()

        self.user1 = User()
        self.user1.login = 'user1'
        self.user1.password = test.generate_password()
        self.user1.email = 'user1@clone.test'

        self.user2 = User()
        self.user2.login = 'user2'
        self.user2.password = test.generate_password()
        self.user2.email = 'user2@clone.test'

        self.bp_for_user2 = BillingPlan()

    def teardown_class(self):
        """
        2
        :return:
        """
        self.user2.delete()
        self.bp_for_user2.delete()

    def test_create_billing_plan(self):
        """
        A: Create billing plan with the following parameters:
        self.billing_plan.label = TestBillingPlan
        self.billing_plan.currency_code = "GBP"
        self.billing_plan.monthly_price = 666.0  # Float since 4.3
        self.billing_plan.allows_kms = False
        self.billing_plan.allows_mak = True
        self.billing_plan.allows_own = False

        R: Billing plan has been created without errors.
        """
        test.gen_api_doc = "Create a new Billing Plan"
        self.billing_plan.label = self.__class__.__name__
        self.billing_plan.currency_code = "GBP"
        self.billing_plan.monthly_price = 666.0  # Float since 4.3
        self.billing_plan.allows_kms = False
        self.billing_plan.allows_mak = True
        self.billing_plan.allows_own = False
        assert self.billing_plan.create(), self.billing_plan.error

    def test_check_billing_plan_label(self):
        """
        A: Check billing plan label
        R: Billing plan label should be - TestBillingPlan
        """
        assert self.__class__.__name__ == self.billing_plan.label

    def test_check_billing_plan_currency_code(self):
        assert "GBP" == self.billing_plan.currency_code

    def test_check_billing_plan_monthly_price(self):
        assert 666.0 == self.billing_plan.monthly_price

    def test_check_billing_plan_allows_kms(self):
        assert not self.billing_plan.allows_kms

    def test_check_billing_plan_allows_mak(self):
        assert self.billing_plan.allows_mak

    def test_check_billing_plan_allows_own(self):
        assert not self.billing_plan.allows_own

    def test_edit_billing_plan_label(self):
        self.billing_plan.label = 'Changed'
        assert self.billing_plan.edit(), self.billing_plan.error

    def test_check_new_billing_plan_label(self):
        assert 'Changed' == self.billing_plan.label

    def test_edit_billing_plan_currency_code(self):
        test.gen_api_doc = "Edit Billing Plan"
        self.billing_plan.currency_code = 'USD'
        assert self.billing_plan.edit(), self.billing_plan.error

    def test_check_new_billing_plan_currency_code(self):
        assert 'USD' == self.billing_plan.currency_code

    def test_edit_billing_plan_monthly_price(self):
        self.billing_plan.monthly_price = 777.0
        assert self.billing_plan.edit(), self.billing_plan.error

    def test_check_new_billing_plan_monthly_price(self):
        assert 777.0 == self.billing_plan.monthly_price

    def test_edit_billing_plan_allows_kms(self):
        self.billing_plan.allows_kms = True
        assert self.billing_plan.edit(), self.billing_plan.error

    def test_check_new_billing_plan_allows_kms(self):
        assert self.billing_plan.allows_kms

    def test_edit_billing_plan_allows_mak(self):
        self.billing_plan.allows_mak = False
        assert self.billing_plan.edit(), self.billing_plan.error

    def test_check_new_billing_plan_allows_mak(self):
        assert not self.billing_plan.allows_mak

    def test_edit_billing_plan_allows_own(self):
        self.billing_plan.allows_own = True
        assert self.billing_plan.edit(), self.billing_plan.error

    def test_check_new_billing_plan_allows_own(self):
        assert self.billing_plan.allows_own

    def test_negative_clone_billing_plan(self):
        self.user1.billing_plan_id = self.billing_plan.id
        assert self.user1.create(), self.user1.error
        assert not self.bp_for_user2.clone(self.user1.id, self.billing_plan.id)
        assert 'Only the plan owner can clone it, and the plan should be ' \
               'associated with at least two users' in \
               self.bp_for_user2.error['base']

    def test_clone_billing_plan(self):
        self.user2.billing_plan_id = self.billing_plan.id
        assert self.user2.create(), self.user2.error

        test.gen_api_doc = "Clone Billing Plan"
        assert self.bp_for_user2.clone(self.user2.id, self.billing_plan.id)
        test.update_object(self.user2)

        assert self.user2.billing_plan_id == self.bp_for_user2.id
        assert self.bp_for_user2.label == "Bucket clone of {}".format(
            self.billing_plan.label
        )
        assert self.bp_for_user2.currency_code == self.billing_plan.currency_code
        assert self.bp_for_user2.allows_kms == self.billing_plan.allows_kms
        assert self.bp_for_user2.allows_mak == self.billing_plan.allows_mak
        assert self.bp_for_user2.allows_own == self.billing_plan.allows_own

        assert self.user1.delete(), self.user1.error
        assert self.user2.delete(), self.user2.error

    def test_copy_billing_plan(self):
        if test.cp_version < 5.5:
            pytest.mark.skip('Supported since 5.5')
        bp_copy = self.billing_plan.create_copy()
        assert bp_copy is not None, bp_copy.error
        assert self.billing_plan.label in bp_copy.label
        assert self.billing_plan.currency_code == bp_copy.currency_code
        assert self.billing_plan.id != bp_copy.id
        assert self.billing_plan.monthly_price == bp_copy.monthly_price
        assert self.billing_plan.allows_kms == bp_copy.allows_kms
        assert self.billing_plan.allows_mak == bp_copy.allows_mak
        assert self.billing_plan.allows_own == bp_copy.allows_own
        assert self.billing_plan.type == bp_copy.type
        if test.cp_version < 5.8:
            assert self.billing_plan.associated_with_users == \
                   bp_copy.associated_with_users
        assert bp_copy.delete(), bp_copy.error

    def test_delete_billing_plan(self):
        test.gen_api_doc = "Delete Billing Plan"
        self.user1.delete()
        # Before deletion of billing plan, you have to delete associated user
        assert self.billing_plan.delete()
