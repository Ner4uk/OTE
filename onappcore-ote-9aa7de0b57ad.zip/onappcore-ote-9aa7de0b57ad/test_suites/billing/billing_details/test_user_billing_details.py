# daily
__author__ = "Arsen"

from onapp_helper import test
from onapp_helper.user import User
from onapp_helper.billing_plan import BillingPlan
from onapp_helper.payment import Payment
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.billing
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.sequentially
################################## End of marks ################################
@pytest.mark.verbose
@pytest.mark.skipif(test.cp_version >= 6.1, reason=test.not_supported_msg(BillingPlan))
class TestUserBillingDetails():
    def setup_class(self):
        if test.cp_version >= 5.7:
            test.api_version.set(5.5)
        try:
            self.billing_plan = BillingPlan()
            self.billing_plan.label = self.__name__
            assert self.billing_plan.create(), self.billing_plan.error

            self.user = User(bp=self.billing_plan)
            self.user.login = self.__name__
            self.user.password = test.generate_password()
            self.user.email = self.user.login + "@autotest.net"
            assert self.user.create(), self.user.error

        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

        self.payment = Payment()

    def teardown_class(self):
        attributes = (
            'user',
            'billing_plan',
            'payment'
        )
        test.clean_up_resources(attributes, self)

    def test_check_total_amount_into_billing_details_of_new_user(self):
        assert 0 == self.user.total_amount

    def test_check_payment_amount_into_billing_details_of_new_user(self):
        assert 0 == self.user.payment_amount

    def test_check_outstanding_amount_into_billing_details_of_new_user(self):
        assert 0 == self.user.outstanding_amount

    def test_create_user_payment(self):
        self.payment.payer_id = self.user.id
        self.payment.invoice_number = '09022017/01'
        self.payment.amount = 100.00
        assert self.payment.create(), self.payment.error
        assert test.update_object(self.user), self.user.error

    def test_check_if_user_payment_shown_in_user_account_details(self):
        assert 100.00 == self.user.payment_amount

    def test_check_outstanding_amount_in_user_account_details_after_payment(self):
        assert -100.00 == self.user.outstanding_amount

    def test_check_total_amount_in_user_account_details_aster_payment(self):
        assert 0 == self.user.total_amount

    def test_set_monthly_price_to_user_billing_plan(self):
        self.billing_plan.monthly_price = 20.00
        assert self.billing_plan.edit(), self.billing_plan.error
        assert test.update_object(self.user), self.user.error

    def test_check_monthly_fee_in_user_account_details_after_setting_monthly_price_to_user_billing_plan(self):
        assert 20.00 == self.billing_plan.monthly_price

    def test_check_total_amount_in_user_account_details_after_setting_monthly_price_to_user_billing_plan(self):
        assert 20.00 == self.user.total_amount

    def test_check_outstanding_amount_in_user_account_details_after_setting_monthly_price_to_user_billing_plan(self):
        assert self.user.total_amount - self.user.payment_amount == self.user.outstanding_amount
