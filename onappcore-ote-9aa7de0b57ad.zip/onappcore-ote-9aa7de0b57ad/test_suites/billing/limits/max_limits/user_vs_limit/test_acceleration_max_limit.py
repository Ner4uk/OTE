from onapp_helper.br_helper.acceleration import AccelerationBR
from onapp_helper.user import User
from onapp_helper.billing_plan import BillingPlan
from onapp_helper import test
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.limits
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version >= 5.6,
    reason="Old billing is not supported..."
)
@pytest.mark.skipif(
    test.cp_version < 4.2,
    reason="Current CP version ({0}) does not support this functionality ".format(test.cp_version)
)
class TestAccelerationMaxLimit():
    def setup_class(self):
        try:
            self.billing_plan = BillingPlan()
            self.billing_plan.label = self.__name__
            assert self.billing_plan.create()

            self.user = User(bp=self.billing_plan)

            self.acceleration = AccelerationBR(billing_plan=self.billing_plan)

            self.user.login = 'accelerationmaxlimitstest'
            self.user.password = test.generate_password()
            self.user.email = 'user@accelerationmaxlimits.test'
            assert self.user.create()
            test.execute_as(self.user.login, self.user.password)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        self.user.delete()
        self.billing_plan.delete()

    def test_check_vs_max_limit(self):
        pass