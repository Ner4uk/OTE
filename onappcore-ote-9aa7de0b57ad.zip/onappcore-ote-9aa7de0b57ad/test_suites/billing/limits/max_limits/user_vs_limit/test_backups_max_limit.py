#  Use any backup type.
from onapp_helper.br_helper.backup import BackupBR
from onapp_helper.br_helper.bsz import BSZBR
from onapp_helper.backup import Backup
from onapp_helper.user import User
from onapp_helper.billing_plan import BillingPlan
from onapp_helper import test
from onapp_helper.server import VirtualServer, ApplicationServer
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.limits
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version >= 5.6,
    reason="Old billing is not supported..."
)
@pytest.mark.incremental
class TestBackupMaxLimit:
    def setup_class(self):
        test.load_env()

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        try:
            self.billing_plan = BillingPlan()
            self.billing_plan.label = self.__name__
            assert self.billing_plan.create()

            self.vs = VirtualServer()
            self.apps = ApplicationServer()
            self.user = User(bp=self.billing_plan)
            self.backup = Backup(self.vs)

            self.backup_br = BackupBR(billing_plan=self.billing_plan)

            if test.env.backup_servers:
                self.bsz_br = BSZBR(
                    billing_plan=self.billing_plan,
                    target_id=test.env.backup_servers[0].backup_server_group_id
                )
                self.bsz_br.limits.limit_backup = 0
                self.bsz_br.limits.limit_backup_disk_size = 0
                assert self.bsz_br.create()

            self.user.login = 'backupmaxlimitstest'
            self.user.password = test.generate_password()
            self.user.email = 'user@backupmaxlimits.test'
            assert self.user.create()
            test.execute_as(self.user.login, self.user.password)
            self.vs.label = self.__name__
            assert self.vs.create(), self.vs.error
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        self.user.delete()
        self.billing_plan.delete()

    def test_set_backup_max_limit_as_0(self):
        # Add 0 limit for all possible ways for backup creation. (HV, BSZ)
        self.backup_br.limits.limit = 0
        assert self.backup_br.create()

    def test_should_be_impossible_to_create_a_manual_backup(self):
        assert not self.backup.create()
        #assert 'You have reached your backup creation limit' in self.backup.error['base'][0]

    # Billing Backups count limits does not work with autobackups
    # https://onappdev.atlassian.net/browse/CORE-5467
    def test_you_can_take_autobackups_for_limit_0(self):
        if test.onapp_settings.allow_incremental_backups:
            bu_source = self.vs
        else:
            bu_source = self.vs.get_primary_disk()
        backups = bu_source.enable_auto_backups()
        assert len([b for b in backups if b.built and b.initiated != 'manual']) == 4


    #TODO Check size limit for autobackups.
