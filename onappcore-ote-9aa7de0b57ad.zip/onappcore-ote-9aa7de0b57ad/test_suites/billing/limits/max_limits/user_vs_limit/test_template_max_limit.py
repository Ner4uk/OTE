from onapp_helper.br_helper.template import TemplateBR
from onapp_helper.br_helper.bsz import BSZBR
from onapp_helper.bsz import BSZ
from onapp_helper.backup import Backup
from onapp_helper.iso import ISO
from onapp_helper.user import User
from onapp_helper.billing_plan import BillingPlan
from onapp_helper import test
from onapp_helper.server import VirtualServer
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.limits
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version >= 5.6,
    reason="Old billing is not supported..."
)
@pytest.mark.incremental
class TestTemplateMaxLimit:
    def setup_class(self):
        test.load_env()

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        try:
            self.billing_plan = BillingPlan()
            self.billing_plan.label = self.__name__
            assert self.billing_plan.create()

            self.vs = VirtualServer()
            self.iso = ISO()
            self.user = User(bp=self.billing_plan)
            self.backup = Backup(self.vs)
            self.template_br = TemplateBR(billing_plan=self.billing_plan)

            self.bsz_base_resources = []
            for bsz_id in BSZ().get_key_values('id'):
                self.bsz_base_resources.append(
                    BSZBR(
                        billing_plan=self.billing_plan,
                        target_id=bsz_id
                    )
                )

            self.user.login = 'templatemaxlimitstest'
            self.user.password = test.generate_password()
            self.user.email = 'user@templatemaxlimits.test'
            assert self.user.create(), self.user.error
            test.execute_as(self.user.login, self.user.password)
            self.vs.label = self.__name__
            assert self.vs.create(), self.vs.error
            assert self.backup.create(), self.backup.error
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        self.user.delete()
        self.billing_plan.delete()

    def test_set_template_max_limit_as_0(self):
        # Add 0 limit for all possible ways for backup creation. (HV, BSZ)
        self.template_br.limits.limit = 0
        assert self.template_br.create()
        for bsz_br in self.bsz_base_resources:
            bsz_br.limits.limit_template = 0
            assert bsz_br.create()

    def test_should_be_impossible_to_create_a_template(self):
        assert not self.backup.convert()
        # The error message depends on backup type.
        # https://onappdev.atlassian.net/browse/CORE-7379
        assert 'You have reached your template creation limit' in \
               self.backup.template.error['base'][0]