from onapp_helper.br_helper.customer_network import CustomerNetworkBR
from onapp_helper.customer_network import CustomerNetwork
from onapp_helper.user import User
from onapp_helper.billing_plan import BillingPlan
from onapp_helper import test
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.limits
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version >= 5.6,
    reason="Old billing is not supported..."
)
@pytest.mark.skipif(test.cp_version >= 5.3, reason="Deprecated functionality")
class TestCustomNetworkMaxLimit:
    def setup_class(self):
        test.load_env()

        if not test.env.hv.id:
            pytest.skip("There is no vmware hypervisor on this cloud")

        try:
            self.billing_plan = BillingPlan()
            self.billing_plan.label = self.__name__
            assert self.billing_plan.create()

            self.user = User(bp=self.billing_plan)

            self.customer_network_br = CustomerNetworkBR(billing_plan=self.billing_plan)

            self.user.login = 'customnetworkmaxlimitstest'
            self.user.password = test.generate_password()
            self.user.email = 'user@customnetworkmaxlimits.test'
            assert self.user.create()
            test.execute_as(self.user.login, self.user.password)
            self.customer_network = CustomerNetwork(self.user)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        self.user.delete()
        self.billing_plan.delete()

    def test_set_custom_network_max_limit_as_0(self):
        self.customer_network_br.limits.limit = 0
        assert self.customer_network_br.create()

    def test_should_be_impossible_to_add_customer_network(self):
        assert not self.customer_network.create()
        assert '' in self.customer_network.error['base']
