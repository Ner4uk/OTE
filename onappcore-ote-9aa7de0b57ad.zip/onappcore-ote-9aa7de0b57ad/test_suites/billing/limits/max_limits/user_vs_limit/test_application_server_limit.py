from onapp_helper.br_helper.as_limit import ASLimit
from onapp_helper.server import ApplicationServer
from onapp_helper.user import User
from onapp_helper.billing_plan import BillingPlan
from onapp_helper import test
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.limits
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version >= 5.6,
    reason="Old billing is not supported..."
)
@pytest.mark.incremental
class TestApplicationMaxLimits:
    def setup_class(self):
        test.load_env(use_public_network=True)

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        try:
            self.billing_plan = BillingPlan()
            self.billing_plan.label = self.__name__
            assert self.billing_plan.create()

            self.apps = ApplicationServer()
            self.apps.template.find_any('ApplicationServer')
            self.user = User(bp=self.billing_plan)

            self.as_limit = ASLimit(billing_plan=self.billing_plan)

            self.user.login = 'applicationmaxlimitstest'
            self.user.password = test.generate_password()
            self.user.email = 'user@applicationmaxlimits.test'
            assert self.user.create()
            test.execute_as(self.user.login, self.user.password)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        self.user.delete()
        self.billing_plan.delete()

    @pytest.mark.skipif(
        test.cp_version < 4.2, reason="{0} API version does not support current functionality.".format(
            test.cp_version
        )
    )
    def test_set_0_max_limit(self):
        self.as_limit.limits.limit = 0
        assert self.as_limit.create()

    @pytest.mark.skipif(
        test.cp_version < 4.2, reason="{0} API version does not support current functionality.".format(
            test.cp_version
        )
    )
    def test_should_be_impossible_to_create_application_server(self):
        assert not self.apps.create()
        assert 'Application server limit exceeded' in self.apps.error['base']