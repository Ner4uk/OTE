import pytest
from onapp_helper.br_helper.ISO import ISOBR
from onapp_helper.iso import ISO
from onapp_helper.user import User

from onapp_helper.billing_plan import BillingPlan
from onapp_helper import test


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.limits
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version >= 5.6,
    reason="Old billing is not supported..."
)
class TestISOMaxLimit:
    def setup_class(self):
        try:
            self.billing_plan = BillingPlan()
            self.billing_plan.label = self.__name__
            assert self.billing_plan.create()

            self.iso = ISO()
            self.user = User(bp=self.billing_plan)

            self.iso_br = ISOBR(billing_plan=self.billing_plan)

            self.user.login = 'isomaxlimitstest'
            self.user.password = test.generate_password()
            self.user.email = 'user@isomaxlimits.test'
            assert self.user.create()
            test.execute_as(self.user.login, self.user.password)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        self.user.delete()
        self.billing_plan.delete()

    def test_set_iso_max_limit_as_0(self):
        self.iso_br.limits.limit = 0
        assert self.iso_br.create()

    def test_should_be_impossible_to_upload_iso(self):
        self.iso.label = self.__class__.__name__
        self.iso.make_public = False
        self.iso.min_memory_size = 512
        self.iso.operating_system = 'Linux'
        self.iso.version = 13
        self.iso.file_url = 'http://artfiles.org/linuxmint.com/linuxmint.com/stable/13/linuxmint-13-xfce-dvd-64bit.iso'
        self.iso.operating_system_distro = 'Mint'
        assert not self.iso.create()
        assert 'You have reached your ISO creation limit' in self.iso.error['base']