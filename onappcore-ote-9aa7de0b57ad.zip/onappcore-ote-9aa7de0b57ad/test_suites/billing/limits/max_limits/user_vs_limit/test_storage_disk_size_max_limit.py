# https://onappdev.atlassian.net/browse/CORE-5554
from onapp_helper.br_helper.storage_disk_size import StorageDiskSizeBR
from onapp_helper.br_helper.bsz import BSZBR
from onapp_helper.bsz import BSZ
from onapp_helper.backup import Backup
from onapp_helper.template import Template
from onapp_helper.iso import ISO
from onapp_helper.user import User
from onapp_helper.billing_plan import BillingPlan
from onapp_helper import test
from onapp_helper.server import VirtualServer
import pytest

RESERVED_STORAGE_SIZE = 100 * 1024  # 100MB in KB
STORAGE_DISK_SIZE_LIMIT = 2


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.limits
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version >= 5.6,
    reason="Old billing is not supported..."
)
@pytest.mark.incremental
class TestStorageDiskSizeMaxLimit:
    def setup_class(self):
        test.load_env()

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        try:
            self.billing_plan = BillingPlan()
            self.billing_plan.label = self.__name__
            assert self.billing_plan.create(), self.billing_plan.error

            self.user = User(bp=self.billing_plan)
            self.user.login = 'storagedisksizemaxlimitstest'
            self.user.password = test.generate_password()
            self.user.email = 'user@storagedisksizemaxlimits.test'
            assert self.user.create(), self.user.error
            test.execute_as(self.user.login, self.user.password)

            self.vs = VirtualServer()
            self.vs.label = self.__name__
            assert self.vs.create(), self.vs.error

            self.backup = Backup(self.vs)
            self.template = Template()
            self.iso = ISO()

            for bsz_id in BSZ().get_key_values('id'):
                bsz_br = BSZBR(
                    billing_plan=self.billing_plan,
                    target_id=bsz_id
                )
                bsz_br.limits.limit_backup_disk_size = 0
                bsz_br.limits.limit_backup = 0
                bsz_br.limits.limit_template_disk_size = 0
                bsz_br.limits.limit_template = 0
                assert bsz_br.create(), bsz_br.error

            self.storage_disk_size_br = StorageDiskSizeBR(billing_plan=self.billing_plan)

            self.backups = []
            self.isos = []

            if test.onapp_settings.get().allow_incremental_backups:
                assert test.onapp_settings.set(allow_incremental_backups=False)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        self.user.delete()
        self.billing_plan.delete()

    def test_set_0_max_limit_for_storage_disk_size(self):
        self.storage_disk_size_br.limits.limit = 0
        assert self.storage_disk_size_br.create()

    def test_you_can_not_create_a_backup_if_storage_disk_size_limit_is_0(self):
        backup = Backup(self.vs)
        assert not backup.create()
        assert 'You have exceeded your storage disk size limit' in backup.error['base']

    def test_set_1_max_limit_for_storage_disk_size(self):
        self.storage_disk_size_br.limits.limit = STORAGE_DISK_SIZE_LIMIT
        assert self.storage_disk_size_br.edit()

    def test_create_one_backup(self):
        backup = Backup(self.vs)
        assert backup.create(), backup.error
        self.backups.append(backup)

    def test_create_one_template(self):
        assert self.backups[0].convert(
            label=self.__class__.__name__
        ), self.backups[0].template.error
        self.template.__dict__.update(self.backups[0].template.__dict__)

    def test_exceeding_your_storage_disk_size_limit(self):
        """ CORE-5554. In some cases it is impossible. We reserve 0.1GB of disk space during backup creation, for example:
            Set limit 1GB:
            1) total disk size = 800MB, add 100MB reserved 900 < 1000 so we can create one more backup/template and
                exceed the limit;
            2) total disk size = 990MB, add 100MB reserved 1100 > 1000 so we can not create one more backup/template and
                exceed the limit in real;

        """
        while True:
            backup = Backup(self.vs)
            # Stop doing backups if size > STORAGE_DISK_SIZE_LIMIT + 1
            if not backup.create() or sum(
                    [b.backup_size for b in self.backups]
            ) + self.template.template_size \
                    + RESERVED_STORAGE_SIZE > (
                        STORAGE_DISK_SIZE_LIMIT + 1
            ) * 1048576:  # if limit does not works
                assert 'You have exceeded your storage disk size limit' in backup.error['base']
                break
            self.backups.append(backup)
        total_disk_size = sum(
            [b.backup_size for b in self.backups]
        ) + self.template.template_size + RESERVED_STORAGE_SIZE
        test.log.info(
            'Total backups/templates disk size - {}'.format(total_disk_size)
        )

    ####################################################################################################################
    # Add code to covering both of this cases
    def test_you_can_not_restore_last_backup_if_total_storage_disk_size_more_than_limit(self):
        if (
                    sum([b.backup_size for b in self.backups])
                    + self.template.template_size
        ) > STORAGE_DISK_SIZE_LIMIT * 1048576:
            assert not self.backups[-1].restore()
            assert 'You have reached disk size limit on backup server' in self.backups[-1].error['base']

    def test_you_can_restore_last_backup_if_total_storage_disk_size_less_than_or_equal_to_limit(self):
        if (
                    sum([b.backup_size for b in self.backups])
                    + self.template.template_size
        ) <= STORAGE_DISK_SIZE_LIMIT * 1048576:
            assert self.backups[-1].restore()
    ####################################################################################################################

    def test_you_can_not_create_one_more_backup(self):
        backup = Backup(self.vs)
        assert not backup.create()
        assert 'You have exceeded your storage disk size limit' in backup.error['base']

    def test_you_can_not_convert_backup_to_template(self):
        assert not self.backups[0].convert()
        assert 'You have exceeded your storage disk size limit' in self.backups[0].template.error['base']

    def test_check_limits_for_iso_template(self):
        while sum(
            [
                self.total_size(self.backups, 'backup_size'),
                self.template.template_size,
                self.total_size(self.isos, 'template_size')
            ]
        ) <= STORAGE_DISK_SIZE_LIMIT * 1048576:
            self.iso.label = "{}{}_{}".format(
                self.__class__.__name__, 'ISO', test.time_stamp()
            )
            self.iso.make_public = False
            self.iso.min_memory_size = 512
            self.iso.operating_system = 'Linux'
            self.iso.version = 13
            self.iso.file_url = 'http://artfiles.org/linuxmint.com/linuxmint.com/stable/13/linuxmint-13-xfce-dvd-64bit.iso'
            self.iso.operating_system_distro = 'Mint'
            if self.iso.create():
                self.isos.append(self.iso)
            else:
                test.log.error(
                    "ISO has not been uploaded: {}".format(self.iso.error)
                )
                break

        self.iso.label = "{}{}_{}".format(
            self.__class__.__name__, 'ISO', test.time_stamp()
        )
        assert not self.iso.create()
        assert 'Disk size limit has been exceeded.' in self.iso.error['base']

    @staticmethod
    def total_size(objects, key):
        return sum([o.__dict__[key] for o in objects])
