# https://onappdev.atlassian.net/browse/CORE-5554
from onapp_helper.br_helper.storage_disk_size import StorageDiskSizeBR
from onapp_helper.br_helper.bsz import BSZBR
from onapp_helper.br_helper.backup import BackupBR
from onapp_helper.br_helper.template import TemplateBR
from onapp_helper.backup import Backup
from onapp_helper.template_ova import OVA
from onapp_helper.backup_server import BackupServer
from onapp_helper.user import User
from onapp_helper.billing_plan import BillingPlan
from onapp_helper import test
from onapp_helper.server import VirtualServer
import time
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.limits
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version >= 5.6,
    reason="Old billing is not supported..."
)
@pytest.mark.incremental
class TestMaxBSZLimit:
    def setup_class(self):
        test.load_env()

        if not test.env.backup_servers:
            pytest.skip('There is no backup servers attached to HV/HVZ')
        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        try:
            # ToDo - First of all need to check if Backup server available and ready for backups!!!
            # ToDo - ASAP uncomment and change if needed error messages in asserts
            #  Select BS for OVA
            self.backup_server = BackupServer().get_for_ova()

            self.billing_plan = BillingPlan()
            self.billing_plan.label = self.__name__
            assert self.billing_plan.create()

            self.backup_br = BackupBR(billing_plan=self.billing_plan)
            self.backup_br.limits.limit = 0
            assert self.backup_br.create()

            self.template_br = TemplateBR(billing_plan=self.billing_plan)
            self.template_br.limits.limit = 0
            assert self.template_br.create()

            self.storage_disk_size_br = StorageDiskSizeBR(billing_plan=self.billing_plan)
            self.storage_disk_size_br.limits.limit = 0
            assert self.storage_disk_size_br.create()

            self.user = User(bp=self.billing_plan)
            self.user.login = 'bszmaxlimitstest'
            self.user.password = test.generate_password()
            self.user.email = 'user@bszmaxlimits.test'
            assert self.user.create()
            test.execute_as(self.user.login, self.user.password)

            self.vs = VirtualServer()
            self.vs.label = self.__name__
            assert self.vs.create(), self.vs.error
            self.primary_disk = self.vs.get_primary_disk()

            self.backups = []
            self.templates = []

            self.bsz_br = BSZBR(billing_plan=self.billing_plan, target_id=test.env.backup_servers[0].backup_server_group_id)

            if test.onapp_settings.get().allow_incremental_backups:
                assert test.onapp_settings.set(allow_incremental_backups=False)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        ovas_to_delete = [
            o for o in OVA().get_all() if o.user_id == self.user.id
            ]
        for ova in ovas_to_delete:
            if ova.locked:
                ova.unlock()
            ova.delete()

        test.execute_as(test.login, test.password)
        self.user.delete()
        self.billing_plan.delete()

    def test_set_max_limit_for_backups_as_0(self):
        self.bsz_br.limits.limit_backup = 0
        assert self.bsz_br.create()

    def test_you_can_not_take_a_backup_for_limit_0(self):
        b = Backup(self.vs)
        assert not b.create()
        #assert 'You have reached your backup creation limit' in b.error['base'][0]

    # Billing Backups count limits does not work with autobackups
    # https://onappdev.atlassian.net/browse/CORE-5467
    def test_you_can_take_disk_autobackups_for_limit_0(self):
        backups = self.primary_disk.enable_auto_backups()
        assert len([b for b in backups if b.built and b.initiated != 'manual']) == 4

        # destroy all autobackups
        for b in backups:
            b.delete()
            assert b.transaction_handler('destroy_backup', b.id)

    #TODO Check size limit for autobackups.

    def test_set_max_limit_for_templates_as_0_and_1_for_backups(self):
        self.bsz_br.limits.limit_backup = 1
        self.bsz_br.limits.limit_template = 0
        assert self.bsz_br.edit()

    def test_you_can_not_convert_backup_with_template_limit_0(self):
        b = Backup(self.vs)
        assert b.create()
        self.backups.append(b)
        assert not b.convert()
        #assert 'You have reached your backup creation limit' in b.template.error['base'][0]

    def test_allow_to_create_one_template(self):
        # Allow 1 Template per BSZ.
        self.bsz_br.limits.limit_template = 1
        assert self.bsz_br.edit()

    def test_should_be_impossible_to_create_a_2nd_backup(self):
        b = Backup(self.vs)
        assert not b.create()
        #assert 'You have reached your backup creation limit' in b.error['base'][0]

    def test_check_max_limit_for_template(self):
        # Create 1 Template - should be possible.
        assert self.backups[0].convert(label=self.__class__.__name__), self.backups[0].template.error

        self.templates.append(self.backups[0].template)

        # Create the 2-nd one - should be impossible.
        assert not self.backups[0].convert()
        #assert 'You have reached your template creation limit' in self.backups[0].template.error['base'][0]

    def test_set_max_backups_and_templates_disk_size_limit_as_1GB(self):
        # Reset BR
        self.bsz_br.limits.limit_backup = None
        self.bsz_br.limits.limit_template = None
        # Allow 1GB of backups per BSZ
        self.bsz_br.limits.limit_backup_disk_size = 1
        # Allow 1GB of templates per BSZ
        self.bsz_br.limits.limit_template_disk_size = 1
        assert self.bsz_br.edit()

    def test_exceed_max_limit_for_backup_disk_size(self):
        """ CORE-5554. In some cases it is impossible. We reserve 0.1GB of disk space during backup creation, for example:
            Set limit 1GB:
            1) total disk size = 800MB, add 100MB reserved 900 < 1000 so we can create one more backup/template and
                exceed the limit;
            2) total disk size = 990MB, add 100MB reserved 1100 > 1000 so we can not create one more backup/template and
                exceed the limit in real;

        """
        while True:
            backup = Backup(self.vs)
            if not backup.create() or sum([b.backup_size for b in self.backups]) > 1572864:
                #assert 'You have exceeded your backup disk size creation limit' in backup.error['base']
                break
            self.backups.append(backup)
        test.log.info('***', sum([b.backup_size for b in self.backups]))
        assert sum([b.backup_size for b in self.backups]) > 1048576

    def test_you_can_not_take_a_backup_if_max_limit_exceeded(self):
        b = Backup(self.vs)
        assert not b.create()
        #assert 'You have reached your backup creation limit' in b.error['base'][0]

    def test_exceed_max_limit_for_template_disk_size(self):
        backup = self.backups[0]
        while True:
            if (
                    not backup.convert()
            ) or (
                    sum([t.template_size for t in self.templates]) > 1572864
            ):
                break
            self.templates.append(backup.template)
        test.log.info('***', sum([t.template_size for t in self.templates]))
        assert sum([t.template_size for t in self.templates]) < 1048576

    def test_you_can_not_convert_a_backup_if_max_limit_exceeded(self):
        assert not self.backups[0].convert()
        #assert 'You have reached your template creation limit' in self.backups[0].template.error['base'][0]

    def test_set_0_limit_for_ova_count(self):
        self.bsz_br.limits.limit_ova = 0
        assert self.bsz_br.edit()

    def test_should_be_impossible_to_upload_ova_with_0_limit(self):
        ova = OVA()
        ova.label = self.__class__.__name__
        ova.backup_server_id = self.backup_server.id
        ova.file_url = 'http://templates.repo.onapp.com/ova/centos6.ova'
        ova.operating_system_distro = ova.OPERATING_SYSTEM_DISTROS.rhel
        ova.operating_system = ova.OPERATING_SYSTEMS.linux
        assert not ova.upload()
        assert "You have reached your OVA creation limit" in ova.error["base"]

    def test_should_be_impossible_to_upload_ova_with_total_size_more_than_1_GB(self):
        self.bsz_br.limits.limit_ova = None
        self.bsz_br.limits.limit_ova_disk_size = 1
        assert self.bsz_br.edit()
        ovas = []
        counter = 0
        while True:
            ova = OVA()
            ova.label = self.__class__.__name__ + str(counter)
            ova.backup_server_id = self.backup_server.id
            ova.file_url = 'https://sourceforge.net/projects/virtualappliances/files/Linux/CentOS/CentOS-6.4-i386-minimal.ova'
            ova.operating_system_distro = ova.OPERATING_SYSTEM_DISTROS.rhel
            ova.operating_system = ova.OPERATING_SYSTEMS.linux
            if not ova.upload() or sum([o.template_size for o in ovas]) > 1572864:
                assert "You have reached your OVA Disk Size Max limit" in ova.error["base"]
                break
            ovas.append(ova)
            counter += 1
            time.sleep(30)
        test.log.info('***', sum([o.template_size for o in ovas]))
        assert sum([o.template_size for o in ovas]) > 1048576
        [o.delete() for o in ovas]
