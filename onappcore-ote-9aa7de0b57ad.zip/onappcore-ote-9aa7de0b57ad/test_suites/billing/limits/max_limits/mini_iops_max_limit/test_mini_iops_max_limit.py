from onapp_helper import test

from onapp_helper.br_helper.minIOPS import MinIOPSBR
from onapp_helper.server import VirtualServer
from onapp_helper.user import User
from onapp_helper.billing_plan import BillingPlan
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.limits
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version >= 5.6,
    reason="Old billing is not supported..."
)
class TestMinIOPSMaxLimits:
    def setup_class(self):
        test.ds_types = ['solidfire']
        test.load_env()

        if not test.env.dsz.id or test.env.ds.data_store_type != 'solidfire':
            pytest.skip(
                "There is no SolidFire data store on - {0}.".format(test.host)
            )

        try:
            # Setup
            self.billing_plan = BillingPlan()
            self.billing_plan.label = self.__name__
            assert self.billing_plan.create()

            # Setup for base resources
            self.min_iops_br = MinIOPSBR(
                billing_plan=self.billing_plan,
                target_id=test.env.dsz.id
            )

            # Set free limits for base resources
            self.min_iops_br.limits.limit_free = 0
            self.min_iops_br.limits.limit = 200   # per DS Zone
            self.min_iops_br.prices.price_on = 100
            self.min_iops_br.prices.price_off = 10
            assert self.min_iops_br.create()

            # Create User and VS
            self.user = User(bp=self.billing_plan)
            self.user.login = "miniopsfreelimitstest"
            self.user.password = test.generate_password()
            self.user.email = 'user@miniopsfreelimitstest.test'
            assert self.user.create()
            # Login as new user
            test.execute_as(self.user.login, self.user.password)

            self.vs = VirtualServer()
            self.vs.rate_limit = 0  #  Unlimited
            self.vs.label = self.__name__
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        if self.vs.locked:
            self.vs.unlock()
        self.vs.delete()
        self.user.delete()
        self.billing_plan.delete()

    def test_should_be_impossible_to_create_vs_with_min_iops_limit_exceded(self):
        self.vs.primary_disk_min_iops = 101
        self.vs.swap_disk_min_iops = 101
        assert not self.vs.create()
        assert "Min iops billing minIOPS limit exceeded" in self.vs.error['disks']

    def test_should_be_possible_to_create_vs_with_no_limit_exceeding(self):
        self.vs.primary_disk_min_iops = 100
        self.vs.swap_disk_min_iops = 100
        assert self.vs.create(), self.vs.error

    def test_should_be_impossible_to_edit_primary_disk_with_min_iops_limit_exceded(self):
        primary_disk = self.vs.get_primary_disk()
        primary_disk.min_iops = 101
        assert not primary_disk.edit()
        assert "billing minIOPS limit exceeded" in primary_disk.error['min_iops']

    def test_should_be_impossible_to_edit_swap_disk_with_min_iops_limit_exceded(self):
        swap_disk = self.vs.get_swap_disk()
        swap_disk.min_iops = 101
        assert not swap_disk.edit()
        assert "billing minIOPS limit exceeded" in swap_disk.error['min_iops']