import pytest
from onapp_helper import test

from onapp_helper.br_helper.hvz import HVZBR
from onapp_helper.server import VirtualServer
from onapp_helper.user import User
from onapp_helper.billing_plan import BillingPlan


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.limits
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version >= 5.6,
    reason="Old billing is not supported..."
)
class TestHVZMaxLimits:
    def setup_class(self):
        test.load_env()

        try:
            # Setup
            self.billing_plan = BillingPlan()
            self.billing_plan.label = self.__name__
            assert self.billing_plan.create()

            # Setup for base resources
            self.hvz_br = HVZBR(billing_plan=self.billing_plan, target_id=test.env.hvz.id)
            assert self.hvz_br.create()

            # Create User and VS
            self.user = User(bp=self.billing_plan)
            self.user.login = "hvzmaxlimitstest"
            self.user.password = test.generate_password()
            self.user.email = 'user@hvzmaxlimitstest.test'
            assert self.user.create()
            # Login as new user
            test.execute_as(self.user.login, self.user.password)

            self.vs = VirtualServer()
            self.vs.rate_limit = 0  #  Unlimited
            self.vs.label = self.__name__
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        self.user.delete()
        self.billing_plan.delete()

    def test_set_cpu_cores_max_limit_as_1_cpus(self):
        self.hvz_br.reset()
        self.hvz_br.limits.limit_cpu = 1
        self.hvz_br.edit()

    def test_should_be_impossible_to_create_vs_with_2_cores(self):
        self.vs.cpus = 2
        assert not self.vs.create()
        assert 'CPUs must be less than or equal to 1 to meet billing requirements' in self.vs.error['cpus']

    def test_set_cpu_shares_max_limit_as_1_percent(self):
        self.hvz_br.reset()
        self.hvz_br.limits.limit_cpu_share = 1
        self.hvz_br.edit()

    def test_should_be_impossible_to_create_vs_with_2_percent(self):
        self.vs.cpu_shares = 2
        assert not self.vs.create()
        assert 'CPU shares must be less than or equal to 1 to meet billing requirements' in self.vs.error['cpu_shares']

    def test_set_memory_max_limit_as_512MB(self):
        self.hvz_br.reset()
        self.hvz_br.limits.limit_memory = 512
        self.hvz_br.edit()

    def test_should_be_impossible_to_create_vs_with_more_than_513MB_of_RAM(self):
        self.vs.memory = 513
        assert not self.vs.create()
        assert 'Memory must be less than or equal to 512 MB to meet billing requirements' in self.vs.error['memory']

    def test_create_a_vs(self):
        self.hvz_br.reset()
        assert self.hvz_br.edit()
        self.vs.cpus = 1
        self.vs.cpu_shares = 1
        self.vs.memory = 512
        assert self.vs.create(), self.vs.error

    def test_set_max_cpus_as_2(self):
        self.hvz_br.limits.limit_cpu = 2
        assert self.hvz_br.edit()

    def test_should_be_impossible_to_set_3_cores(self):
        self.vs.cpus = 3
        assert not self.vs.edit()
        print(self.vs.error)

    def test_set_max_cpu_share_as_2(self):
        self.hvz_br.reset()
        self.hvz_br.limits.limit_cpu_share = 2
        assert self.hvz_br.edit()

    def test_should_be_impossible_to_set_3_cpu_shares(self):
        self.vs.cpus = 1
        self.vs.cpu_shares = 3
        assert not self.vs.edit()
        print(self.vs.error)

    def test_set_max_memory_as_512(self):
        self.hvz_br.reset()
        self.hvz_br.limits.limit_memory = 512
        assert self.hvz_br.edit()

    def test_should_be_impossible_to_set_513_for_ram(self):
        self.vs.cpu_shares = 1
        self.vs.memory = 513
        assert not self.vs.edit()
        print(self.vs.error)