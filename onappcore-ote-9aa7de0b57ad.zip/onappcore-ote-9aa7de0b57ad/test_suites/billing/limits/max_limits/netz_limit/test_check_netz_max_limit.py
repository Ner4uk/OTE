from onapp_helper import test

from onapp_helper.br_helper.ntz import NTZBR
from onapp_helper.server import VirtualServer
from onapp_helper.user import User
from onapp_helper.billing_plan import BillingPlan
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.limits
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version >= 5.6,
    reason="Old billing is not supported..."
)
class TestNTZMaxLimits:
    def setup_class(self):
        test.load_env()

        if not test.env.netz.id:
            pytest.skip("No available network zones.")

        try:
            # Setup
            self.billing_plan = BillingPlan()
            self.billing_plan.label = self.__name__
            assert self.billing_plan.create(), self.billing_plan.error

            # Setup for base resources
            self.ntz_br = NTZBR(billing_plan=self.billing_plan, target_id=test.env.netz.id)
            assert self.ntz_br.create(), self.ntz_br.error

            # Create User and VS
            self.user = User(bp=self.billing_plan)
            self.user.login = "ntzmaxlimitstest"
            self.user.password = test.generate_password()
            self.user.email = 'user@ntzmaxlimitstest.test'
            assert self.user.create(), self.user.error
            # Login as new user
            test.execute_as(self.user.login, self.user.password)

            self.vs = VirtualServer()
            self.vs.rate_limit = 0  #  Unlimited
            self.vs.label = self.__name__
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        test.clean_up_resources(('user', 'billing_plan'), self)

    def test_set_max_ip_address_limit_as_0(self):
        self.ntz_br.reset()
        self.ntz_br.limits.limit_ip = 0
        assert self.ntz_br.edit(), self.ntz_br.error

    def test_should_be_impossible_to_create_vs(self):
        #time.sleep(10)
        assert not self.vs.create()
        # Expected Error Message - eem
        eem = "IP Address can't be used, because you have reached your billing IP address limit"
        assert [e for e in self.vs.error['network_interfaces'] if eem in e]

    def test_set_max_port_speed_as_4(self):
        self.ntz_br.reset()
        self.ntz_br.limits.limit_rate = 4
        assert self.ntz_br.edit(), self.ntz_br.error

    def test_should_be_impossible_to_create_vs_with_port_speed_equal_5(self):
        self.vs.rate_limit = 5
        #time.sleep(10)
        assert not self.vs.create()
        eem1 = 'Port Speed Limit set in Billing Plan exceeded'
        assert [e for e in self.vs.error['network_interfaces'] if eem1 in e]
        eem2 = 'billing limit exceeded'
        assert [e for e in self.vs.error['primary_network_group_id'] if eem2 in e]

    def test_set_max_port_speed_as_1(self):
        self.ntz_br.reset()
        self.ntz_br.limits.limit_rate = 1
        assert self.ntz_br.edit(), self.ntz_br.error

    def test_should_be_impossible_to_create_vs_with_unlimited_port_speed(self):
        self.vs.rate_limit = 0
        #time.sleep(10)
        assert not self.vs.create()
        eem1 = 'Port Speed Limit set in Billing Plan exceeded'
        assert [e for e in self.vs.error['network_interfaces'] if eem1 in e]
        eem2 = 'billing limit exceeded'
        assert [e for e in self.vs.error['primary_network_group_id'] if eem2 in e]
