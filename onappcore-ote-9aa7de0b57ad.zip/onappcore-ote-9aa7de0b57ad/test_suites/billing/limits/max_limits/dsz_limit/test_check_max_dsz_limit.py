import pytest
from onapp_helper import test

from onapp_helper.br_helper.dsz import DSZBR
from onapp_helper.server import VirtualServer
from onapp_helper.user import User
from onapp_helper.billing_plan import BillingPlan


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.limits
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version >= 5.6,
    reason="Old billing is not supported..."
)
class TestDSZMaxLimits:
    def setup_class(self):
        test.load_env()

        try:
            # Setup
            self.billing_plan = BillingPlan()
            self.billing_plan.label = self.__name__
            assert self.billing_plan.create()

            # Setup for base resources
            self.dsz_br = DSZBR(billing_plan=self.billing_plan, target_id=test.env.dsz.id)
            assert self.dsz_br.create()

            # Create User and VS
            self.user = User(bp=self.billing_plan)
            self.user.login = "dszmaxlimitstest"
            self.user.password = test.generate_password()
            self.user.email = 'user@dszmaxlimitstest.test'
            assert self.user.create()
            # Login as new user
            test.execute_as(self.user.login, self.user.password)

            self.vs = VirtualServer()
            self.vs.rate_limit = 0  #  Unlimited
            self.vs.label = self.__name__
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        attributes = (
            'user',
            'billing_plan'
        )
        test.clean_up_resources(attributes, self)

    def test_set_max_disk_size_as_0(self):
        self.dsz_br.limits.limit = 0
        self.dsz_br.edit()

    def test_check_that_you_can_not_create_vs(self):
        assert not self.vs.create()
        assert 'billing limit exceeded for this data store zone' in self.vs.error['primary_disk_size']
        assert 'Size billing limit exceeded for this data store zone' in self.vs.error['disks']
        assert 'billing limit exceeded for this data store zone' in self.vs.error['swap_disk_size']
