import pytest
from onapp_helper import test

from onapp_helper.br_helper.ntz import NTZBR
from onapp_helper.server import VirtualServer
from onapp_helper.user import User
from onapp_helper.billing_plan import BillingPlan
# Stats
from onapp_helper.stats.vm_stat import VmStat
from onapp_helper.ip_address import IpAddress

#from onapp_helper. import UserStats


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.limits
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version >= 5.6,
    reason="Old billing is not supported..."
)
class TestNTZFreeLimits:
    def setup_class(self):
        test.load_env()
        test.run_at(minutes=40)
        test.cp.generate_10MB_test_file()

        try:
            # Setup
            self.billing_plan = BillingPlan()
            self.billing_plan.label = self.__name__
            assert self.billing_plan.create()

            # Setup for base resources
            self.ntz_br = NTZBR(billing_plan=self.billing_plan, target_id=test.env.netz.id)

            # Create User and VS
            self.user = User(bp=self.billing_plan)
            self.user.login = "ntzfreelimitstest"
            self.user.password = test.generate_password()
            self.user.email = 'user@ntzfreelimitstest.test'
            assert self.user.create()
            # Login as new user
            test.execute_as(self.user.login, self.user.password)

            self.vs = VirtualServer()
            self.vs.rate_limit = 0  #  Unlimited
            self.vs.label = self.__name__
            assert self.vs.create(), self.vs.error

            # Set free limits for base resources
            self.ntz_br.limits.limit_ip_free = 1
            self.ntz_br.prices.price_ip_on = 100
            self.ntz_br.prices.price_ip_off = 2
            self.ntz_br.limits.limit_rate_free = int(self.vs.port_speed() / 2)
            self.ntz_br.prices.price_rate_on = 100
            self.ntz_br.prices.price_rate_off = 2
            self.ntz_br.limits.limit_data_received_free = 1
            self.ntz_br.prices.price_data_received = 100
            self.ntz_br.limits.limit_data_sent_free = 1
            self.ntz_br.prices.price_data_sent = 100
            assert self.ntz_br.create()

            self.vm_stat = VmStat(parent_obj=self.vs)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        attributes = (
            'vs',
            'user',
            'billing_plan',
        )
        test.clean_up_resources(attributes, self)

    def test_download_2GB_of_data(self):
        for i in range(20):
            self.vs.download_100MB_of_data()

    def test_add_one_more_ip_address_to_vs(self):
        ip_address = IpAddress(parent_obj=test.env.net).get_free()

        if test.cp_version <= 5.3:
            assert self.vs.ip_address_join.assign_to_server(
                address=ip_address.address
            ), self.vs.ip_address_join.error
        else:
            assert self.vs.ip_address_join.assign_to_server(
                ip_address_id=ip_address.id
            ), self.vs.ip_address_join.error

    def test_get_stat(self):
        self.vm_stat.stats_waiter()
        self.vm_stat.get_hourly_stat_for_the_last_hour()
        test.update_object(self.vs)

    def test_hourly_price_on_should_be_50100(self):
        assert float(self.vs.price_per_hour) == \
               self.vs.price_on_calculated(ntz_br=self.ntz_br) == 50100

    def test_hourly_price_off_should_be_1002(self):
        assert float(self.vs.price_per_hour_powered_off) == \
               self.vs.price_off_calculated(ntz_br=self.ntz_br) == 1002

    def test_ip_address_cost(self):
        if self.vs.booted:
            expected = self.vs.ip_price_on
        else:
            expected = self.vs.ip_price_off

        # expected = price * (self.vm_stat.vm_last_hour_stat.ip_addresses.value - self.ntz_br.own_limits.limit_ip_free)
        actual = self.vm_stat.vm_last_hour_stat.ip_addresses.cost
        print('Expected: {}'.format(expected))
        print('Actual: {}'.format(actual))
        assert actual == expected

    def test_rate_cost(self):
        if self.vs.booted:
            expected = self.vs.rate_limit_price_on
        else:
            expected = self.vs.rate_limit_price_off
        # rate_value = self.vm_stat.vm_last_hour_stat.rate.value
        # if not rate_value: # 0
        #     rate_value = self.vs.port_speed()
        # expected = price * (rate_value - self.ntz_br.own_limits.limit_rate_free)
        actual = self.vm_stat.vm_last_hour_stat.rate.cost
        print('Expected: {}'.format(expected))
        print('Actual: {}'.format(actual))
        assert actual == expected

    def test_data_received_cost(self):
        data_received = self.vm_stat.vm_last_hour_stat.data_received.value / 1048576
        calculated_cost = 0.0
        if data_received > self.ntz_br.limits.limit_data_received_free:
            calculated_cost = float(
                (
                    data_received - self.ntz_br.limits.limit_data_received_free
                ) * self.ntz_br.prices.price_data_received
            )
        print(
            'Data received cost: \n\t calculated - {}\n\t real - {}'.format(
                calculated_cost, self.vm_stat.vm_last_hour_stat.data_received.cost
            )
        )
        assert calculated_cost - (calculated_cost * 0.2) <= \
               self.vm_stat.vm_last_hour_stat.data_received.cost <=  \
               calculated_cost + (calculated_cost * 0.2)

    def test_data_sent_cost(self):
        data_sent = self.vm_stat.vm_last_hour_stat.data_sent.value / 1048576
        calculated_cost = 0.0
        if data_sent > self.ntz_br.limits.limit_data_sent_free:
            calculated_cost = float(
                (
                    data_sent - self.ntz_br.limits.limit_data_sent_free
                ) * self.ntz_br.prices.price_data_sent
            )
        print(
            'Data sent cost: \n\t calculated - {}\n\t real - {}'.format(
                calculated_cost, self.vm_stat.vm_last_hour_stat.data_sent.cost
            )
        )
        assert calculated_cost - (calculated_cost * 0.2) <= \
               self.vm_stat.vm_last_hour_stat.data_sent.cost <= \
               calculated_cost + (calculated_cost * 0.2)
