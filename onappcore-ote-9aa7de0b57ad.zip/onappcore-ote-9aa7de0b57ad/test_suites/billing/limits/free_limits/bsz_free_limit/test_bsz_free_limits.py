import pytest

from onapp_helper import test
from onapp_helper.backup import Backup
from onapp_helper.billing_plan import BillingPlan
from onapp_helper.br_helper.backup import BackupBR
from onapp_helper.br_helper.bsz import BSZBR
from onapp_helper.br_helper.storage_disk_size import StorageDiskSizeBR
from onapp_helper.br_helper.template import TemplateBR
import time
from onapp_helper.template import Template
from onapp_helper.template_ova import OVA
from onapp_helper.backup_server import BackupServer
from onapp_helper.user import User
from onapp_helper.server import VirtualServer

# Stats
from onapp_helper.stats.user_stats import UserStats


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.limits
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version >= 5.6,
    reason="Old billing is not supported..."
)
@pytest.mark.incremental
class TestBSZFreeLimits:
    def setup_class(self):
        test.load_env()
        test.run_at(minutes=40)

        if not test.env.backup_servers:
            pytest.skip('There is no backup servers attached to HV/HVZ')

        try:
            # ToDo - First of all need to check if Backup server available and ready for backups!!!
            #  Select BS for OVA
            self.backup_server = BackupServer().get_for_ova()

            # Setup
            self.billing_plan = BillingPlan()
            self.billing_plan.label = self.__name__
            assert self.billing_plan.create()

            #  Setup for base resources
            self.bsz_br = BSZBR(
                billing_plan=self.billing_plan,
                target_id=test.env.backup_servers[0].backup_server_group_id
            )
            self.storage_disk_size_br = StorageDiskSizeBR(billing_plan=self.billing_plan)
            self.template_br = TemplateBR(billing_plan=self.billing_plan)
            self.backup_br = BackupBR(billing_plan=self.billing_plan)

            # Set free limits for base resources
            self.storage_disk_size_br.limits.limit = 0
            self.storage_disk_size_br.limits.limit_free = 0
            self.storage_disk_size_br.prices.price = 0
            assert self.storage_disk_size_br.create()

            self.template_br.limits.limit = 0
            self.template_br.limits.limit_free = 0
            self.template_br.prices.price = 0
            assert self.template_br.create()

            self.backup_br.limits.limit = 0
            self.backup_br.limits.limit_free = 0
            self.backup_br.prices.price = 0
            assert self.backup_br.create()

            self.bsz_br.limits.limit_template_free = 1
            self.bsz_br.limits.limit_backup_free = 1
            self.bsz_br.limits.limit_ova_free = 1
            self.bsz_br.limits.limit_backup_disk_size_free = 1
            self.bsz_br.limits.limit_template_disk_size_free = 1
            self.bsz_br.limits.limit_ova_disk_size_free = 1
            self.bsz_br.prices.price_template = 100
            self.bsz_br.prices.price_backup = 100
            self.bsz_br.prices.price_ova = 100
            assert self.bsz_br.create()

            # Create User and VS
            self.user = User(bp=self.billing_plan)
            self.user.login = "bszfreelimitstest"
            self.user.password = test.generate_password()
            self.user.email = 'user@bszfreelimitstest.test'
            assert self.user.create()
            # Login as new user
            test.execute_as(self.user.login, self.user.password)

            self.vs = VirtualServer()
            self.vs.rate_limit = 0  #  Unlimited
            self.vs.label = self.__name__
            assert self.vs.create(), self.vs.error

            self.template = Template()

            self.backups = []
            self.templates = []
            self.ovas = []

            # Better with normal backups
            if test.onapp_settings.get().allow_incremental_backups:
                assert test.onapp_settings.set(allow_incremental_backups=False)
            self.user_stats = UserStats(self.user)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        ovas_to_delete = [
            o for o in OVA().get_all() if o.user_id == self.user.id
            ]
        for ova in ovas_to_delete:
            if ova.locked:
                ova.unlock()
            ova.delete()

        test.execute_as(test.login, test.password)
        attributes = (
            'vs',
            'user',
            'billing_plan'
        )
        test.clean_up_resources(attributes, self)

    def test_create_backups_to_reach_1GB_disk_size_limit(self):
        while True:
            backup = Backup(self.vs)
            backup.create()
            assert backup.backup_server_id
            self.backups.append(backup)
            if sum([b.backup_size for b in self.backups]) > 1048576:
                break

    def test_create_templates_to_reach_1GB_disk_size_limit(self):
        backup = self.backups[0]
        # Check that impossible to create backups with more than 1GB total size.
        template_count = 1
        while True:
            assert backup.convert(
                label=self.__class__.__name__ + str(template_count)
            ), backup.template.error
            template_count += 1
            self.templates.append(backup.template)
            if sum([b.template_size for b in self.templates]) > 1048576:
                break

    def test_upload_ovas_to_reach_1GB_disk_size_limit(self):
        counter = 0
        while True:
            ova = OVA()
            ova.label = self.__class__.__name__ + str(counter)
            ova.backup_server_id = self.backup_server.id
            ova.file_url = 'http://templates.repo.onapp.com/ova/centos6.ova'
            ova.operating_system_distro = ova.OPERATING_SYSTEM_DISTROS.rhel
            ova.operating_system = ova.OPERATING_SYSTEMS.linux
            assert ova.upload(), ova.error
            self.ovas.append(ova)
            if sum([o.template_size for o in self.ovas]) > 1572864:
                break
            counter += 1
            time.sleep(30)
        test.log.info('***{}'.format(sum([o.template_size for o in self.ovas])))
        assert sum([o.template_size for o in self.ovas]) > 1048576

    def test_get_stat(self):
        self.user_stats.stats_waiter()
        self.user_stats.get_user_stat_for_the_last_hour()

    def test_backup_count_cost(self):
        assert self.user_stats.backup_count_cost == float(
            (
                len(self.backups) - self.bsz_br.limits.limit_backup_free
            ) * self.bsz_br.prices.price_backup
        )

    def test_template_count_cost(self):
        assert self.user_stats.template_count_cost == float(
            (
                len(self.templates) - self.bsz_br.limits.limit_template_free
            ) * self.bsz_br.prices.price_template
        )

    def test_backup_disk_size_cost(self):
        total_bu_size = sum([b.backup_size for b in self.backups])
        test.log.info("Total_bu_size - {0}".format(total_bu_size))
        total_backup_disk_size_in_gb = total_bu_size / 1048576.0
        assert round(self.user_stats.backup_disk_size_cost, 2) == round(
            float(
                (total_backup_disk_size_in_gb - self.bsz_br.limits.limit_backup_disk_size_free) *
                self.bsz_br.prices.price_backup_disk_size
            ), 2
        )

    def test_template_disk_size_cost(self):
        total_template_size = sum([t.template_size for t in self.templates])
        test.log.info("Total_template_size - {0}".format(total_template_size))
        total_template_disk_size_in_gb = total_template_size / 1048576.0
        assert round(self.user_stats.template_disk_size_cost, 2) == round(
            float(
                (total_template_disk_size_in_gb - self.bsz_br.limits.limit_template_disk_size_free) *
                self.bsz_br.prices.price_template_disk_size
            ), 2
        )

    def test_ova_count_cost(self):
        assert self.user_stats.ova_count_cost == float(
            (
                len(self.ovas) - self.bsz_br.limits.limit_ova_free
            ) * self.bsz_br.prices.price_ova
        )

    def test_ova_disk_size_cost(self):
        total_ova_size = sum([ova.template_size for ova in self.ovas])
        test.log.info("Total_ova_size - {0}".format(total_ova_size))
        total_ova_disk_size_in_gb = total_ova_size / 1048576.0
        assert round(self.user_stats.ova_size_cost, 2) == round(
            float(
                (total_ova_disk_size_in_gb - self.bsz_br.limits.limit_ova_disk_size_free) *
                self.bsz_br.prices.price_ova_disk_size
            ), 2
        )

    def test_backup_cost_should_be_0(self):
        assert self.user_stats.backup_cost == 0.0

    def test_template_cost_should_be_0(self):
        assert self.user_stats.template_cost == 0.0

    def test_storage_disk_size_cost_should_be_0(self):
        assert self.user_stats.storage_disk_size_cost == 0.0

    # def test_delete_ova_files(self):
    #     assert False not in [o.delete_ova_files() for o in self.ovas]
    #
    # def test_get_a_new_stat(self):
    #     self.user_stats.stats_waiter()
    #     self.user_stats.get_user_stat_for_the_last_hour()