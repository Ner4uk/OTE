from onapp_helper import test
from onapp_helper.billing_plan import BillingPlan
from onapp_helper.br_helper.customer_network import CustomerNetworkBR
from onapp_helper.customer_network import CustomerNetwork
from onapp_helper.user import User

# Stats
from onapp_helper.stats.user_stats import UserStats
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.limits
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version >= 5.3, reason="Deprecated functionality")
class TestCustomerNetworkFreeLimit:
    def setup_class(self):
        test.load_env()

        if not test.env.hv.id:
            pytest.skip("There is no vmware hypervisor on this cloud")

        test.run_at(minutes=40)

        try:
            self.billing_plan = BillingPlan()
            self.billing_plan.label = self.__name__
            assert self.billing_plan.create()

            self.user = User(bp=self.billing_plan)

            self.customer_network_br = CustomerNetworkBR(billing_plan=self.billing_plan)

            self.user.login = 'customnetworkfreelimitstest'
            self.user.password = test.generate_password()
            self.user.email = 'user@customnetworkfreelimitstest.test'
            assert self.user.create()
            self.customer_network = CustomerNetwork(self.user)
            test.execute_as(self.user.login, self.user.password)

            self.customer_network_br.limits.limit_free = 1
            self.customer_network_br.prices.price = 100
            assert self.customer_network_br.create()
            self.user_stats = UserStats(self.user)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        self.user.delete()
        self.billing_plan.delete()

    def test_add_customer_network(self):
        assert self.customer_network.create()

    def test_get_stat(self):
        self.user_stats.stats_waiter()
        self.user_stats.get_user_stat_for_the_last_hour()

    def test_customer_network_cost_should_be_0(self):
        assert self.user_stats.customer_network_cost == float(
            (1 - self.customer_network_br.limits.limit_free) * self.customer_network_br.prices.price
        )