import pytest

from onapp_helper import test
from onapp_helper.server import VirtualServer, ApplicationServer
from onapp_helper.autoscaling import MemoryUp
from onapp_helper.billing_plan import BillingPlan
from onapp_helper.br_helper.vm_monit import VmMonitBR
from onapp_helper.user import User

# Stats
from onapp_helper.stats.user_stats import UserStats


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.limits
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version >= 5.6,
    reason="Old billing is not supported..."
)
@pytest.mark.incremental
class TestAutoscalingMaxLimit:
    def setup_class(self):
        test.load_env()

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        test.run_at(minutes=40)

        try:
            self.billing_plan = BillingPlan()
            self.billing_plan.label = self.__name__
            assert self.billing_plan.create()

            self.vs = VirtualServer()
            self.apps = ApplicationServer()
            self.user = User(bp=self.billing_plan)

            self.vm_monit_br = VmMonitBR(billing_plan=self.billing_plan)

            self.user.login = 'autoscalingfreelimitstest'
            self.user.password = test.generate_password()
            self.user.email = 'user@autoscalingfreelimits.test'
            assert self.user.create(), self.user.error
            test.execute_as(self.user.login, self.user.password)
            self.vs.label = self.__name__
            assert self.vs.create(), self.vs.error
            assert self.vs.autoscale_enable(), self.vs.error
            self.memory_autoscaling_up = MemoryUp(self.vs)
            self.vm_monit_br.limits.limit_free = 1
            self.vm_monit_br.prices.price = 100
            assert self.vm_monit_br.create(), self.vm_monit_br.error
            self.user_stats = UserStats(self.user)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        self.user.delete()
        self.billing_plan.delete()

    def test_set_memory_up(self):
        self.memory_autoscaling_up.enabled = 1
        self.memory_autoscaling_up.adjust_units = 128
        self.memory_autoscaling_up.for_minutes = 5
        self.memory_autoscaling_up.limit_trigger = 10
        self.memory_autoscaling_up.up_to = 1024
        assert self.memory_autoscaling_up.create(), self.memory_autoscaling_up.error

    def test_get_stat(self):
        self.user_stats.stats_waiter()
        self.user_stats.get_user_stat_for_the_last_hour()

    def test_monit_cost_should_be_0(self):
        assert self.user_stats.monit_cost == float(
            (1 - self.vm_monit_br.limits.limit_free) * self.vm_monit_br.prices.price
        )
