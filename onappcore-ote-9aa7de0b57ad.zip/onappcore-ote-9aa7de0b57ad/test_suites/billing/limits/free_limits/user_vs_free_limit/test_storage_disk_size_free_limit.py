import pytest

from onapp_helper import test
from onapp_helper.backup import Backup
from onapp_helper.billing_plan import BillingPlan
from onapp_helper.br_helper.backup import BackupBR
from onapp_helper.br_helper.bsz import BSZBR
from onapp_helper.br_helper.storage_disk_size import StorageDiskSizeBR
from onapp_helper.br_helper.template import TemplateBR
from onapp_helper.template import Template
from onapp_helper.user import User
from onapp_helper.server import VirtualServer

# Stats
from onapp_helper.stats.user_stats import UserStats


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.limits
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version >= 5.6,
    reason="Old billing is not supported..."
)
@pytest.mark.incremental
class TestCheckStorageDiskSizeAndBackupTemplatesFreeLimits:
    def setup_class(self):
        test.load_env()

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        test.run_at(minutes=40)

        try:
            # Setup
            self.billing_plan = BillingPlan()
            self.billing_plan.label = self.__name__
            assert self.billing_plan.create()

            # Setup for base resources
            self.storage_disk_size_br = StorageDiskSizeBR(billing_plan=self.billing_plan)
            self.template_br = TemplateBR(billing_plan=self.billing_plan)
            self.backup_br = BackupBR(billing_plan=self.billing_plan)
            self.bsz_br = BSZBR(billing_plan=self.billing_plan, target_id=test.env.backup_servers[0].backup_server_group_id)

            # Set free limits for base resources
            self.storage_disk_size_br.limits.limit_free = 1
            self.storage_disk_size_br.prices.price = 100
            assert self.storage_disk_size_br.create()

            self.template_br.limits.limit_free = 1
            self.template_br.prices.price = 100
            assert self.template_br.create()

            self.backup_br.limits.limit_free = 1
            self.backup_br.prices.price = 100
            assert self.backup_br.create()

            # Deny using BSZ for backups/templates
            self.bsz_br.limits.limit_template = 0
            self.bsz_br.limits.limit_backup = 0
            self.bsz_br.limits.limit_backup_disk_size = 0
            self.bsz_br.limits.limit_template_disk_size = 0
            assert self.bsz_br.create()

            # Create User and VS
            self.user = User(bp=self.billing_plan)
            self.user.login = "storagefreelimitstest"
            self.user.password = test.generate_password()
            self.user.email = 'user@storagefreelimitstest.test'
            assert self.user.create()
            # Login as new user
            test.execute_as(self.user.login, self.user.password)

            self.vs = VirtualServer()
            self.vs.rate_limit = 0  #  Unlimited
            self.vs.label = self.__name__
            assert self.vs.create(), self.vs.error

            self.template = Template()

            self.backups = []

            # Better with normal backups
            if test.onapp_settings.get().allow_incremental_backups:
                assert test.onapp_settings.set(allow_incremental_backups=False)
            self.user_stats = UserStats(self.user)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        attributes = (
            'vs',
            'user',
            'billing_plan'
        )
        test.clean_up_resources(attributes, self)

    def test_create_backups_to_reach_free_disk_size_limit(self):
        while True:
            backup = Backup(self.vs)
            backup.create()
            self.backups.append(backup)
            if sum([b.backup_size for b in self.backups]) > 1048576:
                break

    def test_create_template(self):
        assert self.backups[0].convert(
            label=self.__class__.__name__
        ), self.backups[0].template.error
        self.template.__dict__.update(self.backups[0].template.__dict__)

    def test_get_stat(self):
        self.user_stats.stats_waiter()
        self.user_stats.get_user_stat_for_the_last_hour()

    #  User VS limits
    def test_backup_cost(self):
        assert self.user_stats.backup_cost == float(
            (len(self.backups) - self.backup_br.limits.limit_free) * self.backup_br.prices.price
        )

    def test_template_cost(self):
        assert self.user_stats.template_cost == float(
            (1 - self.template_br.limits.limit_free) * self.template_br.prices.price
        )

    def test_storage_disk_size_cost(self):
        total_bu_size = sum([b.backup_size for b in self.backups])
        test.log.info("Total_bu_size - {0}".format(total_bu_size))
        total_storage_disk_size_in_GB = (total_bu_size + self.template.template_size) / 1048576.0
        assert round(self.user_stats.storage_disk_size_cost, 2) == round(
            float(
                (total_storage_disk_size_in_GB - self.storage_disk_size_br.limits.limit_free) *
                self.storage_disk_size_br.prices.price
            ), 2
        )

    # BSZ Limits
    def test_backup_count_cost_should_be_0(self):
        assert self.user_stats.backup_count_cost == 0.0

    def test_backup_disk_size_cost_should_be_0(self):
        assert self.user_stats.backup_disk_size_cost == 0.0

    def test_template_count_cost_should_be_0(self):
        assert self.user_stats.template_count_cost == 0.0

    def test_template_disk_size_cost_should_be_0(self):
        assert self.user_stats.template_disk_size_cost == 0.0