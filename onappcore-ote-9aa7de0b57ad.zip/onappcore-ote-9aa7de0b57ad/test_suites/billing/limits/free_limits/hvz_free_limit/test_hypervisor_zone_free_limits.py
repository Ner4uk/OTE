import pytest
from onapp_helper import test

from onapp_helper.br_helper.hvz import HVZBR
from onapp_helper.server import VirtualServer
from onapp_helper.user import User
from onapp_helper.billing_plan import BillingPlan
# Stats
from onapp_helper.stats.vm_stat import VmStat
#from onapp_helper. import UserStats


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.limits
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version >= 5.6,
    reason="Old billing is not supported..."
)
class TestHVZFreeLimits:
    def setup_class(self):
        test.load_env()
        test.run_at(minutes=40)

        try:
            # Setup
            self.billing_plan = BillingPlan()
            self.billing_plan.label = self.__name__
            assert self.billing_plan.create()

            # Setup for base resources
            self.hvz_br = HVZBR(billing_plan=self.billing_plan, target_id=test.env.hvz.id)

            # Create User and VS
            self.user = User(bp=self.billing_plan)
            self.user.login = "hvzfreelimitstest"
            self.user.password = test.generate_password()
            self.user.email = 'user@hvzfreelimitstest.test'
            assert self.user.create()
            # Login as new user
            test.execute_as(self.user.login, self.user.password)

            self.vs = VirtualServer()
            self.vs.rate_limit = 0  #  Unlimited
            self.vs.label = self.__name__
            self.vs.cpus = 2
            self.vs.memory = 512
            self.vs.cpu_shares = 50
            assert self.vs.create(), self.vs.error

            # Set free limits for base resources
            self.hvz_br.limits.limit_free_cpu = self.vs.cpus - 1
            self.hvz_br.prices.price_on_cpu = 100
            self.hvz_br.prices.price_off_cpu = 2
            self.hvz_br.limits.limit_free_cpu_share = self.vs.cpu_shares
            self.hvz_br.prices.price_on_cpu_share = 100
            self.hvz_br.prices.price_off_cpu_share = 2
            self.hvz_br.limits.limit_free_memory = self.vs.memory - 256
            self.hvz_br.prices.price_on_memory = 100
            self.hvz_br.prices.price_off_memory = 2
            assert self.hvz_br.create()

            self.vm_stat = VmStat(parent_obj=self.vs)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        if self.vs.locked:
            self.vs.unlock()
        self.vs.delete()
        self.user.delete()
        self.billing_plan.delete()

    def test_get_stat(self):
        self.vm_stat.stats_waiter()
        self.vm_stat.get_hourly_stat_for_the_last_hour()
        test.update_object(self.vs)

    def test_check_hourly_price_on(self):
        assert float(self.vs.price_per_hour) == self.vs.price_on_calculated(hvz_br=self.hvz_br)

    def test_check_hourly_price_off(self):
        assert float(self.vs.price_per_hour_powered_off) == self.vs.price_off_calculated(hvz_br=self.hvz_br)

    def test_cpu_cost(self):
        if self.vs.booted:
            price = self.vs.cpu_price_on
        else:
            price = self.vs.cpu_price_off
        assert self.vm_stat.vm_last_hour_stat.cpus.cost == price

    def test_cpu_share_cost(self):
        if self.vs.booted:
            price = self.vs.cpu_shares_price_on
        else:
            price = self.vs.cpu_shares_price_off
        assert self.vm_stat.vm_last_hour_stat.cpu_shares.cost == price

    def test_memory_cost(self):
        if self.vs.booted:
            price = self.vs.memory_price_on
        else:
            price = self.vs.memory_price_off
        assert self.vm_stat.vm_last_hour_stat.memory.cost == price
