from onapp_helper import test
import pytest

from onapp_helper.br_helper.dsz import DSZBR
from onapp_helper.server import VirtualServer
from onapp_helper.user import User
from onapp_helper.billing_plan import BillingPlan
# Stats
from onapp_helper.stats.vm_stat import VmStat
#from onapp_helper. import UserStats


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.limits
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version >= 5.6,
    reason="Old billing is not supported..."
)
@pytest.mark.incremental
class TestDSZFreeLimits():
    def setup_class(self):
        test.load_env()
        test.run_at(minutes=40)

        try:
            # Setup
            self.billing_plan = BillingPlan()
            self.billing_plan.label = self.__name__
            assert self.billing_plan.create()

            # Setup for base resources
            self.dsz_br = DSZBR(billing_plan=self.billing_plan, target_id=test.env.dsz.id)

            # Create User and VS
            self.user = User(bp=self.billing_plan)
            self.user.login = "dszfreelimitstest"
            self.user.password = test.generate_password()
            self.user.email = 'user@dszfreelimitstest.test'
            assert self.user.create()
            # Login as new user
            test.execute_as(self.user.login, self.user.password)

            self.vs = VirtualServer()
            self.vs.rate_limit = 0  #  Unlimited
            self.vs.label = self.__name__
            assert self.vs.create(), self.vs.error

            # Set free limits for base resources
            self.dsz_br.limits.limit_free = 1
            self.dsz_br.prices.price_on = 100
            self.dsz_br.prices.price_off = 2
            self.dsz_br.limits.limit_data_read_free = 1
            self.dsz_br.prices.price_data_read = 100
            self.dsz_br.limits.limit_data_written_free = 1
            self.dsz_br.prices.price_data_written = 100
            self.dsz_br.limits.limit_reads_completed_free = 1
            self.dsz_br.prices.price_reads_completed = 100
            self.dsz_br.limits.limit_writes_completed_free = 1
            self.dsz_br.prices.price_writes_completed = 100
            assert self.dsz_br.create()

            self.vm_stat = VmStat(parent_obj=self.vs)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        attributes = (
            'vs',
            'user',
            'billing_plan'
        )
        test.clean_up_resources(attributes, self)

    def test_generate_1GB_of_data(self):
        self.vs.execute(
            'cd {0} && dd if=/dev/urandom of=1GB bs=1024k count=1000'.format(
                self.vs.working_path
            )
        )
        assert '1GB' in self.vs.execute(
            'cd {0} && ls -l'.format(self.vs.working_path)
        )

    def test_copy_1GB_of_data(self):
        self.vs.execute('cd {0} && cp ./1GB ./1GB_copy'.format(self.vs.working_path))
        assert '1GB_copy' in self.vs.execute('cd {0} && ls -l'.format(self.vs.working_path))

    def test_get_stat(self):
        self.vm_stat.stats_waiter()
        self.vm_stat.get_hourly_stat_for_the_last_hour()
        test.update_object(self.vs)

    def test_hourly_price_on_should_be_0(self):
        assert float(self.vs.price_per_hour) == self.vs.price_on_calculated(dsz_br=self.dsz_br)

    def test_hourly_price_off_should_be_0(self):
        assert float(self.vs.price_per_hour_powered_off) == self.vs.price_off_calculated(dsz_br=self.dsz_br)

    def test_disk_size_cost(self):
        if self.vs.booted:
            price = self.vs.disks_price_on
        else:
            price = self.vs.disks_price_off
        assert self.vm_stat.vm_last_hour_stat.disk_size.cost == price

    def test_data_read_cost(self):
        test.log.info("Data read value - {0}".format(self.vm_stat.vm_last_hour_stat.data_read.value))
        data_read = self.vm_stat.vm_last_hour_stat.data_read.value / 1048576.0
        calculated_cost = 0.0
        if data_read > self.dsz_br.limits.limit_data_read_free:
            calculated_cost = float(
               (
                   data_read - self.dsz_br.limits.limit_data_read_free
               ) * self.dsz_br.prices.price_data_read
            )
            test.log.info(
            'Data read cost: \n\t calculated - {}\n\t real - {}'.format(
                calculated_cost, self.vm_stat.vm_last_hour_stat.data_read.cost
            )
        )
        assert calculated_cost - (calculated_cost * 0.3) <= \
               self.vm_stat.vm_last_hour_stat.data_read.cost <= \
               calculated_cost + (calculated_cost * 0.3)

    def test_data_written_cost(self):
        test.log.info(
            "Data written value - {0}".format(
                self.vm_stat.vm_last_hour_stat.data_written.value
            )
        )
        data_written = self.vm_stat.vm_last_hour_stat.data_written.value / 1048576.0
        calculated_cost = 0.0
        if data_written > self.dsz_br.limits.limit_data_written_free:
            calculated_cost = float(
                (
                    data_written - self.dsz_br.limits.limit_data_written_free
                ) * self.dsz_br.prices.price_data_written
            )
        test.log.info(
            'Data written cost: \n\t calculated - {}\n\t real - {}'.format(
                calculated_cost, self.vm_stat.vm_last_hour_stat.data_written.cost
            )
        )
        assert calculated_cost - (calculated_cost * 0.3) <= \
               self.vm_stat.vm_last_hour_stat.data_written.cost <= \
               calculated_cost + (calculated_cost * 0.3)

    def test_reads_completed_cost(self):
        assert self.vm_stat.vm_last_hour_stat.reads_completed.cost == 0.0

    def test_writes_completed_cost(self):
        assert self.vm_stat.vm_last_hour_stat.writes_completed.cost == 0.0
