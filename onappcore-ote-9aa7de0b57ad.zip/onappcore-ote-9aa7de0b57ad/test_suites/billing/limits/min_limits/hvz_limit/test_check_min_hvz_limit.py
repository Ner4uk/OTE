from onapp_helper import test

from onapp_helper.br_helper.hvz import HVZBR
from onapp_helper.server import VirtualServer
from onapp_helper.user import User
from onapp_helper.billing_plan import BillingPlan
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.limits
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version >= 5.6,
    reason="Old billing is not supported..."
)
class TestHVZMinLimits:
    def setup_class(self):
        test.load_env()

        if test.env.hv.hypervisor_type == 'kvm' and test.env.hv.os_version == 5:
            pytest.skip("Does not work for KVM under centos5")

        try:
            # Setup
            self.billing_plan = BillingPlan()
            self.billing_plan.label = self.__name__
            assert self.billing_plan.create()

            # Setup for base resources
            self.hvz_br = HVZBR(billing_plan=self.billing_plan, target_id=test.env.hvz.id)
            assert self.hvz_br.create()

            # Create User and VS
            self.user = User(bp=self.billing_plan)
            self.user.login = "hvzminlimitstest"
            self.user.password = test.generate_password()
            self.user.email = 'user@hvzminlimitstest.test'
            assert self.user.create()
            # Login as new user
            test.execute_as(self.user.login, self.user.password)

            self.vs = VirtualServer()
            self.vs.rate_limit = 0  #  Unlimited
            self.vs.label = self.__name__
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        self.user.delete()
        self.billing_plan.delete()

    def test_should_be_impossible_to_create_one_core_vs_with_limit_min_cpu_2(self):
        self.hvz_br.reset()
        self.hvz_br.limits.limit_min_cpu = 2
        assert self.hvz_br.edit()
        self.vs.cpus = 1
        assert not self.vs.create()
        assert 'CPUs must be greater than or equal to 2 to meet billing requirements' in self.vs.error['cpus']

    def test_should_be_impossible_to_create_1_cpu_priority_vs_with_limit_min_cpu_priority_50(self):
        self.hvz_br.reset()
        self.hvz_br.limits.limit_min_cpu_priority = 50
        assert self.hvz_br.edit()
        self.vs.cpu_shares = 1
        assert not self.vs.create()
        assert 'CPU priority must be greater than or equal to 50 to meet billing requirements' in self.vs.error['cpu_priority']

    def test_should_be_impossible_to_create_512MB_memory_vs_with_limit_min_memory_1GB(self):
        self.hvz_br.reset()
        self.hvz_br.limits.limit_min_memory = 1024
        self.hvz_br.edit()
        self.vs.memory = 512
        assert not self.vs.create()
        assert 'Memory must be greater than or equal to 1024 MB to meet billing requirements' in self.vs.error['memory']

