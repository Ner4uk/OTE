#! /usr/bin/env python

__author__ = 'zhuk'
import pytest
from onapp_helper.vcloud.orchestration_model import OrchestrationModel
from onapp_helper.user_group import UserGroup
from onapp_helper.hypervisor import Hypervisor
from onapp_helper.company_plan import CompanyPlan
from onapp_helper.company_resource.hvz import CompanyHVZBR
from onapp_helper.company_resource.dsz import CompanyDSZBR
from onapp_helper.company_resource.ntz import CompanyNTZBR
from test_helper import errorsTH
from onapp_helper import test
import re


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.limits
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version >= 5.6,
    reason="Old billing is not supported..."
)
class TestDeployOrchestrationModelsPayAsYouGoMinLimits():
    def setup_class(self):
        try:
            self.more_cpu_message = 'is [0-9.]+GHz but must be [0-9.]+GHz or more, according to the company plan and template limits'
            self.more_memory_message = 'is [0-9.]+GB, but must be [0-9.]+GB or more, according to the company plan and template limits'

            self.hv = Hypervisor()
            hvs = self.hv.get_vcloud()
            if hvs:
                self.hv = hvs[0]
            else:
                raise ValueError("There is no vcloud HV on this cloud.")

            self.user_group = UserGroup()
            # self.user_group = UserGroup(id=3198)
            self.user_group = [
                ug for ug in self.user_group.get_all() if ug.label == 'onapp'
                ][0]

            # Get user group company plan
            self.company_plan = CompanyPlan(
                self.user_group.company_billing_plan_id
            )

            # Set up Company Plan limits# Set up Company Plan limits
            if not self.company_plan.resource_in_company_plan(
                    self.hv.hypervisor_group_id
            ):
                self.company_hvz_br = CompanyHVZBR(
                    company_plan=self.company_plan,
                    target_id=self.hv.id
                )
                assert self.company_hvz_br.create(), self.company_hvz_br.error
            else:
                self.company_hvz_br = [hvz_br for hvz_br in CompanyHVZBR(
                    company_plan=self.company_plan
                ).get_all() if hvz_br.target_id == self.hv.hypervisor_group_id][0]

            # OM
            self.om = OrchestrationModel(self.hv.id)

            #  Add missing data store zones to company base resources
            for ds in self.om.provider_vdc.storage_policies:
                if not self.company_plan.resource_in_company_plan(
                        ds["storage_policy"]["id"]
                ):
                    CompanyDSZBR(
                        company_plan=self.company_plan,
                        target_id=ds["storage_policy"]["id"]
                    ).create()

            # Add missing network zones to company base resources
            for np in self.om.provider_vdc.network_pools:
                if not self.company_plan.resource_in_company_plan(
                        np["network_pool"]["id"]
                ):
                    CompanyNTZBR(
                        company_plan=self.company_plan,
                        target_id=np["network_pool"]["id"]
                    ).create()

            # Set limits
            self.company_hvz_br.limits.limit_min_pay_as_you_go_cpu_limit = (
                self.om.provider_vdc.cpu_used / 1000.0
            )
            self.company_hvz_br.limits.limit_min_pay_as_you_go_memory_limit = (
                self.om.provider_vdc.memory_used / 1000.0
            )
            self.company_hvz_br.edit()

            self.om.network_to_create = [
                {
                    "name": "Network-1",
                    "type": "routed",
                    "network_address": "11.11.1.1/24",
                    "dns": "9.9.9.9"
                },
                {
                    "name": "Network-2",
                    "type": "routed",
                    "network_address": "11.11.2.1/24",
                    "dns": "9.9.4.4"
                }
            ]
            self.om.label = self.__name__
            self.om.vdc_model_type = 'pay_as_you_go'
            assert self.om.create(), self.om.error
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        self.om.delete()
        self.company_hvz_br.limits.limit_min_pay_as_you_go_cpu_limit = None
        self.company_hvz_br.limits.limit_min_pay_as_you_go_memory_limit = None
        assert self.company_hvz_br.edit(), self.company_hvz_br.error

    def test_should_be_impossible_to_deploy_om_with_cpu_limit_less_than_min(self):
        self.om.cpu_quota = self.company_hvz_br.limits.limit_min_pay_as_you_go_cpu_limit - 1
        self.om.memory_quota = self.company_hvz_br.limits.limit_min_pay_as_you_go_memory_limit
        assert not self.om.deploy(self.user_group.id)
        assert errorsTH.check_if_error_in_error_list_by_reg_exp(
            self.more_cpu_message, self.om.error['cpu_quota']
        )

    def test_should_be_impossible_to_deploy_om_with_memory_limit_less_than_min(self):
        self.om.cpu_quota = self.company_hvz_br.limits.limit_min_pay_as_you_go_cpu_limit
        self.om.memory_quota = self.company_hvz_br.limits.limit_min_pay_as_you_go_memory_limit - 1
        assert not self.om.deploy(self.user_group.id)
        assert errorsTH.check_if_error_in_error_list_by_reg_exp(
            self.more_memory_message, self.om.error['memory_quota']
        )




