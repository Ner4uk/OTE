#! /usr/bin/env python

__author__ = 'zhuk'
import pytest
from onapp_helper.vcloud.resource_pool import ResourcePool
from onapp_helper.vcloud.resource_pool_ds import ResourcePoolDS
from onapp_helper.vcloud.provider_vdc import ProviderVDC
from onapp_helper.user_group import UserGroup
from onapp_helper.billing_plan import BillingPlan
from onapp_helper.company_plan import CompanyPlan
from onapp_helper.networks import ExternalNetwork
from onapp_helper.company_resource.hvz import CompanyHVZBR
from onapp_helper.company_resource.dsz import CompanyDSZBR
from onapp_helper.company_resource.ntz import CompanyNTZBR
from onapp_helper.hypervisor import Hypervisor
from test_helper import errorsTH
from onapp_helper.role import Role
from onapp_helper.user import User
import re
from onapp_helper import test


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.limits
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version >= 5.6,
    reason="Old billing is not supported..."
)
class TestPayAsYouGoMinLimit(object):
    def setup_class(self):
        try:
            # ',' is missing in more_cpu_message before 'but'
            self.more_cpu_message = 'is [0-9.]+GHz but must be [0-9.]+GHz or more, according to the company plan and template limits'
            self.more_memory_message = 'is [0-9.]+GB, but must be [0-9.]+GB or more, according to the company plan and template limits'

            self.resource_pool = ResourcePool()
            self.resources_pool = ResourcePool().get_all()
            self.resource_pool_ds = ResourcePoolDS(self.resource_pool)

            # Get provider VDC id
            self.provider_vdc = ProviderVDC()
            self.provider_vdc.get_first()
            self.provider_vdc_data_stores = self.provider_vdc.storage_policies
            self.provider_vdc_data_store_group_id = self.provider_vdc_data_stores[0]["storage_policy"]["id"]

            # Get vcloud HV (resource pool)
            self.hv = Hypervisor(self.provider_vdc.hypervisor_id)
            # Create Billing Plan
            self.billing_plan = BillingPlan()
            self.billing_plan.label = self.__name__
            assert self.billing_plan.create()
            # Create Company Plan
            self.company_plan = CompanyPlan()
            self.company_plan.label = self.__name__
            assert self.company_plan.create()
            # Create Company (User Group)
            self.company = UserGroup()
            self.company.label = self.__name__
            self.company.assign_to_vcloud = True
            self.company.hypervisor_id = self.hv.id
            self.company.company_billing_plan_id = self.company_plan.id
            self.company.billing_plan_ids.append(self.billing_plan.id)
            assert self.company.create()

            # Add compute zone to company plan
            self.company_hvz_br = CompanyHVZBR(
                company_plan=self.company_plan,
                target_id=self.hv.hypervisor_group_id
            )
            self.company_hvz_br.create()

            # Set limits
            self.company_hvz_br.limits.limit_min_pay_as_you_go_cpu_limit = (
                self.provider_vdc.cpu_used / 1000.0
            )
            self.company_hvz_br.limits.limit_min_pay_as_you_go_memory_limit = (
                self.provider_vdc.memory_used / 1000.0
            )
            self.company_hvz_br.edit()

            # Add DSZ to company plan
            self.company_dsz_br = CompanyDSZBR(
                company_plan=self.company_plan,
                target_id=self.provider_vdc_data_store_group_id
            )
            self.company_dsz_br.limits.limit_min_disk_size = 10
            self.company_dsz_br.limits.limit_disk_size = 100
            self.company_dsz_br.create()

            # Add NTZ to company plan
            self.external_networks = ExternalNetwork()
            self.company_ntz_brs = [
                CompanyNTZBR(
                    company_plan=self.company_plan,
                    target_id=en.network_group_id
                ).create()
                for en in self.external_networks.get_all()
                ]

            #Permanent settings
            self.resource_pool.provider_vdc_id = self.provider_vdc.id
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        attributes = (
            'resource_pool',
            'company',
            'company_plan',
            'billing_plan'
        )
        test.clean_up_resources(attributes, self)

    def test_should_be_impossible_to_create_resource_pool_with_cpu_limit_less_than_min(self):
        """
            guaranteed_cpu,
            guaranteed_memory,
            vm_quota,
            cpu_limit(GHz),
            memory_limit(GB),
            vcpu_speed(MHz)
        """
        self.resource_pool.user_group_id = self.company.id
        self.resource_pool.label = self.__class__.__name__
        self.resource_pool.allocation_models = "AllocationVApp"
        self.resource_pool.data_store_group_id = self.provider_vdc_data_store_group_id
        self.resource_pool.data_store_size = self.company_dsz_br.limits.limit_disk_size

        self.resource_pool.guaranteed_cpu = 1
        self.resource_pool.guaranteed_memory = 5
        self.resource_pool.vm_quota = 5
        self.resource_pool.cpu_limit = self.company_hvz_br.limits.limit_min_pay_as_you_go_cpu_limit - 1
        self.resource_pool.memory_limit = 5
        self.resource_pool.vcpu_speed = 260

        assert not self.resource_pool.create()
        assert errorsTH.check_if_error_in_error_list_by_reg_exp(
            self.more_cpu_message, self.resource_pool.error['cpu_limit']
        )

    def test_should_be_impossible_to_create_resource_pool_with_memory_limit_less_than_min(self):
        """
            guaranteed_cpu,
            guaranteed_memory,
            vm_quota,
            cpu_limit(GHz),
            memory_limit(GB),
            vcpu_speed(MHz)
        """
        self.resource_pool.user_group_id = self.company.id
        self.resource_pool.label = self.__class__.__name__
        self.resource_pool.allocation_models = "AllocationVApp"
        self.resource_pool.data_store_group_id = self.provider_vdc_data_store_group_id
        self.resource_pool.data_store_size = self.company_dsz_br.limits.limit_disk_size

        self.resource_pool.guaranteed_cpu = 1
        self.resource_pool.guaranteed_memory = 5
        self.resource_pool.vm_quota = 5
        self.resource_pool.cpu_limit = self.company_hvz_br.limits.limit_min_pay_as_you_go_cpu_limit
        self.resource_pool.memory_limit = self.company_hvz_br.limits.limit_min_pay_as_you_go_memory_limit - 1
        self.resource_pool.vcpu_speed = 260

        assert not self.resource_pool.create()
        assert errorsTH.check_if_error_in_error_list_by_reg_exp(
            self.more_memory_message, self.resource_pool.error['memory_limit']
        )

    def test_create_with_unlimited_min_memory_and_cpu_limits(self):
        """
            guaranteed_cpu,
            guaranteed_memory,
            vm_quota,
            cpu_limit(GHz),
            memory_limit(GB),
            vcpu_speed(MHz)
        """
        # Set unlimited min limits
        self.company_hvz_br.limits.limit_min_pay_as_you_go_cpu_limit = 0
        self.company_hvz_br.limits.limit_min_pay_as_you_go_memory_limit = 0
        self.company_hvz_br.limits.limit_pay_as_you_go_cpu_limit = 5
        self.company_hvz_br.limits.limit_pay_as_you_go_memory_limit = 5
        self.company_hvz_br.edit()

        self.resource_pool.user_group_id = self.company.id
        self.resource_pool.label = self.__class__.__name__
        self.resource_pool.allocation_models = "AllocationVApp"
        self.resource_pool.data_store_group_id = self.provider_vdc_data_store_group_id
        self.resource_pool.data_store_size = self.company_dsz_br.limits.limit_disk_size

        self.resource_pool.guaranteed_cpu = 1
        self.resource_pool.guaranteed_memory = 5
        self.resource_pool.vm_quota = 5
        self.resource_pool.cpu_limit = 0.26
        self.resource_pool.memory_limit = 1.5
        self.resource_pool.vcpu_speed = 260

        assert self.resource_pool.create(), self.resource_pool.error


