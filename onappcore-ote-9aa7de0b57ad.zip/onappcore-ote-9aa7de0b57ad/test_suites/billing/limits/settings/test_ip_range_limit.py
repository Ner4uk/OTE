#  https://onappdev.atlassian.net/browse/CORE-6296

from onapp_helper.settings import Settings
from onapp_helper.networks import Network
from onapp_helper.ip_address import IpAddress
from onapp_helper import test
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.limits
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
class TestIPRangeLimit:
    def setup_class(self):
        test.load_onapp_settings()
        if test.cp_version >= 5.4 and not hasattr(
                test.onapp_settings, 'ip_range_limit'
        ):
            pytest.skip('No longer supported.')
        try:
            self.settings = Settings()
            self.settings.get()
            self.ip_range_limit = self.settings.ip_range_limit
            #self.settings.ip_range_limit = 5
            self.settings.set(ip_range_limit=5)
            self.settings.get()
            print(self.settings.ip_range_limit)
            self.network = Network()
            self.network.label = self.__name__
            assert self.network.create()
            self.ip_address = IpAddress(parent_obj=self.network)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        self.network.delete()
        self.settings.set(ip_range_limit=self.ip_range_limit)
        self.settings.get()
        print(self.settings.ip_range_limit)

    def test_should_not_exceed_ip_range_limit(self):
        self.ip_address.address = '6.6.6.6-36'
        self.ip_address.gateway = '6.6.6.1'
        self.ip_address.netmask = '255.255.255.0'
        self.ip_address.disallowed_primary = False
        assert not self.ip_address.create()
        assert 'Cannot create more than 5 IP Addresses in one step' in self.ip_address.error['address']

    def test_ip_range_limit(self):
        self.settings.set(ip_range_limit=30)
        self.settings.get()
        print(self.settings.ip_range_limit)
        assert self.ip_address.create()