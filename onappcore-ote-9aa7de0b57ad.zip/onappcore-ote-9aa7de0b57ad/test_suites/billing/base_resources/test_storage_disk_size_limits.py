# daily
import pytest
from onapp_helper.br_helper.storage_disk_size import StorageDiskSizeBR
from onapp_helper.billing_plan import BillingPlan
from onapp_helper import test


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.base_resources
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version >= 6.1, reason=test.not_supported_msg(BillingPlan))
class TestStorageDiskSizeLimits():
    def setup_class(self):
        self.billing_plan = BillingPlan()
        self.billing_plan.create()
        self.storage_disk_size_br = StorageDiskSizeBR(billing_plan=self.billing_plan)

    def teardown_class(self):
        self.billing_plan.delete()

    def test_create_storage_disk_size_br_with_negative_limit(self):
        # Create with negative limit
        self.storage_disk_size_br.limits.limit = -10
        assert not self.storage_disk_size_br.create()

    def test_check_error_message_for_storage_disk_size_br_with_negative_limit(self):
        assert self.storage_disk_size_br.E_VALIDATION_VALUE in self.storage_disk_size_br.error['limit']

    def test_create_storage_disk_size_br_with_negative_free_limit(self):
        # Create with negative free_limit
        self.storage_disk_size_br.limits.limit = 10
        self.storage_disk_size_br.limits.limit_free = -10
        assert not self.storage_disk_size_br.create()

    def test_check_error_message_for_storage_disk_size_br_with_negative_free_limit(self):
        assert self.storage_disk_size_br.E_VALIDATION_VALUE in self.storage_disk_size_br.error['limit_free']

    def test_create_storage_disk_size_br_with_negative_price(self):
        # Create with negative price
        self.storage_disk_size_br.limits.limit_free = 10
        self.storage_disk_size_br.prices.price = -10
        assert not self.storage_disk_size_br.create()

    def test_check_error_message_for_storage_disk_size_br_with_negative_price(self):
        assert self.storage_disk_size_br.E_VALIDATION_VALUE in self.storage_disk_size_br.error['price']

    def test_create_storage_disk_size_br_with_correct_parameters(self):
        # Create with correct values
        if test.api_version == 4.2:
            test.gen_api_doc = True
        self.storage_disk_size_br.prices.price = 10
        assert self.storage_disk_size_br.create()
        assert self.storage_disk_size_br.limits.limit == 10
        assert self.storage_disk_size_br.limits.limit_free == 10
        assert self.storage_disk_size_br.prices.price == 10

    def test_edit_storage_disk_size_br_limit(self):
        # Edit limit
        if test.api_version == 4.2:
            test.gen_api_doc = True
        self.storage_disk_size_br.limits.limit = 66
        assert self.storage_disk_size_br.edit()
        assert self.storage_disk_size_br.limits.limit == 66

    def test_edit_storage_disk_size_br_limit_free(self):
        #Edit limit free
        self.storage_disk_size_br.limits.limit_free = 66
        assert self.storage_disk_size_br.edit()
        assert self.storage_disk_size_br.limits.limit_free == 66

    def test_edit_storage_disk_size_br_price(self):
        # Edit price
        self.storage_disk_size_br.prices.price = 66
        assert self.storage_disk_size_br.edit()
        assert self.storage_disk_size_br.prices.price == 66

    def test_delete_storage_disk_size_br(self):
        # Delete
        if test.api_version == 4.2:
            test.gen_api_doc = True
        assert self.storage_disk_size_br.delete()