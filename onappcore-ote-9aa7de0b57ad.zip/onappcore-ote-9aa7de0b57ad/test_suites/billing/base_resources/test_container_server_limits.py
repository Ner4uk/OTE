# daily
from onapp_helper.br_helper.cs_limit import CSLimit
from onapp_helper.billing_plan import BillingPlan
from onapp_helper import test
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.base_resources
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version >= 6.1, reason=test.not_supported_msg(BillingPlan))
class TestContainerServerLimits():
    def setup_class(self):
        self.billing_plan = BillingPlan()
        self.billing_plan.label = self.__name__
        assert self.billing_plan.create()
        self.cs_limit = CSLimit(billing_plan=self.billing_plan)

    def teardown_class(self):
        self.billing_plan.delete()

    # def test_create_with_negative_limit(self):
    #     # Create with negative limit
    #     self.cs_limit.limits.limit = -10
    #     self.cs_limit.create()
    #     assert 'must be greater than or equal to 0' in self.cs_limit.error['limit']

    def test_create_with_correct_parameter(self):
        # Create with correct values
        self.cs_limit.limits.limit = 12
        assert self.cs_limit.create()
        assert self.cs_limit.limits.limit == 12

    def test_edit(self):
        # Edit limit
        self.cs_limit.limits.limit = 101
        assert self.cs_limit.edit()
        assert self.cs_limit.limits.limit == 101

    def test_delete(self):
        # Delete
        assert self.cs_limit.delete()