# daily
from onapp_helper.br_helper.as_limit import ASLimit
from onapp_helper.billing_plan import BillingPlan
from onapp_helper import test
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.base_resources
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version < 4.2,
    reason="Current CP version ({0}) does not support this functionality ".format(test.cp_version)
)
@pytest.mark.skipif(test.cp_version >= 6.1, reason=test.not_supported_msg(BillingPlan))
class TestApplicationServerLimits():
    def setup_class(self):
        self.billing_plan = BillingPlan()
        self.billing_plan.create()
        self.apps_br = ASLimit(billing_plan=self.billing_plan)

    def teardown_class(self):
        self.billing_plan.delete()

    def test_you_can_not_create_apps_br_with_negative_limit(self):
        # Create with negative limit
        self.apps_br.limits.limit = -10
        assert not self.apps_br.create()

    def test_check_error_message_for_apps_br_negative_limit(self):
        assert self.apps_br.E_VALIDATION_VALUE in self.apps_br.error['limit']

    def test_create_apps_br_with_correct_value(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        # Create with correct values
        self.apps_br.limits.limit = 10
        assert self.apps_br.create()

    def test_check_apps_br_limit(self):
        assert self.apps_br.limits.limit == 10

    def test_edit_apps_br_limit(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        # Edit limit
        self.apps_br.limits.limit = 66
        assert self.apps_br.edit()

    def test_check_apps_br_limit_after_edit(self):
        assert self.apps_br.limits.limit == 66

    def test_delete_apps_br(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        # Delete
        assert self.apps_br.delete()