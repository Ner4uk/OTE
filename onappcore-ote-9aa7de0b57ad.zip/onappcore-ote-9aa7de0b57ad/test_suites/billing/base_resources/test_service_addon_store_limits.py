# daily
from onapp_helper.br_helper.service_addon_store import ServiceAddonStoreBR
from onapp_helper.billing_plan import BillingPlan
from onapp_helper.service_addon.service_addon_group import ServiceAddonGroup
from onapp_helper import test
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.base_resources
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version < 5.3,
    reason="Current CP version ({0}) does not support this functionality ".format(test.cp_version)
)
@pytest.mark.skipif(test.cp_version >= 6.1, reason=test.not_supported_msg(BillingPlan))
class TestServiceAddonStoreLimits():
    def setup_class(self):
        self.billing_plan = BillingPlan()
        self.billing_plan.create()
        self.service_addon_store = ServiceAddonGroup()
        self.service_addon_store.label = self.__name__
        self.service_addon_store.create()

        self.service_addon_store_br = ServiceAddonStoreBR(
            billing_plan=self.billing_plan,
            target_id=self.service_addon_store.id
        )

    def teardown_class(self):
        self.billing_plan.delete()
        self.service_addon_store.delete()

    def test_create_service_addon_store_br(self):
        test.gen_api_doc = 'Create Service Addon Store Limit'
        assert self.service_addon_store_br.create()

    def test_get_service_addon_store_br(self):
        test.gen_api_doc = 'Get Service Addon Store Limit Details'
        assert test.update_object(self.service_addon_store_br)

    def test_check_service_addon_store_br(self):
        assert self.service_addon_store.label == self.service_addon_store_br.label

    def test_delete_service_addon_store_br(self):
        test.gen_api_doc = 'Delete Service Addon Store Limit'
        assert self.service_addon_store_br.delete()