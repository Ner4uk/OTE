# daily
from onapp_helper.br_helper.minIOPS import MinIOPSBR
from onapp_helper.billing_plan import BillingPlan
from onapp_helper import test
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.base_resources
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version >= 6.1, reason=test.not_supported_msg(BillingPlan))
class TestMiniIOPSLimits():
    def setup_class(self):
        test.ds_types = ['solidfire']
        test.load_env()
        if not test.env.dsz.id or test.env.ds.data_store_type != 'solidfire':
            pytest.skip(
                "There is no SolidFire data store on - {0}.".format(test.host)
            )

        self.billing_plan = BillingPlan()
        self.billing_plan.create()
        self.minIOPS_br = MinIOPSBR(billing_plan=self.billing_plan, target_id=test.env.dsz.id)

    def teardown_class(self):
        self.billing_plan.delete()

    def test_create_minIOPS_br(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        # CREATE
        # Set limits
        self.minIOPS_br.limits.limit_free = 10
        self.minIOPS_br.limits.limit = 20
        # Set prices
        self.minIOPS_br.prices.price_on = 100
        self.minIOPS_br.prices.price_off = 23
        # Create
        assert self.minIOPS_br.create()

    def test_check_minIOPS_br_limit_free(self):
        # CHECK
        # Check limits
        assert self.minIOPS_br.limits.limit_free == 10

    def test_check_minIOPS_br_limit(self):
        assert self.minIOPS_br.limits.limit == 20

    def test_check_minIOPS_br_price_on(self):
        # Check prices
        assert self.minIOPS_br.prices.price_on == 100

    def test_check_minIOPS_br_price_off(self):
        assert self.minIOPS_br.prices.price_off == 23

    def test_edit_minIOPS_br(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        # EDIT
        # Set limits
        self.minIOPS_br.limits.limit_free = 11
        self.minIOPS_br.limits.limit = 22
        # Set prices
        self.minIOPS_br.prices.price_on = 101
        self.minIOPS_br.prices.price_off = 25
        # Edit
        assert self.minIOPS_br.edit()

    def test_check_minIOPS_br_new_limit_free(self):
        # CHECK
        # Check limits
        assert self.minIOPS_br.limits.limit_free == 11

    def test_check_minIOPS_br_new_limit(self):
        assert self.minIOPS_br.limits.limit == 22

    def test_check_minIOPS_br_new_price_on(self):
        # Check prices
        assert self.minIOPS_br.prices.price_on == 101

    def test_check_minIOPS_br_new_price_off(self):
        assert self.minIOPS_br.prices.price_off == 25
        
    # Delete
    def test_delete_minIOPS_br(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        assert self.minIOPS_br.delete()