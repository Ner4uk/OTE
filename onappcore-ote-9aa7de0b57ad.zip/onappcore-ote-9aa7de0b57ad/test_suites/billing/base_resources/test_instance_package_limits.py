# daily
from onapp_helper.br_helper.instance_package import InstancePackageBR
from onapp_helper.br_helper.hvz import HVZBR
from onapp_helper.br_helper.dsz import DSZBR
from onapp_helper.br_helper.ntz import NTZBR
from onapp_helper.billing_plan import BillingPlan
from onapp_helper.instance_package import InstancePackage
from onapp_helper.hypervisor_zone import HypervisorZone
from onapp_helper.data_store_zone import DataStoreZone
from onapp_helper.network_zone import NetworkZone
from onapp_helper import test
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.base_resources
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version < 4.2,
    reason="Current CP version ({0}) does not support this functionality ".format(test.cp_version)
)
@pytest.mark.skipif(test.cp_version >= 6.1, reason=test.not_supported_msg(BillingPlan))
class TestInstanceTypesLimits():
    def setup_class(self):
        self.billing_plan = BillingPlan()
        self.billing_plan.create()
        # Create InsType
        self.instance_type = InstancePackage()
        self.instance_type.label = self.__name__
        assert self.instance_type.create()
        # Get targets
        self.hvz = HypervisorZone()
        self.hvz.label = self.__name__
        assert self.hvz.create()

        self.ntz = NetworkZone()
        self.ntz.label = self.__name__
        assert self.ntz.create()

        self.dsz = DataStoreZone()
        self.dsz.label = self.__name__
        assert self.dsz.create()

        self.instance_types_br = InstancePackageBR(
            billing_plan=self.billing_plan,
            target_id=self.instance_type.id
        )

        if test.cp_version >= 5.7:
            HVZBR(
                billing_plan=self.billing_plan,
                target_id=self.hvz.id
            ).create()
            DSZBR(
                billing_plan=self.billing_plan,
                target_id=self.dsz.id
            ).create()
            NTZBR(
                billing_plan=self.billing_plan,
                target_id=self.ntz.id
            ).create()

    def teardown_class(self):
        self.billing_plan.delete()
        self.instance_type.delete()
        self.hvz.delete()
        self.dsz.delete()
        self.ntz.delete()

    def test_create_instance_type_br(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        # Set IT prices
        self.instance_types_br.prices.price_on = 100
        self.instance_types_br.prices.price_off = 20
        self.instance_types_br.prices.price_overused_bandwidth = 99
        # Set IT preferences
        self.instance_types_br.preferences.hypervisor_group_ids.append(
            self.hvz.id)
        self.instance_types_br.preferences.data_store_group_ids.append(
            self.dsz.id)
        self.instance_types_br.preferences.network_group_ids.append(
            self.ntz.id)
        # Create IT limit
        assert self.instance_types_br.create()

    def test_check_instance_type_br_price_on(self):
        # Check prices
        assert self.instance_types_br.prices.price_on == 100

    def test_check_instance_type_br_price_off(self):
        assert self.instance_types_br.prices.price_off == 20

    def test_check_instance_type_br_price_overused_bandwidth(self):
        assert self.instance_types_br.prices.price_overused_bandwidth == 99

    def test_check_instance_type_br_hypervisor_group_ids(self):
        # Check preferences
        assert self.hvz.id in self.instance_types_br.preferences.hypervisor_group_ids

    def test_check_instance_type_br_data_store_group_ids(self):
        assert self.dsz.id in self.instance_types_br.preferences.data_store_group_ids

    def test_check_instance_type_br_network_group_ids(self):
        assert self.ntz.id in self.instance_types_br.preferences.network_group_ids

    def test_edit_instance_type_br(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        # EDIT
        # Edit prices
        self.instance_types_br.prices.price_on = 101
        self.instance_types_br.prices.price_off = 21
        self.instance_types_br.prices.price_overused_bandwidth = 991
        # Remove HVZ id
        self.instance_types_br.preferences.hypervisor_group_ids.remove(
            self.hvz.id)
        self.instance_types_br.preferences.data_store_group_ids.remove(
            self.dsz.id)
        self.instance_types_br.preferences.network_group_ids.remove(self.ntz.id)
        assert self.instance_types_br.edit()

    def test_check_instance_type_br_new_price_on(self):
        # Check prices
        assert self.instance_types_br.prices.price_on == 101

    def test_check_instance_type_br_new_price_off(self):
        assert self.instance_types_br.prices.price_off == 21

    def test_check_instance_type_br_new_price_overused_bandwidth(self):
        assert self.instance_types_br.prices.price_overused_bandwidth == 991

    def test_check_instance_type_br_new_hypervisor_group_ids(self):
        # Check preferences
        assert not self.instance_types_br.preferences.hypervisor_group_ids

    def test_check_instance_type_br_new_data_store_group_ids(self):
        assert not self.instance_types_br.preferences.data_store_group_ids

    def test_check_instance_type_br_new_network_group_ids(self):
        assert not self.instance_types_br.preferences.network_group_ids

    def test_delete_instance_type_br(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        assert self.instance_types_br.delete()


