# daily
from onapp_helper.br_helper.dsz import DSZBR
from onapp_helper.data_store_zone import DataStoreZone
from onapp_helper.billing_plan import BillingPlan
from onapp_helper import test
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.base_resources
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version >= 6.1, reason=test.not_supported_msg(BillingPlan))
class TestDSZLimits():
    def setup_class(self):
        self.billing_plan = BillingPlan()
        self.billing_plan.create()
        self.dsz = DataStoreZone()
        self.dsz.label = self.__name__
        self.dsz.create()
        self.dsz_br = DSZBR(billing_plan=self.billing_plan,
                            target_id=self.dsz.id)

    def teardown_class(self):
        self.billing_plan.delete()
        self.dsz.delete()

    def test_create_dsz_br(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        # Set limits
        self.dsz_br.limits.limit_free = 5
        self.dsz_br.limits.limit = 25
        self.dsz_br.limits.limit_data_read_free = 1
        self.dsz_br.limits.limit_data_written_free = 1
        self.dsz_br.limits.limit_writes_completed_free = 100
        self.dsz_br.limits.limit_reads_completed_free = 200
        # Set prices
        self.dsz_br.prices.price_on = 10
        self.dsz_br.prices.price_off = 2
        self.dsz_br.prices.price_data_read = 100
        self.dsz_br.prices.price_data_written = 100
        self.dsz_br.prices.price_reads_completed = 10
        self.dsz_br.prices.price_writes_completed = 10
        # Create
        assert self.dsz_br.create()

    def test_check_dsz_br_limits(self):
        # Check limits
        assert self.dsz_br.limits.limit_free == 5
        assert self.dsz_br.limits.limit == 25
        assert self.dsz_br.limits.limit_data_read_free == 1
        assert self.dsz_br.limits.limit_data_written_free == 1
        assert self.dsz_br.limits.limit_writes_completed_free == 100
        assert self.dsz_br.limits.limit_reads_completed_free == 200
        
    def test_check_dsz_br_prices(self):
        # Check prices
        assert self.dsz_br.prices.price_on == 10
        assert self.dsz_br.prices.price_off == 2
        assert self.dsz_br.prices.price_data_read == 100
        assert self.dsz_br.prices.price_data_written == 100
        assert self.dsz_br.prices.price_reads_completed == 10
        assert self.dsz_br.prices.price_writes_completed == 10

    def test_edit_dsz_br(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        # EDITING
        # Set limits
        self.dsz_br.limits.limit_free = 15
        self.dsz_br.limits.limit = 125
        self.dsz_br.limits.limit_data_read_free = 11
        self.dsz_br.limits.limit_data_written_free = 11
        self.dsz_br.limits.limit_writes_completed_free = 1100
        self.dsz_br.limits.limit_reads_completed_free = 2100
        # Set prices
        self.dsz_br.prices.price_on = 110
        self.dsz_br.prices.price_off = 12
        self.dsz_br.prices.price_data_read = 1100
        self.dsz_br.prices.price_data_written = 1100
        self.dsz_br.prices.price_reads_completed = 110
        self.dsz_br.prices.price_writes_completed = 110
        # Create
        assert self.dsz_br.edit()

    def test_check_new_dsz_br_limits(self):
        # Check limits
        assert self.dsz_br.limits.limit_free == 15
        assert self.dsz_br.limits.limit == 125
        assert self.dsz_br.limits.limit_data_read_free == 11
        assert self.dsz_br.limits.limit_data_written_free == 11
        assert self.dsz_br.limits.limit_writes_completed_free == 1100
        assert self.dsz_br.limits.limit_reads_completed_free == 2100

    def test_check_new_dsz_br_prices(self):
        # Check prices
        assert self.dsz_br.prices.price_on == 110
        assert self.dsz_br.prices.price_off == 12
        assert self.dsz_br.prices.price_data_read == 1100
        assert self.dsz_br.prices.price_data_written == 1100
        assert self.dsz_br.prices.price_reads_completed == 110
        assert self.dsz_br.prices.price_writes_completed == 110

    @pytest.mark.skipif(test.api_version >= 4.2, reason="Deprecated.")
    def test_check_use_master_template_zone_switcher_till_4_2_version(self):
        # Check "Use Master Template Zone?" switcher.
        assert not self.dsz_br.in_template_zone
        self.dsz_br.in_template_zone = True
        assert self.dsz_br.edit()
        assert self.dsz_br.in_template_zone

    @pytest.mark.skipif(test.api_version < 4.2, reason="Not implemented.")
    @pytest.mark.skipif(test.api_version >= 5.7, reason="Deprecated.")
    def test_check_use_master_template_zone_switcher_since_4_2_version(self):
        # Check "Use Master Template Zone?" switcher.
        assert not self.dsz_br.in_master_zone
        self.dsz_br.in_master_zone = True
        assert self.dsz_br.edit()
        assert self.dsz_br.in_master_zone

    def test_delete_dsz_br(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        assert self.dsz_br.delete()