# ignore
from onapp_helper.br_helper.customer_network import CustomerNetworkBR
from onapp_helper.billing_plan import BillingPlan
from onapp_helper import test
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.base_resources
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version >= 6.1, reason=test.not_supported_msg(BillingPlan))
@pytest.mark.skipif(test.cp_version >= 5.3, reason="Deprecated functionality")
class TestCustomerNetworkLimits():
    def setup_class(self):
        self.billing_plan = BillingPlan()
        self.billing_plan.create()
        self.customer_netw = CustomerNetworkBR(billing_plan=self.billing_plan)

    def teardown_class(self):
        self.billing_plan.delete()
        
    def test_create_with_negative_limit(self):
        # Create with negative limit
        self.customer_netw.limits.limit = -10
        self.customer_netw.create()
        assert self.customer_netw.E_VALIDATION_VALUE in self.customer_netw.error['limit']
        
    def test_create_with_negative_free_limit(self):
        # Create with negative free_limit
        self.customer_netw.limits.limit = 10
        self.customer_netw.limits.limit_free = -10
        self.customer_netw.create()
        assert self.customer_netw.E_VALIDATION_VALUE in self.customer_netw.error['limit_free']
    
    def test_create_with_negative_price(self):
        # Create with negative price
        self.customer_netw.limits.limit_free = 10
        self.customer_netw.prices.price = -10
        self.customer_netw.create()
        assert self.customer_netw.E_VALIDATION_VALUE in self.customer_netw.error['price']
        
    def test_create_with_correct_value(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        # Create with correct values
        self.customer_netw.prices.price = 10
        assert self.customer_netw.create()
        assert self.customer_netw.limits.limit == 10
        assert self.customer_netw.limits.limit_free == 10
        assert self.customer_netw.prices.price == 10
        
    def test_edit_limit(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        # Edit limit
        self.customer_netw.limits.limit = 66
        self.customer_netw.edit()
        assert self.customer_netw.limits.limit == 66
        
    def test_edit_limit_free(self):
        #Edit limit free
        self.customer_netw.limits.limit_free = 66
        self.customer_netw.edit()
        assert self.customer_netw.limits.limit_free == 66
        
    def test_edit_price(self):
        # Edit price
        self.customer_netw.prices.price = 66
        self.customer_netw.edit()
        assert self.customer_netw.prices.price == 66
        
    def test_delete(self):
        # Delete
        if test.api_version == 4.2:
            test.gen_api_doc = True
        assert self.customer_netw.delete()