# daily
import pytest
from onapp_helper.br_helper.template_store import TemplateStoreBR
from onapp_helper.billing_plan import BillingPlan
from onapp_helper.template_store import TemplateStore
from onapp_helper import test


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.base_resources
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version >= 6.1, reason=test.not_supported_msg(BillingPlan))
class TestTemplateStoreLimits():
    def setup_class(self):
        self.billing_plan = BillingPlan()
        self.billing_plan.create()
        self.t_store = TemplateStore()
        self.t_store.get_any()

        self.template_store_br = TemplateStoreBR(billing_plan=self.billing_plan, target_id=self.t_store.id)

    def teardown_class(self):
        self.billing_plan.delete()

    def test_create_template_store_br(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        assert self.template_store_br.create()

    def test_check_template_store_br(self):
        assert self.t_store.label == self.template_store_br.label

    def test_delete_template_store_br(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        assert self.template_store_br.delete()