# daily
from onapp_helper.br_helper.draas import DRaaSBR
from onapp_helper.billing_plan import BillingPlan
import pytest
from onapp_helper import test


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.base_resources
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version < 4.2,
    reason="Current CP version ({0}) does not support this functionality ".format(test.cp_version)
)
@pytest.mark.skipif(test.cp_version >= 6.1, reason=test.not_supported_msg(BillingPlan))
class TestDRaaSLimits():
    def setup_class(self):
        self.billing_plan = BillingPlan()
        self.billing_plan.create()
        self.draas_br = DRaaSBR(billing_plan=self.billing_plan)

    def teardown_class(self):
        self.billing_plan.delete()
    
    def test_you_can_not_create_draas_br_with_negative_disk_size_price(self):
        # Create with negative price
        self.draas_br.prices.price_disk_size = -10
        assert not self.draas_br.create()

    def test_check_error_for_draas_br_negative_disk_size_price(self):
        assert self.draas_br.E_VALIDATION_VALUE in self.draas_br.error['price_disk_size']

    def test_you_can_not_create_draas_br_with_negative_memory_price(self):
        # Create with negative price
        self.draas_br.prices.price_memory = -10
        assert not self.draas_br.create()

    def test_check_error_message_for_draas_br_negative_memory_price(self):
        assert self.draas_br.E_VALIDATION_VALUE in self.draas_br.error['price_memory']

    def test_you_can_not_create_draas_br_with_negative_cpus_price(self):
        # Create with negative price
        self.draas_br.prices.price_cpus = -10
        assert not self.draas_br.create()

    def test_check_error_message_for_draas_br_negative_cpus_price(self):
        assert self.draas_br.E_VALIDATION_VALUE in self.draas_br.error['price_cpus']

    def test_you_can_not_create_draas_br_with_negative_cpu_shares_price(self):
        # Create with negative price
        self.draas_br.prices.price_cpu_shares = -10
        assert not self.draas_br.create()

    def test_check_error_message_for_draas_br_negative_cpu_shares_price(self):
        assert self.draas_br.E_VALIDATION_VALUE in self.draas_br.error['price_cpu_shares']

    def test_you_can_not_create_draas_br_with_negative_cpu_units_price(self):
        # Create with negative price
        self.draas_br.prices.price_cpu_units = -10
        assert not self.draas_br.create()

    def test_check_error_message_for_draas_br_negative_cpu_units_price(self):
        assert self.draas_br.E_VALIDATION_VALUE in self.draas_br.error['price_cpu_units']

    def test_you_can_not_create_draas_br_with_negative_node_price(self):
        # Create with negative price
        self.draas_br.prices.price_nodes = -10
        assert not self.draas_br.create()

    def test_check_error_message_for_draas_br_negative_node_price(self):
        assert self.draas_br.E_VALIDATION_VALUE in self.draas_br.error['price_nodes']
        
    def test_create_draas_br_with_correct_value(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        # Create with correct values
        self.draas_br.prices.price_disk_size = 10
        self.draas_br.prices.price_memory = 11
        self.draas_br.prices.price_cpus = 12
        self.draas_br.prices.price_cpu_shares = 13
        self.draas_br.prices.price_cpu_units = 14
        self.draas_br.prices.price_nodes = 15
        assert self.draas_br.create()

    def test_check_draas_br_prices(self):
        assert self.draas_br.prices.price_disk_size == 10
        assert self.draas_br.prices.price_memory == 11
        assert self.draas_br.prices.price_cpus == 12
        assert self.draas_br.prices.price_cpu_shares == 13
        assert self.draas_br.prices.price_cpu_units == 14
        assert self.draas_br.prices.price_nodes == 15
        
    def test_edit_draas_br_prices(self):
        # Edit prices
        if test.api_version == 4.2:
            test.gen_api_doc = True

        self.draas_br.prices.price_disk_size = 11
        self.draas_br.prices.price_memory = 12
        self.draas_br.prices.price_cpus = 13
        self.draas_br.prices.price_cpu_shares = 14
        self.draas_br.prices.price_cpu_units = 15
        self.draas_br.prices.price_nodes = 16
        assert self.draas_br.edit()

    def test_check_draas_br_new_prices(self):
        assert self.draas_br.prices.price_disk_size == 11
        assert self.draas_br.prices.price_memory == 12
        assert self.draas_br.prices.price_cpus == 13
        assert self.draas_br.prices.price_cpu_shares == 14
        assert self.draas_br.prices.price_cpu_units == 15
        assert self.draas_br.prices.price_nodes == 16
        
    def test_delete_draas_br(self):
        # Delete
        if test.api_version == 4.2:
            test.gen_api_doc = True
        assert self.draas_br.delete()