# daily
from onapp_helper.br_helper.acceleration import AccelerationBR
from onapp_helper.billing_plan import BillingPlan
from onapp_helper import test
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.base_resources
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version < 4.2,
    reason="Current CP version ({0}) does not support this functionality ".format(test.cp_version)
)
@pytest.mark.skipif(test.cp_version >= 6.1, reason=test.not_supported_msg(BillingPlan))
class TestAccelerationLimit():
    def setup_class(self):
        self.billing_plan = BillingPlan()
        self.billing_plan.create()
        self.acceleration_br = AccelerationBR(billing_plan=self.billing_plan)

    def teardown_class(self):
        self.billing_plan.delete()

    def test_you_can_not_create_acceleration_br_with_negative_limit(self):
        # Create with negative limit
        self.acceleration_br.limits.limit = -10
        self.acceleration_br.create()
        assert self.acceleration_br.E_VALIDATION_VALUE in self.acceleration_br.error['limit']

    def test_you_can_not_create_acceleration_br_with_negative_free_limit(self):
        # Create with negative free_limit
        self.acceleration_br.limits.limit = 10
        self.acceleration_br.limits.limit_free = -10
        self.acceleration_br.create()
        assert self.acceleration_br.E_VALIDATION_VALUE in self.acceleration_br.error['limit_free']

    def test_you_can_not_create_acceleration_br_with_negative_price(self):
        # Create with negative price On
        self.acceleration_br.limits.limit_free = 10
        self.acceleration_br.prices.price = -10
        self.acceleration_br.create()
        assert self.acceleration_br.E_VALIDATION_VALUE in self.acceleration_br.error['price']

    def test_create_acceleration_br_with_correct_parameters(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        # Create with correct values
        self.acceleration_br.prices.price = 10
        assert self.acceleration_br.create()

    def test_check_acceleration_br_limit(self):
        assert 10 == self.acceleration_br.limits.limit

    def test_check_acceleration_br_limit_free(self):
        assert 10 == self.acceleration_br.limits.limit_free

    def test_check_acceleration_br_price(self):
        assert 10 == self.acceleration_br.prices.price

    def test_edit_acceleration_br_limit(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        # Edit limit
        self.acceleration_br.limits.limit = 66
        assert self.acceleration_br.edit()

    def test_check_acceleration_br_limit_after_edit(self):
        assert 66 == self.acceleration_br.limits.limit

    def test_edit_acceleration_br_limit_free(self):
        #Edit limit free
        self.acceleration_br.limits.limit_free = 66
        assert self.acceleration_br.edit()

    def test_check_acceleration_br_limit_free_after_edit(self):
        assert 66 == self.acceleration_br.limits.limit_free

    def test_edit_acceleration_br_price(self):
        # Edit price on
        self.acceleration_br.prices.price = 66
        assert self.acceleration_br.edit()

    def test_check_acceleration_br_price_after_edit(self):
        assert self.acceleration_br.prices.price == 66

    def test_delete_acceleration_br(self):
        # Delete
        if test.api_version == 4.2:
            test.gen_api_doc = True
        assert self.acceleration_br.delete()