# daily
import pytest
from onapp_helper import test
from onapp_helper.billing_plan import BillingPlan
from onapp_helper.br_helper.recipe_group import RecipeGroupBR
from onapp_helper.recipe.recipe_groups import RecipeGroup


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.base_resources
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version >= 6.1, reason=test.not_supported_msg(BillingPlan))
class TestRecipeGroupLimits():
    def setup_class(self):
        self.billing_plan = BillingPlan()
        self.billing_plan.create()
        self.r_group = RecipeGroup()
        assert self.r_group.create()
        self.recipe_group_br = RecipeGroupBR(billing_plan=self.billing_plan, target_id=self.r_group.id)

    def teardown_class(self):
        self.billing_plan.delete()
        self.r_group.delete()

    def test_create_recipe_group_br(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        assert self.recipe_group_br.create()

    def test_check_recipe_group_br(self):
        assert self.r_group.label == self.recipe_group_br.label

    def test_delete_recipe_group_br(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        assert self.recipe_group_br.delete()