# daily
import pytest
from onapp_helper.br_helper.template import TemplateBR
from onapp_helper.billing_plan import BillingPlan
from onapp_helper import test


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.base_resources
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version >= 6.1, reason=test.not_supported_msg(BillingPlan))
class TestTemplateLimits():
    def setup_class(self):
        self.billing_plan = BillingPlan()
        self.billing_plan.create()
        self.template_br = TemplateBR(billing_plan=self.billing_plan)

    def teardown_class(self):
        self.billing_plan.delete()

    def test_create_template_br_with_negative_limit(self):
        # Create with negative limit
        self.template_br.limits.limit = -10
        assert not self.template_br.create()

    def test_check_error_message_for_template_br_with_negative_limit(self):
        assert self.template_br.E_VALIDATION_VALUE in self.template_br.error['limit']

    def test_create_template_br_with_negative_free_limit(self):
        # Create with negative free_limit
        self.template_br.limits.limit = 10
        self.template_br.limits.limit_free = -10
        assert not self.template_br.create()

    def test_check_error_message_for_template_br_with_negative_free_limit(self):
        assert self.template_br.E_VALIDATION_VALUE in self.template_br.error['limit_free']

    def test_create_template_br_with_negative_price(self):
        # Create with negative price
        self.template_br.limits.limit_free = 10
        self.template_br.prices.price = -10
        assert not self.template_br.create()

    def test_check_error_message_for_template_br_with_negative_price(self):
        assert self.template_br.E_VALIDATION_VALUE in self.template_br.error['price']

    def test_create_template_br_with_correct_parameters(self):
        # Create with correct values
        self.template_br.prices.price = 10
        if test.api_version == 4.2:
            test.gen_api_doc = True
        assert self.template_br.create()
        assert self.template_br.limits.limit == 10
        assert self.template_br.limits.limit_free == 10
        assert self.template_br.prices.price == 10

    def test_edit_template_br_limit(self):
        # Edit limit
        if test.api_version == 4.2:
            test.gen_api_doc = True
        self.template_br.limits.limit = 66
        assert self.template_br.edit()
        assert self.template_br.limits.limit == 66

    def test_edit_template_br_limit_free(self):
        #Edit limit free
        self.template_br.limits.limit_free = 66
        assert self.template_br.edit()
        assert self.template_br.limits.limit_free == 66

    def test_edit_template_br_price(self):
        # Edit price
        self.template_br.prices.price = 66
        assert self.template_br.edit()
        assert self.template_br.prices.price == 66

    def test_delete_template_br(self):
        # Delete
        if test.api_version == 4.2:
            test.gen_api_doc = True
        assert self.template_br.delete()