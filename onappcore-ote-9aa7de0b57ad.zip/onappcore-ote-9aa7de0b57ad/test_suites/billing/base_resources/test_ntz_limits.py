# daily
from onapp_helper.br_helper.ntz import NTZBR
from onapp_helper.network_zone import NetworkZone
from onapp_helper.billing_plan import BillingPlan
from onapp_helper import test
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.base_resources
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version >= 6.1, reason=test.not_supported_msg(BillingPlan))
class TestNTZLimits():
    def setup_class(self):
        self.billing_plan = BillingPlan()
        self.billing_plan.create()
        self.ntz = NetworkZone()
        self.ntz.label = self.__name__
        self.ntz.create()
        self.ntz_br = NTZBR(billing_plan=self.billing_plan,
                            target_id=self.ntz.id)

    def teardown_class(self):
        self.billing_plan.delete()
        self.ntz.delete()

    # CREATE
    def test_create_ntz_br(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        # set limits
        self.ntz_br.limits.limit_ip_free = 1
        self.ntz_br.limits.limit_ip = 5
        self.ntz_br.limits.limit_rate_free = 12
        self.ntz_br.limits.limit_rate = 999
        self.ntz_br.limits.limit_data_received_free = 1
        self.ntz_br.limits.limit_data_sent_free = 1
        # set prices
        self.ntz_br.prices.price_ip_on = 10
        self.ntz_br.prices.price_ip_off = 5
        self.ntz_br.prices.price_rate_on = 10
        self.ntz_br.prices.price_rate_off = 5
        self.ntz_br.prices.price_data_received = 10
        self.ntz_br.prices.price_data_sent = 5
        # create
        assert self.ntz_br.create()

    # CHECK
    # limits
    def test_check_ntz_br_limit_ip_free(self):
        assert self.ntz_br.limits.limit_ip_free == 1

    def test_check_ntz_br_limit_ip(self):
        assert self.ntz_br.limits.limit_ip == 5

    def test_check_ntz_br_limit_rate_free(self):
        assert self.ntz_br.limits.limit_rate_free == 12

    def test_check_ntz_br_limit_rate(self):
        assert self.ntz_br.limits.limit_rate == 999

    def test_check_ntz_br_limit_data_received_free(self):
        assert self.ntz_br.limits.limit_data_received_free == 1

    def test_check_ntz_br_limit_data_sent_free(self):
        assert self.ntz_br.limits.limit_data_sent_free == 1

    # prices
    def test_check_ntz_br_price_ip_on(self):
        assert self.ntz_br.prices.price_ip_on == 10

    def test_check_ntz_br_price_ip_off(self):
        assert self.ntz_br.prices.price_ip_off == 5

    def test_check_ntz_br_price_rate_on(self):
        assert self.ntz_br.prices.price_rate_on == 10

    def test_check_ntz_br_price_rate_off(self):
        assert self.ntz_br.prices.price_rate_off == 5

    def test_check_ntz_br_price_data_received(self):
        assert self.ntz_br.prices.price_data_received == 10

    def test_check_ntz_br_price_data_sent(self):
        assert self.ntz_br.prices.price_data_sent == 5

    # EDIT
    def test_edit_ntz_br(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        # set limits
        self.ntz_br.limits.limit_ip_free = 11
        self.ntz_br.limits.limit_ip = 51
        self.ntz_br.limits.limit_rate_free = 121
        self.ntz_br.limits.limit_rate = 888
        self.ntz_br.limits.limit_data_received_free = 11
        self.ntz_br.limits.limit_data_sent_free = 11
        # set prices
        self.ntz_br.prices.price_ip_on = 101
        self.ntz_br.prices.price_ip_off = 51
        self.ntz_br.prices.price_rate_on = 101
        self.ntz_br.prices.price_rate_off = 51
        self.ntz_br.prices.price_data_received = 101
        self.ntz_br.prices.price_data_sent = 51
        # edit
        assert self.ntz_br.edit()

    # CHECK
    # limits
    def test_check_ntz_br_new_limit_ip_free(self):
        assert self.ntz_br.limits.limit_ip_free == 11

    def test_check_ntz_br_new_limit_ip(self):
        assert self.ntz_br.limits.limit_ip == 51

    def test_check_ntz_br_new_limit_rate_free(self):
        assert self.ntz_br.limits.limit_rate_free == 121

    def test_check_ntz_br_new_limit_rate(self):
        assert self.ntz_br.limits.limit_rate == 888

    def test_check_ntz_br_new_limit_data_received_free(self):
        assert self.ntz_br.limits.limit_data_received_free == 11

    def test_check_ntz_br_new_limit_data_sent_free(self):
        assert self.ntz_br.limits.limit_data_sent_free == 11

    # prices
    def test_check_ntz_br_new_price_ip_on(self):
        assert self.ntz_br.prices.price_ip_on == 101

    def test_check_ntz_br_new_price_ip_off(self):
        assert self.ntz_br.prices.price_ip_off == 51

    def test_check_ntz_br_new_price_rate_on(self):
        assert self.ntz_br.prices.price_rate_on == 101

    def test_check_ntz_br_new_price_rate_off(self):
        assert self.ntz_br.prices.price_rate_off == 51

    def test_check_ntz_br_new_price_data_received(self):
        assert self.ntz_br.prices.price_data_received == 101

    def test_check_ntz_br_new_price_data_sent(self):
        assert self.ntz_br.prices.price_data_sent == 51

    @pytest.mark.skipif(test.api_version >= 4.2, reason="Deprecated.")
    def test_check_use_master_template_zone_switcher_till_4_2_version(self):
        # Check "Use Master Template Zone?" switcher.
        assert not self.dsz.in_template_zone
        self.ntz_br.in_template_zone = True
        assert self.ntz_br.edit()
        assert self.ntz_br.in_template_zone

    @pytest.mark.skipif(test.api_version < 4.2, reason="Not implemented.")
    @pytest.mark.skipif(test.api_version >= 5.7, reason="Deprecated.")
    def test_check_use_master_template_zone_switcher_since_4_2_version(self):
        # Check "Use Master Template Zone?" switcher.
        assert not self.ntz_br.in_master_zone
        self.ntz_br.in_master_zone = True
        assert self.ntz_br.edit()
        assert self.ntz_br.in_master_zone

    def test_delete_ntz_br(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        assert self.ntz_br.delete()