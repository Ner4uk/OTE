# daily
import pytest
from onapp_helper.br_helper.bsz import BSZBR
from onapp_helper.billing_plan import BillingPlan
from onapp_helper.bsz import BSZ
from onapp_helper import test


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.base_resources
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version >= 6.1, reason=test.not_supported_msg(BillingPlan))
class TestBSZLimits():
    def setup_class(self):
        self.billing_plan = BillingPlan()
        self.billing_plan.create()
        self.bsz = BSZ()
        self.bsz.label = self.__name__
        self.bsz.create()
        self.bsz_br = BSZBR(billing_plan=self.billing_plan, target_id=self.bsz.id)

    def teardown_class(self):
        self.billing_plan.delete()
        self.bsz.delete()

    def test_create_bsz_br(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        # Set free limits
        self.bsz_br.limits.limit_backup_free = 10
        self.bsz_br.limits.limit_backup_disk_size_free = 11
        self.bsz_br.limits.limit_template_free = 12
        self.bsz_br.limits.limit_template_disk_size_free = 13
        if test.cp_version >= 5.2:
            self.bsz_br.limits.limit_ova_free = 15
            self.bsz_br.limits.limit_ova_disk_size_free = 17
        # Set limits
        self.bsz_br.limits.limit_backup = 101
        self.bsz_br.limits.limit_backup_disk_size = 111
        self.bsz_br.limits.limit_template = 121
        self.bsz_br.limits.limit_template_disk_size = 131
        if test.cp_version >= 5.2:
            self.bsz_br.limits.limit_ova = 141
            self.bsz_br.limits.limit_ova_disk_size = 151
        #Set prices
        self.bsz_br.prices.price_backup = 110
        self.bsz_br.prices.price_backup_disk_size = 120
        self.bsz_br.prices.price_template = 130
        self.bsz_br.prices.price_template_disk_size = 140
        if test.cp_version >= 5.2:
            self.bsz_br.prices.price_ova = 150
            self.bsz_br.prices.price_ova_disk_size = 160
        # Create
        assert self.bsz_br.create()
        
    def test_check_free_limits_for_bsz_br(self):
        # Check
        # Check free limits
        assert self.bsz_br.limits.limit_backup_free == 10
        assert self.bsz_br.limits.limit_backup_disk_size_free == 11
        assert self.bsz_br.limits.limit_template_free == 12
        assert self.bsz_br.limits.limit_template_disk_size_free == 13
        if test.cp_version >= 5.2:
            assert self.bsz_br.limits.limit_ova_free == 15
            assert self.bsz_br.limits.limit_ova_disk_size_free == 17

    def test_check_limits_for_bsz_br(self):
        # Check limits
        assert self.bsz_br.limits.limit_backup == 101
        assert self.bsz_br.limits.limit_backup_disk_size == 111
        assert self.bsz_br.limits.limit_template == 121
        assert self.bsz_br.limits.limit_template_disk_size == 131
        if test.cp_version >= 5.2:
            assert self.bsz_br.limits.limit_ova == 141
            assert self.bsz_br.limits.limit_ova_disk_size == 151

    def test_check_prices_for_bsz_br(self):
        # Check prices
        assert self.bsz_br.prices.price_backup == 110
        assert self.bsz_br.prices.price_backup_disk_size == 120
        assert self.bsz_br.prices.price_template == 130
        assert self.bsz_br.prices.price_template_disk_size == 140
        if test.cp_version >= 5.2:
            assert self.bsz_br.prices.price_ova == 150
            assert self.bsz_br.prices.price_ova_disk_size == 160

    def test_edit_bsz_br(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        # EDIT
        # Set free limits
        self.bsz_br.limits.limit_backup_free = 0
        self.bsz_br.limits.limit_backup_disk_size_free = 1
        self.bsz_br.limits.limit_template_free = 2
        self.bsz_br.limits.limit_template_disk_size_free = 3
        if test.cp_version >= 5.2:
            self.bsz_br.limits.limit_ova_free = 4
            self.bsz_br.limits.limit_ova_disk_size_free = 5
        # Set limits
        self.bsz_br.limits.limit_backup = 10
        self.bsz_br.limits.limit_backup_disk_size = 11
        self.bsz_br.limits.limit_template = 12
        self.bsz_br.limits.limit_template_disk_size = 13
        if test.cp_version >= 5.2:
            self.bsz_br.limits.limit_ova = 14
            self.bsz_br.limits.limit_ova_disk_size = 15
        #Set prices
        self.bsz_br.prices.price_backup = 11
        self.bsz_br.prices.price_backup_disk_size = 12
        self.bsz_br.prices.price_template = 13
        self.bsz_br.prices.price_template_disk_size = 14
        if test.cp_version >= 5.2:
            self.bsz_br.prices.price_ova = 15
            self.bsz_br.prices.price_ova_disk_size = 16
        # Edit
        assert self.bsz_br.edit()

    def test_check_new_free_limits_for_bsz_br(self):
        # Check
        # Check free limits
        assert self.bsz_br.limits.limit_backup_free == 0
        assert self.bsz_br.limits.limit_backup_disk_size_free == 1
        assert self.bsz_br.limits.limit_template_free == 2
        assert self.bsz_br.limits.limit_template_disk_size_free == 3
        if test.cp_version >= 5.2:
            assert self.bsz_br.limits.limit_ova_free == 4
            assert self.bsz_br.limits.limit_ova_disk_size_free == 5

    def test_check_new_limits_for_bsz_br(self):
        # Check limits
        assert self.bsz_br.limits.limit_backup == 10
        assert self.bsz_br.limits.limit_backup_disk_size == 11
        assert self.bsz_br.limits.limit_template == 12
        assert self.bsz_br.limits.limit_template_disk_size == 13
        if test.cp_version >= 5.2:
            assert self.bsz_br.limits.limit_ova == 14
            assert self.bsz_br.limits.limit_ova_disk_size == 15

    def test_check_new_prices_for_bsz_br(self):
        # Check prices
        assert self.bsz_br.prices.price_backup == 11
        assert self.bsz_br.prices.price_backup_disk_size == 12
        assert self.bsz_br.prices.price_template == 13
        assert self.bsz_br.prices.price_template_disk_size == 14
        if test.cp_version >= 5.2:
            assert self.bsz_br.prices.price_ova == 15
            assert self.bsz_br.prices.price_ova_disk_size == 16

    def test_delete_bsz_br(self):
        # Delete
        if test.api_version == 4.2:
            test.gen_api_doc = True
        assert self.bsz_br.delete()