# daily
import pytest
from onapp_helper.br_helper.vm_monit import VmMonitBR
from onapp_helper.billing_plan import BillingPlan
from onapp_helper import test


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.base_resources
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version >= 6.1, reason=test.not_supported_msg(BillingPlan))
class TestAutoScalingLimits():
    def setup_class(self):
        self.billing_plan = BillingPlan()
        self.billing_plan.create()
        self.auto_scaling_br = VmMonitBR(billing_plan=self.billing_plan)

    def teardown_class(self):
        self.billing_plan.delete()

    def test_you_can_not_create_auto_scaling_br_with_negative_limit(self):
        # Create with negative limit
        self.auto_scaling_br.limits.limit = -10
        assert not self.auto_scaling_br.create()

    def test_check_error_message_for_auto_scaling_br_negative_limit(self):
        assert self.auto_scaling_br.E_VALIDATION_VALUE in self.auto_scaling_br.error['limit']

    def test_you_can_not_create_auto_scaling_br_with_negative_free_limit(self):
        # Create with negative free_limit
        self.auto_scaling_br.limits.limit = 10
        self.auto_scaling_br.limits.limit_free = -10
        assert not self.auto_scaling_br.create()

    def test_check_error_message_for_auto_scaling_br_negative_free_limit(self):
        assert self.auto_scaling_br.E_VALIDATION_VALUE in self.auto_scaling_br.error['limit_free']

    def test_you_can_not_create_auto_scaling_br_with_negative_price(self):
        # Create with negative price
        self.auto_scaling_br.limits.limit_free = 10
        self.auto_scaling_br.prices.price = -10
        assert not self.auto_scaling_br.create()

    def test_check_error_message_for_auto_scaling_br_negative_price(self):
        assert self.auto_scaling_br.E_VALIDATION_VALUE in self.auto_scaling_br.error['price']

    def test_create_auto_scaling_br_with_correct_values(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        # Create with correct values
        self.auto_scaling_br.prices.price = 10
        assert self.auto_scaling_br.create()

    def test_check_auto_scaling_br_limit(self):
        assert self.auto_scaling_br.limits.limit == 10

    def test_auto_scaling_br_limit_free(self):
        assert self.auto_scaling_br.limits.limit_free == 10

    def test_auto_scaling_br_price(self):
        assert self.auto_scaling_br.prices.price == 10

    def test_edit_auto_scaling_br_limit(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        # Edit limit
        self.auto_scaling_br.limits.limit = 66
        assert self.auto_scaling_br.edit()

    def test_check_auto_scaling_br_limit_after_edit(self):
        assert self.auto_scaling_br.limits.limit == 66

    def test_edit_auto_scaling_br_limit_free(self):
        #Edit limit free
        self.auto_scaling_br.limits.limit_free = 66
        assert self.auto_scaling_br.edit()

    def test_check_auto_scaling_br_limit_free_after_edit(self):
        assert self.auto_scaling_br.limits.limit_free == 66

    def test_edit_auto_scaling_br_price(self):
        # Edit price
        self.auto_scaling_br.prices.price = 66
        assert self.auto_scaling_br.edit()

    def test_check_auto_scaling_br_price_after_edit(self):
        assert self.auto_scaling_br.prices.price == 66

    def test_delete_auto_scaling_br(self):
        # Delete
        if test.api_version == 4.2:
            test.gen_api_doc = True
        assert self.auto_scaling_br.delete()