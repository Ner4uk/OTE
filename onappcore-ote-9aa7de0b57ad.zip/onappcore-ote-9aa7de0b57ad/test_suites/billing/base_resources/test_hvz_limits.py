# daily
from onapp_helper.br_helper.hvz import HVZBR
from onapp_helper.hypervisor_zone import HypervisorZone
from onapp_helper.billing_plan import BillingPlan
from onapp_helper import test
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.base_resources
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(test.cp_version >= 6.1, reason=test.not_supported_msg(BillingPlan))
class TestHVZLimits():
    def setup_class(self):
        self.billing_plan = BillingPlan()
        self.billing_plan.create()
        self.hvz = HypervisorZone()
        self.hvz.label = self.__name__
        assert self.hvz.create()
        self.hvz_br = HVZBR(billing_plan=self.billing_plan, target_id=self.hvz.id)

    def teardown_class(self):
        self.billing_plan.delete()
        self.hvz.delete()

    def test_you_can_not_create_hvz_br_with_negative_free_cpu_limit(self):
        # Try to create with negative free limits
        self.hvz_br.limits.limit_free_cpu = -10
        assert not self.hvz_br.create()

    def test_error_message_for_hvz_br_with_negative_free_cpu_limit(self):
        assert self.hvz_br.E_VALIDATION_VALUE in self.hvz_br.error['limit_free_cpu']

    def test_you_can_not_create_hvz_br_with_negative_free_cpu_share_limit(self):
        self.hvz_br.reset()
        self.hvz_br.limits.limit_free_cpu_share = -10
        assert not self.hvz_br.create()

    def test_error_message_for_hvz_br_with_negative_free_cpu_share_limit(self):
        assert self.hvz_br.E_VALIDATION_VALUE in self.hvz_br.error['limit_free_cpu_share']

    def test_you_can_not_create_hvz_br_with_negative_free_memory_limit(self):
        self.hvz_br.reset()
        self.hvz_br.limits.limit_free_memory = -10
        assert not self.hvz_br.create()

    def test_error_message_for_hvz_br_with_negative_free_memory_limit(self):
        assert self.hvz_br.E_VALIDATION_VALUE in self.hvz_br.error['limit_free_memory']

    def test_you_can_not_create_hvz_br_with_negative_cpu_limit(self):
        # Try to create with negative limits
        self.hvz_br.limits.limit_cpu = -10
        assert not self.hvz_br.create()

    def test_error_message_for_hvz_br_with_negative_cpu_limit(self):
        assert self.hvz_br.E_VALIDATION_VALUE in self.hvz_br.error['limit_cpu']

    def test_you_can_not_create_hvz_br_with_negative_cpu_share_limit(self):
        self.hvz_br.reset()
        self.hvz_br.limits.limit_cpu_share = -10
        assert not self.hvz_br.create()

    def test_error_message_for_hvz_br_with_negative_cpu_share_limit(self):
        assert self.hvz_br.E_VALIDATION_VALUE in self.hvz_br.error['limit_cpu_share']

    def test_you_can_not_create_hvz_br_with_negative_memory_limit(self):
        self.hvz_br.reset()
        self.hvz_br.limits.limit_memory = -10
        assert not self.hvz_br.create()

    def test_error_message_for_hvz_br_with_negative_memory_limit(self):
        assert self.hvz_br.E_VALIDATION_VALUE in self.hvz_br.error['limit_memory']

        # TO DO - add another tests for checking validation.

        # Create with correct values
    def test_create_hvz_br_with_correct_parameters(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        self.hvz_br.reset()
        self.hvz_br.limits.limit_free_cpu = 1
        self.hvz_br.limits.limit_free_cpu_share = 10
        self.hvz_br.limits.limit_free_memory = 128
        self.hvz_br.limits.limit_cpu = 4
        self.hvz_br.limits.limit_default_cpu_share = 50
        self.hvz_br.limits.limit_cpu_share = 90
        self.hvz_br.limits.limit_memory = 512
        self.hvz_br.prices.price_on_cpu = 10
        self.hvz_br.prices.price_on_cpu_share = 10
        self.hvz_br.prices.price_on_memory = 10
        self.hvz_br.prices.price_off_cpu = 5
        self.hvz_br.prices.price_off_cpu_share = 5
        self.hvz_br.prices.price_off_memory = 5
        assert self.hvz_br.create(), self.hvz_br.error

    def test_check_hvz_br_limit_free_cpu(self):
        assert self.hvz_br.limits.limit_free_cpu == 1

    def test_check_hvz_br_limit_free_cpu_share(self):
        assert self.hvz_br.limits.limit_free_cpu_share == 10

    def test_check_hvz_br_limit_free_memory(self):
        assert self.hvz_br.limits.limit_free_memory == 128

    def test_check_hvz_br_limit_cpu(self):
        assert self.hvz_br.limits.limit_cpu == 4

    def test_check_hvz_br_limit_cpu_share(self):
        assert self.hvz_br.limits.limit_cpu_share == 90

    def test_check_hvz_br_limit_memory(self):
        assert self.hvz_br.limits.limit_memory == 512

    def test_check_hvz_br_price_on_cpu(self):
        assert self.hvz_br.prices.price_on_cpu == 10

    def test_check_hvz_br_price_on_cpu_share(self):
        assert self.hvz_br.prices.price_on_cpu_share == 10

    def test_check_hvz_br_price_on_memory(self):
        assert self.hvz_br.prices.price_on_memory == 10

    def test_check_hvz_br_price_off_cpu(self):
        assert self.hvz_br.prices.price_off_cpu == 5

    def test_check_hvz_br_price_off_cpu_share(self):
        assert self.hvz_br.prices.price_off_cpu_share == 5

    def test_check_hvz_br_price_off_memory(self):
        assert self.hvz_br.prices.price_off_memory == 5

    def test_edit_hvz_br(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        # Edit
        self.hvz_br.limits.limit_free_cpu = 2
        self.hvz_br.limits.limit_free_cpu_share = 20
        self.hvz_br.limits.limit_free_memory = 256
        self.hvz_br.limits.limit_cpu = 8
        self.hvz_br.limits.limit_cpu_share = 99
        self.hvz_br.limits.limit_memory = 1024
        self.hvz_br.prices.price_on_cpu = 20
        self.hvz_br.prices.price_on_cpu_share = 20
        self.hvz_br.prices.price_on_memory = 20
        self.hvz_br.prices.price_off_cpu = 2
        self.hvz_br.prices.price_off_cpu_share = 2
        self.hvz_br.prices.price_off_memory = 2
        assert self.hvz_br.edit()

    def test_check_hvz_br_new_limit_free_cpu(self):
        assert self.hvz_br.limits.limit_free_cpu == 2

    def test_check_hvz_br_new_limit_free_cpu_share(self):
        assert self.hvz_br.limits.limit_free_cpu_share == 20

    def test_check_hvz_br_new_limit_free_memory(self):
        assert self.hvz_br.limits.limit_free_memory == 256

    def test_check_hvz_br_new_limit_cpu(self):
        assert self.hvz_br.limits.limit_cpu == 8

    def test_check_hvz_br_new_limit_cpu_share(self):
        assert self.hvz_br.limits.limit_cpu_share == 99

    def test_check_hvz_br_new_limit_memory(self):
        assert self.hvz_br.limits.limit_memory == 1024

    def test_check_hvz_br_new_price_on_cpu(self):
        assert self.hvz_br.prices.price_on_cpu == 20

    def test_check_hvz_br_new_price_on_cpu_share(self):
        assert self.hvz_br.prices.price_on_cpu_share == 20

    def test_check_hvz_br_new_price_on_memory(self):
        assert self.hvz_br.prices.price_on_memory == 20

    def test_check_hvz_br_new_price_off_cpu(self):
        assert self.hvz_br.prices.price_off_cpu == 2

    def test_check_hvz_br_new_price_off_cpu_share(self):
        assert self.hvz_br.prices.price_off_cpu_share == 2

    def test_check_hvz_br_new_price_off_memory(self):
        assert self.hvz_br.prices.price_off_memory == 2

    def test_check_use_cpu_units_switcher(self):
        # Check 'Use CPU units?' switcher
        self.hvz_br.preferences.use_cpu_units = True
        assert self.hvz_br.edit()
        assert self.hvz_br.preferences.use_cpu_units

    def test_set_hvz_br_vs_creation_properties(self):
        self.hvz_br.reset()
        # Set VS creation properties
        self.hvz_br.limits.limit_default_cpu = 4
        self.hvz_br.limits.limit_default_cpu_share = 66
        self.hvz_br.limits.limit_min_cpu = 2
        self.hvz_br.limits.limit_min_cpu_priority = 33
        self.hvz_br.limits.limit_min_memory = 256
        self.hvz_br.preferences.use_default_cpu = True
        self.hvz_br.preferences.use_default_cpu_share = True
        assert self.hvz_br.edit()

    def test_check_hvz_br_limit_default_cpu(self):
        # Check VS creation properties
        assert self.hvz_br.limits.limit_default_cpu == 4

    def test_check_hvz_br_limit_default_cpu_share(self):
        assert self.hvz_br.limits.limit_default_cpu_share == 66

    def test_check_hvz_br_limit_min_cpu(self):
        assert self.hvz_br.limits.limit_min_cpu == 2

    def test_check_hvz_br_limit_min_cpu_priority(self):
        assert self.hvz_br.limits.limit_min_cpu_priority == 33

    def test_check_hvz_br_limit_min_memory(self):
        assert self.hvz_br.limits.limit_min_memory == 256

    def test_check_hvz_br_use_default_cpu(self):
        assert self.hvz_br.preferences.use_default_cpu

    def test_check_hvz_br_use_default_cpu_share(self):
        assert self.hvz_br.preferences.use_default_cpu_share

    @pytest.mark.skipif(test.api_version >= 4.2, reason="Deprecated.")
    def test_check_use_master_bucket_zone_switcher_till_4_2_version(self):
        # Check "Use Master Bucket Zone?" switcher.
        assert not self.hvz_br.in_bucket_zone
        self.hvz_br.in_bucket_zone = True
        assert self.hvz_br.edit()
        assert self.hvz_br.in_bucket_zone

    @pytest.mark.skipif(test.api_version < 4.2, reason="Not implemented.")
    @pytest.mark.skipif(test.api_version >= 5.7, reason="Deprecated.")
    def test_check_use_master_bucket_zone_switcher_since_4_2_version(self):
        # Check "Use Master Bucket Zone?" switcher.
        assert not self.hvz_br.in_master_zone
        self.hvz_br.in_master_zone = True
        assert self.hvz_br.edit()
        assert self.hvz_br.in_master_zone

    def test_delete_hvz_br(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        assert self.hvz_br.delete()