# daily
import pytest

from onapp_helper import test
from onapp_helper.billing_plan import BillingPlan
from onapp_helper.br_helper.edge_group import EdgeGroupBR
from onapp_helper.cdn.edge_group import EdgeGroup


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.base_resources
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version >= 6.1,
    reason=test.not_supported_msg(BillingPlan)
)
class TestEdgeGroupsLimits:
    def setup_class(self):
        eg = EdgeGroup()
        eg.get_all()
        if eg.status_code == 403:
            pytest.skip("Edge Groups is not supported. See onapp license.")

        try:
            self.billing_plan = BillingPlan()
            self.billing_plan.create()
            self.e_group = EdgeGroup()
            self.e_group.label = self.__name__
            assert self.e_group.create(), self.e_group.error
            self.edge_group_br = EdgeGroupBR(
                billing_plan=self.billing_plan,
                target_id=self.e_group.id
            )
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        attributes = (
            'billing_plan',
            'e_group'
        )
        test.clean_up_resources(attributes, self)

    def test_create_edge_group_br(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        self.edge_group_br.prices.price = 90
        assert self.edge_group_br.create()

    def test_check_edge_group_br_price(self):
        assert self.edge_group_br.prices.price == 90

    def test_check_edge_group_br_label(self):
        assert self.e_group.label == self.edge_group_br.label

    def test_edit_edge_group_br_price(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        self.edge_group_br.prices.price = 190
        assert self.edge_group_br.edit()

    def test_check_new_edge_group_br_price(self):
        assert self.edge_group_br.prices.price == 190

    def test_delete_edge_group_br(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        assert self.edge_group_br.delete()