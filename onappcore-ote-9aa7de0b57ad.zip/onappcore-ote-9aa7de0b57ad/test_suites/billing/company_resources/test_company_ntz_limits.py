# daily
# Since 4.2
from onapp_helper.company_resource.ntz import CompanyNTZBR
from onapp_helper.company_plan import CompanyPlan
from onapp_helper.network_zone import NetworkZone
from onapp_helper import test
import pytest


#test.load_env()
#
#
#@pytest.mark.skipif(
#    not test.env.netz.id,
#    reason="No available NTZ."
#)


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.company_resources
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version >= 5.6,
    reason="Old billing is not supported..."
)
class TestCompanyNTZLimits():
    def setup_class(self):
        try:
            self.company_plan = CompanyPlan()
            assert self.company_plan.create()
            self.ntzs = NetworkZone().get_by_params()
            #ntz_id = test.env.netz.id
            self.company_ntz_br = CompanyNTZBR(
                company_plan=self.company_plan,
                target_id=self.ntzs[0].id
            )
            self.limits = {
                "limit_free_ip": 1,
                "limit_free_data_sent": 1,
                "limit_free_data_received": 1,
                "limit_ip": 5
            }

            self.prices = {
                "price_ip": 5,
                "price_data_sent": 10,
                "price_data_received": 15
            }
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        self.company_plan.delete()

    def test_negative_limits(self):
        for key in self.limits.keys():
            self.company_ntz_br.reset()
            self.company_ntz_br.limits.__dict__[key] = -10
            self.company_ntz_br.create()
            assert 'must be greater than or equal to 0' in self.company_ntz_br.error[key]

    def test_create_with_correct_parameters(self):
        self.company_ntz_br.reset()

        # Set limits
        for key, value in self.limits.items():
            self.company_ntz_br.limits.__dict__[key] = value

        # Set prices
        for key, value in self.prices.items():
            self.company_ntz_br.prices.__dict__[key] = value
        test.gen_api_doc = True
        assert self.company_ntz_br.create()

    def test_check_limits(self):
        for key, value in self.limits.items():
            assert self.company_ntz_br.limits.__dict__[key] == value

    def test_check_prices(self):
        for key, value in self.prices.items():
            assert self.company_ntz_br.prices.__dict__[key] == value

    def test_edit_limits(self):
        for key, value in self.limits.items():
            self.limits[key] = value * 2
            self.company_ntz_br.limits.__dict__[key] = value * 2
        test.gen_api_doc = True
        assert self.company_ntz_br.edit()

    def test_check_new_limits(self):
        for key, value in self.limits.items():
            assert self.company_ntz_br.limits.__dict__[key] == value

    def test_edit_pricess(self):
        for key, value in self.prices.items():
            self.prices[key] = value * 2
            self.company_ntz_br.prices.__dict__[key] = value * 2
        assert self.company_ntz_br.edit()

    def test_check_new_prices(self):
        for key, value in self.prices.items():
            assert self.company_ntz_br.prices.__dict__[key] == value

    # https://onappdev.atlassian.net/browse/CORE-5980
    def test_target_id_should_not_be_changed(self):
        self.company_ntz_br.target_id = self.ntzs[1].id
        assert self.company_ntz_br.edit()
        assert self.company_ntz_br.target_id == self.ntzs[0].id

    # https://onappdev.atlassian.net/browse/CORE-5980
    def test_target_type_should_not_be_changed(self):
        self.company_ntz_br.target_type = "Paack"  # Should be checked in DB
        assert self.company_ntz_br.edit()
        q = 'SELECT target_type from base_resources WHERE id={}'.format(
            self.company_ntz_br.id
        )
        assert test.cp.mysql_execute(q)[0] == "Pack"

    def test_delete_company_resource(self):
        test.gen_api_doc = True
        assert self.company_ntz_br.delete()