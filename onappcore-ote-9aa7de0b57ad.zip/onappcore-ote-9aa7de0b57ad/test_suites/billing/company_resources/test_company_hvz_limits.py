# daily
# Since 4.2
from onapp_helper.company_resource.hvz import CompanyHVZBR
from onapp_helper.company_plan import CompanyPlan
from onapp_helper.hypervisor_zone import HypervisorZone
from onapp_helper import test
import pytest


#test.load_env()


#@pytest.mark.skipif(
#    not test.env.hvz.id,
#    reason="No available HVZ."
#)


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.company_resources
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version >= 5.6,
    reason="Old billing is not supported..."
)
class TestCompanyHVZLimits():
    def setup_class(self):
        try:
            self.company_plan = CompanyPlan()
            assert self.company_plan.create()
            self.hvzs = HypervisorZone().get_by_params()
            hvz_id = self.hvzs[0].id
            self.company_hvz_br = CompanyHVZBR(
                company_plan=self.company_plan,
                target_id=hvz_id
            )
            self.limits = {
                "limit_free_allocation_cpu_allocation": 2,
                "limit_free_allocation_cpu_resources_guaranteed": 2,
                "limit_free_allocation_memory_allocation": 128,
                "limit_free_allocation_memory_resources_guaranteed": 256,
                #"limit_free_allocation_vcpu_speed": 10,
                "limit_min_allocation_cpu_allocation": 2,
                "limit_min_allocation_cpu_resources_guaranteed": 2,
                "limit_min_allocation_memory_allocation": 128,
                "limit_min_allocation_memory_resources_guaranteed": 256,
                #"limit_min_allocation_vcpu_speed": 10,
                "limit_allocation_cpu_allocation": 4,
                "limit_allocation_cpu_resources_guaranteed": 100,
                "limit_allocation_memory_allocation": 512,
                "limit_allocation_memory_resources_guaranteed": 1024,
                #"limit_allocation_vcpu_speed": 100,
                "limit_free_reservation_cpu_allocation": 2,
                "limit_free_reservation_memory_allocation": 512,
                "limit_min_reservation_cpu_allocation": 40,
                "limit_min_reservation_memory_allocation": 256,
                "limit_reservation_cpu_allocation": 50,
                "limit_reservation_memory_allocation": 60,
                "limit_free_pay_as_you_go_cpu_limit": 10,
                "limit_free_pay_as_you_go_memory_limit": 20,
                "limit_free_pay_as_you_go_cpu_used": 30,
                "limit_free_pay_as_you_go_memory_used": 40,
                "limit_min_pay_as_you_go_cpu_limit": 50,
                "limit_min_pay_as_you_go_memory_limit": 60,
                "limit_pay_as_you_go_cpu_limit": 70,
                "limit_pay_as_you_go_memory_limit": 80
            }

            self.prices = {
                "price_allocation_cpu_allocation": 10,
                "price_allocation_cpu_resources_guaranteed": 20,
                "price_allocation_memory_allocation": 30,
                "price_allocation_memory_resources_guaranteed": 40,
                #"price_allocation_vcpu_speed": 50,
                "price_reservation_cpu_allocation": 60,
                "price_reservation_memory_allocation": 70,
                "price_pay_as_you_go_cpu_limit": 1,
                "price_pay_as_you_go_memory_limit": 1,
                "price_pay_as_you_go_cpu_used": 10,
                "price_pay_as_you_go_memory_used": 10,
                "price_pay_as_you_go_cpu_limit_unlimited": 50,
                "price_pay_as_you_go_memory_limit_unlimited": 60
            }
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        self.company_plan.delete()

    def test_negative_limits(self):
        for key in self.limits.keys():
            self.company_hvz_br.reset()
            self.company_hvz_br.limits.__dict__[key] = -10
            self.company_hvz_br.create()
            assert 'must be greater than or equal to 0' in self.company_hvz_br.error[key]

    def test_create_with_correct_parameters(self):
        self.company_hvz_br.reset()

        # Set limits
        for key, value in self.limits.items():
            self.company_hvz_br.limits.__dict__[key] = value

        # Set prices
        for key, value in self.prices.items():
            self.company_hvz_br.prices.__dict__[key] = value

        test.gen_api_doc = True
        assert self.company_hvz_br.create()

    def test_check_limits(self):
        for key, value in self.limits.items():
            assert self.company_hvz_br.limits.__dict__[key] == value

    def test_check_prices(self):
        for key, value in self.prices.items():
            assert self.company_hvz_br.prices.__dict__[key] == value

    def test_edit_limits(self):
        for key, value in self.limits.items():
            self.limits[key] = value * 2
            self.company_hvz_br.limits.__dict__[key] = value * 2
        test.gen_api_doc = True
        assert self.company_hvz_br.edit()

    def test_check_new_limits(self):
        for key, value in self.limits.items():
            assert self.company_hvz_br.limits.__dict__[key] == value

    def test_edit_prices(self):
        for key, value in self.prices.items():
            self.prices[key] = value * 2
            self.company_hvz_br.prices.__dict__[key] = value * 2
        assert self.company_hvz_br.edit()

    def test_check_new_prices(self):
        for key, value in self.prices.items():
            assert self.company_hvz_br.prices.__dict__[key] == value

    # https://onappdev.atlassian.net/browse/CORE-5980
    def test_target_id_should_not_be_changed(self):
        self.company_hvz_br.target_id = self.hvzs[1].id
        assert self.company_hvz_br.edit()
        assert self.company_hvz_br.target_id == self.hvzs[0].id

    # https://onappdev.atlassian.net/browse/CORE-5980
    def test_target_type_should_not_be_changed(self):
        self.company_hvz_br.target_type = "Paack"  # Should be checked in DB
        assert self.company_hvz_br.edit()
        q = 'SELECT target_type from base_resources WHERE id={}'.format(
            self.company_hvz_br.id
        )
        assert test.cp.mysql_execute(q)[0] == "Pack"

    def test_delete_company_resource(self):
        test.gen_api_doc = True
        assert self.company_hvz_br.delete()