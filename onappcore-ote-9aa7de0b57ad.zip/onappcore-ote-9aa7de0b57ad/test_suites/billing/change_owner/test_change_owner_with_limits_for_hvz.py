from onapp_helper.br_helper.hvz import HVZBR
from onapp_helper.user import User
from onapp_helper.billing_plan import BillingPlan
from onapp_helper import test
from onapp_helper.server import VirtualServer
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.change_owner
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version >= 5.6,
    reason="Old billing is not supported..."
)
@pytest.mark.skipif(test.cp_version >= 6.1, reason=test.not_supported_msg(BillingPlan))
@pytest.mark.incremental
class TestChangingOwnerForHVZLimits:
    def setup_class(self):
        test.load_env()

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        try:
            self.billing_plan_1 = BillingPlan()
            self.billing_plan_1.label = "{0}1".format(self.__name__)
            assert self.billing_plan_1.create()

            self.billing_plan_2 = BillingPlan()
            self.billing_plan_2.label = "{0}2".format(self.__name__)
            assert self.billing_plan_2.create()

            self.hvz_br2 = HVZBR(billing_plan=self.billing_plan_2, target_id=test.env.hvz.id)
            assert self.hvz_br2.create()

            self.user_1 = User(bp=self.billing_plan_1)
            self.user_1.login = "{0}1".format(self.__name__).lower()
            self.user_1.password = test.generate_password()
            self.user_1.email = 'chown1@for.hvz'
            assert self.user_1.create()

            self.user_2 = User(bp=self.billing_plan_2)
            self.user_2.login = "{0}2".format(self.__name__).lower()
            self.user_2.password = test.generate_password()
            self.user_2.email = 'chown2@for.hvz'
            assert self.user_2.create()

            test.execute_as(self.user_1.login, self.user_1.password)

            self.vs = VirtualServer()
            self.vs.label = self.__name__
            assert self.vs.create(), self.vs.error
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        attributes = (
            'user_1',
            'billing_plan_1',
            'user_2',
            'billing_plan_2',
        )
        test.clean_up_resources(attributes, self)

    def test_cant_change_owner_with_cpu_limit_less_than_used(self):
        self.hvz_br2.limits.limit_cpu = self.vs.cpus - 1
        assert self.hvz_br2.edit(), self.hvz_br2.error
        assert not self.vs.change_owner(self.user_2.id)

    def test_can_change_owner_with_cpu_limit_eq_or_more_than_used(self):
        self.hvz_br2.limits.limit_cpu = self.vs.cpus
        self.hvz_br2.edit()
        assert self.vs.change_owner(self.user_2.id)
        # Change user back
        assert self.vs.change_owner(self.user_1.id)
        self.hvz_br2.reset()
        assert self.hvz_br2.edit(), self.hvz_br2.error

    def test_cant_change_owner_with_cpu_share_limit_less_than_used(self):
        self.hvz_br2.limits.limit_cpu_share = (self.vs.cpus * self.vs.cpu_shares) - 1
        assert self.hvz_br2.edit(), self.hvz_br2.error
        assert not self.vs.change_owner(self.user_2.id)

    def test_can_change_owner_with_cpu_shares_limit_eq_or_more_than_used(self):
        self.hvz_br2.limits.limit_cpu_share = self.vs.cpus * self.vs.cpu_shares
        assert self.hvz_br2.edit(), self.hvz_br2.error
        assert self.vs.change_owner(self.user_2.id), self.vs.error
        # Change user back
        assert self.vs.change_owner(self.user_1.id), self.vs.error
        self.hvz_br2.reset()
        assert self.hvz_br2.edit(), self.hvz_br2.error

    def test_cant_change_owner_with_memory_limit_less_than_used(self):
        self.hvz_br2.limits.limit_memory = self.vs.memory - 1
        assert self.hvz_br2.edit(), self.hvz_br2.error
        assert not self.vs.change_owner(self.user_2.id)

    def test_can_change_owner_with_memory_limit_eq_or_more_than_used(self):
        self.hvz_br2.limits.limit_memory = self.vs.memory
        assert self.hvz_br2.edit(), self.hvz_br2.error
        assert self.vs.change_owner(self.user_2.id), self.vs.error
        # Change user back
        assert self.vs.change_owner(self.user_1.id)
        self.hvz_br2.reset()
        assert self.hvz_br2.edit(), self.hvz_br2.error

