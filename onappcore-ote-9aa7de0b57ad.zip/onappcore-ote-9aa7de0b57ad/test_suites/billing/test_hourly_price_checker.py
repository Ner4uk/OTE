import time

import pytest

from onapp_helper import test
from onapp_helper.backup import Backup
from onapp_helper.billing_plan import BillingPlan
from onapp_helper.br_helper.backup import BackupBR
from onapp_helper.br_helper.bsz import BSZBR
from onapp_helper.br_helper.dsz import DSZBR
from onapp_helper.br_helper.hvz import HVZBR
from onapp_helper.br_helper.ntz import NTZBR
from onapp_helper.br_helper.storage_disk_size import StorageDiskSizeBR
from onapp_helper.br_helper.template import TemplateBR
from onapp_helper.bsz import BSZ
from onapp_helper.stats.user_stats import UserStats
from onapp_helper.stats.vm_stat import VmStat
from onapp_helper.template import Template
from onapp_helper.user import User
from onapp_helper.server import VirtualServer
from test_helper import billingTH

#TODO Add ISO, Autoscaling


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.hourly_price
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version >= 5.6,
    reason="Old billing is not supported..."
)
@pytest.mark.incremental
@pytest.mark.verbose
class TestHourlyPriceChecker:
    KB_IN_1GB = 1048576.0

    def setup_class(self):
        test.load_env()

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        test.cp.generate_10MB_test_file()
        test.run_at(minutes=40)

        try:
            self.billing_plan = BillingPlan()
            self.billing_plan.label = 'HourlyPriceChecker'
            self.billing_plan.monthly_price = 100.0
            self.billing_plan.currency_code = 'USD'
            assert self.billing_plan.create(), self.billing_plan.error

            if test.env.backup_servers:
                self.bsz = BSZ(id=test.env.backup_servers[0].backup_server_group_id)
            else:
                self.bsz = BSZ()

            self.template_br = TemplateBR(billing_plan=self.billing_plan)
            self.backup_br = BackupBR(billing_plan=self.billing_plan)
            self.storage_disk_size_br = StorageDiskSizeBR(billing_plan=self.billing_plan)
            self.hvz_br = HVZBR(billing_plan=self.billing_plan)
            self.dsz_br = DSZBR(billing_plan=self.billing_plan)
            self.ntz_br = NTZBR(billing_plan=self.billing_plan)
            self.bsz_br = BSZBR(billing_plan=self.billing_plan)

            self.user = User(bp=self.billing_plan)
            self.user.login = 'hourlypricechecker'
            self.user.email = 'hourlypricechecker@user.test'
            self.user.password = test.generate_password()
            self.user.role_ids = [1]
            assert self.user.create(), self.user.error

            test.execute_as(self.user.login, self.user.password)

            self.vs = VirtualServer()
            self.vs.label = self.__name__
            self.vs.set_template()
            self.vs.rate_limit = 0

            self.backup = Backup(self.vs)
            self.template = Template()

            self.vm_stat = VmStat(parent_obj=self.vs)
            self.user_stats = UserStats(self.user)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)

        attributes = (
            'vs',
            'user',
            'billing_plan'
        )
        test.clean_up_resources(attributes, self)

    def test_create_template_base_resources(self):
        # Add base resources to template
        self.template_br.limits.limit = 1
        self.template_br.limits.limit_free = 0
        self.template_br.prices.price = 0.00000243
        assert self.template_br.create()

    def test_create_backup_base_resources(self):
        # Add base resources to Backups
        self.backup_br.limits.limit = 1
        self.backup_br.limits.limit_free = 0
        self.backup_br.prices.price = 0.00000234
        assert self.backup_br.create()

    def test_create_storage_disk_size_base_resources(self):
        # Add base resources to storage_disk_size
        self.storage_disk_size_br.limits.limit = None
        self.storage_disk_size_br.limits.limit_free = 0
        self.storage_disk_size_br.prices.price = 0.00004531
        assert self.storage_disk_size_br.create()

    def test_create_hypervisor_zone_base_resources(self):
        # Add base resource to HVZ
        self.hvz_br.target_id = test.env.hvz.id
        self.hvz_br.limits.limit_cpu = 2
        self.hvz_br.limits.limit_cpu_share = None
        self.hvz_br.limits.limit_free_cpu = 1
        self.hvz_br.limits.limit_free_cpu_share = 1
        self.hvz_br.limits.limit_free_memory = self.vs.template.min_memory_size
        self.hvz_br.limits.limit_memory = 1024
        self.hvz_br.prices.price_on_cpu = 0.00002315
        self.hvz_br.prices.price_off_cpu = 0.00000123
        self.hvz_br.prices.price_on_cpu_share = 0.012215
        self.hvz_br.prices.price_off_cpu_share = 0.0000957
        self.hvz_br.prices.price_on_memory = 0.054637
        self.hvz_br.prices.price_off_memory = 0.00054392
        assert self.hvz_br.create()

    def test_create_data_store_zone_base_resources(self):
        # Add base resources to DSZ
        self.dsz_br.target_id = test.env.dsz.id
        self.dsz_br.limits.limit_free = 6
        self.dsz_br.limits.limit = 20
        self.dsz_br.limits.limit_reads_completed_free = 1
        self.dsz_br.limits.limit_writes_completed_free = 1
        self.dsz_br.limits.limit_data_written_free = 1
        self.dsz_br.limits.limit_data_read_free = 1
        self.dsz_br.prices.price_data_written = 0.090123
        self.dsz_br.prices.price_off = 0.12468765
        self.dsz_br.prices.price_on = 0.00265243
        self.dsz_br.prices.price_data_read = 0.0001224
        self.dsz_br.prices.price_writes_completed = 0.00013421
        self.dsz_br.prices.price_reads_completed = 0.00162346
        assert self.dsz_br.create()

    def test_create_network_zone_base_resources(self):
        # Add base resources to NTZ
        self.ntz_br.target_id = test.env.netz.id
        self.ntz_br.limits.limit_ip = 2
        self.ntz_br.limits.limit_rate = None
        self.ntz_br.limits.limit_data_sent_free = 1
        if not self.vs.rate_limit:
            self.ntz_br.limits.limit_rate_free = None
        else:
            self.ntz_br.limits.limit_rate_free = self.vs.rate_limit
        self.ntz_br.limits.limit_ip_free = 1
        self.ntz_br.limits.limit_data_received_free = 1
        self.ntz_br.prices.price_ip_on = 0.01235186
        self.ntz_br.prices.price_ip_off = 0.00095634
        self.ntz_br.prices.price_rate_on = 0.4134135
        self.ntz_br.prices.price_rate_off = 0.14322534
        self.ntz_br.prices.price_data_sent = 0.0412346
        self.ntz_br.prices.price_data_received = 0.0234568
        assert self.ntz_br.create()

    def test_create_backup_server_zone_base_resources(self):
        # Add base resources to BSZ
        if self.bsz.id:
            self.bsz_br.target_id = self.bsz.id
            self.bsz_br.limits.limit_backup_free = 0
            self.bsz_br.limits.limit_backup = 1
            self.bsz_br.limits.limit_backup_disk_size_free = 0
            self.bsz_br.limits.limit_backup_disk_size = None
            self.bsz_br.limits.limit_template_disk_size_free = 0
            self.bsz_br.limits.limit_template_disk_size = None
            self.bsz_br.limits.limit_template_free = 0
            self.bsz_br.limits.limit_template = 1
            self.bsz_br.prices.price_backup = 0.00042523
            self.bsz_br.prices.price_backup_disk_size = 0.00000034
            self.bsz_br.prices.price_template = 0.00123463
            self.bsz_br.prices.price_template_disk_size = 0.00643562
            assert self.bsz_br.create()

    def test_create_server_with_0_price_per_hour(self):
        # Create VS with 0 price/hr
        assert self.vs.create(), self.vs.error
        time.sleep(300)
        price_on = self.vs.price_on_calculated(
            hvz_br=self.hvz_br,
            dsz_br=self.dsz_br,
            ntz_br=self.ntz_br
        )
        assert price_on == self.vs.get_price_per_hour() == 0.0
        price_off = self.vs.price_off_calculated(
            hvz_br=self.hvz_br,
            dsz_br=self.dsz_br,
            ntz_br=self.ntz_br
        )
        assert price_off == self.vs.get_price_per_hour_powered_off() == 0.0

    # https://onappdev.atlassian.net/browse/CORE-6321
    def test_get_users_vs(self):
        users_servers = self.user.get_own_virtual_servers()
        test.log.info("Users Virtual Servers list - \n{0}".format(users_servers))
        assert len(users_servers) == 1

    def test_change_billing_to_get_not_0_price_per_hour(self):
        # Change Billing
        # HV
        self.hvz_br.limits.limit_free_cpu = 0
        self.hvz_br.limits.limit_cpu = 2
        self.hvz_br.limits.limit_free_cpu_share = 0
        self.hvz_br.limits.limit_cpu_share = None
        self.hvz_br.limits.limit_free_memory = 0
        self.hvz_br.limits.limit_memory = 1024
        assert self.hvz_br.edit()
        # DS
        self.dsz_br.limits.limit_free = 0
        self.dsz_br.limits.limit = 20
        self.dsz_br.limits.limit_reads_completed_free = 0
        self.dsz_br.limits.limit_data_written_free = 0
        self.dsz_br.limits.limit_data_read_free = 0
        self.dsz_br.limits.limit_writes_completed_free = 0
        assert self.dsz_br.edit()
        # NW
        self.ntz_br.limits.limit_ip = 2
        self.ntz_br.limits.limit_rate = None
        self.ntz_br.limits.limit_data_sent_free = 0
        self.ntz_br.limits.limit_rate_free = 0
        self.ntz_br.limits.limit_ip_free = 0
        self.ntz_br.limits.limit_data_received_free = 0
        assert self.ntz_br.edit()

    def test_new_price(self):
        time.sleep(360)
        price_on = self.vs.price_on_calculated(
            hvz_br=self.hvz_br, dsz_br=self.dsz_br, ntz_br=self.ntz_br
        )
        assert round(price_on, 3) == self.vs.get_price_per_hour() != 0.0
        price_off = self.vs.price_off_calculated(
            hvz_br=self.hvz_br, dsz_br=self.dsz_br, ntz_br=self.ntz_br
        )
        assert round(price_off, 3) == self.vs.get_price_per_hour_powered_off() != 0.0

    def test_download_100MB_of_data(self):
        # Add sleep to fix some issue I think.
        # Before sleep the data in redis for network after downloading 100MB looks like:
        # redis/var/run/redis/redis.sock > ZRANGE net:7242 0 38
        # 1) "1470745623,3131,86034,0,0,1470745623"
        # 2) "1470745684,4171,107599,1040,21565,61"
        # 3) "1470745742,4171,107600,0,1,58"
        # ...
        #
        # and
        # redis/var/run/redis/redis.sock > ZRANGE net:7244 0 30
        # 1) "1470818079,1962,64445,0,0,1470818079"
        # 2) "1470818137,3441,107463,1479,43018,58"
        # 3) "1470818199,3442,107464,1,1,62"
        # ...
        #
        # After fix:
        # redis/var/run/redis/redis.sock > ZRANGE net:7245 0 30
        # 1) "1470821857,3,7,0,0,1470821857"
        # 2) "1470821918,4,8,1,1,61"
        # 3) "1470821977,3293,107409,3289,107401,59"
        # 4) "1470822046,3321,107444,28,35,69"

        time.sleep(120)

        # Download 1GB of data
        assert self.vs.download_100MB_of_data()

    def test_write_100MB_of_data(self):
        # Write 1GB of data
        assert self.vs.copy_100MB_of_data()

    def test_create_backup(self):
        # Create BU
        assert self.backup.create(), self.backup.error

    def test_convert_to_template(self):
        # Convert to template
        if self.backup:
            assert self.backup.convert(label=self.__class__.__name__), self.backup.template.error
            self.template.__dict__.update(self.backup.template.__dict__)

    # def test_create_cpu_usage(self):
    #     self.vs.execute('python -c "while True: pass" &')

    def test_get_server_and_user_stats(self):
        # Check Usage Statistics
        self.vm_stat.stats_waiter()
        self.vm_stat.get_hourly_stat_for_the_last_hour()
        self.user_stats.get_user_stat_for_the_last_hour()

    # TODO - write expected and real price to some file for more comfortable view.
    def test_check_template_cost(self):
        # Check template cost
        expected_price = 0.0
        if not self.template.backup_server_id:
            expected_price = self.template_br.prices.price
        test.log.info('\nTemplate Cost:')
        assert billingTH.price_comparator(
            expected_price,
            self.user_stats.template_cost
        )

    def test_check_template_count_cost(self):
        # Check template count cost
        expected_price = 0.0
        if self.template.backup_server_id:
            expected_price = self.bsz_br.prices.price_template
        test.log.info('\nTemplate Count Cost:')
        assert billingTH.price_comparator(
            expected_price,
            self.user_stats.template_count_cost
        )

    def test_check_template_disk_size_cost(self):
        # Check template disk size cost
        expected_price = 0.0
        if self.template.backup_server_id:
            expected_price = (
                self.template.template_size /
                self.KB_IN_1GB *
                self.bsz_br.prices.price_template_disk_size
            )
        test.log.info('\nTemplate Disk Size Cost:')
        assert billingTH.price_comparator(
            expected_price,
            self.user_stats.template_disk_size_cost
        )

    def test_check_backup_cost(self):
        # Check backup cost
        expected_price = 0.0
        if not self.backup.backup_server_id:
            expected_price = self.backup_br.prices.price
        test.log.info('\nBackup Cost:')
        assert billingTH.price_comparator(
            expected_price,
            self.user_stats.backup_cost
        )

    def test_check_backup_count_cost(self):
        # Check backup count cost
        expected_price = 0.0
        if self.backup.backup_server_id:
            expected_price = self.bsz_br.prices.price_backup
        test.log.info('\nBackup Count Cost:')
        assert billingTH.price_comparator(
            expected_price,
            self.user_stats.backup_count_cost
        )

    def test_backup_disk_size_cost(self):
        # Check backup disk size cost
        expected_price = 0.0
        if self.backup.backup_server_id:
            expected_price = (
                self.backup.backup_size /
                self.KB_IN_1GB *
                self.bsz_br.prices.price_backup_disk_size
            )
        test.log.info('\nBackup Disk Size Cost:')
        assert billingTH.price_comparator(
            expected_price,
            self.user_stats.backup_disk_size_cost
        )

    def test_check_storage_disk_size_cost(self):
        # Check Storage Disk Size cost
        # if template/backup is located on HV
        total_size = 0
        if not self.backup.backup_server_id:
            total_size += self.backup.backup_size
        if not self.template.backup_server_id:
            total_size += self.template.template_size
        expected_price = (total_size / self.KB_IN_1GB) * \
                         self.storage_disk_size_br.prices.price
        test.log.info('\nStorage Disk Size Cost:')
        assert billingTH.price_comparator(
            expected_price,
            self.user_stats.storage_disk_size_cost
        )

        # Check Usage Statistics ???

    def test_check_disk_size_cost(self):
        # Check Disk size cost
        test.log.info('\nDisk Size Cost:')
        assert billingTH.price_comparator(
            self.vs.disks_price_on,
            self.vm_stat.vm_last_hour_stat.disk_size.cost
        )

    def test_check_data_read_cost(self):
        # Check Data Read cost
        expected_price = (
            self.dsz_br.prices.price_data_read *
            self.vm_stat.vm_last_hour_stat.data_read.value /
            self.KB_IN_1GB
        )
        test.log.info('\nData Read Cost:')
        assert billingTH.price_comparator(
            expected_price,
            self.vm_stat.vm_last_hour_stat.data_read.cost
        )

    def test_check_data_written_cost(self):
        # Check Data Written cost
        expected_price = (
            self.dsz_br.prices.price_data_written *
            self.vm_stat.vm_last_hour_stat.data_written.value /
            self.KB_IN_1GB
        )
        test.log.info('\nData Written Cost:')
        assert billingTH.price_comparator(
            expected_price,
            self.vm_stat.vm_last_hour_stat.data_written.cost
        )

    def test_check_reads_completed_cost(self):
        # Check Reads Completed cost
        expected_price = (
            self.dsz_br.prices.price_reads_completed *
            self.vm_stat.vm_last_hour_stat.reads_completed.value /
            1000000.0
        )
        test.log.info('Reads Completed Cost:')
        assert billingTH.price_comparator(
            expected_price,
            self.vm_stat.vm_last_hour_stat.reads_completed.cost
        )

    def test_check_writes_completed(self):
        # Check Writes Completed cost
        expected_price = (
            self.dsz_br.prices.price_writes_completed *
            self.vm_stat.vm_last_hour_stat.writes_completed.value /
            1000000.0
        )
        test.log.info('Writes Completed Cost:')
        assert billingTH.price_comparator(
            expected_price,
            self.vm_stat.vm_last_hour_stat.writes_completed.cost
        )

    def test_check_ip_address_cost(self):
        # Check IP Address cost
        test.log.info('IP address Cost:')
        assert billingTH.price_comparator(
            self.vs.ip_price_on,
            self.vm_stat.vm_last_hour_stat.ip_addresses.cost
        )

    def test_check_rate_cost(self):
        # Check Rate cost
        test.log.info('Rate Cost:')
        assert billingTH.price_comparator(
            self.vs.rate_limit_price_on,
            self.vm_stat.vm_last_hour_stat.rate.cost
        )

    def test_check_data_received_cost(self):
        # Check Data Received cost
        expected_price = (
            self.ntz_br.prices.price_data_received *
            self.vm_stat.vm_last_hour_stat.data_received.value /
            self.KB_IN_1GB
        )
        test.log.info('Data Received Cost:')
        assert billingTH.price_comparator(
            expected_price, self.vm_stat.vm_last_hour_stat.data_received.cost
        )

    def test_check_data_sent_cost(self):
        # Check Data Sent cost
        expected_price = (
            self.ntz_br.prices.price_data_sent *
            self.vm_stat.vm_last_hour_stat.data_sent.value /
            self.KB_IN_1GB
        )
        test.log.info('Data Sent Cost:')
        assert billingTH.price_comparator(
            expected_price, self.vm_stat.vm_last_hour_stat.data_sent.cost
        )

    def test_check_cpu_share_cost(self):
        # Check CPU Shares cost
        test.log.info('CPU chare Cost:')
        assert billingTH.price_comparator(
            self.vs.cpu_shares_price_on,
            self.vm_stat.vm_last_hour_stat.cpu_shares.cost
        )

    def test_check_cpu_cost(self):
        # Check CPUs cost
        test.log.info('CPU Cost:')
        assert billingTH.price_comparator(
            self.vs.cpu_price_on,
            self.vm_stat.vm_last_hour_stat.cpus.cost
        )

    def test_check_memory_cost(self):
        # Check Memory cost
        test.log.info('Memory Cost:')
        assert billingTH.price_comparator(
            self.vs.memory_price_on,
            self.vm_stat.vm_last_hour_stat.memory.cost
        )

    # Check CPU Usage cost

        # Check Total cost

        # Check VM Resources cost

        # Check Usage cost

    def test_check_hourly_price_for_turned_off_server_from_ui(self):
        # Turn Off VS from UI, check hourly price and booted value - should be 0.
        # Check hourly price for shut downed VS.
        self.vs.shutdown()
        if not self.vs.booted:
            self.vm_stat.stats_waiter()
            self.vm_stat.get_hourly_stat_for_the_last_hour()
            test.log.info('Hourly price for turned off server from UI:')
            assert billingTH.price_comparator(
                self.vs.get_price_per_hour_powered_off(),
                self.vm_stat.vm_last_hour_stat.vm_resources_cost
            )

    def test_check_hourly_price_for_turned_on_server_from_ui(self):
        # Turn On VS from UI, check hourly price and booted value - should be 1.
        # Check hourly price for booted VS.
        self.vs.start()
        if self.vs.booted:
            self.vm_stat.stats_waiter()
            self.vm_stat.get_hourly_stat_for_the_last_hour()
            test.log.info('Hourly price for turned on server from UI:')
            assert billingTH.price_comparator(
                self.vs.get_price_per_hour(),
                self.vm_stat.vm_last_hour_stat.vm_resources_cost
            )

    def test_check_hourly_price_for_turned_off_server_from_inside(self):
        # Shutdown VS from inside, check hourly price and booted value - should be 0.
        # Check hourly price for shut downed VS from inside.
        assert self.vs.execute('init 0') == '', self.vs.error
        self.vs.wait_for_action(
            lambda: test.update_object(self.vs) and not self.vs.booted,
            timeout=60,
            step=5
        )
        self.vm_stat.stats_waiter()
        self.vm_stat.get_hourly_stat_for_the_last_hour()
        test.log.info('Hourly price for turned off server from inside:')
        assert billingTH.price_comparator(
            self.vs.get_price_per_hour_powered_off(),
            self.vm_stat.vm_last_hour_stat.vm_resources_cost
        )

    def test_check_hourly_price_for_changed_price(self):
        if not self.vs.booted:
            self.vs.start()

        # Change prices for HVZ
        self.hvz_br.prices.price_on_cpu = 0.03214356
        self.hvz_br.prices.price_off_cpu = 0.1543135
        self.hvz_br.prices.price_on_cpu_share = 0.00001465
        self.hvz_br.prices.price_off_cpu_share = 0.46733451
        self.hvz_br.prices.price_on_memory = 0.1004225
        self.hvz_br.prices.price_off_memory = 0.12340745
        assert self.hvz_br.edit()

        self.vm_stat.stats_waiter()
        self.vm_stat.get_hourly_stat_for_the_last_hour()
        test.log.info('Hourly price for changed prices:')
        assert billingTH.price_comparator(
            self.vs.get_price_per_hour(),
            self.vm_stat.vm_last_hour_stat.vm_resources_cost
        )
