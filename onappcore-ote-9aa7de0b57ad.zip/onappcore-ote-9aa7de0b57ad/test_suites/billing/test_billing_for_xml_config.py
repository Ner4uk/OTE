from time import sleep
import pytest
from onapp_helper.server import VirtualServer
from onapp_helper.user import User
from onapp_helper.billing_plan import BillingPlan
from onapp_helper.br_helper.hvz import HVZBR
from onapp_helper.xml_config import XmlConfig
from onapp_helper import test

DEFAULT_SERVER_MEMORY = 512
INCREASED_SERVER_MEMORY = DEFAULT_SERVER_MEMORY + 128


#################################### Marks #####################################
# Component
@pytest.mark.billing
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version >= 5.6,
    reason="Old billing is not supported..."
)
@pytest.mark.skipif(
    test.cp_version < 5.5,
    reason="Supported since 5.5, current version is {}".format(test.cp_version)
)
@pytest.mark.verbose
class TestBillingForXMLConfig:
    def setup_class(self):
        test.hv_types = ['kvm']
        test.load_env()

        try:
            self.billing_plan = BillingPlan()
            self.billing_plan.label = self.__name__
            assert self.billing_plan.create()

            self.user = User(bp=self.billing_plan)
            self.user.login = self.__name__.lower()
            self.user.password = test.generate_password()
            self.user.email = '{}@test.com'.format(self.__name__.lower())
            assert self.user.create(), self.user.error

            # # Check on_app.yml
            test.onapp_settings.get_on_app_yaml()
            if not test.onapp_settings.on_app_yaml.get(
                    'allow_advanced_vs_management'
            ):
                test.onapp_settings.update_on_app_yaml(
                    allow_advanced_vs_management=True
                )
                test.cp.restart_httpd()

            # Create User VS
            test.execute_as(self.user.login, self.user.password)

            # Create VS
            self.vs = VirtualServer()
            self.vs.label = self.__name__
            self.vs.memory = DEFAULT_SERVER_MEMORY
            self.vs.cpus = 1
            self.vs.cpu_shares = 1
            assert self.vs.create(), self.vs.error

            # Set limits and prices for HVZ
            self.hvz_br = HVZBR(
                billing_plan=self.billing_plan, target_id=test.env.hvz.id
            )
            assert self.hvz_br.create(), self.hvz_br.error

            self.xml_config = XmlConfig(self.vs)
            self.xml_config.get_xml_config()

        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        attributes = (
            'vs',
            'user',
            'billing_plan',
        )
        test.clean_up_resources(attributes, self)

    def test_check_xml_config_without_allow_advanced_vs_management_in_on_app_config(self):
        test.onapp_settings.get_on_app_yaml()
        if 'allow_advanced_vs_management' in \
                test.onapp_settings.on_app_yaml.keys():
            test.onapp_settings.on_app_yaml.pop('allow_advanced_vs_management')
            test.onapp_settings.update_on_app_yaml()
            test.cp.restart_httpd()
        assert not self.xml_config.get_xml_config()
        assert 'You do not have permissions for this action' in self.xml_config.error

    def test_setup_allow_advanced_vs_management_in_to_on_app_config(self):
        test.onapp_settings.get_on_app_yaml()
        key = 'allow_advanced_vs_management'
        if key not in test.onapp_settings.on_app_yaml.keys() or not \
                test.onapp_settings.on_app_yaml.get(key):
            test.onapp_settings.update_on_app_yaml(
                allow_advanced_vs_management=True
            )
            test.cp.restart_httpd()

    # CPU
    def test_check_limits_for_cpu(self):
        self.hvz_br.reset()
        self.hvz_br.limits.limit_cpu = 2
        assert self.hvz_br.edit(), self.hvz_br.error
        self.xml_config.domain.edit_cpu(4)
        assert not self.xml_config.update_xml_config(reboot=True)
        msg = 'CPUs must be less than or equal to {} to meet billing requirements'.format(
            self.hvz_br.limits.limit_cpu
        )
        assert msg in self.xml_config.error['cpus']

    def test_set_price_for_cpu(self):
        self.hvz_br.reset()
        self.hvz_br.limits.limit_free_cpu = self.vs.cpus
        self.hvz_br.prices.price_on_cpu = 0.0025
        self.hvz_br.prices.price_off_cpu = 0.00125
        assert self.hvz_br.edit(), self.hvz_br.error

    def test_edit_cpu_in_xml_config(self):
        self.xml_config.domain.edit_cpu(4)
        assert self.xml_config.update_xml_config(reboot=True), self.xml_config.error

    def test_check_server_cpus(self):
        assert self.vs.cpus == 4

    def test_native_server_cpus(self):
        native_cpus = self.vs.native_cpus_count()
        assert native_cpus == 4
        test.log.info(
            'Real CPUs - {}, Expected CPUs - {}'.format(native_cpus, 4)
        )

    def test_wait_for_new_price_for_cpus(self):
        sleep(300)

    def test_check_price_on_with_new_cpu(self):
        assert self.vs.get_price_per_hour() == \
               self.hvz_br.prices.price_on_cpu * (
                   self.vs.cpus - self.hvz_br.limits.limit_free_cpu
               )

    def test_check_price_off_with_new_cpu(self):
        assert self.vs.get_price_per_hour_powered_off() == \
               self.hvz_br.prices.price_off_cpu * (
                   self.vs.cpus - self.hvz_br.limits.limit_free_cpu
               )

    # # CPU Shares does not support
    # def test_set_price_for_cpu_shares(self):
    #     self.hvz_br.reset()
    #     self.hvz_br.limits.limit_free_cpu_share = self.vs.cpu_shares
    #     self.hvz_br.prices.price_on_cpu_share = 0.0025
    #     self.hvz_br.prices.price_off_cpu_share = 0.00125
    #     assert self.hvz_br.edit(), self.hvz_br.error
    #
    # def test_edit_cpu_shares_in_xml_config(self):
    #     self.xml_config.domain.edit_cpu_shares(50)
    #     assert self.xml_config.update_xml_config(reboot=True), self.xml_config.error
    #
    # def test_check_server_cpu_shares(self):
    #     assert self.vs.cpu_shares == 50
    #
    # def test_wait_for_new_price_for_cpu_shares(self):
    #     sleep(300)
    #
    # def test_check_price_on_with_new_cpu_shares(self):
    #     assert self.vs.get_price_per_hour() == \
    #            self.hvz_br.prices.price_on_cpu_share * (
    #                self.vs.cpu_shares - self.hvz_br.limits.limit_free_cpu_share
    #            )
    #
    # def test_check_price_off_with_new_cpu_shares(self):
    #     assert self.vs.get_price_per_hour_powered_off() == \
    #            self.hvz_br.prices.price_off_cpu_share * (
    #                self.vs.cpu_shares - self.hvz_br.limits.limit_free_cpu_share
    #            )

    # Memory
    def test_check_limits_for_memory(self):
        self.hvz_br.reset()
        self.hvz_br.limits.limit_memory = DEFAULT_SERVER_MEMORY
        assert self.hvz_br.edit(), self.hvz_br.error

        new_memory = INCREASED_SERVER_MEMORY * 1024
        self.xml_config.domain.edit_current_memory(new_memory)
        self.xml_config.domain.edit_memory(new_memory)
        assert not self.xml_config.update_xml_config(reboot=True)
        msg = 'Memory must be less than or equal to {} MB to meet billing requirements'.format(
            self.hvz_br.limits.limit_memory
        )
        assert msg in self.xml_config.error['memory']

    def test_set_price_for_memory(self):
        self.hvz_br.reset()
        self.hvz_br.limits.limit_free_memory = self.vs.memory
        self.hvz_br.prices.price_on_memory = 0.0025
        self.hvz_br.prices.price_off_memory = 0.00125
        assert self.hvz_br.edit(), self.hvz_br.error

    def test_memory_can_not_be_increased_for_running_server(self):
        new_memory = INCREASED_SERVER_MEMORY * 1024
        self.xml_config.domain.edit_memory(DEFAULT_SERVER_MEMORY * 1024)
        self.xml_config.domain.edit_current_memory(new_memory)
        assert not self.xml_config.update_xml_config(reboot=True)
        assert 'can not be increased to {} for running virtual server'.format(
            INCREASED_SERVER_MEMORY
        ) in self.xml_config.error['memory']

    def test_edit_memory_in_xml_config(self):
        new_memory = INCREASED_SERVER_MEMORY * 1024
        assert self.vs.shutdown(), self.vs.error
        self.xml_config.domain.edit_memory(new_memory)
        self.xml_config.domain.edit_current_memory(new_memory)
        assert self.xml_config.update_xml_config(reboot=True), self.xml_config.error
        assert self.vs.start(), self.vs.error

    def test_check_server_memory(self):
        assert self.vs.memory == INCREASED_SERVER_MEMORY
        native_ram = self.vs.native_ram_size()
        delta = INCREASED_SERVER_MEMORY * 0.055  # 5.5%
        assert (INCREASED_SERVER_MEMORY - delta) <= native_ram <= INCREASED_SERVER_MEMORY

        test.log.info(
            'Real RAM - {}, Expected RAM {} <= {} <= {}'.format(
                native_ram, INCREASED_SERVER_MEMORY-delta, native_ram,
                INCREASED_SERVER_MEMORY
            )
        )

    def test_wait_for_new_price_for_memory(self):
        sleep(300)

    def test_check_price_on_with_new_memory(self):
        assert self.vs.get_price_per_hour() == \
               self.hvz_br.prices.price_on_memory * (
                   self.vs.memory - self.hvz_br.limits.limit_free_memory
               )

    def test_check_price_off_with_new_memory(self):
        assert self.vs.get_price_per_hour_powered_off() == \
               self.hvz_br.prices.price_off_memory * (
                   self.vs.memory - self.hvz_br.limits.limit_free_memory
               )

    def test_reset_xml_config_to_default(self):
        assert self.xml_config.reset_xml_config(), self.xml_config.error
        assert self.vs.reboot(), self.vs.error

    def test_check_memory_after_reset_xml_config(self):
        assert self.vs.memory == INCREASED_SERVER_MEMORY
        native_ram = self.vs.native_ram_size()
        delta = INCREASED_SERVER_MEMORY * 0.055  # 5.5%
        assert (
               INCREASED_SERVER_MEMORY - delta
               ) <= native_ram <= INCREASED_SERVER_MEMORY

    def test_check_cpu_after_reset_xml_config(self):
        assert self.vs.cpus == 4
        native_cpus = self.vs.native_cpus_count()
        assert native_cpus == 4
