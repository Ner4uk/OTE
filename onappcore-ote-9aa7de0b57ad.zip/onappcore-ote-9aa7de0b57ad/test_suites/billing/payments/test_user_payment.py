# daily
__author__ = "Arsen"


from onapp_helper import test
from onapp_helper.payment import Payment
from onapp_helper.user import User
from onapp_helper.billing_plan import BillingPlan
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.payments
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.verbose
@pytest.mark.skipif(test.cp_version >= 6.1, reason=test.not_supported_msg(BillingPlan))
class TestUserPayment:
    def setup_class(self):
        try:
            self.billing_plan = BillingPlan()
            self.billing_plan.label = self.__name__
            assert self.billing_plan.create(), self.billing_plan.error

            self.user_1 = User(bp=self.billing_plan)
            self.user_1.login = self.__name__ + "1"
            self.user_1.password = test.generate_password()
            self.user_1.email = self.user_1.login + "@autotest.net"
            assert self.user_1.create(), self.user_1.error

            self.user_2 = User(bp=self.billing_plan)
            self.user_2.login = self.__name__ + "2"
            self.user_2.password = test.generate_password()
            self.user_2.email = self.user_2.login + "@autotest.net"
            assert self.user_2.create(), self.user_2.error

        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

        self.payment = Payment()

    def teardown_class(self):
        attributes = (
            'user_1',
            'user_2',
            'billing_plan',
            'payment'
        )
        test.clean_up_resources(attributes, self)

    def test_should_be_impossible_to_create_user_payment_without_amount(self):
        self.reset_payments_attributes(self.user_1)
        self.payment.amount = None
        assert not self.payment.create()
        assert "can\'t be blank" in self.payment.error["amount"]
        assert "is not a number" in self.payment.error["amount"]

    def test_should_be_impossible_to_create_user_payment_without_invoice_number(self):
        self.reset_payments_attributes(self.user_1)
        self.payment.invoice_number = None
        assert not self.payment.create()
        assert "can\'t be blank" in self.payment.error["invoice_number"]

    def test_should_be_impossible_to_create_user_payment_without_payer_id(self):
        self.reset_payments_attributes(self.user_1)
        self.payment.payer_id = None
        assert not self.payment.create()
        assert "can\'t be blank" in self.payment.error["payer_id"]
        if test.cp_version < 5.7:
            assert "not found" in self.payment.error["user"]

    def test_should_be_impossible_to_create_user_payment_with_wrong_payer_id(self):
        self.reset_payments_attributes(self.user_1)
        self.payment.payer_id = -123
        assert not self.payment.create()
        if test.cp_version >= 6.0:
            assert 'does not exists' in self.payment.error["payer_id"]
        else:
            assert "can\'t be blank" in self.payment.error["payer_id"]
        if test.cp_version < 5.7:
            assert "not found" in self.payment.error["user"]

    @pytest.mark.skipif(
        test.cp_version < 5.8, reason="payer_type available since 5.8"
    )
    @pytest.mark.skipif(
        test.cp_version >= 6.0, reason="https://onappdev.atlassian.net/browse/CORE-9627"
    )
    def test_should_be_impossible_to_create_user_payment_without_payer_type(self):
        self.reset_payments_attributes(self.user_1)
        self.payment.payer_type = None
        assert not self.payment.create()
        assert "invalid payer type" in self.payment.error["payer_type"]

    def test_create_payment_for_user_1(self):
        self.reset_payments_attributes(self.user_1)
        test.gen_api_doc = "Create user payment"
        assert self.payment.create(), self.payment.error

    def test_check_if_user_payment_was_created(self):
        assert self.payment.id

    def test_check_payer_id_of_created_user_payment(self):
        assert self.user_1.id == self.payment.payer_id

    def test_check_invoice_number_for_created_user_payment(self):
        assert '31012017/01' == self.payment.invoice_number

    def test_check_amount_for_created_user_payment(self):
        assert 888.88 == self.payment.amount

    @pytest.mark.skipif(
         test.cp_version < 5.8, reason="payer_type available since 5.8"
    )
    @pytest.mark.skipif(
        test.cp_version >= 6.0, reason="https://onappdev.atlassian.net/browse/CORE-9627"
    )
    def test_check_payer_type_for_created_user_payment(self):
        assert self.payment.payer_type == Payment.PAYER_TYPE.user

    def test_get_user_payment_details(self):
        test.gen_api_doc = "Get user payment details"
        assert self.payment.get(), self.payment.error

    def test_you_cannot_edit_payment_with_empty_payer_id(self):
        self.payment.payer_id = None
        assert not self.payment.edit()
        assert "can\'t be blank" in self.payment.error["payer_id"]
        if test.cp_version < 5.7:
            assert "not found" in self.payment.error["user"]

    def test_change_payer_id_for_payment(self):
        self.payment.payer_id = self.user_2.id
        test.gen_api_doc = "Edit user payment"
        assert self.payment.edit(), self.payment.error

    def test_check_payer_id_of_payment_after_their_changing(self):
        assert self.user_2.id == self.payment.payer_id

    def test_you_cannot_edit_payment_with_empty_invoice_number(self):
        self.payment.invoice_number = None
        assert not self.payment.edit()
        assert "can\'t be blank" in self.payment.error["invoice_number"]

    def test_change_invoice_number_of_payment(self):
        self.payment.invoice_number = 'qwerty'
        assert self.payment.edit(), self.payment.error

    def test_check_invoice_number_of_payment_after_their_changing(self):
        assert 'qwerty' == self.payment.invoice_number

    def test_you_cannot_edit_payment_with_empty_amount(self):
        self.payment.amount = None
        assert not self.payment.edit()
        assert "can\'t be blank" in self.payment.error["amount"]
        assert "is not a number" in self.payment.error["amount"]

    def test_change_amount_of_payment(self):
        self.payment.amount = 1000.00
        assert self.payment.edit(), self.payment.error

    def test_check_amount_of_payment_after_their_changing(self):
        assert 1000.00 == self.payment.amount

    def test_create_payment_for_user2(self):
        self.payment.payer_id = self.user_2.id
        self.payment.invoice_number = '31012017/02'
        self.payment.amount = 888.88
        assert self.payment.create(), self.payment.error

    def test_show_payments_for_user2(self):
        test.gen_api_doc = "Get payments for particular user"
        if test.cp_version < 5.7:
            payments = self.payment.get_all(
                payer=self.user_2.id
            )
        elif test.cp_version < 5.8:
            payments = self.payment.get_all(
                user_id=self.user_2.id
            )
        elif 6.0 > test.cp_version >= 5.8:
            payments = self.payment.get_all(
                payer_type=Payment.PAYER_TYPE.user,
                payer_id=self.user_2.id
            )
        else:
            payments = self.payment.get_all(
                payer_id=self.user_2.id
            )
        for payment in payments:
            assert payment.payer_id == self.user_2.id

    def test_show_all_users_payments(self):
        test.gen_api_doc = "Create users payments"
        if 6.0 > test.cp_version >= 5.8:
            assert self.payment.get_all(
                payer_type=Payment.PAYER_TYPE.user
            ), self.payment.error
        else:
            assert self.payment.get_all(), self.payment.error

    def test_delete_user_payment(self):
        test.gen_api_doc = "Delete user payment"
        assert self.payment.delete(), self.payment.error

    def test_payment_does_not_exist(self):
        assert not self.payment.get()

    def reset_payments_attributes(self, user):
        self.payment.payer_id = user.id
        self.payment.invoice_number = '31012017/01'
        self.payment.amount = 888.88
        if 6.0 > test.cp_version >= 5.8:
            self.payment.payer_type = Payment.PAYER_TYPE.user
