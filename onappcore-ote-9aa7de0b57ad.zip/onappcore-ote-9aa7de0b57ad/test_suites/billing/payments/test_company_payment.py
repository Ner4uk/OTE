# daily
__author__ = "Arsen"


from onapp_helper import test
from onapp_helper.company_payment import CompanyPayment
from onapp_helper.vcloud.organization import Organization
from onapp_helper.payment import Payment
from onapp_helper.user_group import UserGroup
from onapp_helper.hypervisor import Hypervisor
from onapp_helper.billing_plan import BillingPlan
from onapp_helper.company_plan import CompanyPlan
import pytest


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.payments
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version >= 5.6,
    reason="Old billing is not supported..."
)
@pytest.mark.verbose
class TestCompanyPayment:
    def setup_class(self):
        try:
            self.billing_plan = BillingPlan()
            self.billing_plan.label = self.__name__
            assert self.billing_plan.create(), self.billing_plan.error

            self.company_plan = CompanyPlan()
            self.company_plan.label = self.__name__
            assert self.company_plan.create(), self.company_plan.error

            if test.cp_version >= 5.8:
                self.org_1 = Organization()
                self.org_1.label = self.__name__ + '1'
                self.org_1.hypervisor_id = Hypervisor().get_vcloud()[0].id
                self.org_1.company_billing_plan_id = self.company_plan.id
                self.org_1.create_user_group = True
                assert self.org_1.create(), self.org_1.error

                self.usergroup_1 = UserGroup(id=self.org_1.user_group_id)

                self.org_2 = Organization()
                self.org_2.label = self.__name__ + '2'
                self.org_2.hypervisor_id = Hypervisor().get_vcloud()[0].id
                self.org_2.company_billing_plan_id = self.company_plan.id
                self.org_2.create_user_group = True
                assert self.org_2.create(), self.org_2.error

                self.usergroup_2 = UserGroup(id=self.org_2.user_group_id)
            else:
                self.usergroup_1 = UserGroup()
                self.usergroup_1.label = self.__name__ + '1'
                self.usergroup_1.assign_to_vcloud = True
                self.usergroup_1.hypervisor_id = Hypervisor().get_vcloud()[0].id
                self.usergroup_1.company_billing_plan_id = self.company_plan.id
                self.usergroup_1.billing_plan_ids = [self.billing_plan.id]
                assert self.usergroup_1.create(), self.usergroup_1.error

                self.usergroup_2 = UserGroup()
                self.usergroup_2.label = self.__name__ + '2'
                self.usergroup_2.assign_to_vcloud = True
                self.usergroup_2.hypervisor_id = Hypervisor().get_vcloud()[0].id
                self.usergroup_2.company_billing_plan_id = self.company_plan.id
                self.usergroup_2.billing_plan_ids = [self.billing_plan.id]
                assert self.usergroup_2.create(), self.usergroup_2.error

        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

        if 6.0 > test.cp_version >= 5.8:
            self.payment_company = Payment()
        else:
            self.payment_company = CompanyPayment()

    def teardown_class(self):
        attributes = (
            'org_1',
            'org_2',
            'usergroup_1',
            'usergroup_2',
            'billing_plan',
            'company_plan',
            'payment_company'
        )
        test.clean_up_resources(attributes, self)

    def test_should_be_impossible_to_create_company_payment_without_amount(self):
        self.reset_payments_attributes(self.usergroup_1)
        self.payment_company.amount = None
        assert not self.payment_company.create()
        assert "can\'t be blank" in self.payment_company.error["amount"]
        assert "is not a number" in self.payment_company.error["amount"]

    def test_should_be_impossible_to_create_company_payment_without_invoice_number(self):
        self.reset_payments_attributes(self.usergroup_1)
        self.payment_company.invoice_number = None
        assert not self.payment_company.create()
        assert "can\'t be blank" in self.payment_company.error["invoice_number"]

    def test_should_be_impossible_to_create_company_payment_without_payer_id(self):
        self.reset_payments_attributes(self.usergroup_1)
        self.payment_company.payer_id = None
        assert not self.payment_company.create()
        assert "can\'t be blank" in self.payment_company.error["payer_id"]
        if test.cp_version < 5.8:
            assert "not found" in self.payment_company.error["company"]

    @pytest.mark.skipif(
        test.cp_version < 5.8, reason="payer_id is not supported"
    )
    @pytest.mark.skipif(
        test.cp_version >= 6.0, reason="https://onappdev.atlassian.net/browse/CORE-9627"
    )
    def test_should_be_impossible_to_create_company_payment_without_payer_type(self):
        self.reset_payments_attributes(self.usergroup_1)
        self.payment_company.payer_type = None
        assert not self.payment_company.create()
        assert "invalid payer type" in self.payment_company.error["payer_type"]

    def test_create_new_company_payment(self):
        test.gen_api_doc = "Create company payment"
        self.reset_payments_attributes(self.usergroup_1)
        self.payment_company.payer_id = self.usergroup_1.id
        self.payment_company.invoice_number = '01022017/01'
        self.payment_company.amount = 111.22
        assert self.payment_company.create(), self.payment_company.error

    def test_check_if_company_payment_was_created(self):
        assert self.payment_company.id

    def test_check_payer_id_of_company_payment(self):
        assert self.usergroup_1.id == self.payment_company.payer_id

    def test_check_invoice_number_of_company_payment(self):
        assert '01022017/01' == self.payment_company.invoice_number

    def test_check_amount_of_company_payment(self):
        assert 111.22 == self.payment_company.amount

    def test_get_company_payment_details(self):
        test.gen_api_doc = "Get company payment details"
        assert self.payment_company.get(), self.payment_company.error

    def test_you_cannot_edit_company_payment_with_empty_payer_id(self):
        self.payment_company.payer_id = None
        assert not self.payment_company.edit()
        assert "can\'t be blank" in self.payment_company.error["payer_id"]
        if test.cp_version < 5.8:
            assert "not found" in self.payment_company.error["company"]

    def test_change_payer_id_for_company_payment(self):
        self.payment_company.payer_id = self.usergroup_2.id
        assert self.payment_company.edit(), self.payment_company.error

    def test_check_payer_id_of_company_payment_after_editing(self):
        assert self.usergroup_2.id == self.payment_company.payer_id

    def test_you_cannot_edit_company_payment_with_empty_invoice_number(self):
        self.payment_company.invoice_number = None
        assert not self.payment_company.edit()
        assert "can\'t be blank" in self.payment_company.error["invoice_number"]

    def test_change_invoice_number_for_company_payment(self):
        test.gen_api_doc = "Edit company payment"
        self.payment_company.invoice_number = '12345'
        assert self.payment_company.edit(), self.payment_company.error

    def test_check_invoice_number_of_company_payment_after_editing(self):
        assert '12345' == self.payment_company.invoice_number

    def test_you_cannot_edit_company_payment_with_empty_amount(self):
        self.payment_company.amount = None
        assert not self.payment_company.edit()
        assert "can\'t be blank" in self.payment_company.error["amount"]
        assert "is not a number" in self.payment_company.error["amount"]

    def test_change_amount_for_company_payment(self):
        self.payment_company.amount = 1234.56
        assert self.payment_company.edit(), self.payment_company.error

    def test_check_amount_of_company_payment_after_editing(self):
        assert 1234.56 == self.payment_company.amount

    def test_create_second_payment_for_usergroup_1(self):
        self.payment_company.payer_id = self.usergroup_1.id
        self.payment_company.invoice_number = '01022017/02'
        self.payment_company.amount = 9876.54
        assert self.payment_company.create(), self.payment_company.error

    def test_show_payments_for_usergroup_2(self):
        test.gen_api_doc = "Get payments for particular company"
        if test.cp_version < 5.8 or test.cp_version >= 6.0:
            payments = self.payment_company.get_company_payments(
                company_id=self.usergroup_2.id
            )
        else:
            payments = self.payment_company.get_all(
                payer_id=self.usergroup_2.id,
                payer_type=Payment.PAYER_TYPE.user_group
            )
        for payment in payments:
            assert payment.payer_id == self.usergroup_2.id

    def test_show_all_companies_payments(self):
        test.gen_api_doc = "Get company payments"
        if test.cp_version < 5.8 or test.cp_version >= 6.0:
            assert self.payment_company.get_company_payments(), self.payment_company.error
        else:
            assert self.payment_company.get_all(
                payer_type=Payment.PAYER_TYPE.user_group
            ), self.payment_company.error

    def test_delete_company_payment(self):
        test.gen_api_doc = "Delete company payment"
        assert self.payment_company.delete(), self.payment_company.error

    def test_payment_does_not_exist(self):
        assert not self.payment_company.get()

    def reset_payments_attributes(self, user_group):
        self.payment_company.payer_id = user_group.id
        self.payment_company.invoice_number = '01022017/01'
        self.payment_company.amount = 111.22
        if 6.0 > test.cp_version >= 5.8:
            self.payment_company.payer_type = Payment.PAYER_TYPE.user_group
