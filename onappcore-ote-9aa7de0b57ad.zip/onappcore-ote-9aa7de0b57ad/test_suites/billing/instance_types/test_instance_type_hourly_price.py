import pytest

from onapp_helper import test
from onapp_helper.billing_plan import BillingPlan
from onapp_helper.br_helper.instance_package import InstancePackageBR
from onapp_helper.instance_package import InstancePackage
from onapp_helper.stats.user_stats import UserStats
from onapp_helper.stats.vm_stat import VmStat
from onapp_helper.user import User
from onapp_helper.server import VirtualServer
from test_helper import billingTH


#################################### Marks #####################################
# Component
@pytest.mark.billing
@pytest.mark.hourly_price
# Depth
@pytest.mark.smoke
@pytest.mark.regression
# Executing (parallel/sequentially)
@pytest.mark.parallel
################################## End of marks ################################
@pytest.mark.skipif(
    test.cp_version >= 5.6,
    reason="Old billing is not supported..."
)
@pytest.mark.skipif(
    test.cp_version < 4.1,
    reason="Current CP version ({0}) does not support this functionality ".format(test.cp_version)
)
@pytest.mark.skipif(test.cp_version >= 6.1, reason=test.not_supported_msg(BillingPlan))
@pytest.mark.incremental
class TestInstanceTypeHourlyPrice:
    def setup_class(self):
        test.load_env()

        if not test.env.hvz.id:
            pytest.skip("No available HVZ.")
        if not test.env.dsz.id:
            pytest.skip("No available DSZ.")
        if not test.env.netz.id:
            pytest.skip("No available NetZ.")

        test.cp.generate_10MB_test_file()
        test.run_at(minutes=40)

        try:
            self.billing_plan = BillingPlan()
            self.billing_plan.label = self.__name__
            assert self.billing_plan.create()

            self.instance_type = InstancePackage()
            self.instance_type.label = self.__name__
            self.instance_type.cpus = 2
            self.instance_type.memory = 512
            self.instance_type.disk_size = 7
            self.instance_type.bandwidth = 1
            assert self.instance_type.create()

            # Get targets
            self.hvz_id = test.env.hvz.id
            self.ntz_id = test.env.netz.id
            self.dsz_id = test.env.dsz.id

            self.instance_type_br = InstancePackageBR(
                billing_plan=self.billing_plan,
                target_id=self.instance_type.id
            )
            # Set IT prices
            self.instance_type_br.prices.price_on = 100
            self.instance_type_br.prices.price_off = 20
            self.instance_type_br.prices.price_overused_bandwidth = 99
            # Set IT preferences
            self.instance_type_br.preferences.hypervisor_group_ids.append(self.hvz_id)
            self.instance_type_br.preferences.data_store_group_ids.append(self.dsz_id)
            self.instance_type_br.preferences.network_group_ids.append(self.ntz_id)
            # Create IT limit
            assert self.instance_type_br.create()

            self.user = User(bp=self.billing_plan)
            self.user.login = 'instancetypehourlyprice'
            self.user.password = test.generate_password()
            self.user.email = 'user@instancetypehourlyprice.test'
            assert self.user.create()

            test.execute_as(self.user.login, self.user.password)

            self.vs = VirtualServer()
            # test.env.ip_address.assign_ip_addresses_to_user(ip_addresses=[test.env.ip_address.id], user=self.user)

            if test.cp_version >= 5.4:
                self.vs.selected_ip_address = test.env.ip_address.address
            else:
                self.vs.selected_ip_address_id = test.env.ip_address.id

            self.vs.label = self.__name__
            self.vs.instance_package_id = self.instance_type.id
            assert self.vs.create(), self.vs.error
            self.user_stats = UserStats(self.user)
            self.vm_stat = VmStat(parent_obj=self.vs)
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        test.execute_as(test.login, test.password)
        attributes = (
            'user',
            'billing_plan',
            'instance_type'
        )
        test.clean_up_resources(attributes, self)

    def test_if_vs_has_build(self):
        assert self.vs.booted and self.vs.built

    def test_check_cpu(self):
        assert self.vs.cpus == self.instance_type.cpus

    def test_memory(self):
        assert self.vs.memory == self.instance_type.memory

    def test_total_disk_size(self):
        assert sum(
            [d.disk_size for d in self.vs.disks()]
        ) == self.instance_type.disk_size

    def test_load_more_than_1gb_of_data_to_check_owerused_bandwith(self):
        for i in range(15):
            self.vs.download_100MB_of_data()

    def test_price_on(self):
        assert billingTH.price_comparator(
            self.vs.price_per_hour,
            self.instance_type_br.prices.price_on
        )

    def test_price_off(self):
        assert billingTH.price_comparator(
            self.vs.price_per_hour_powered_off,
            self.instance_type_br.prices.price_off
        )

    def test_wait_for_statistics(self):
        # Check Usage Statistics
        self.vm_stat.stats_waiter()
        self.vm_stat.get_hourly_stat_for_the_last_hour()
        self.user_stats.get_user_stat_for_the_last_hour()
        # pytest.set_trace()

    def test_vm_resources_cost(self):
        assert billingTH.price_comparator(
            self.vm_stat.vm_last_hour_stat.vm_resources_cost,
            self.instance_type_br.prices.price_on
        )

    def test_bandwidth_overused_cost(self):
        total_value = self.vm_stat.vm_last_hour_stat.data_received.value + \
                      self.vm_stat.vm_last_hour_stat.data_sent.value
        price_overused_bandwidth = self.instance_type_br.prices.price_overused_bandwidth
        expected_price = ((total_value - 1048576.0) / 1048576.0) * \
                         price_overused_bandwidth

        assert billingTH.price_comparator(
            expected_price,
            self.vm_stat.vm_last_hour_stat.bandwidth_overused.cost
        )
