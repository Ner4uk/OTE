
from onapp_helper import test
from onapp_helper.role import Role


class TestApprovals:
    def setup_class(self):
        self.role = Role()
        self.role.label = self.__name__
        assert self.role.create(), self.role.error

    def teardown_class(self):
        self.role.delete()

    def test_get_approvals(self):
        test.gen_api_doc = 'Get Approvals.'
        assert self.role.get_approvals(), self.role.error

    def test_by_default_all_approvals_should_be_disabled(self):
        approvals = self.role.get_approvals()
        for approval in approvals:
            assert not approval['enabled']

    def test_set_approvals(self):
        approvals = self.role.get_approvals()
        approval_ids = []
        approvals_to_set = [
            'destroy_disk',
            'build_disk',
        ]
        for approval in approvals:
            if approval['action'] in approvals_to_set:
                approval_ids.append(approval['id'])

        test.gen_api_doc = "Set Approvals"
        assert self.role.set_approvals(approval_ids), self.role.error

        approvals = self.role.get_approvals()
        for approval in approvals:
            if approval['action'] in approvals_to_set:
                assert approval['enabled']
            else:
                assert not approval['enabled']

