# OTE (Onapp Test Engine)

**Installation:**

* Setup working environment
```
git clone git@bitbucket.org:onappcore/ote.git
cd ./ote
./ote --install
```

* Open a new console to apply changes

* Activate virtualenv:

```
  source ./venv/oteX.Y/bin/activate
```

* Install PyCharm (recommended) or any other IDE for developing.
    
* Go to PyCharm -> Preferences -> Project:ote and setup Project Interpreter
(add virtual environment) and Project Structure (if needed)


**Jenkins:**

* Install jenkins;
* Generate ssh key:
```
    sudo -u jenkins ssh-keygen
```
* Add ssh key to bitbucket and CP's;
* Add Git to the 'Source Code Management'
  - in case "stderr: Host key verification failed" please execute the following
  on jenkins host:
  ```
  sudo -u jenkins git ls-remote -h git@bitbucket.org:onappcore/ote.git HEAD
  ```
  and press 'yes'.

  - Go to 'Build Triggers' -> Build periodically and set '* * * * *'

  Execute OTE_SEED job

  run ote installer

  go to /var/lib/jenkins/jobs/OTE_SEED/workspace and execute:
  ```
    ./ote --install
  ```

* For Jenkins change owner for ote directory to jenkins:
```
  chown -R jenkins:jenkins ../ote
```

For Allure: install in to your virtual environment *pytest-allure-adaptor* 
  
  (https://pypi.python.org/pypi/pytest-allure-adaptor)

```
    pip install pytest-allure-adaptor
```
in case 'JAVA_HOME' issue execute the following strings:
    
```
    export JAVA_HOME="/usr/lib/jvm/jre-1.8.0-openjdk.x86_64"
    /etc/init.d/jenkins restart
```
where 'jre-1.8.0-openjdk.x86_64' java runtime environment installed on your 
computer.

**Test Example**

Test template you can find by: 

    ./conf/test_template.py 
    
another example see below: 

```
# import onapp test engine which is responsible for test environment, session and other things.
from onapp_helper import test
# import modules which help to work with OnApp through API
from onapp_helper.billing_plan import BillingPlan
# pytest framework
import pytest


class TestBillingPlan():
    # Actions before running test
    def setup_class(self):
        self.billing_plan = BillingPlan()

    # Actions after running test
    def teardown_class(self):
        pass

    def test_create_billing_plan(self):
        if test.api_version == 4.2:
            test.gen_api_doc = True
        self.billing_plan.label = 'ZAZA TEST billing_plan'
        self.billing_plan.currency_code = "GBP"
        self.billing_plan.monthly_price = 666.0  # Float since 4.3
        self.billing_plan.allows_kms = "false"
        self.billing_plan.allows_mak = "true"
        self.billing_plan.allows_own = "false"
        self.billing_plan.create()

    ...
```

**Base Setup:**

* go to conf path and rename all files(excluding extended.cfg) with *.cfg.example to *.cfg;
* put in to this files correct data.
* run test:

**Extended Setup:**

Briefly: you may want to set some of these in case your tests include a CP installation, or use cloudboots.

Inside *extended.cfg* one may set the following parameters(none of them is required currently unless it is called straightly from some tests or new functionality):

* *ssh_port* - required only if non-standard port is used for ssh on the CP host.
* *licensing_server* - if set to *staging*, the CP will be set up to sync the license on staging licensing servers. Any other value(as well as the absence of this parameter) will make the CP to work with the production licensing service. 
* *license_key* - required if a new CP is to be installed.
* *clb_net_ip* - only required if the tests use cloudboot HVs. This will be used for:  *Static config target*, *CP server CloudBoot target*, *CloudBoot Domain Name Servers*

If your tests are designed to control resources in VSphere cloud, you should use *vsphere.cfg* to set host and credentials for access to VCenter host

**Running:**

*1 (Recommended):*

```
ote -C dev5 -t ./test_suites/billing/test_billing.py
```
Execute ote -h to see more options

*2:*

```
py.test -s ./test_suites/billing/test_billing.py
```
In this case the parameters from ./conf/global.cfg will be used. 

*3:*

```
CLOUD=dev5 ONAPP_API_VERSION=4.2 py.test -s ./test_suites/billing/test_billing.py
```
In this case the global settings will be skipped.

*You also can set the following environment variables as:*

* CLOUD - dev1, dev5, qa1, sf1. This parameter is required!!! (defined in clouds.cfg)
* HV_TYPE - xen, kvm, vcloud, vcenter... 
    
    Note:
     1. Set for example 'xen' to select only 'xen' hypervisor or you can set 
     some 'range' of hypervisor types, like 'xen,kvm' to select any of them.
     2. The same behaviour for HV_DISTRO, DS_TYPE, SERVER_TYPE
     
* HV_DISTRO - centos5, centos6, ... 
* DS_TYPE - lvm, solidfire, ...
* TEMPLATE_MANAGER_ID - go to onapp templates to find particular manager id.
* SERVER_TYPE - hypervisor server type (virtual, baremetal, smart).
* ONAPP_API_VERSION - specify the particular API version.

**Collectors:**

In log directory is located 3 files:

* 500.log - to collect all requests with 500 status code;
* errors_collector.log - to collect all catching errors;
* wrong_status_code.log - to collect all responses with status code which is not
    described in onapp API documentation.

*test object structure looks like:*
```
 test
   |-- session
   |     |-- log
   |     |     |-- info
   |     |     |-- debug by default
   |     |     |-- warning
   |     |     |-- error
   |     |     `-- critical
   |     |-- get
   |     |-- put
   |     |-- post
   |     |-- delete
   |     |-- host
   |     |-- login
   |     `-- password
   |-- start_new_session
   |-- cp_version
   |-- cp (possibility to execute command on CP, HV, etc.)
   |-- api_version
   |-- use_public_network
   |-- host
   |-- login
   |-- password
   |-- load_env (activate 'env')
   |-- env
   |     |-- ip_address - an ip address which you can use during server creation
   |     |-- backup_servers
   |     |-- ds
   |     |-- dsz
   |     |-- hv
   |     |-- hvz
   |     |-- net
   |     `-- netz
   |-- generate_password
   |-- global_config
   |-- config
   |-- template_manager_id
   |-- init_mail - return the email obj
   |-- gen_api_doc - True, False or string message to describe current action
   |-- run_at - allows to execute test at specific time
   |-- clean_up_resources - correctly removes created resources (is using in teardown class)
   |-- hide_output
   |-- show_output
   |-- migrate_server allow to use environment to check server migration False
   |-- migrate_disk allow to use environment to check disk migration False
```

  *GET, PUT, POST, DELETE - this methods are realised for each onapp object 
  in BaseHelper module.*

**Mysql Dump**

You can also create database dump just running the following command:

```ote -C dev1 -d dump_name```

**Console**

Execute the following string to run console:

```ote -C dev1 -c```

**API Doc generating**

To generate API examples set test.gen_api_doc = True # or some description "Create VS limit"

API doc generator will triggered only for first request(Only for Create from example below):

*Code example:*

```
        if test.api_version == 4.2:
            test.gen_api_doc = True
        # Create Limit
        self.vm_limit.own_limits.limit = 10
        assert self.vm_limit.create()
        # Edit limit
        self.vm_limit.own_limits.limit = 66
        assert self.vm_limit.edit()
```

*API doc example:*

```
XML - POST

curl -i -X POST -u user:userpass --url http://onapp.test/billing/user/plans/977/resources.xml -H 'Accept: application/xml' -H 'Content-type: application/xml' -d '<resource><limits><limit>10</limit></limits><resource_class>Resource::VmLimit</resource_class><billing_plan_id>977</billing_plan_id><target_id>None</target_id><target_type>None</target_type><limit_type>hourly</limit_type></resource>'

Response:

  <resource>
    <resource_name>vm_limit</resource_name>
    <preferences></preferences>
    <limits>
        <limit>10</limit>
    </limits>
    <billing_plan_id>977</billing_plan_id>
    <created_at>2015-12-29T09:39:23+02:00</created_at>
    <target_id>None</target_id>
    <updated_at>2015-12-29T09:39:23+02:00</updated_at>
    <limit_type>hourly</limit_type>
    <label>Virtual Server</label>
    <master>False</master>
    <in_master_zone>False</in_master_zone>
    <prices></prices>
    <id>4200</id>
    <unit>None</unit>
  </resource>


JSON - POST

curl -i -X POST -u user:userpass --url http://onapp.test/billing/user/plans/977/resources.json -H 'Accept: application/json' -H 'Content-type: application/json' -d '{"resource": {"limits": {"limit": 10}, "resource_class": "Resource::VmLimit", "billing_plan_id": 977, "target_id": null, "target_type": null, "limit_type": "hourly"}}'

Response:
{"resource": {"resource_name": "vm_limit", "preferences": {}, "limits": {"limit": 10}, "billing_plan_id": 977, "created_at": "2015-12-29T09:39:23+02:00", "target_id": null, "updated_at": "2015-12-29T09:39:23+02:00", "limit_type": "hourly", "label": "Virtual Server", "master": false, "in_master_zone": false, "prices": {}, "id": 4200, "unit": null}}
```



## The OpenStack testsuite:

**Requirements**

There are two ways to get these tests running:

1. Prepare OnApp cloud(version>5.4) with the OpenStack integration

    This way you should be able to run all the tests except the _test_fresh_install_ and _test_prepare_cp_to_openstack_servers_deployment_

2. Prepare a specific testbed in VSphere

    This allows you to run the whole testsuite in cycles without further interventions.

Below are the step-by-step instructions for both methods.


**Prepare the OnApp cloud for openstack tests:**

Basically, all you need is OnApp cloud with the OpenStack integration enabled, and resources configured apparently so that it is possible to create an OpenStack Server.
Lets do this step by step assuming you have installed the OnApp CP version > 5.4 with the OpenStack integration(be sure to enable the feature in license).

1. Create DataStore zone and Hypervisor Zone (OCM type)
2. Create at least one cloudboot HV(openstack type) - you'll need to enable cloudboots in settings and add ip addresses for them.
3. Create an integrated storage datastore - you'll need to have IS enabled in settings(and some drives assigned to IS on created HVs)
4. Move created HV to created HV zone, and datastore to DataStore zone.
5. Attach the datastore to the HV zone.
6. Now some specific OpenStack preparations(one can do them in Horizon which can be entered by route <onapp_cp>/openstack or one may prefer to do them in CLI on the CP host):
   1. Add any template(consider CirrOs as the most lightweight)
   2. Add a network with the subnet
7. Create a template store and add openstack templates to it.
8. Synchronize the instance packages(press the button on the page /instance_packages)

That's all, if you do not want to create instances from within the OpenStack - for that you'll need to do one more thing: add the openstack instance packages to the admin's billing plan.
Now you should be able to run tests.

**Prepare the testbed for openstack tests:**

The access to VCenter is required with enough permissions and resources to create the VMs as described below. Also ensure the vcenter ip accessible from the host where the tests will be launched from.
For the starters, let's prepare VMs:

1. Create a VM for CP host:
    * provide all the resources for this VM as you would do that for the ordinary OnApp CP. 
        * HDD - 20G would be just enough.
        * RAM - for me 16G did the job, but they were guaranteed(reserved in VSphere).
        * Two NICs attached to a public and management networks respectively.Of cause, one may consider more networks, which will be closer to a production environment, but here we presume a VM with 2 NICs attached.
    * use minimal Centos 7 image
    * add ssh key of a user which will be running tests to root's authorized keys
2. The tricky part. Provide the access to the CP host from the location where the tests will be launched, by the management ip address.
So, let's say you configure public ip address of the CP on the first interface, and management ip on the second one.
You'll have to specify that management ip both as **host:** in *clouds.cfg* and **clb_net_ip** in *extended.cfg*.
Let your management ip be **10.0.52.233** on the interface **eno33557248** and your PC host is **192.168.129.168** mask **22** and the gateway is **10.0.52.1**.

On the CP host create file **/etc/sysconfig/network-scripts/route-eno33557248** with the following content:
`192.168.129.0/22 via 10.0.52.1 dev eno33557248`
and restart networking service.

**_Why? To avoid telling a long story i'd just say - the problem lays in the way that the openstack client authenticates in OpenStack.
Sure, there are different ways to achieve that but i've did not manage to find any more simple than this one._**

3. Create a snapshot of the created VM. The name of the snapshot should be put in **SNAPSHOT_TO_USE** variable in *test_fresh_install.py* . It will be reused to run deployments.

2. Create VMs for cloudbooted HVs - as many as you wish, just keep in mind that at least two of them needed to facilitate tests with migrations.
Names of these VMs should be put into **VSPHERE_HYPERVISOR_HOSTS** variable in *test_prepare_cp_to_openstack_servers_deployment.py*
I suggest to provide at least the following resources:
    * 8G RAM
    * 50G HDD(at least one)
    * One NIC attached to the management network

That's all. Now you have to only put your VCenter credentials into *vsphere.cfg* and run tests. The proper order is:
1. *test_fresh_install.py*
2. *test_prepare_cp_to_openstack_servers_deployment.py*
3. The following - in any order, or even in parallel(according to available resources in cloud):
    * *test_openstack_server_api*
    * *test_resize_openstack_server*
    * *test_cold_migrate_openstack_server*
    * *test_hot_migrate_openstack_server*
    * *test_multiple_migrates_openstack_server*
    
...and all this pack in cycles.

**Additionally :** to make use of vnc client, one should have the [tesseract installed on the host](https://github.com/tesseract-ocr/tesseract/wiki)

## Running tests in Docker container

In case the full ote install on the workstation is undesirable(or impossible), consider running and developing tests in docker container.

The **cote.sh** script provides:
* generating a relevant Docker file
* creating the image
* running a container with the ready-to-go environment

**Requirements**
1. [Docker installed](https://www.google.com.ua/url?sa=t&rct=j&q=&esrc=s&source=web&cd=1&cad=rja&uact=8&ved=0ahUKEwi_48uNjJ3WAhUjG5oKHXnkCCwQFggnMAA&url=https%3A%2F%2Fdocs.docker.com%2Fengine%2Finstallation%2F&usg=AFQjCNHX_qhaYPLI5F2STuE4mRr9GZjosw) and allowed for current user
2. ssh-keys which allow access to the [OTE repo](https://bitbucket.org/onappcore/ote)
3. The **conf** folder with the OTE configuration files inside - in current folder
4. The host machine should have the Internet access

Once the requirements above are satisfied, one may merely run ./cote.sh to read the explanation on usage.
Or run the command with the following options and get into the working environment at once:

```./cote.sh -b -e```

The above command builds a container with the ote sources and configured environment, starts it and opens console.
After that one can run the tests or use ote console - as usual. You can quit container with the ```Ctl-D``` combination and then return to it with the command:

```./cote.sh -e```


Also it is possible to create and use a partial container - where ote sources are not cloned into container but mounted as a current working directory from host.
And, of course, one can operate the container in a usual way - with all the plenty of the Docker tools.