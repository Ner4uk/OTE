import re

__doc__ = """ Collect all helpers for check errors"""


def check_if_error_in_error_list_by_reg_exp(reg_exp_error_msg, error_list):
    """
    Check if some regular expression is present in list of errors
    :param reg_exp_error_msg: regular expression
    :param error_list: list of errors
    :return: an array of found errors.
    """
    return [e for e in error_list if re.findall(reg_exp_error_msg, e)]


def check_if_error_in_error_list(error_msg, error_list):
    """
    Check if some error message is present in list of errors
    :param error_msg: error message
    :param error_list: list of error messages
    :return: an array of found errors.
    """
    return [e for e in error_list if error_msg in e]