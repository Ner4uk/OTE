import pytest
from onapp_helper import test
from onapp_helper.bucket import rate_cards as rc

RC_WITHOUT_AC = [
    rc.DraasRC.type
]

# https://onappdev.atlassian.net/browse/CORE-12510)
if test.cp_version >= 6.0:
    RC_WITHOUT_AC.append(rc.AcceleratedServersRC.type)


@pytest.mark.verbose
class BaseTest:
    def teardown_class(self):
        attributes = (
            'target',
            'incorrect_target',
            'target_apply_to_all_resources',
            'bucket'
        )
        test.clean_up_resources(attributes, self)

    def test_negative_prices(self):
        for key in self.prices.keys():
            self.rc.reset()
            self.rc.prices.__dict__[key] = -10
            self.rc.create()
            assert self.rc.E_GREATER_OR_EQUAL_TO_0 in self.rc.error[key]

    def test_create_rc_with_correct_parameters(self):
        self.rc.reset()
        self._set_prices(self.rc)
        assert self.rc.create(), self.rc.error

    def test_access_control_has_not_been_created(self):
        if self.rc.type in RC_WITHOUT_AC:
            pytest.skip(
                "Access controls is not supported by {}".format(self.rc.type)
            )
        assert not self.ac.get()

    def test_check_prices_after_create(self):
        self._check_prices(self.rc)

    def test_edit_prices(self):
        test.gen_api_doc = 'Edit {} Rate Card'.format(
            self._doc_title()
        )
        for key, value in self.prices.items():
            test.log.info(
                'Edit {} from {} to {}...'.format(key, value, value * 2)
            )
            self.prices[key] = value * 2
            self.rc.prices.__dict__[key] = value * 2
            assert self.rc.edit(), self.rc.error

    def test_check_prices_after_edit(self):
        self._check_prices(self.rc)

    def test_delete_rc(self):
        test.gen_api_doc = 'Delete {} Rate Card'.format(
            self._doc_title()
        )
        assert self.rc.delete(), self.rc.error

    def test_check_create_access_control_parameter(self):
        if self.rc.type in RC_WITHOUT_AC:
            pytest.skip(
                "Access controls is not supported by {}".format(self.ac.type)
            )
        self.rc.create_access_control = True
        assert self.rc.create(), self.rc.error
        assert self.ac.get(), self.ac.error

    def _set_prices(self, rc, multiplier=1):
        '''
        set prices for rc prices object using dictionary prices variable
        :param rc: bucket rate card
        :param multiplier: in case it's needed to change all prices for bucket rc
        :return:
        '''
        for key, value in self.prices.items():
            self.prices[key] = round(value * multiplier, 2)
            rc.prices.__dict__[key] = self.prices[key]

    def _check_prices(self, rc, zero=False):
        '''
        check prices for rc prices object using prices limits variable
        :param rc:  bucket rate card
        :param zero: if prices should be zero set True
        :return:
        '''
        if zero:
            for key, value in self.prices.items():
                assert rc.prices.__dict__[key] == 0
        else:
            for key, value in self.prices.items():
                assert rc.prices.__dict__[key] == value

    def _doc_title(self):
        server_type = ' '.join(
            [s.capitalize() for s in self.rc.server_type.split('_')]
        ) if (
            self.rc.server_type != rc.SERVER_TYPE.vpc
        ) else self.rc.server_type.upper()
        rc_type = ' '.join([s.capitalize() for s in self.rc.type.split('_')])
        return '{} {}'.format(server_type, rc_type)
