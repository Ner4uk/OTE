# ignore
__author__ = ''
__doc__ = """"""
__since__ = None  # Describe version since this functional available
from onapp_helper import test
from onapp_helper import template_store
from onapp_helper.bucket.bucket import Bucket
from onapp_helper.user import User
from onapp_helper.bucket.access_controls import TemplateGroupsAC


def prepare_template_for_server_creation(template):
    """
    For buckets
    1. Create template store if not exist
    2. Add template to template store if needed
    3. Add template store to current user access control
    """

    test.log.info(f'Prepare template {template.label} for server creation')
    # Create template store if not exists
    template_stores = [
        ts for ts in template_store.TemplateStore().get_all()
        if ts.label == 'OTE'
    ]
    ts = template_stores[0] if template_stores else None
    if not ts:
        test.log.info('Create template store')
        ts = template_store.TemplateStore()
        ts.label = 'OTE'
        ts.create()
    # Add template to template store
    rtgs = [
        rtg for rtg in template_store.RelationGroupTemplate(ts).get_all()
        if rtg.template_id == template.id and rtg.image_template_group_id == ts.id
    ]
    rtg = rtgs[0] if rtgs else None
    if not rtg:
        test.log.info('Add template to template store')
        rtg = template_store.RelationGroupTemplate(ts)
        rtg.attach_template_to_group(template.id)
    # Add template store to current user bucket
    user = User().search(phrase=test.session.login)[0]
    bucket = Bucket(id=user.bucket_id)
    ts_ac = TemplateGroupsAC(
        parent_obj=bucket,
        target_id=ts.id,
        server_type=TemplateGroupsAC.SERVER_TYPE.other
    )
    if not ts_ac.get():
        test.log.info('Add template store to access control')
        ts_ac.create()