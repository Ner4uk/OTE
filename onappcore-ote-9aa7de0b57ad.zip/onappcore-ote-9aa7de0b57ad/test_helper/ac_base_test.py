import pytest
from onapp_helper import test
from onapp_helper.bucket import access_controls as ac

AC_WITHOUT_RC = [
    ac.AcceleratedServersAC.type,
    ac.ApplicationServersAC.type,
    ac.ContainerServersAC.type,
    ac.BaremetalServerAC.type,
    ac.SmartServerAC.type,
    ac.VirtualServerAC.type,
]


@pytest.mark.verbose
class BaseTest:
    def teardown_class(self):
        attributes = (
            'target',
            'bucket'
        )
        test.clean_up_resources(attributes, self)

    def test_negative_limits(self):
        for key in self.limits.keys():
            self.ac.reset()
            self.ac.limits.__dict__[key] = -10
            self.ac.create()
            assert self.ac.E_GREATER_OR_EQUAL_TO_0 in self.ac.error[key]

    def test_create_ac_with_correct_parameters(self):
        self.ac.reset()
        self._set_limits(self.ac)
        test.gen_api_doc = 'Create {} Access Control'.format(
            self._doc_title()
        )
        assert self.ac.create(), self.ac.error

    def test_rate_card_has_not_been_created(self):
        if self.ac.type in AC_WITHOUT_RC:
            pytest.skip(
                "Rate cards is not supported by {}".format(self.ac.type)
            )
        assert not self.rc.get()

    def test_check_limits_after_create(self):
        self._check_limits(self.ac)

    def test_edit_limits(self):
        test.gen_api_doc = 'Edit {} Access Control'.format(
            self._doc_title()
        )
        for key, value in self.limits.items():
            test.log.info(
                'Edit {} from {} to {}...'.format(key, value, value * 2)
            )
            self.limits[key] = value * 2
            self.ac.limits.__dict__[key] = value * 2
            assert self.ac.edit(), self.ac.error

    def test_check_limits_after_edit(self):
        self._check_limits(self.ac)

    def test_delete_ac(self):
        test.gen_api_doc = 'Delete {} Access Control'.format(
            self._doc_title()
        )
        assert self.ac.delete(), self.ac.error
        assert not self.ac.get()

    def test_check_create_rate_card_parameter(self):
        if self.ac.type in AC_WITHOUT_RC:
            pytest.skip(
                "Rate cards is not supported by {}".format(self.ac.type)
            )
        self.ac.create_rate_card = True
        assert self.ac.create(), self.ac.error
        assert self.rc.get(), self.rc.error

    def _doc_title(self):
        server_type = ' '.join(
            [s.capitalize() for s in self.ac.server_type.split('_')]
        ) if (
            self.ac.server_type != ac.SERVER_TYPE.vpc
        ) else self.ac.server_type.upper()
        ac_type = ' '.join([s.capitalize() for s in self.ac.type.split('_')])
        return '{} {}'.format(server_type, ac_type)

    def _set_limits(self, ac, multiplier=1):
        '''
        set limits for ac limits object using dictionary limits variable
        :param ac: bucket access control
        :param multiplier: in case it's needed to change all limits for bucket ac
        :return:
        '''
        for key, value in self.limits.items():
            self.limits[key] = value * multiplier
            ac.limits.__dict__[key] = self.limits[key]

    def _check_limits(self, ac, unlimited=False):
        '''
        check limits for ac limits object using dictionary limits variable
        :param ac:  bucket access control
        :param unlimited: if values should be unlimited set True
        :return:
        '''
        if unlimited:
            for key, value in self.limits.items():
                if key in ['limit_default_cpu', 'limit_min_cpu', 'limit_min_cpu_priority']:
                    assert ac.limits.__dict__[key] == 1
                elif key == 'limit_default_cpu_share':
                    assert ac.limits.__dict__[key] == 100
                elif key == 'limit_min_memory':
                    assert ac.limits.__dict__[key] == 128
                else:
                    assert ac.limits.__dict__[key] is None
        else:
            for key, value in self.limits.items():
                assert ac.limits.__dict__[key] == value