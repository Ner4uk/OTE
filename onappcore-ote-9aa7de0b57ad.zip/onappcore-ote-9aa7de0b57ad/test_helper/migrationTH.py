import re

from onapp_helper import test
from onapp_helper.hypervisor import Hypervisor
from onapp_helper.hypervisor_zone import HypervisorZone
from onapp_helper.data_store import DataStore
from onapp_helper.networks import Network

__doc__ = """ Collect all helpers for migration tests (Server/Disk)

"""


def lvs_grep_disk_identifier(disk_identifier, target):
    """
    Grep string by disk identifier from lvs output
    :param disk_identifier: disk identifier
    :param target: HV/BS object
    :return: execution result
    """
    return target.execute('lvs | grep {}'.format(disk_identifier))


def remove_disk_backup(ds_identifier, disk_backup, target):
    """
    Remove disk backup on specific data store from target (HV/BS)
    :param ds_identifier: data store identifier
    :param disk_backup: disk backup
    :param target: HV/BS object
    :return: execution result
    """
    return target.execute(
        'lvremove -fv /dev/{}/{}'.format(
            ds_identifier, disk_backup
        )
    )


def disk_backup_id(disk_identifier, target):
    lvs_output = lvs_grep_disk_identifier(disk_identifier, target)
    disk_backup_ids = re.findall(
        pattern='[a-z]+-[0-9]+', string=lvs_output
    )
    return disk_backup_ids[0] if disk_backup_ids else None


def get_expected_migration_time(server, migration_rate_limit):
    """
    Calculate expected migration time according to migration_rate_limit
    :param server: any server object
    :param migration_rate_limit: migration_rate_limit
    :return: expected migration time in minutes
    """
    disk_sizes = [d.disk_size for d in server.disks() if not d.is_swap]
    disks_size = sum(disk_sizes)

    return disks_size * 1024.0 / migration_rate_limit / 60.0


def get_actual_migtarion_time(server, migration_type):
    """
    Get total disk copy time from log output
    :param server: any server object
    :return: actual migration time in minutes
    """

    # !!! Does not implemented for 'hot_full_migrate'
    action = 'full_migrate' if migration_type is None else 'hot_full_migrate'
    if server.transaction_handler(action):
        stop = 0
        minutes = []
        seconds = []
        disks_migration_count = server.transaction.log_output.count(
            'Running: echo Disk copy time:'
        )
        for i in range(disks_migration_count):
            start = server.transaction.log_output.find(
                'Running: echo Disk copy time:', stop
            )
            stop = server.transaction.log_output.find(
                '\n', start
            )
            s = server.transaction.log_output[start:stop]
            if s:
                digits = re.findall(r'\d+', s)
                minutes.append(int(digits[1]))
                seconds.append(int(digits[2]))
        return sum(minutes) + (sum(seconds)/60)


def check_firewall_rules_by_key(target, key, *vals):
    """
    Get firewall rules from destination host (hypervisor) grepping by key

    :param target: HV object
    :param key: key for grep
    :param vals: a tuple of additional values to be checked
    :return: result string
    """
    result = target.execute(command=f"iptables -L -n | grep -w {key}")
    if not vals:
        return key in result
    else:
        return all(
            [val in result for val in vals]
        )


def get_destination_hv(source_hypervisor_id, destination_hv_zone=None):
    """Get destination hv to migrate knowing source hypervisor_id"""
    if destination_hv_zone is None:
        destination_hv_zone = test.env.hvz

    hvs = [
        hv for hv in destination_hv_zone.attached_hypervisors() if
        hv.enabled and hv.online and hv.id != source_hypervisor_id
    ]
    return hvs[0] if hvs else None


def get_destination_hv_zone(source_hv):
    suitable_hvz_ids = [
        hv.hypervisor_group_id for hv in Hypervisor().get_all()
        if hv.hypervisor_type == source_hv.hypervisor_type
           and hv.hypervisor_group_id != source_hv.hypervisor_group_id
    ]
    if suitable_hvz_ids:
        return HypervisorZone(id=suitable_hvz_ids[0])
    return None


def get_destination_data_store(
        source_data_store, destination_hv, destination_hvz
):
    ds_joins = destination_hv.data_store_joins() + \
               destination_hvz.data_store_joins()

    dst_data_stores_ids = [
        ds_join.data_store_id for ds_join in ds_joins
        if ds_join.data_store_id != source_data_store.id
    ]
    if dst_data_stores_ids:
        data_stores = [DataStore(id=ds_id) for ds_id in dst_data_stores_ids]
        # Return not local data store
        return [ds for ds in data_stores if not ds.local_hypervisor_id][0]
    return None


def get_destination_networks(destination_hv, destination_hvz):
    network_joins = destination_hv.network_joins() + \
               destination_hvz.network_joins()

    return [
        Network(network_join.network_id) for network_join in network_joins
    ]


def bridge_is_present(bridge_name, target):
    return bridge_name in target.execute(f'brctl show | grep {bridge_name}')
