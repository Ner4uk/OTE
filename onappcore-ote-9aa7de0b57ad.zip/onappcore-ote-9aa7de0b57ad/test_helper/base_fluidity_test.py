import re
import os
from onapp_helper import test
from onapp_helper.hypervisor_zone import HypervisorZone
from onapp_helper.ip_address import IpAddress
from onapp_helper.ip_network import IpNetwork
from onapp_helper.ip_range import IpRange
from test_helper import migrationTH


class BaseFluidityTest:
    def test_create_some_file_on_disks(self, vs, additional_disk):
        """
        Create test file on primary and additional disks
        :param vs:
        :return:
        """
        test_files = [
            os.path.join(
                d.mount_point if d.mount_point else '/', "test_file"
            ) for d in vs.disks() if not d.is_swap
        ]

        [
            vs.execute(
                f'echo "fluidity" > {test_file}'
            ) for test_file in test_files
        ]

        assert all(
            [
                "fluidity" in vs.execute(
                    f'cat {test_file}'
                ) for test_file in test_files
            ]
        ), 'Some test file has not been created'

    def test_server_is_running_on_source_hv_before_migrate(self, vs, src_hv):
        assert src_hv.domain_is_running(vs.identifier, timeout=10)

    def test_primary_nic_firewall_rules_is_present_on_source_hv_before_migrate(
            self, vs, src_hv, primary_nic
    ):
        assert migrationTH.check_firewall_rules_by_key(
            src_hv, vs.ip_address, primary_nic.identifier
        )

    def test_additional_nic_firewall_rules_is_present_on_source_hv_before_migrate(
            self, additional_nic_ip_address, src_hv, additional_nic
    ):
        assert migrationTH.check_firewall_rules_by_key(
            src_hv, additional_nic_ip_address.address, additional_nic.identifier
        )

    def test_primary_nic_custom_firewall_rules_is_present_on_source_hv_before_migrate(
            self, vs, custom_firewall_rule_for_primary_nic, src_hv
    ):
        assert migrationTH.check_firewall_rules_by_key(
            src_hv, custom_firewall_rule_for_primary_nic.address.split('/')[0]
        )

    def test_additional_nic_custom_firewall_rules_is_present_on_source_hv_before_migrate(
            self, vs, custom_firewall_rule_for_additional_nic, src_hv
    ):
        assert migrationTH.check_firewall_rules_by_key(
            src_hv, custom_firewall_rule_for_additional_nic.address.split('/')[0]
        )

    def test_primary_nic_bridge_is_present_on_source_hv_before_migrate(
            self, vs, src_hv, primary_nic
    ):
        assert migrationTH.bridge_is_present(primary_nic.identifier, src_hv)

    def test_additional_nic_bridge_is_present_on_source_hv_before_migrate(
        self, additional_nic, src_hv
    ):
        assert migrationTH.bridge_is_present(additional_nic.identifier, src_hv)

    def test_disks_is_present_on_source_data_store_before_migrate(
            self, vs, src_ds, src_hv
    ):
        for d in vs.disks():
            lvs_output = migrationTH.lvs_grep_disk_identifier(
                d.identifier, src_hv
            )
            assert d.identifier in lvs_output and src_ds.identifier in lvs_output

    def test_full_migrate(
            self, vs, dst_hv, src_hv, additional_nic, migration_type, dst_ds
    ):
        dst_networks = migrationTH.get_destination_networks(
            dst_hv, HypervisorZone(id=dst_hv.hypervisor_group_id)
        )

        disk_destinations = {str(d.id): dst_ds.id for d in vs.disks()}

        dst_primary_network = dst_networks[0]
        dst_additional_network = dst_networks[1]

        primary_nic_id = vs.network_interface.get_primary().id
        primary_ip_net = IpNetwork(parent_obj=dst_primary_network).get_all()[0]
        primary_ip_range = IpRange(parent_obj=primary_ip_net).get_all()[0]
        primary_ip_address = IpAddress(
            parent_obj=dst_primary_network
        ).get_free(primary_ip_range)

        additional_ip_net = IpNetwork(
            parent_obj=dst_additional_network
        ).get_all()[0]
        additional_ip_range = IpRange(parent_obj=additional_ip_net).get_all()[0]
        additional_ip_address = IpAddress(
            parent_obj=dst_additional_network
        ).get_free(additional_ip_range)

        network_destinations = {
            str(primary_nic_id): {
                "network_id": dst_primary_network.id,
                "ip_net_id": primary_ip_net.id,
                "ip_range_id": primary_ip_range.id,
                "ip_address": primary_ip_address.address
            },
            str(additional_nic.id): {
                "network_id": dst_additional_network.id,
                "ip_net_id": additional_ip_net.id,
                "ip_range_id": additional_ip_range.id,
                "ip_address": additional_ip_address.address
            }
        }
        assert vs.full_migrate(
            dst_hv.id,
            dst_hv.hypervisor_group_id,
            disk_destinations,
            network_destinations,
            migration_type
        ), vs.error

        vs.get()

        assert dst_hv.id == vs.hypervisor_id != src_hv.id

        # Ping ip addresses after migrate
        assert vs.ping(target=primary_ip_address.address)
        assert vs.ping(target=additional_ip_address.address)

    def test_server_is_running_on_destination_hv_after_migrate(self, vs, dst_hv):
        assert dst_hv.domain_is_running(vs.identifier, timeout=10)

    def test_server_is_not_running_on_source_hv_after_migrate(self, vs, src_hv):
        assert not src_hv.domain_is_running(vs.identifier, timeout=10)

    def test_primary_nic_firewall_rules_is_present_on_destination_hv_after_migrate(
            self, dst_hv, dst_primary_ip_address, primary_nic
    ):
        assert migrationTH.check_firewall_rules_by_key(
            dst_hv, dst_primary_ip_address, primary_nic.identifier
        )

    def test_primary_nic_firewall_rules_is_not_present_on_source_hv_after_migrate(
            self, src_hv, vs, primary_nic
    ):
        assert not migrationTH.check_firewall_rules_by_key(
            src_hv, vs.ip_address, primary_nic.identifier
        )

    def test_additional_nic_firewall_rules_is_present_on_destination_hv_after_migrate(
            self, dst_hv, dst_additional_ip_address, additional_nic
    ):
        assert migrationTH.check_firewall_rules_by_key(
            dst_hv, dst_additional_ip_address, additional_nic.identifier
        )

    def test_additional_nic_firewall_rules_is_not_present_on_source_hv_after_migrate(
            self, additional_nic_ip_address, src_hv, additional_nic
    ):
        assert not migrationTH.check_firewall_rules_by_key(
            src_hv, additional_nic_ip_address.address, additional_nic.identifier
        )

    def test_primary_nic_custom_firewall_rules_is_present_on_destination_hv_after_migrate(
            self, custom_firewall_rule_for_primary_nic, dst_hv
    ):
        assert migrationTH.check_firewall_rules_by_key(
            dst_hv, custom_firewall_rule_for_primary_nic.address.split('/')[0]
        )

    def test_primary_nic_custom_firewall_rules_is_not_present_on_source_hv_after_migrate(
            self, custom_firewall_rule_for_primary_nic, src_hv
    ):
        assert not migrationTH.check_firewall_rules_by_key(
            src_hv, custom_firewall_rule_for_primary_nic.address.split('/')[0]
        )

    def test_additional_nic_custom_firewall_rules_is_present_on_destination_hv_after_migrate(
            self, custom_firewall_rule_for_additional_nic, dst_hv
    ):
        assert migrationTH.check_firewall_rules_by_key(
            dst_hv, custom_firewall_rule_for_additional_nic.address.split('/')[0]
        )

    def test_additional_nic_custom_firewall_rules_is_not_present_on_source_hv_after_migrate(
            self, custom_firewall_rule_for_additional_nic, src_hv
    ):
        assert not migrationTH.check_firewall_rules_by_key(
            src_hv, custom_firewall_rule_for_additional_nic.address.split('/')[0]
        )

    def test_primary_nic_bridge_is_present_on_destination_hv_after_migrate(
        self, vs, dst_hv, primary_nic
    ):
        assert migrationTH.bridge_is_present(primary_nic.identifier, dst_hv)

    def test_primary_nic_bridge_is_not_present_on_source_hv_after_migrate(
        self, vs, src_hv, primary_nic
    ):
        assert not migrationTH.bridge_is_present(primary_nic.identifier, src_hv)

    def test_additional_nic_bridge_is_present_on_destination_hv_after_migrate(
        self, additional_nic, dst_hv
    ):
        assert migrationTH.bridge_is_present(
            additional_nic.identifier, dst_hv
        )

    def test_additional_nic_bridge_is_not_present_on_source_hv_after_migrate(
        self, additional_nic, src_hv
    ):
        assert not migrationTH.bridge_is_present(
            additional_nic.identifier, src_hv
        )

    def test_check_files_after_migrate(self, vs, dst_primary_ip_address):
        test_files = [
            os.path.join(
                d.mount_point if d.mount_point else '/', "test_file"
            ) for d in vs.disks() if not d.is_swap
        ]

        assert len(test_files) == 2

        assert all(
            [
                "fluidity" in vs.execute(
                    f'cat {test_file}', target=dst_primary_ip_address
                ) for test_file in test_files
            ]
        ), 'Some disk has been migrated incorrect'

    def test_disks_is_not_present_on_source_data_store_after_migrate(
            self, vs, src_ds, src_hv
    ):
        for d in vs.disks():
            lvs_output = migrationTH.lvs_grep_disk_identifier(
                d.identifier, src_hv
            )

            assert not [
                l for l in lvs_output.split('\n')
                if src_ds.identifier in l and d.identifier in l.split()
            ]

    def test_disks_is_present_on_destination_data_store_after_migrate(
            self, vs, dst_ds, dst_hv
    ):
        for d in vs.disks():
            lvs_output = migrationTH.lvs_grep_disk_identifier(
                d.identifier, dst_hv
            )

            assert [
                l for l in lvs_output.split('\n')
                if dst_ds.identifier in l and d.identifier in l.split()
            ]