from onapp_helper import test


def check_grub_file(server):
    server.get_grub_config_file_path()
    if test.env.hv.hypervisor_type == 'xen':
        line = 'console=tty0 console=hvc0'
    elif test.env.hv.hypervisor_type == 'kvm':
        line = 'console=tty0 console=ttyS0,115200'
    else:
        assert False, 'Undefined Hypervisor Type'
    # For xen/kvm line is the same for both cases!!!
    # We do not remove this line from grub
    assert line in server.execute(
        f'cat {server.grub_conf_file_path}'
    )


def check_xml_config(xml_config):
    if test.env.hv.hypervisor_type == 'xen':
        assert xml_config.domain.devices.console.type == 'pty'
        assert xml_config.domain.devices.console.target.type == 'xen'
        assert xml_config.domain.devices.console.target.port == '0'

    elif test.env.hv.hypervisor_type == 'kvm':
        assert xml_config.domain.devices.console.type == 'pty'
        assert xml_config.domain.devices.console.target.type == 'serial'
        assert xml_config.domain.devices.console.target.port == '0'
        assert xml_config.domain.devices.serial.type == 'pty'
        assert xml_config.domain.devices.serial.target.port == '0'
    else:
        assert False, 'Undefined Hypervisor Type'