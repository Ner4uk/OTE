from random import randint, choice
import string


def generate_ipv4():
    return '.'.join([str(randint(0, 256)) for _ in range(4)])


def generate_port(count):
    return ''.join(choice(string.digits) for _ in range(count))


def generate_name(n=8):
    return ''.join(choice(string.ascii_lowercase) for _ in range(n))


def generate_number_string():
    return str(randint(10, 100))

