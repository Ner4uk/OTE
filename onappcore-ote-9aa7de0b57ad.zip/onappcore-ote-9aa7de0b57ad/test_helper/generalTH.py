__doc__ = """Collect all general helpers for tests"""


def value_comparator(expected, actual, precision=0.2):
    if expected == actual == 0.0:
        print("Expected: {}".format(expected))
        print("Actual: {}".format(actual))
        return True
    delta = expected * precision / 100.0
    print("Expected: {}, +/-{}".format(expected, delta))
    print("Actual: {}".format(actual))
    if expected - delta <= actual <= expected + delta:
        return True
    return False


def value_comparator_with_round(expected, actual, ndigits):
    """Compare two prices with rounding"""
    return round(expected, ndigits=ndigits) == round(actual, ndigits=ndigits)
