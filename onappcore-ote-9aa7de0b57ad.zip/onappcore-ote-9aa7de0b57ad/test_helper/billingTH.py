__doc__ = """Collect all helpers for billing tests"""
from pytest import approx


def price_comparator(expected, actual, precision=0.2, rel=None):
    if expected == actual == 0.0:
        print("Expected: {}".format(expected))
        print("Actual: {}".format(actual))
        return True
    delta = expected * precision / 100.0
    print("Expected: {}, +/-{}".format(expected, delta))
    print("Actual: {}".format(actual))
    return expected == approx(actual, abs=delta)


def price_comparator_with_round(expected, actual, ndigits):
    """Compare two prices with rounding"""
    print("Expected: {}".format(round(expected, ndigits=ndigits)))
    print("Actual: {}".format(round(actual, ndigits=ndigits)))
    # return round(expected, ndigits=ndigits) == round(actual, ndigits=ndigits)
    return expected == approx(actual)


def get_free_amount(current_value, free_value):
    if current_value <= free_value:
        return current_value
    else:
        return free_value
