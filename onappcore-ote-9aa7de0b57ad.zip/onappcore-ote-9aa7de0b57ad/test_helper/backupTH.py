# Test methods
import os

COUNT = 100
TEST_FILE_NAME = f'{COUNT}MB'


def check_facl(vs, file):
    if vs.ping(timeout=60):
        return '-rwxrwxrwx' in vs.execute(f'ls -al {file}')
    return False


def set_facl(vs, file):
    vs.ping(timeout=60)
    vs.execute(f'chmod 777 {file}')


def check_xattr(vs, file):
    if vs.ping(timeout=60):
        facl = vs.execute(f'getfacl {file}')
        return 'user:root:rwx' in facl and 'mask::rwx' in facl
    return False


def set_xattr(vs, file):
    vs.ping(timeout=60)
    vs.execute(f'setfacl -m "u:root:rwx" {file}')


def create_file(vs, file):
    if vs.ping(timeout=60):
        return vs.execute(
            f'dd if=/dev/urandom of={file} bs=1024k count={COUNT}'
        )
    return False


def file_exist(vs, file):
    if vs.ping(timeout=60):
        return TEST_FILE_NAME in vs.execute(f'ls -l {os.path.dirname(file)}')
    return False


def delete_file(vs, file):
    vs.ping(timeout=60)
    vs.execute(f'rm -rfv {file}')


def edit_grub_config(vs):
    if vs.ping(timeout=60):
        return vs.execute(
            f'echo \'# OTE test comment\' >> {vs.grub_conf_file_path}'
        )
    return False


def check_grub_config(vs):
    if vs.ping(timeout=60):
        return "# OTE test comment" in vs.execute(
            f'cat {vs.grub_conf_file_path}'
        )
    return False
