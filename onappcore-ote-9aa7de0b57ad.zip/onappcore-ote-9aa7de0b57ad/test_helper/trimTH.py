import ruamel

from onapp_helper import test
from onapp_helper.xml_config import XmlConfig


################################################################################
def _disk_target_device(disk):
    cfg = disk.parent_obj.template.disk_target_device  # "---\nxen: sda\nkvm: hd\n"
    if cfg:  # cfg is None for OVA templates
        cfg_dict = ruamel.yaml.safe_load(cfg)  # {'xen': 'sda', 'kvm': 'hd'}
        return cfg_dict[disk.parent_obj.hypervisor_type]
    return ''


def _check_xml_config_for_kvm(xml_config, disk, trim_option):
    """
    KVM:
    #without trim
    <disk type="block" device="disk">
      <source dev="/dev/onapp-cojvkmbtowfjlc/uacqdrhxwgiddb"/>
      <target *dev="vda" bus="virtio"*/>
      <driver type="raw" name="qemu" cache="none" *discard="ignore"*/>
    </disk>

    #with trim
    <disk type="block" device="disk">
      <source dev="/dev/onapp-vomyebhkmcclgb/byfktyfbaprcdc\>
      <target *dev="sda" bus="scsi"*/>
      <driver type="raw" name="qemu" cache="none" *discard="unmap"*/>
      <address type="drive" *controller="0"* bus="0" target="0" unit="0"/>
    </disk>

    controller equals to disk_vm_number
    discard can be unmap/ignore

    :param disk: disk object
    :param xml_config: xml config object
    :param trim_option: Set True if you need to check that trim should work
    for current environment and configuration (template, hv, etc.), else False
    :return:
    """
    errors = list()
    xml_config_disk = [
        d for d in xml_config.domain.devices.disks
        if disk.identifier in d.source.dev
    ][0]

    # target
    # target device for enabled trim is 'sda'
    trim_target_dev = 'sd'

    if trim_option:
        if trim_target_dev not in xml_config_disk.target.dev:
            errors.append(
                f'Target device is "{xml_config_disk.target.dev}" instead '
                f'of "{trim_target_dev}" for trim option "{trim_option}"'
            )
    elif not trim_option and _disk_target_device(disk) != 'sda':
        if trim_target_dev in xml_config_disk.target.dev:
            errors.append(
                f'Target device should not be "{xml_config_disk.target.dev}" '
                f'for trim option "{trim_option}"'
            )
    elif not trim_option and disk.parent_obj.template.type == "ImageTemplateOva":
        if trim_target_dev in xml_config_disk.target.dev:
            errors.append(
                f'Target device should not be "{xml_config_disk.target.dev}" '
                f'for OVA template with trim option "{trim_option}"'
            )

    if disk.parent_obj.template.type == "ImageTemplateOva":
        target_bus = ''
    else:
        target_bus = 'scsi' if trim_option else 'virtio'
    if xml_config_disk.target.bus != target_bus:
        errors.append(
            f'Target bus is "{xml_config_disk.target.bus}" for '
            f'trim option "{trim_option}"'
        )

    # driver
    if trim_option:
        if disk.is_swap or disk.file_system == 'ext3':
            if xml_config_disk.driver.discard != 'ignore':
                errors.append(
                    f'Wrong discard option "{xml_config_disk.driver.discard}" '
                    f'instead of "ignore" for trim option "{trim_option}"'
                )
        else:
            if xml_config_disk.driver.discard != 'unmap':
                errors.append(
                    f'Wrong discard option "{xml_config_disk.driver.discard}" '
                    f'instead of "unmap" for trim option "{trim_option}"'
                )
    else:
        if xml_config_disk.driver.discard != 'ignore':
            errors.append(
                f'Wrong discard option "{xml_config_disk.driver.discard}" '
                f'instead of "ignore" for trim option "{trim_option}"'
            )

    # address
    if trim_option:
        if xml_config_disk.address and xml_config_disk.address.controller:
            if int(xml_config_disk.address.controller) != disk.disk_vm_number:
                errors.append(
                    f'Wrong address controller number "{xml_config_disk.address.controller}"'
                    f' for disk number "{disk.disk_vm_number}"'
                )
        else:
            errors.append('Address is not specified')
    else:
        if xml_config_disk.address and xml_config_disk.address.controller:
            errors.append(
                f'Address should be empty for trim option {trim_option}'
            )
    return errors


def _check_xml_config_for_xen(xml_config, disk, trim_option):
    """
    XEN: nothing to change

    :param disk: disk object
    :param xml_config: xml config object
    :param trim_option: Set True if you need to check that trim should work
    for current environment and configuration (template, hv, etc.), else False
    :return:
    """

    errors = list()
    xml_config_disk = [
        d for d in xml_config.domain.devices.disks
        if disk.identifier in d.source.dev
    ][0]

    # target
    target_dev = _disk_target_device(disk)
    if target_dev not in xml_config_disk.target.dev:
        errors.append(
            f'Target device is "{xml_config_disk.target.dev}" for '
            f'trim option "{trim_option}"'
        )

    target_bus = 'xen'
    if xml_config_disk.target.bus != target_bus:
        errors.append(
            f'Target bus is "{xml_config_disk.target.bus}" instead of {target_bus} for '
            f'trim option "{trim_option}"'
        )

    # No driver for XEN
    # # driver
    # if xml_config_disk.driver.discard != 'ignore':
    #     errors.append(
    #         f'Wrong discard type "{xml_config_disk.driver.discard}"'
    #     )

    return errors


def _xml_config_checker(xml_config, disk, trim_option):
    """
    :param disk: disk object
    :param xml_config: xml config object
    :param trim_option: Set True if you need to check that trim should work
    for current environment and configuration (template, hv, etc.), else False
    :return:
    """
    if disk.parent_obj.hypervisor_type == 'kvm':
        return _check_xml_config_for_kvm(xml_config, disk, trim_option)
    elif disk.parent_obj.hypervisor_type == 'xen':
        return _check_xml_config_for_xen(xml_config, disk, trim_option)


def _get_xml_config(vs):
    xml_config = XmlConfig(vs)
    xml_config.get_xml_config()
    return xml_config


def check_xml_config(vs, trim_option):
    errors = list()
    xml_config = _get_xml_config(vs)

    for disk in vs.disks():
        errors += _xml_config_checker(xml_config, disk, trim_option)

    assert not errors, [test.log.error(e) for e in errors]


def check_xml_config_for_disk(vs, disk, trim_option):
    xml_config = _get_xml_config(vs)
    errors = _xml_config_checker(xml_config, disk, trim_option)

    assert not errors, [test.log.error(e) for e in errors]
# ==============================================================================


def check_grub(vs, trim_option):
    """
    #without trim
    $ cat /boot/grub/grub.conf | grep -v ^#| grep kernel
       kernel /boot/vmlinuz-3.10.0-327.36.3.el7.centos.plus.x86_64 *root=/dev/vda1* console=tty0 ro vconsole.keymap=us vconsole.font=latarcyrheb-sun16 LANG=en_US.UTF-8 net.ifnames=0 biosdevname=0 nomodeset

    #with trim
    cat /boot/grub/grub.conf | grep -v ^#| grep kernel
      kernel /boot/vmlinuz-3.10.0-327.36.3.el7.centos.plus.x86_64 *root=/dev/sda1* console=tty0 ro vconsole.keymap=us vconsole.font=latarcyrheb-sun16 LANG=en_US.UTF-8 net.ifnames=0 biosdevname=0 nomodeset
    :param vs: vs object
    :param trim_option: Set True if you need to check that trim should work
    for current environment and configuration (template, hv, etc.), else False
    :return:
    """
    if not vs.grub_conf_file_path:
        raise ValueError('GRUB file can not be found')
    grub = vs.execute(f'cat {vs.grub_conf_file_path} | grep -v ^#| grep kernel')

    if trim_option and vs.hypervisor_type == 'kvm':
        assert 'root=/dev/sda1' in grub
    else:
        assert 'root=/dev/vda1' in grub or 'root=/dev/xvda1' in grub
# ==============================================================================


def _fstab_checker(fstab, disk, trim_option):
    """
    #without trim
    $ cat /etc/fstab
    /dev/*vda1* /        ext4  defaults 1 1
    /dev/*vdb*  swap swap defaults 0 0

    #with trim
    $ cat /etc/fstab
    /dev/*sda1* /        ext4  defaults,*discard* 1 1
    /dev/*sdb*  swap swap defaults              0 0
    :param fstab:
    :param disk:
    :param trim_option: Set True if you need to check that trim should work
    for current environment and configuration (template, hv, etc.), else False
    :return:
    """

    errors = list()
    if disk.primary:
        mount_point = '/'
    elif disk.is_swap:
        mount_point = 'swap'
    else:
        mount_point = disk.mount_point

    line_splt = None
    for line in fstab:
        line_splt = line.split()
        if line_splt[1] == mount_point:
            break

    if line_splt:
        if disk.parent_obj.template.type == 'ImageTemplateOva':
            dev = 'UUID'
        else:
            if disk.parent_obj.template.operating_system_distro == 'freebsd':
                dev = 'ada'
            else:
                dev = 'sd' if (
                        trim_option and disk.parent_obj.hypervisor_type == 'kvm'
                ) else 'vd'

        if dev not in line_splt[0]:
            errors.append(
                f'Wrong device {line_splt[0]} for trim option "{trim_option}"'
            )

        discard = 'discard'
        if trim_option and not disk.is_swap and disk.file_system != 'ext3':
            if discard not in line_splt[3]:
                errors.append(
                    f'discard should be present for {disk.file_system} with'
                    f' trim option "{trim_option}"'
                )
        else:
            if discard in line_splt[3]:
                errors.append(
                    f'discard should not be present for {disk.file_system} with'
                    f' trim option "{trim_option}"'
                )

    else:
        errors.append(f'No record about {disk.id} disk in fstab')
    return errors


def _get_fstab(vs):
    fstab_src = vs.execute('cat /etc/fstab')
    fstab = [
        line for line in fstab_src.split('\n') if
        not line.startswith('#') and line
    ]
    return fstab


def check_fstab_for_disk(vs, disk, trim_option):
    fstab = _get_fstab(vs)
    errors = _fstab_checker(fstab, disk, trim_option)

    assert not errors, [test.log.error(e) for e in errors]


def check_fstab(vs, trim_option):
    fstab = _get_fstab(vs)
    errors = list()

    for disk in vs.disks():
        errors += _fstab_checker(fstab, disk, trim_option)

    assert not errors, [test.log.error(e) for e in errors]


def set_trim_option(ds, value):
    assert ds.edit(trim=value), ds.error

################################################################################
