from selenium import webdriver


class Login:
    def __init__(self):
        self.driver = webdriver.Chrome()
        self.driver.get('http://69.168.237.37')
        self.username = self.driver.find_element_by_id('user_login')
        self.password = self.driver.find_element_by_xpath('//*[@id="user_password"]')
        self.submit = self.driver.find_element_by_name('commit')

    def error_message(self):
        return self.driver.find_element_by_xpath('//*[@id="flasher"]/span').text


