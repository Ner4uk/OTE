#!/usr/bin/env python
import paramiko
from time import sleep
import socket
from engine.lib.logger import Logger

log = Logger().logger


# Decorator for executing ssh
def ssh_exec(ssh):
    def wrap_exec(self, command, user, password, port, verbose):
        res = ''
        exit_status = None
        if self._connect(user, password, port):
            exit_status, res = ssh(self, command, user, password, port, verbose)
            self._disconnect()
        return exit_status, res
    return wrap_exec


class SSH():
    def __init__(self, host='', user='root', password='', port=22):
        self.client = paramiko.SSHClient()
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.host = host
        self.user = user
        self.password = password
        self.port = port

    def execute(
            self,
            command='',
            tunnel_host=None,
            timeout=10,
            user=None,
            password=None,
            port=None,
            verbose=True
    ):
        exit_status, output = self.ext_execute(
            command=command,
            tunnel_host=tunnel_host,
            timeout=timeout,
            user=user,
            password=password,
            port=port,
            verbose=verbose
        )
        return output

    def ext_execute(
            self,
            command='',
            tunnel_host=None,
            timeout=10,
            user=None,
            password=None,
            port=None,
            verbose=True
    ):
        """
        Simple usage: executing command on host which was defined during init
        or separately.
        Extended usage: if you need execute some command on remote host
        (tunnel) from current host you have to define tunnel_host additionally.

        Example:
            You init ssh for CP and you want to execute some command on HV
            than you need to execute current command with the following
            parameters like:

            >>> CP.ssh.execute(command='ls -l', tunnel_host='192.168.7.42')
        """
        if not user:
            user = self.user
        if not password:
            password = self.password
        if not port:
            port = self.port

        exit_status = None
        if command and tunnel_host != '':
            log.info(("*" * 80))
            # Extended usage (Remote executing command on another host via ssh)
            if tunnel_host:
                command = 'ssh -i /home/onapp/.ssh/id_rsa ' \
                          '-o StrictHostKeyChecking=no ' \
                          '-o UserKnownHostsFile=/dev/null ' \
                          '-o PasswordAuthentication=no root@{0} "{1}"'.format(
                    tunnel_host, command
                )
                log.info(
                    "Executing '{0}' on remote host {1} from {2}...".format(
                        command, tunnel_host, self.host
                    )
                )
            # Simple usage
            else:
                log.info(
                    "Executing '{0}' on {1}...".format(command, self.host)
                )

            # Wait while ssh connection will be established.
            exit_status, output = self._exe(
                command, user, password, port, verbose
            )
            while 'No route to host' in output[:100] \
                    or 'Connection refused' in output[:100] \
                    or 'Connection timed out' in output[:100]:
                if not timeout:
                    raise TimeoutError('Connection timed out.')
                log.info('{0} attempts left...'.format(timeout))
                sleep(5)
                exit_status, output = self._exe(
                    command, user, password, port, verbose
                )
                timeout -= 1
            #print(output)
            if 'Permission denied' in output and timeout:
                raise ConnectionError('Permission denied.')
            return exit_status, output
        elif tunnel_host == '':
            log.warning(
                'Incorrect "tunnel_host", current - "", expected None or "xxx.xxx.xxx.xxx"...'
            )
        else:
            log.info('No command to execute...')
        return exit_status, False

    # Is using for simple usage only.
    def _port_is_open(self, host=None, port=22, attempts=60):
        if not host and self.host:
            host = self.host
        log.info('Check if port {} is open on {} host'.format(port, host))
        while attempts:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            result = sock.connect_ex((host, port))
            log.debug('Result - {}, expected - 0'.format(result))
            if result == 0:
                break
            attempts -= 1
            sleep(1)
        if attempts:
            return True
        log.error("Port {} on host {} is closed.".format(port, host))
        return False

    def _connect(self, user, password, port):
        if self._port_is_open(host=self.host, port=port):
            # Try to connect
            try:
                self.client.connect(
                    hostname=self.host,
                    username=user,
                    password=password,
                    port=port,
                    timeout=300.0
                )
                return True
            except paramiko.AuthenticationException as AE:
                log.error(
                    """{}\n The possible issues:
                    - password is required;
                    - your public key is absent on CP;
                    - host is empty.""".format(AE)
                )

                return False
        return False

    def _disconnect(self):
        self.client.close()

    # @ssh_exec
    # def _exe(self, command):
    #     self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    #     transport = self.client.get_transport()
    #     print(transport.default_window_size)
    #     channel = transport.open_session()
    #     channel.settimeout(5)
    #     print(channel.timeout)
    #     channel.exec_command(command)
    #     print(channel.recv_exit_status())
    #     stdout = channel.makefile('rb').read()  # Be sure to read before the channel closes
    #     stderr = channel.makefile_stderr('rb').read()
    #     channel.close()
    #     #stdin, stdout, stderr = self.client.exec_command(command, timeout=600)
    #     return (stdout + stderr).decode()

    @ssh_exec
    def _exe(self, command, user, password, port, verbose):
        exit_status = None
        output = ''
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        transport = self.client.get_transport()
        log.debug(
            'Default window size - {}'.format(transport.default_window_size)
        )
        channel = transport.open_session()
        channel.settimeout(3600)
        log.debug('Channel timeout - {}'.format(channel.timeout))
        channel.exec_command(command)
        while True:
            output += self._receive_data(channel, verbose=verbose)
            #print(output)

            if channel.exit_status_ready():
                output += self._receive_data(channel)
                exit_status = channel.recv_exit_status()
                break
            sleep(1)
        transport.close()
        return exit_status, output

    @staticmethod
    def _receive_data(channel, verbose=True):
        output = ''
        if channel.recv_ready():
            log.debug('GET DATA...')
            data = channel.recv(1024).decode()
            while data:
                if verbose:
                    print(data, end='')
                output += data
                data = channel.recv(1024).decode()
        if channel.recv_stderr_ready():
            log.debug('GET ERROR...')
            data = channel.recv_stderr(1024).decode()
            while data:
                if verbose:
                    print(data, end='')
                output += data
                data = channel.recv_stderr(1024).decode()

        return output