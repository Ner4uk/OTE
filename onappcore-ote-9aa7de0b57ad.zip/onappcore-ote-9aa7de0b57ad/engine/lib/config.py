from configparser import ConfigParser
import os


class BaseConfig:
    def __init__(self, config_path):
        self.config_path = config_path
        self._config_parser = ConfigParser()
        self.read()

    def read(self):
        self._config_parser.read(self.config_path)

    def _get_option(self, section, option):
        return self._config_parser.get(section, option) if \
            self._config_parser.has_option(section, option) else None


class CloudsConfig(BaseConfig):
    config_path = os.path.join(os.getcwd(), 'conf/clouds.cfg')

    def __init__(self, section=None):
        super(CloudsConfig, self).__init__(self.config_path)
        self.section = section

    @property
    def host(self):
        return self._get_option(self.section, 'host')

    @property
    def port(self):
        return self._get_option(self.section, 'port')

    @property
    def hv_macs(self):
        return self._get_option(self.section, 'hv_macs').\
            split(',')

    @property
    def storage_network_macs(self):
        return self._get_option(self.section, 'storage_network_macs').\
            split(',')

    @property
    def custom_config(self):
        return self._get_option(self.section, 'custom_config')

    @property
    def hypervisor_group_id(self):
        return self._get_option(self.section, 'hypervisor_group_id')

    @property
    def login(self):
        return self._get_option(self.section, 'login')

    @property
    def password(self):
        return self._get_option(self.section, 'password')

    @property
    def clb_net_ip(self):
        return self._get_option(self.section, 'clb_net_ip')

    @property
    def license_key(self):
        return self._get_option(self.section, 'license_key')

    @property
    def licensing_server(self):
        return self._get_option(self.section, 'licensing_server')

    @property
    def ssh_port(self):
        return self._get_option(self.section, 'ssh_port')

    @property
    def scheme(self):
        return self._get_option(self.section, 'scheme')


class GlobalConfig(BaseConfig):
    config_path = os.path.join(os.getcwd(), 'conf/global.cfg')

    def __init__(self):
        super(GlobalConfig, self).__init__(self.config_path)
        self._glob_section = 'glob'
        self._env_section = 'env'

    @property
    def hv_type(self):
        return self._get_option(self._glob_section, 'HV_TYPE')

    @property
    def hv_distro(self):
        return self._get_option(self._glob_section, 'HV_DISTRO')

    @property
    def ds_type(self):
        return self._get_option(self._glob_section, 'DS_TYPE')

    @property
    def template_manager_id(self):
        return self._get_option(self._glob_section, 'TEMPLATE_MANAGER_ID')

    @property
    def server_type(self):
        return self._get_option(self._glob_section, 'SERVER_TYPE')

    @property
    def cloud(self):
        return self._get_option(self._glob_section, 'CLOUD')

    @property
    def onapp_api_version(self):
        return self._get_option(self._glob_section, 'ONAPP_API_VERSION')

    @property
    def python_release(self):
        return self._get_option(self._env_section, 'python_release')

    @property
    def python_version(self):
        return self._get_option(self._env_section, 'python_version')


class TestConfig(BaseConfig):
    config_path = os.path.join(os.getcwd(), 'conf/test.cfg')

    def __init__(self):
        super(TestConfig, self).__init__(self.config_path)
        self._server_section = 'server'
        self._jenkins_section = 'jenkins'
        self._jira_section = 'jira'
        self._debug_section = 'debug'

    @property
    def server_template(self):
        return self._get_option(self._server_section, 'template')

    @property
    def jenkins_host(self):
        return self._get_option(self._jenkins_section, 'host')

    @property
    def jenkins_port(self):
        return self._get_option(self._jenkins_section, 'port')

    @property
    def log_level(self):
        return self._get_option(self._debug_section, 'log_level')

    @property
    def jira_server(self):
        return self._get_option(self._jira_section, 'server')

    @property
    def jira_user(self):
        return self._get_option(self._jira_section, 'user')

    @property
    def jira_password(self):
        return self._get_option(self._jira_section, 'password')


class _ClusterConfig(BaseConfig):
    """
    Base class for HAConfig
    """
    config_path = os.path.join(os.getcwd(), 'conf/ha.cfg')

    def __init__(self, section):
        super(_ClusterConfig, self).__init__(self.config_path)
        self._section = section

    @property
    def name(self):
        return self._get_option(self._section, 'name')

    @property
    def status(self):
        return self._get_option(self._section, 'status')

    @property
    def ip(self):
        return self._get_option(self._section, 'ip')

    @property
    def prefix(self):
        return self._get_option(self._section, 'prefix')

    @property
    def port(self):
        return self._get_option(self._section, 'port')

    @property
    def nodes_ips(self):
        return self._get_option(self._section, 'nodes_ips')

    @property
    def nodes_interfaces(self):
        return self._get_option(self._section, 'nodes_interfaces')

    @property
    def nodes_priority(self):
        return self._get_option(self._section, 'nodes_priority')


class HAConfig(BaseConfig):
    config_path = os.path.join(os.getcwd(), 'conf/ha.cfg')

    def __init__(self):
        super(HAConfig, self).__init__(self.config_path)
        self._credentials = 'credentials'
        self._hosts = 'hosts'
        self._communications = 'communications'

        # Clusters config objects
        self.ui = _ClusterConfig('UI')
        self.cloud_boot = _ClusterConfig('CLOUD_BOOT')
        self.load_balancer = _ClusterConfig('LOAD_BALANCER')
        self.database = _ClusterConfig('DATABASE')
        self.redis = _ClusterConfig('REDIS')
        self.message_queue = _ClusterConfig('MESSAGE_QUEUE')
        self.daemon = _ClusterConfig('DAEMON')

    @property
    def ssh_user(self):
        return self._get_option(self._credentials, 'ssh_user')

    @property
    def ssh_password(self):
        return self._get_option(self._credentials, 'ssh_password')

    @property
    def ssh_key_path(self):
        return self._get_option(self._credentials, 'ssh_key_path')

    @property
    def license_key(self):
        return self._get_option(self._credentials, 'license_key')

    @property
    def license_server(self):
        return self._get_option(self._credentials, 'license_server')

    @property
    def api_token(self):
        return self._get_option(self._credentials, 'api_token')

    @property
    def cp_version(self):
        return self._get_option(self._credentials, 'cp_version')

    @property
    def hostnames(self):
        return self._get_option(self._hosts, 'hostnames')

    @property
    def ip_addresses(self):
        return self._get_option(self._hosts, 'ip_addresses')

    @property
    def network(self):
        return self._get_option(self._communications, 'network')

    @property
    def multicast_ip_address(self):
        return self._get_option(self._communications, 'multicast_ip_address')

    @property
    def multicast_port(self):
        return self._get_option(self._communications, 'multicast_port')

    @property
    def members(self):
        return self._get_option(self._communications, 'members')

    @property
    def ttl(self):
        return self._get_option(self._communications, 'ttl')

    @property
    def network_method(self):
        return self._get_option(self._communications, 'network_method')


class OteConfig(BaseConfig):
    config_path = os.path.join(os.getcwd(), 'conf/ote.cfg')

    def __init__(self, section=None):
        super(OteConfig, self).__init__(self.config_path)
        self.section = section

    @property
    def python_version(self):
        return self._get_option(self.section, 'python_version')
