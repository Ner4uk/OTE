#!/usr/bin/env python
import socket
from time import sleep

import paramiko

from engine.lib.logger import Logger

log = Logger().logger
NBYTES = 1024


class SshClient:
    def __init__(self, host='', user='root', password='', port=22):
        self.client = paramiko.SSHClient()
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.host = host
        self.user = user
        self.password = password
        self.port = port

    def __enter__(self):
        if self._connect(self.user, self.password, self.port):
            return self
        else:
            raise ConnectionError

    def __exit__(self, *args):
        self._disconnect()

    # Is using for simple usage only.
    def _port_is_open(self, host=None, port=22, timeout=10):
        if not host and self.host:
            host = self.host
        log.info('Check if port {} is open on {} host'.format(port, host))
        connection = False
        try:
            socket.setdefaulttimeout(timeout)
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.connect((host, port))
            connection = True
        except socket.error as e:
            log.error(e)
        finally:
            sock.close()

        return connection

    def _connect(self, user, password, port):
        if self._port_is_open(host=self.host, port=port):
            # Try to connect
            try:
                self.client.connect(
                    hostname=self.host,
                    username=user,
                    password=password,
                    port=port,
                    timeout=300.0
                )
                return True
            except paramiko.AuthenticationException as AE:
                log.error(
                    """{}\n The possible issues:
                    - password is required;
                    - your public key is absent on CP;
                    - host is empty;
                    - your ssh-agent may missing your public key
                      try the following 'ssh-add ~/.ssh/id_rsa'""".format(AE)
                )

                return False
        return False

    def _disconnect(self):
        self.transport.close()
        self.client.close()

    def execute(self, command, verbose):
        exit_status = None
        output = ''
        self.client.set_missing_host_key_policy(
            paramiko.AutoAddPolicy()
        )
        self.transport = self.client.get_transport()
        self.channel = self.transport.open_session()
        self.channel.settimeout(3600)
        log.debug('Channel timeout - {}'.format(self.channel.timeout))

        log.debug(
            'Default window size - {}'.format(
                self.transport.default_window_size
            )
        )
        self.channel.exec_command(command)
        while True:
            output += self._receive_data(verbose=verbose)

            if self.channel.exit_status_ready():
                output += self._receive_data()
                exit_status = self.channel.recv_exit_status()
                break
            sleep(1)
        return exit_status, output

    def _receive_data(self, verbose=True):
        output = ''
        if self.channel.recv_ready():
            log.debug('GET DATA...')
            data = self.channel.recv(NBYTES).decode()
            while data:
                if verbose:
                    print(data, end='')
                output += data
                data = self.channel.recv(NBYTES).decode()
        if self.channel.recv_stderr_ready():
            log.debug('GET ERROR...')
            data = self.channel.recv_stderr(NBYTES).decode()
            while data:
                if verbose:
                    print(data, end='')
                output += data
                data = self.channel.recv_stderr(NBYTES).decode()

        return output


class SSH():
    def __init__(self, host='', user='root', password='', port=22):
        self.client = paramiko.SSHClient()
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.host = host
        self.user = user
        self.password = password
        self.port = port

    def execute(
            self,
            command='',
            tunnel_host=None,
            tunnel_port=None,
            timeout=10,
            user=None,
            password=None,
            port=None,
            verbose=True
    ):
        exit_status, output = self.ext_execute(
            command=command,
            tunnel_host=tunnel_host,
            tunnel_port=tunnel_port,
            timeout=timeout,
            user=user,
            password=password,
            port=port,
            verbose=verbose
        )
        return output

    def ext_execute(
            self,
            command='',
            tunnel_host=None,
            tunnel_port=None,
            timeout=10,
            user=None,
            password=None,
            port=None,
            verbose=True
    ):
        """
        Simple usage: executing command on host which was defined during init
        or separately.
        Extended usage: if you need execute some command on remote host
        (tunnel) from current host you have to define tunnel_host additionally.

        Example:
            You init ssh for CP and you want to execute some command on HV
            than you need to execute current command with the following
            parameters like:

            >>> CP.ssh.execute(command='ls -l', tunnel_host='192.168.7.42')
        :param command: command
        :param tunnel_host: compute resource or backup server or virtual
            server host
        :param tunnel_port: compute resource or backup server or virtual
            server port
        :param timeout: ConnectionAttempts option for ssh
        :param user: user name
        :param password: user password
        :param port: target port
        :param verbose:
        :return:
        """
        if not port:
            port = self.port
        exit_status = None
        if command and tunnel_host != '':
            log.info(("*" * 80))
            # Extended usage (Remote executing command on another host via ssh)
            if tunnel_host and not (user and password):
                tunnel_port = 22 if tunnel_port is None else tunnel_port
                command = f'ssh -i /home/onapp/.ssh/id_rsa ' \
                          f'-o StrictHostKeyChecking=no ' \
                          f'-o UserKnownHostsFile=/dev/null ' \
                          f'-o PasswordAuthentication=no ' \
                          f'-o ConnectionAttempts={timeout} ' \
                          f'root@{tunnel_host} -p{tunnel_port} "{command}"'
                log.info(
                    "Executing '{0}' on remote host {1} from {2}...".format(
                        command, tunnel_host, self.host
                    )
                )
            elif tunnel_host and user and password:
                command = f'ssh -o ConnectionAttempts={timeout}' \
                    f' root@{tunnel_host} -p{port} "{command}"'
            # Simple usage
            else:
                log.info(
                    "Executing '{0}' on {1}...".format(command, self.host)
                )

            if not user:
                user = self.user
            if not password:
                password = self.password
            # Execute with context manager.
            with SshClient(
                    host=self.host,
                    user=user,
                    password=password,
                    port=port
            ) as ssh_client:
                exit_status, output = ssh_client.execute(command, verbose)
                bad_responces = [
                    'No route to host',
                    'Connection refused',
                    'Connection timed out',
                    'Permission denied',
                ]
                if [
                    responce for responce in bad_responces
                    if responce in output[:100]
                ]:
                    log.error(output)
                    return exit_status, False

                return exit_status, output
        elif tunnel_host == '':
            log.warning(
                'Incorrect "tunnel_host", current - "", '
                'expected None or "xxx.xxx.xxx.xxx"...'
            )
        else:
            log.info('No command to execute...')
        return exit_status, False
