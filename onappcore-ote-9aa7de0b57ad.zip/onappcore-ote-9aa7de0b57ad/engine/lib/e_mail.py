from email.mime.text import MIMEText
import smtplib


class Email():
    def __init__(self, msg_from='', msg_to='', subject='', message=''):
        self.message = message
        self.msg_from = msg_from
        self.msg_to = msg_to
        self.subject = subject

    def send(self, domain):
        """
        domain - the domain/ip_address of the receiver (
        the some email client should be enable on this server).
        """
        msg = MIMEText(self.message)
        msg["From"] = self.msg_from
        msg["To"] = self.msg_to
        msg["Subject"] = self.subject
        s = smtplib.SMTP(domain)
        return s.send_message(msg)