import json
from os.path import join as os_path_join
from time import sleep, strftime

import requests

from engine.lib.logger import Logger

log = Logger().logger
log_path = Logger().log_path


class Session:
    METHODS = {
        'GET': requests.get,
        'PUT': requests.put,
        'POST': requests.post,
        'PATCH': requests.patch,
        'DELETE': requests.delete
    }

    def __init__(self, host, login, password):
        self.login = login
        self.password = password
        self.authorization = (self.login, self.password)
        self.scheme = 'http'
        self.host = host
        self.port = 80
        #self.requests = requests
        self.response = None
        self.headers = {
            'content-type': 'application/json',
            'accept': 'application/json'
        }
        self.url = ''
        self.error = {}

    #  The method which handling the main session methods
    def method_handler(self, url=None, data=None, method='GET', host=None):
        """
        Logging and printing debugging info
        :param url: an url to send request
        :param data: a dict of parameters
        :param method: method name as string. 'GET' by default.
        :param host: some another hostname
        :return: response requests obj
        """
        method = self.METHODS[method]
        self.url = self.make_url(host=host, url=url)
        log_msg = "{0} - {1}".format(method.__name__.upper(), self.url)
        log.info(log_msg)
        # if 'transactions' not in url:
        #     print('\n', ' '.join([ctime(), log_msg]), sep='')

        if data:
            log_msg = "    DATA - {0}".format(data)
            log.info(log_msg)
            # if 'transactions' not in url:
            #     print(ctime(), log_msg)
        #  getting response
        self.sent_request(method, data)
        #  Add possibility to keep test in running state
        # in case Connection Error. !!! Not tested yet.
        retries = 10
        while self.response is None:
            sleep(5)
            self.sent_request(method, data)
            retries -= 1
            if not retries:
                return False

        # 207 status code - https://onappdev.atlassian.net/browse/CORE-10210
        # 202 is not documented (
        # POST - http://212.118.238.15/application_servers/942/applications/1_30196/backup.json
        # )
        if self.response.status_code in [
            200, 201, 202, 204, 207, 403, 404, 422, 500, 503
        ]:
            log_msg = "    Status - {0}".format(self.response.status_code)
            log.info(log_msg)
        else:
            self._collect_wrong_status_code(self.response)
            log_msg = "--!--Wrong Status - {0}".format(self.response.status_code)
            log.warning(log_msg)
        # if 'transactions' not in url:
        #     print(ctime(), log_msg)
        if self.response.content:
            log_msg = "        Content - {0}".format(self.response.content)
            log.debug(log_msg)
            # if 'transactions' not in url \
            #         and self.log_level == 'debug'\
            #         or self.response.status_code > 204:
            #     print(ctime(), log_msg)
        return True

    def make_url(self, host=None, url=None):
        """

        :param host:
        :param url: can be full URL (http://69.168.237.205/settings/hypervisors)
            and not full (/settings/hypervisors.json)
        :return:
        """
        if not host:
            host = self.host

        if host not in url:
            if self.port == 80:
                self.url = '{0}://{1}{2}'.format(self.scheme, host, url)
            else:
                self.url = '{0}://{1}:{2}{3}'.format(
                    self.scheme, host, self.port, url
                )
            return self.url
        return url

    def sent_request(self, method, data):
        if data is None:
            data = {}
        try:
            self.response = method(
                self.url,
                auth=(self.login, self.password),
                data=json.dumps(data),
                headers=self.headers,
                timeout=120,
                verify=False  # ignore verifying the SSL certificate
            )
            return True
        except requests.ConnectionError as e:
            self.response = None
            log.error(e)
            self.error['session'] = e
            # print(e)
        except requests.ReadTimeout as e:
            self.response = None
            log.error(e)
            self.error['session'] = e
            # print(e)
        return False

    @staticmethod
    def _collect_wrong_status_code(response):
        with open(os_path_join(log_path, 'wrong_status_code.log'), 'a') as ec:
            log.error(response.content.decode())
            msg = ' '.join(
                [
                    strftime('[%Y-%m-%d %H:%M:%S]'),
                    response.request.method,
                    str(response.status_code),
                    response.request.url,
                    response.request.body,
                    response.content.decode(),
                    '\n'
                ]
            )
            ec.write(msg)
