from os import system
from time import sleep

import yaml

from engine.lib.logger import Logger
from engine.lib.ssh import SSH

log = Logger().logger


class CP:
    def __init__(
            self,
            host=None,
            ssh_user=None,
            ssh_password=None,
            user=None,
            password=None,
            clb_net_ip=None,
            ssh_port=22
    ):
        """
        Provide methods for working with CP via ssh in general
        :param host: CP ip address
        :param user: user for GUI access
        :param password: password for GUI access
        :param ssh_user: user for ssh access
        :param ssh_password: password for ssh access

        To work with CP via SSH, executing some commands, set user,
        password in ssh obj.
        """
        self.host = host
        self.clb_net_ip = clb_net_ip
        self.user = user
        self.password = password
        self.ssh_port = ssh_port
        self.ssh = SSH(host=self.host, port=self.ssh_port)
        if ssh_user:
            self.ssh.user = ssh_user
        if ssh_password:
            self.ssh.password = ssh_password
        self.db_host = ''
        self.db_name = ''
        self.db_pass = ''
        self.db_user = ''
        self.error = {}

    # Before using requests to MySQL please init DB.
    def db_init(self):
        """
        Init DB. Get host, name, password, user from config file
        :return:
        """
        self.error = {}

        # Get raw yml format
        database_yaml = self.execute('cat /onapp/interface/config/database.yml')
        # Convert to python dict obj
        database_yaml_obj = yaml.load(database_yaml)

        self.database_yaml = [
            database_yaml_obj.get(key) for key in list(
                database_yaml_obj.keys()
            ) if
            isinstance(database_yaml_obj.get(key), dict)
        ][0]

        # split removes possible \n\r in the end of output
        self.db_host = self.database_yaml['host']
        self.db_name = self.database_yaml['database']
        self.db_pass = self.database_yaml['password']
        # Temporary fix for pass as string in config
        if self.db_pass[0] == self.db_pass[-1] and self.db_pass[0] in ["'", '"']:
            self.db_pass = self.db_pass[1:-1]

        self.db_user = self.database_yaml['username']

    def ext_execute(self,
                    command=None,
                    tunnel_host=None,
                    tunnel_port=None,
                    timeout=10,
                    verbose=True):
        """
        Execute command on CP
        :param command: command to execute
        :param tunnel_host: host where we can execute current command from CP
        :return: exit_status, data
        """
        self.error = {}
        if command:
            try:
                return self.ssh.ext_execute(
                    command=command,
                    tunnel_host=tunnel_host,
                    tunnel_port=tunnel_port,
                    timeout=timeout,
                    verbose=verbose,
                    port=self.ssh_port
                )
            except TimeoutError as e:
                self.error['ssh_execute_failed'] = e
            except ConnectionError as e:
                self.error['ssh_execute_failed'] = e
        else:
            log.error('"command" should not be empty!')
        return None, ''

    def execute(self,
                command=None,
                tunnel_host=None,
                tunnel_port=None,
                timeout=10,
                verbose=True):
        status_code, data = self.ext_execute(
            command=command,
            tunnel_host=tunnel_host,
            tunnel_port=tunnel_port,
            timeout=timeout,
            verbose=verbose
        )
        return data

    def rails_execute(self, cmd):
        """
        Execute rails command
        :param cmd: rails command
        :return: code status and result tuple
        """
        rails = self.execute('which rails').split('\n')[0]
        if rails:
            return self.ext_execute(
                f"cd /onapp/interface;"
                f"su onapp -c \"RAILS_ENV=production {rails} runner '{cmd}'\""
            )
        raise SystemError("rails not found")

    ###########################################################################
    # Here described commonly used commands
    def centos_release(self):
        return self.execute(command='cat /etc/issue')

    def free_space(self):
        result = self.execute(command='df -ah')
        if result:
            return True
        return False

    # Getting Native Parameters
    def native_disk_size(self, mount_point, host):
        """Return disk size in GB"""
        disks_info = self.execute(
            command="df -k", tunnel_host=host
        ).split('\n')
        for s in disks_info:
            if s and s.split()[-1] == mount_point:
                return float(s.split()[1]) / 1048576
        return 0

    def mysql_execute(self, query=None):
        """
        Return an array of query results.
        Please use queries which select only one parameter.
        Sorry for this limit :)

        Example:
            In [26]: test.cp.mysql_execute('SELECT initial_root_password FROM virtual_machines WHERE id = 9790')

            ********************************************************************************
            Executing 'mysql --password='EvFjTixeNv' -h'localhost' onapp -e"SELECT initial_root_password FROM virtual_machines WHERE id = 9790" && echo done || echo error' on 109.123.91.18...
            initial_root_password
            5KZ6CDSIDiNr
            done

            Out[26]: ['5KZ6CDSIDiNr']
        """
        self.error = {}
        if not self.db_user:
            self.db_init()
        command = " ".join(
            [
                "mysql",               # program
                "--password='{0}'",    # password
                "-h'{1}'",             # host
                "{2}",                 # db name
                "-e\"{3}\"",           # execute
                "&& echo done || echo error"
            ]
        ).format(
            self.db_pass, self.db_host, self.db_name, query
        )
        result = self.execute(command=command)
        if 'done' in result:
            # remove first element and last 'done' from output
            return result.split('done')[0].split('\n')[1:-1]
        log.error("MySQL execution failed...")
        return False

    def mysql_dump(self, name):
        """
        Create DB dump in to /tmp dir
        :param name: dump name
        :return:
        """
        if not self.db_user:
            self.db_init()
        if name:
            command = "mysqldump -u {} -p'{}' {} | gzip > /tmp/{}".format(
                self.db_user, self.db_pass, self.db_name, name
            )
            self.execute(command=command)
        else:
            raise ValueError("mysql dump name should be defined")

    def install(self, version=None, ha=False, use_cdn=True, testing=False, staging=False, development=False):
        """
        Install Control Panel (onapp)
        :param development: use Onapp-development repo if True
        :param staging: use Onapp-staging repo if True
        :param testing: use Onapp-testing repo if True
        :param use_cdn: avoid using cdn servers for repos if False
        :param version: onapp version X.Y
        :param ha: ha installation if True

        :return:
        """
        if version:
            onapp_repo = self.execute('cat /etc/yum.repos.d/OnApp.repo')
            snmp_trap_ips = [self.host, ]
            if self.clb_net_ip:
                snmp_trap_ips.append(self.clb_net_ip)
            if 'onapp-{}'.format(version) not in onapp_repo:
                self.execute('rpm -Uvh http://rpm.repo.onapp.com/repo/onapp-repo-{}.noarch.rpm'.format(version))
            if testing:
                self.execute('wget http://rpm.repo.onapp.com/repo/OnApp-testing.repo -O '
                             '/etc/yum.repos.d/OnApp-testing.repo')
            if staging:
                self.execute('wget http://rpm.repo.onapp.com/repo/OnApp-staging.repo -O '
                             '/etc/yum.repos.d/OnApp-staging.repo')
            if development:
                self.execute('wget http://rpm.repo.onapp.com/repo/OnApp-development.repo -O '
                             '/etc/yum.repos.d/OnApp-development.repo')
            if not use_cdn:
                self.execute("sed -i 's/cdn.//g' /etc/yum.repos.d/OnApp*.repo")
            self.execute('yum install onapp-cp-install -y')
            if ha:
                self.execute(
                    '/onapp/onapp-cp-install/onapp-cp-install.sh --ha-install --percona-cluster -a --accept-eula')  #
                #  can't be finished
            else:
                install_cmd = f"/onapp/onapp-cp-install/onapp-cp-install.sh -i {','.join(snmp_trap_ips)} -a"
                if version >= 5.5:
                    install_cmd += ' --accept-eula'
                    if self.user == 'admin':
                        install_cmd += f" -P {self.password}"
                self.execute(install_cmd)
            self.execute('service onapp restart')
        else:
            log.error('version is invalid')
            exit()

    def upgrade(self, version=None, use_cdn=True, testing=False, staging=False, development=False):
        """
        Update/upgrade Control Panel (onapp)
        :param development: use Onapp-development repo if True
        :param staging: use Onapp-staging repo if True
        :param testing: use Onapp-testing repo if True
        :param use_cdn: avoid using cdn servers for repos if False
        :param version: onapp version X.Y
        :return: Boolean (True if all steps returned exit code 0)
        """
        if version:
            yum_clean_status, yum_clean_message = self.ext_execute('yum clean all')
            assert not yum_clean_status, yum_clean_message
            onapp_repo = self.execute('cat /etc/yum.repos.d/OnApp.repo')
            snmp_trap_ips = [self.host, ]
            if self.clb_net_ip:
                snmp_trap_ips.append(self.clb_net_ip)
            if 'onapp-{}'.format(version) not in onapp_repo:
                self.execute('rpm -Uvh http://rpm.repo.onapp.com/repo/onapp-repo-{}.noarch.rpm'.format(version))
            if testing:
                self.execute('wget http://rpm.repo.onapp.com/repo/OnApp-testing.repo -O '
                             '/etc/yum.repos.d/OnApp-testing.repo')
            if staging:
                self.execute('wget http://rpm.repo.onapp.com/repo/OnApp-staging.repo -O '
                             '/etc/yum.repos.d/OnApp-staging.repo')
            if development:
                self.execute('wget http://rpm.repo.onapp.com/repo/OnApp-development.repo -O '
                             '/etc/yum.repos.d/OnApp-development.repo')
            if not use_cdn:
                self.execute("sed -i 's/cdn.//g' /etc/yum.repos.d/OnApp*.repo")
            installer_updated_status, installer_updated_message = self.ext_execute('yum update onapp-cp-install -y')
            assert not installer_updated_status, installer_updated_message
            cp_updated_status, cp_updated_message = self.ext_execute(
                'yes|/onapp/onapp-cp-install/onapp-cp-install.sh -y')
            assert not cp_updated_status, cp_updated_message
            cp_updated_status, cp_updated_message = self.ext_execute('/onapp/onapp-cp-install/onapp-cp-install.sh -a')
            assert not cp_updated_status, cp_updated_message
        else:
            log.error('version is invalid')
            return False
        return True

    def store_install(self):
        store_installed_status, store_installed_message = self.ext_execute('yum -y install onapp-store-install')
        if store_installed_status:
            log.error(f"Updating storage installer on CP failed - {store_installed_message}")
            return False
        store_installed_status, store_installed_message = self.ext_execute(
            'echo |/onapp/onapp-store-install/onapp-store-install.sh')
        if store_installed_status:
            log.error(f"Updating storage on CP failed - {store_installed_message}")
            return False
        def_installed_status, def_installed_message = self.ext_execute('yum -y install onapp-ramdisk-centos7-default')
        if def_installed_status:
            log.error(f"Installing default image on CP failed - {def_installed_message}")
            return False
        return True

    def store_upgrade(self, images_to_update=''):
        images_to_update += ' onapp-ramdisk-tools'
        images_updated_status, images_updated_message = self.ext_execute('yum -y update ' + images_to_update)
        if images_updated_status:
            log.error(f"Updating HV images on CP failed - {images_updated_message}")
            return False

        store_updated_status, store_updated_message = self.ext_execute('yum -y update onapp-store-install')
        if store_updated_status:
            log.error(f"Updating storage installer on CP failed - {store_updated_message}")
            return False
        store_updated_status, store_updated_message = self.ext_execute(
            'echo |/onapp/onapp-store-install/onapp-store-install.sh')
        if store_updated_status:
            log.error(f"Updating storage on CP failed - {store_updated_message}")
            return False
        return True

    def openstack_install(self):
        self.execute('yum -y install onapp-openstack-install')
        installer = "/onapp/onapp-openstack-install/onapp-openstack-install.sh"
        self.execute(
            f"{installer} --ip-public {self.host} --ip-mgt {self.clb_net_ip}"
        )

    def ping(self, address=None, timeout=60):
        """
        ping the server
        :param address: if no address ping itself
        :param timeout:
        :return: True if success else false
        """
        if address:
            cmd = f"ping -ot {timeout} {address}"
            log.info(cmd)
            result = self.execute(command=cmd, timeout=timeout)
            if '100% packet loss' not in result:
                return True
        else:
            # ??? ping CP
            log.info("*" * 80)
            log.info("PING...")
            return system(f"ping -ot {timeout} {self.host}") == 0
        return False

    def generate_10MB_test_file(self):
        """
        Generate 10MB file on CP in to /tmp directory
        :return:
        """
        if 'zaza_test_10MB' not in self.execute('ls -l /tmp/'):
            self.execute(
                'dd if=/dev/urandom of=/tmp/zaza_test_10MB bs=1M count=10'
            )

    def restart_httpd(self):
        """
        Restart httpd service
        :param self:
        :return: a tuple of exit status code with output.
        """
        return self.ext_execute('service httpd restart')

    def get_version(self):
        import re
        result = self.execute('cat /onapp/interface/.version')
        version = re.findall('[\d.]+-\d+', result)
        if version:
            return version[0]
        log.error(result)
        return ''

    def platform_version_is_centos6(self):
        """
        Checks the CentOS release version on which the CP is installed
        :return: True if CentOS version is 6 else False
        """
        result = self.execute('cat /etc/centos-release')
        if 'release 6' in result:
            return True
