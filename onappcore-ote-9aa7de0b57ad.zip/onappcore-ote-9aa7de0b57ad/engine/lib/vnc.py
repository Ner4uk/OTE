#!/usr/bin/env python
import os
from time import sleep

import pyocr
import pyocr.builders
from PIL import Image
from vncdotool import api

from engine.lib.logger import Logger
from engine.lib.ssh import SSH
from onapp_helper import test

OCR_CMD = 'tesseract'  # the system command of OCR tool installed - just to check if we can use pyocr at all
# see requirements https://github.com/openpaperwork/pyocr and use this https://github.com/tesseract-ocr/tesseract/wiki
TEST_STRING = '777'  # because for some reason it likes these digits :) and recognition is more reliable this way

log = Logger().logger


class VncConsole:
    ip_address = None
    port = None
    password = None
    tool = None
    lang = None
    tmp_folder = None
    initialized = False

    def __init__(self, vs_instance, temp_dir_for_screenshots=''):
        """
          VS console - to initialize it requires the Console button to be pressed
        at least once (to get local_remote_access_ip_address,
        local_remote_access_port, local_remote_access_password filled in.
          Also we initialize here the ocr tool - to use it for checking that
        entered symbols appear on screen"""
        if not self.initialized:
            log.info("Initializing console...")
            assert not os.system(OCR_CMD), "There's no required OCR tool installed in this system - u'd better " \
                                           "exclude VNC check from tests until the one installed "
            self.tmp_folder = temp_dir_for_screenshots
            tools = pyocr.get_available_tools()
            assert len(tools) > 0, "No OCR tool found!"
            # The tools are returned in the recommended order of usage
            self.tool = tools[0]
            log.info("Will use tool '%s'" % (self.tool.get_name()))
            langs = self.tool.get_available_languages()
            log.info("Available languages: %s" % ", ".join(langs))
            self.lang = langs[0]
            log.info("Will use lang '%s'" % self.lang)
            # Ex: Will use lang 'eng'
            # Note that languages are NOT sorted in any way. Please refer
            # to the system locale settings for the default language
            # to use.
            vnc_url = "/{0}/{1}/console_popup".format(
                vs_instance.route, vs_instance.id
            )
            test.get_object(vs_instance, vnc_url)
            log.info("Waiting 10 sec for server to get remote params updated")
            sleep(10)
            self.initialized = True
        vs_instance.get()
        self.ip_address = vs_instance.local_remote_access_ip_address
        self.port = vs_instance.local_remote_access_port
        self.password = vs_instance.remote_access_password
        assert self.ip_address, "local_remote_ip_address is empty"
        assert self.port, "local_remote_port is empty"
        assert self.password, "local_remote_password is empty"

    def is_alive(self, string_to_send=TEST_STRING):
        """
        Checks that vnc console is available and receives keystrokes
        :param string_to_send: symbols to send
        :return: Boolean(signifies the presence of the sent template in a text
                 on a taken screenshot)
        """
        if not self.send(string_to_send * 2):
            return False
        return self.string_is_on_screen(string_to_send)

    def is_accessible(self):
        """
        Checks that vnc console is available
        :return: Boolean(True if connection succeeded an)
        """
        if self.send('1'):
            return True
        return False

    def string_is_on_screen(self, data):
        """
        Checks that text data is present on the console screen
        :param data: text to search on screen
        :return: Boolean
        """
        vnc_screen = self.tmp_folder.join('vnc_screen.png').strpath
        self.client = api.connect(
            self.ip_address + '::' + str(self.port),
            password=self.password
        )
        try:
            self.client.captureScreen(vnc_screen)
        except api.VNCDoException as e:
            log.error(f"No console - {e}")
            return False
        self.client.disconnect()
        vnc_screen_text = self.tool.image_to_string(
            Image.open(vnc_screen),
            lang=self.lang,
            builder=pyocr.builders.TextBuilder()
        )
        return data in vnc_screen_text

    def send(self, string_to_send):
        """
        Method sends passed string to a console
        """
        if not SSH()._port_is_open(
                host=self.ip_address, port=self.port, timeout=3
        ):
            log.error("VNC console port is not reachable!")
            return False
        try:
            self.client = api.connect(
                self.ip_address + '::' + str(self.port),
                password=self.password
            )
        except TypeError:
            log.error(
                "Either local_remote_access_ip_address or local_remote_access_port is empty(or maybe both)."
            )
            return False
        for char in string_to_send:
            try:
                self.client.keyPress(char)
                sleep(1)
            except api.VNCDoException as e:
                log.error(f"No console - {e}")
                return False
        self.client.disconnect()
        return True
