import sys
from re import findall
from os import path, getcwd, makedirs
import logging
import logging.handlers
try:
    import colorlog
    COLOR_LOG = True
except ImportError as e:
    print(e, 'Please execute:\npip install -r requirements.txt')
    COLOR_LOG = False
###############################################################################
# Logger #
###############################################################################


class Logger:
    instance = None
    initialized = False

    DEFAULT_LOG_FILE = "./log/ote.log"

    def __new__(cls, *args, **kwargs): #, name=DEFAULT_LOG_FILE, log_level='debug'
        if cls.instance is None:
            cls.instance = super(Logger, cls).__new__(cls)
        return cls.instance

    def __init__(self, log_level='debug'):
        if not self.initialized:
            if not COLOR_LOG:
                self.logger = logging.getLogger(__name__)
                formatter = logging.Formatter(
                    u'[%(asctime)s] %(levelname)-8s %(message)s'
                )
            else:
                self.logger = colorlog.getLogger(__name__)
                formatter = colorlog.ColoredFormatter(
                    '%(log_color)s[%(asctime)s] %(levelname)-8s %(message)s'
                )

            # To show logs in your terminal please uncomment the following
            # strings:
            handler = colorlog.StreamHandler()
            handler.setFormatter(
                colorlog.ColoredFormatter(
                    '%(log_color)s[%(asctime)s] %(levelname)-8s %(message)s'
                )
            )
            self.logger.addHandler(handler)

            # Set up log level
            # Log levels:
            # CRITICAL = 50
            # FATAL = CRITICAL
            # ERROR = 40
            # WARNING = 30
            # WARN = WARNING
            # INFO = 20
            # DEBUG = 10
            # NOTSET = 0
            level = logging.DEBUG
            if log_level == 'info':
                level = logging.INFO
            elif log_level == 'debug':
                level = logging.DEBUG
            elif log_level == 'warning':
                level = logging.WARNING
            elif log_level == 'error':
                level = logging.ERROR
            elif log_level == 'critical':
                level = logging.CRITICAL
            else:
                print("Unsupported log level...")

            self.logger.setLevel(level)

            # Create Log directory
            self.log_path = path.join(getcwd(), 'log')
            if not path.exists(self.log_path):
                makedirs(self.log_path, 0o777)

            #  Get executable file name for doc and log file name
            self.executable_file_name = 'ote'
            for arg in sys.argv:
                exe_file = findall("[.\/0-9a-zA-Z_]*\.py", arg)
                if exe_file:
                    self.executable_file_name = \
                    path.basename(exe_file[0]).split('.')[0]
                    break

            log_name = path.join(
                self.log_path, self.executable_file_name + '.log'
            )

            log_rotation_handler = logging.handlers.TimedRotatingFileHandler(
                filename=log_name,
                when='W0',
                interval=1,
                backupCount=4,
                encoding=None,
                delay=False,
                utc=False
            )

            log_rotation_handler.setLevel(level)

            log_rotation_handler.setFormatter(formatter)
            self.logger.addHandler(log_rotation_handler)

            self.initialized = True
###############################################################################
