__doc__ = 'https://jira.readthedocs.io/en/master/index.html'
from jira import JIRA, JIRAError
from engine.lib.logger import Logger

log = Logger().logger


class Jira:
    __doc__ = """Usage example in your test:
    # Connect to jira
    test.jira.connect()
    # Check if issue is closed
    if test.jira.issue_is_closed('CORE-12306'):
        # do something
    """

    def __init__(self, server, user, password):
        self.server = server
        self.user = user
        self.password = password

    def connect(self):
        try:
            self.jira = JIRA(
                server=self.server,
                basic_auth=(self.user, self.password)
            )
            return True
        except JIRAError:
            log.error(
                'Can not connect to JIRA, please check settings in your test.cfg file'
            )

        return False

    def _issue(self, issue_id, fields=None):
        return self.jira.issue(issue_id, fields=fields)

    def issue_is_closed(self, issue_id):
        issue_status = self._issue(issue_id, fields='status').fields.status.name
        return True if issue_status == 'Closed' else False
