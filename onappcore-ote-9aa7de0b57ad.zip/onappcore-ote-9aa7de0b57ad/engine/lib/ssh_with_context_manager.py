#!/usr/bin/env python
import socket
from time import sleep

import paramiko

from engine.lib.logger import Logger

log = Logger().logger


class SshClient:
    def __init__(self, host='', user='root', password='', port=22):
        self.client = paramiko.SSHClient()
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.host = host
        self.user = user
        self.password = password
        self.port = port

    def __enter__(self):
        if self._connect(self.user, self.password, self.port):
            return self
        else:
            raise ConnectionError

    def __exit__(self, *args):
        self._disconnect()

    # Is using for simple usage only.
    def _port_is_open(self, host=None, port=22, attempts=60):
        if not host and self.host:
            host = self.host
        log.info('Check if port {} is open on {} host'.format(port, host))
        # while attempts:
        #     sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        #     result = sock.connect_ex((host, port))
        #     log.debug('Result - {}, expected - 0'.format(result))
        #     if result == 0:
        #         return True
        #     attempts -= 1
        #     sleep(1)
        # if attempts:
        #     return True
        # log.error("Port {} on host {} is closed.".format(port, host))
        # return False

        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.connect_ex((host, port))
            return True
        except OSError as e:
            log.error(e)
            return False

    def _connect(self, user, password, port):
        if self._port_is_open(host=self.host, port=port):
            # Try to connect
            try:
                self.client.connect(
                    hostname=self.host,
                    username=user,
                    password=password,
                    port=port,
                    timeout=300.0
                )
                return True
            except paramiko.AuthenticationException as AE:
                log.error(
                    """{}\n The possible issues:
                    - password is required;
                    - your public key is absent on CP;
                    - host is empty.""".format(AE)
                )

                return False
        return False

    def _disconnect(self):
        self.transport.close()
        self.client.close()

    def execute(self, command, verbose):
        exit_status = None
        output = ''
        self.client.set_missing_host_key_policy(
            paramiko.AutoAddPolicy()
        )
        self.transport = self.client.get_transport()
        self.channel = self.transport.open_session()
        self.channel.settimeout(3600)
        log.debug('Channel timeout - {}'.format(self.channel.timeout))

        log.debug(
            'Default window size - {}'.format(self.transport.default_window_size)
        )
        self.channel.exec_command(command)
        while True:
            output += self._receive_data(verbose=verbose)
            #print(output)

            if self.channel.exit_status_ready():
                output += self._receive_data()
                exit_status = self.channel.recv_exit_status()
                break
            sleep(1)
        return exit_status, output

    def _receive_data(self, verbose=True):
        output = ''
        if self.channel.recv_ready():
            log.debug('GET DATA...')
            data = self.channel.recv(1024).decode()
            while data:
                if verbose:
                    print(data, end='')
                output += data
                data = self.channel.recv(1024).decode()
        if self.channel.recv_stderr_ready():
            log.debug('GET ERROR...')
            data = self.channel.recv_stderr(1024).decode()
            while data:
                if verbose:
                    print(data, end='')
                output += data
                data = self.channel.recv_stderr(1024).decode()

        return output


class SSH():
    def __init__(self, host='', user='root', password='', port=22):
        self.client = paramiko.SSHClient()
        self.client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        self.host = host
        self.user = user
        self.password = password
        self.port = port

    def execute(
            self,
            command='',
            tunnel_host=None,
            timeout=10,
            user=None,
            password=None,
            port=None,
            verbose=True
    ):
        exit_status, output = self.ext_execute(
            command=command,
            tunnel_host=tunnel_host,
            timeout=timeout,
            user=user,
            password=password,
            port=port,
            verbose=verbose
        )
        return output

    def ext_execute(
            self,
            command='',
            tunnel_host=None,
            timeout=10,
            user=None,
            password=None,
            port=None,
            verbose=True
    ):
        """
        Simple usage: executing command on host which was defined during init
        or separately.
        Extended usage: if you need execute some command on remote host
        (tunnel) from current host you have to define tunnel_host additionally.

        Example:
            You init ssh for CP and you want to execute some command on HV
            than you need to execute current command with the following
            parameters like:

            >>> CP.ssh.execute(command='ls -l', tunnel_host='192.168.7.42')
        """
        if not user:
            user = self.user
        if not password:
            password = self.password
        if not port:
            port = self.port

        exit_status = None
        if command and tunnel_host != '':
            log.info(("*" * 80))
            # Extended usage (Remote executing command on another host via ssh)
            if tunnel_host:
                command = 'ssh -i /home/onapp/.ssh/id_rsa ' \
                          '-o StrictHostKeyChecking=no ' \
                          '-o UserKnownHostsFile=/dev/null ' \
                          '-o PasswordAuthentication=no root@{0} "{1}"'.format(
                    tunnel_host, command
                )
                log.info(
                    "Executing '{0}' on remote host {1} from {2}...".format(
                        command, tunnel_host, self.host
                    )
                )
            # Simple usage
            else:
                log.info(
                    "Executing '{0}' on {1}...".format(command, self.host)
                )

            # Execute with context manager.
            with SshClient(
                    host=self.host,
                    user=user,
                    password=password,
                    port=port
            ) as ssh_client:
                exit_status, output = ssh_client.execute(command, verbose)
                while 'No route to host' in output[:100] \
                        or 'Connection refused' in output[:100] \
                        or 'Connection timed out' in output[:100]:
                    if not timeout:
                        raise TimeoutError('Connection timed out.')
                    log.info('{0} attempts left...'.format(timeout))
                    sleep(5)
                    exit_status, output = ssh_client.execute(command, verbose)
                    timeout -= 1
                #print(output)
                if 'Permission denied' in output and timeout:
                    raise ConnectionError('Permission denied.')
                return exit_status, output
        elif tunnel_host == '':
            log.warning(
                'Incorrect "tunnel_host", current - "", expected None or "xxx.xxx.xxx.xxx"...'
            )
        else:
            log.info('No command to execute...')
        return exit_status, False
