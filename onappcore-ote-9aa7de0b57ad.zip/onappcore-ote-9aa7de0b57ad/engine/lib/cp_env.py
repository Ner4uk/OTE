#!/usr/bin/env python
"""
Fetching environment settings and available resources
1. Getting hypervisors
2. Getting hypervisors from ds joins if DS parameters has been set
3. If at least one hypervisor exists:
 3.1 Getting data store joins from HV and HVZ (if they missing on HV)
 3.2 From data store join we are getting DS/DSZ
 3.3 Getting network joins from HV/HVZ.
 3.4 Getting Network and Network Zone
4. Getting main CP settings - (by /configuration route) and from on_app.yml
5. If cloudboots are to be used - getting assets and cloudboot ip addresses
"""

import ipaddress
from random import randint

from onapp_helper import test
from onapp_helper.backup_server import BackupServer
from onapp_helper.bsz import BSZ
from onapp_helper.cloud_boot_ip_address import CloudBootIpAddress
from onapp_helper.data_store import DataStore
from onapp_helper.data_store_zone import DataStoreZone
from onapp_helper.hypervisor import Hypervisor
from onapp_helper.hypervisor_zone import HypervisorZone
from onapp_helper.instance_package import InstancePackage
from onapp_helper.ip_address import IpAddress
from onapp_helper.ip_network import IpNetwork
from onapp_helper.ip_range import IpRange
from onapp_helper.network_zone import NetworkZone
from onapp_helper.networks import *
from onapp_helper.settings import Settings


class TestConfig:
    def __init__(self):
        self.migrate_server = False
        self.migrate_disk = False
        self.use_public_network = False
        self.use_two_network_joins = False
        self.use_cloud_boot_hv = False


class Env:
    def __init__(self):
        self.ds = None
        self.hv = None
        self.hvz = None
        self.dsz = None
        self.net = None
        self.netz = None
        self.network_joins = []
        self.backup_servers = []
        self.ip_address = None
        self.assets = []
        self.clb_ips = []
        self.ip_net = None  # Since 5.10 for multi networks
        self.ip_range = None  # Since 5.10 for multi networks


class CPEnv:
    def __init__(self):
        self.cp_env = Env()
        self.ds = DataStore()
        self.dsz = DataStoreZone()
        self.hv = Hypervisor()
        self.hvz = HypervisorZone()
        self.network = Network()
        self.ip_net = IpNetwork()  # Since 5.10 for multi networks
        self.ip_range = IpRange()  # Since 5.10 for multi networks
        self.netz = NetworkZone()
        self.ip_address = IpAddress()  # not supported since 5.4
        self.instance_packages = InstancePackage()
        self.error = {}
        self.test_config = TestConfig()

    def load_env(
            self,
            hv_parameters,
            ds_parameters,
            **kwargs
    ):
        """
        Load CP environment based on hv/ds parameters.
        :param hv_parameters:
        :param ds_parameters:
        :return: Env object
        """
        self.test_config.__init__()
        self.test_config.__dict__.update(kwargs)

        test.log.info(
            "Getting working environment... Please wait a while..."
        )
        #  Current method produce a huge unused output, as workaround redirect
        # this to /dev/null (hide)
        # Log levels:
        # CRITICAL = 50
        # FATAL = CRITICAL
        # ERROR = 40
        # WARNING = 30
        # WARN = WARNING
        # INFO = 20
        # DEBUG = 10
        # NOTSET = 0
        if not test.log.level == 10:
            test.hide_output()

        #only load instance packages if no other server type is involved apart of openstack
        if test.hv_types == ["openstack"]:
            self.cp_env.instance_packages = self.instance_packages.get_openstack_only()

        if self._compute_hv(hv_parameters, ds_parameters):
            self._compute_data_store(ds_parameters)
            #  Handling networks to get Network Zone
            if test.cp_version <= 5.3:
                self._compute_network()
            else:
                self._compute_network_since_54()

            backup_servers = []
            if test.cp_version > 5.0:
                # Get BS joins
                bs_joins = self.hv.backup_server_joins() + self.hvz.backup_server_joins()
                bs_join_ids = set(
                    [bs_join.backup_server_id for bs_join in bs_joins]
                )
                for bs in [BackupServer(id=bs_join_id) for bs_join_id in bs_join_ids]:
                    if bs.enabled:
                        bsz = BSZ(id=bs.backup_server_group_id)
                        if bsz.location_group_id == self.hvz.location_group_id:
                            backup_servers.append(bs)

            # Get network_joins
            network_joins = []
            for obj in [self.hv, self.hvz]:
                network_joins += obj.network_joins()

            self.cp_env.ds = self.ds
            self.cp_env.hv = self.hv
            self.cp_env.hvz = self.hvz
            self.cp_env.dsz = self.dsz
            self.cp_env.net = self.network
            self.cp_env.netz = self.netz
            self.cp_env.network_joins = network_joins
            self.cp_env.backup_servers = backup_servers
            self.cp_env.ip_address = self.ip_address
            self.cp_env.ip_net = self.ip_net
            self.cp_env.ip_range = self.ip_range

            if not test.log.level == 10:
                test.show_output()

            test.log.info('Thanks...')

            test.log.info(
                'Datastore id - {0}, type - {1}'.format(
                    self.cp_env.ds.id, self.cp_env.ds.data_store_type
                )
            )
            test.log.info('Datastore Group id - {0}'.format(self.cp_env.dsz.id))
            test.log.info(
                'Hypervisor id - {0}, type - {1}, os_version - {2}'.format(
                    self.cp_env.hv.id,
                    self.cp_env.hv.hypervisor_type,
                    self.cp_env.hv.os_version
                )
            )
            test.log.info('Hypervisor Group id - {0}'.format(self.cp_env.hvz.id))
            test.log.info('Network id - {0}'.format(self.cp_env.net.id))
            test.log.info('Network Group id - {0}'.format(self.cp_env.netz.id))
            test.log.info('Network joins - {}'.format(self.cp_env.network_joins))
            for bs in self.cp_env.backup_servers:
                test.log.info('Backup Server id - {0}'.format(bs.id))

            if test.cp_version >= '5.10':
                test.log.info(
                    f"Selected Ip Net - {self.ip_net} ({self.ip_net.network_address})"
                )
                test.log.info(
                    f"Selected Ip Range - {self.ip_range}, "
                    f"({self.ip_range.start_address}-{self.ip_range.end_address})"
                )

            if test.cp_version >= 5.4:
                test.log.info(
                    "Selected Ip Address - {}".format(self.ip_address.address)
                )
            else:
                test.log.info(
                    "Selected Ip Address ID - {}".format(self.ip_address.id)
                )
        else:
            test.log.info('Thanks...')
            test.log.warning(
                'No compute resources available, all the other resources skipped(networks,datastores,BS)'
            )
            self.cp_env.ds = self.ds
            self.cp_env.hv = self.hv
            self.cp_env.hvz = self.hvz
            self.cp_env.dsz = self.dsz
            self.cp_env.net = self.network
            self.cp_env.netz = self.netz
            self.cp_env.ip_net = self.ip_net
            self.cp_env.ip_range = self.ip_range
        if test.onapp_settings is None:
            test.onapp_settings = Settings().get()
        if self.test_config.use_cloud_boot_hv:
            self.cp_env.assets = CloudBootIpAddress().assets.get_all()
            self.cp_env.clb_ips = CloudBootIpAddress().get_all_free()
        return self.cp_env

    def _get_ds_from_joins(self, ds_joins):
        """Return data stores array from ds_joins."""
        ds_ids = [ds_join.data_store_id for ds_join in ds_joins]
        return [ds for ds in DataStore().get_all() if ds.id in ds_ids]

    def _set_ds_dsz(self, ds_parameters):
        """ Setting up ds and dsz obj based on ds parameters """
        filtered_ds_joins = self._get_ds_joins(
            ds_parameters, [self.hv], [self.hvz]
        )

        self.ds._ds_with_less_usage(self._get_ds_from_joins(filtered_ds_joins))
        self.dsz = DataStoreZone(self.ds.data_store_group_id)

    def _ip_ok(self, ip):
        """
        Check if ip can be used for test
        :param ip: ip obj
        :return: True if success else False
        """
        status = False
        if ':' not in ip.address:
            status = ip.free and not ip.disallowed_primary and not ip.user_id
            if self.test_config.use_public_network and status:
                # is_global for IPv4Address is supported since python 3.5.2
                try:
                    status = ipaddress.IPv4Address(u"{0}".format(ip.address)).is_global
                except:
                    status = ipaddress.IPv4Network(u"{0}".format(ip.network_address)).is_global
        return status

    def _net_netz_handler(self, net):
        """
        Set up network and network zone objects from network obj
        :param net: network obj
        :return: True if success else False
        """
        self.network = net
        if self.network.network_group_id:
            self.netz.id = self.network.network_group_id
            test.update_object(self.netz)
            return True
        return False

    def _hv_filter(self, hvs=None):
        """
        hvs - an array of hypervisors. Return one of the suitable hypervisor.
        :param hvs: an array of hypervisors objects.
        :return: Return one of the suitable hypervisor or False
        """
        suitable_hvs = [
            hv for hv in hvs
            if hv.free_memory >= 512 or 'vcloud' in test.hv_types
               and hv._can_be_used()
        ]
        if suitable_hvs:
            # Return random HV for less load
            return suitable_hvs[randint(0, len(suitable_hvs) - 1)]
        return False

    def _compute_hv(self, hv_parameters, ds_parameters):
        """
        Set up hv and hvz objects based on hv/ds parameters.
        :param hv_parameters:
        :param ds_parameters:
        :return: True if succes else False
        """
        hvs = self._select_hvs(hv_parameters, ds_parameters)

        # Get HV obj
        if hvs:
            if self.test_config.migrate_server:
                hvs = self.get_for_migration(hvs, key='hv')
                if not hvs:
                    self.error['_compute_hv'] = "No available hypervisors for migrate."
                    test.log.error("No available hypervisors for migrate.")
                    return False
            self.hv = self._hv_filter(hvs=hvs)
            try:
                self.hvz = HypervisorZone(self.hv.hypervisor_group_id)
                return True
            except AttributeError:
                test.log.warning("No available compute resource found.")
        return False

    def _select_hvs(self, hv_parameters, ds_parameters):
        """
        Select hypervisors based on hv/ds parameters
        :param hv_parameters:
        :param ds_parameters:
        :return: an array of hypervisors objects
        """
        hvs = self.hv.get_by_params(hv_parameters)

        # Select hvs with two or more network joins
        if self.test_config.use_two_network_joins:
            hv_zone_ids = list(set([hv.hypervisor_group_id for hv in hvs]))
            hvzs = [
                hvz for hvz in HypervisorZone().get_all()
                if hvz.id in hv_zone_ids
            ]
            # get hvs with two or more network joins
            hvs_with_2_nics = [hv for hv in hvs if len(hv.network_joins()) >= 2]
            hvs_ids_with_2_nics = [hv.id for hv in hvs_with_2_nics]

            # get hvz_ids with two or more network joins
            hvz_ids_with_2_nics = [
                hvz.id for hvz in hvzs if len(hvz.network_joins()) >= 2
                ]

            # Get HV which is allocated to HVZ with 2 or more network joins
            hvs_from_hvzs = [
                hv for hv in hvs if
                hv.hypervisor_group_id in hvz_ids_with_2_nics and
                hv.id not in hvs_ids_with_2_nics
                ]

            hvs = hvs_with_2_nics + hvs_from_hvzs

        if ds_parameters:
            hv_zone_ids = list(set([hv.hypervisor_group_id for hv in hvs]))
            hvzs = [
                hvz for hvz in HypervisorZone().get_all()
                if hvz.id in hv_zone_ids
            ]

            filtered_ds_joins = self._get_ds_joins(ds_parameters, hvs, hvzs)
            if not filtered_ds_joins:
                pass
                # raise SystemError("No data store joins available.")
            filtered_hvs = []
            for hv in hvs:
                for ds_join in filtered_ds_joins:
                    if (
                                    ds_join.target_join_type == "Hypervisor" and
                                    hv.id == ds_join.target_join_id
                    ) or (
                                    ds_join.target_join_type == "HypervisorGroup" and
                                    hv.hypervisor_group_id == ds_join.target_join_id
                    ):
                        filtered_hvs.append(hv)
            return filtered_hvs
        return hvs

    def _compute_data_store(self, ds_parameters):
        """
        Handle DS environment based on ds parameters.
        :param ds_parameters:
        :return:
        """
        # Get data_store_joins from hypervisor
        self._set_ds_dsz(ds_parameters)
        if not self.ds.id or not self.dsz.id:
            test.log.warning('No data store joins available.')

    def _compute_network(self):
        """
        Handle network environment.
        :return:
        """
        net_joins = self.hv.network_joins() + self.hvz.network_joins()
        if net_joins:
            networks = [
                Network(id=net_join.network_id) for net_join in net_joins
                if net_join.interface != 'dummy0'
            ]
            if networks:
                # Looking for global network IP Address.
                for network in networks:
                    # Get all network IP addresses
                    self.ip_address.parent_obj = network
                    ips = self.ip_address.get_all()
                    # Search global network and others...
                    for ip in ips:
                        if self._ip_ok(ip):
                            self.ip_address = ip  # allow to use env.ip_address during VS creation.
                            if self._net_netz_handler(network):
                                break

    def _compute_network_since_54(self):
        """
        Compute network env since 5.4 version
        :return:
        """
        net_joins = self.hv.network_joins() + self.hvz.network_joins()
        if net_joins:
            networks = [
                Network(id=net_join.network_id) for net_join in net_joins
                # if net_join.interface != 'dummy0'
            ]

            # Get IP networks with free ip addresses
            networks = [
                network for network in networks
                if IpAddress(parent_obj=network).get_free().address
            ]

            if networks:
                ip_nets = []
                [
                    ip_nets.extend(
                        IpNetwork(net).list_ip_nets_by_network()
                    ) for net in networks
                ]

                # Use only ipv4 networks
                ip_nets = [
                    ip_net for ip_net in ip_nets if
                    ip_net.network_address.count('.') == 3
                ]

                # Looking for global network IP Address.
                if ip_nets:
                    if self.test_config.use_public_network:
                        for ip_net in ip_nets:
                            if ipaddress.IPv4Network(
                                    u"{0}".format(ip_net.network_address)
                                    ).is_global:
                                self.ip_net = ip_net
                    else:
                        self.ip_net = ip_nets[randint(0, len(ip_nets) - 1)]

                if self.ip_net.id:
                    if self.hv.hypervisor_type == 'vcloud':
                        # Looks like here should be another network
                        self.network = Network(
                            id=self.ip_net.parent_obj.id
                        )
                    elif self.hv.hypervisor_type == 'openstack':
                        self.network = OpenstackNetwork(
                            id=self.ip_net.parent_obj.id
                        )
                    else:
                        self.network = Network(
                            id=self.ip_net.parent_obj.id
                        )
                    self.netz = NetworkZone(id=self.network.network_group_id)

                    #  Select an ip address
                    ip_ranges = IpRange(parent_obj=self.ip_net).get_all()
                    if ip_ranges:
                        for ip_range in ip_ranges:
                            self.ip_address = IpAddress(
                                parent_obj=self.network
                            ).get_free(ip_range=ip_range)

                            if self.ip_address.address:
                                self.ip_range = ip_range
                                break

    def _get_ds_joins(self, ds_parameters, hvs, hvzs):
        """
        Get data store joins depends on ds_parameters and selected arrays of
        hypervizors and hypervizor zones.
        :param ds_parameters: dict of ds parameters
        :param hvs: an array of hv
        :param hvzs: an array of hvz
        :return: an array of filtered data store joins
        """
        datastores = [ds for ds in self.ds.get_by_params(ds_parameters)]
        if self.test_config.migrate_disk:
            datastores = self.get_for_migration(datastores, key='ds')
            if not datastores:
                self.error['datastores'] = "No available datastores for migrate."
                test.log.error("No available datastores for migrate.")
                return []

        datastore_ids = [ds.id for ds in datastores]
        ds_joins = []
        for hv in hvs:
            ds_joins.extend(hv.data_store_joins())

        for hvz in hvzs:
            ds_joins.extend(hvz.data_store_joins())

        return [
            ds_join for ds_join in ds_joins
            if ds_join.data_store_id in datastore_ids
        ]

    def get_for_migration(self, objects, key=None):
        """
        Get objects for migration from one Zone.
        :param objects: hv or ds objects array.
        :param key: 'hv' or 'ds'
        :return: a new objects array from objects where migration is possible
        """
        if key == 'hv':
            group_id = 'hypervisor_group_id'
        elif key == 'ds':
            group_id = 'data_store_group_id'
        else:
            raise AttributeError('Undefined key - {}'.format(key))

        objects_for_mirgation = {}  # key - object group id
        for obj in objects:

            obj_group_id_key = str(obj.__dict__[group_id])
            if obj_group_id_key not in objects_for_mirgation:
                objects_for_mirgation[obj_group_id_key] = 1
            else:
                objects_for_mirgation[obj_group_id_key] = objects_for_mirgation[obj_group_id_key] + 1

        return [
            obj for obj in objects
            if objects_for_mirgation[str(obj.__dict__[group_id])] >= 2
        ]

