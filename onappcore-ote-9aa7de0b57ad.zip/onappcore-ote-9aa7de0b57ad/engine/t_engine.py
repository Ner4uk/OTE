import json
import socket
import string
import sys
import time
from configparser import ConfigParser
from os import path, environ, pathsep, getcwd, mkdir, makedirs, system
from random import choice as rand_choice
from re import findall
from packaging import version


from engine.extentions.api_doc_generator import ApiDocGenerator
from engine.extentions.request_handler import RequestHandler
from engine.lib import config
from engine.lib.cp import CP
from engine.lib.e_mail import Email
from engine.lib.jira import Jira
from engine.lib.logger import Logger
from engine.lib.session import Session


class Version:
    """
    Obj which allows to compare CP and API versions.

    Examples:
        In [1]: test.cp_version.full()
        Out[1]: '5.10.0-32'

        In [2]: test.cp_version
        Out[2]: 5.10.0-32

        In [3]: test.api_version
        Out[3]: 5.10.0-32

        In [4]: print(test.cp_version)
        5.10

        In [5]: test.cp_version == '5.10'
        Out[5]: True

        In [6]: test.cp_version > '5.10'
        Out[6]: False

        In [7]: test.cp_version > 5.9
        Out[7]: True

        In [8]: test.cp_version == 5.9
        Out[8]: False

        In [9]: test.cp_version < 5.9
        Out[9]: False

        In [10]:

    """
    RANGE = ('major', 'minor', 'micro', 'build')

    def __init__(self, value, cp_obj=None):
        self.cp_obj = cp_obj
        for r in self.RANGE:
            self.__dict__[r] = 0

        if isinstance(value, str) and value:
            # "5.10.0-1" for example
            try:
                self.major, self.minor, self.micro, self.build = [
                    int(i) for i in findall(pattern='\d+', string=value)
                ]
            except ValueError:  # '5.10' for example
                version_lst = [
                    int(i) for i in findall(pattern='\d+', string=value)
                ]
                for i, v in enumerate(version_lst):
                    self.__dict__[self.RANGE[i]] = v

        elif isinstance(value, float) and value:  # 5.9 for example
            self.major, self.minor = [
                int(i) for i in findall(pattern='\d+', string=str(value))
            ]
        else:
            for r in self.RANGE:
                self.__dict__[r] = 0

    def full(self):
        return f'{self.major}.{self.minor}.{self.micro}-{self.build}'

    def __eq__(self, other):
        """=="""
        return self.__base_cpm('__eq__', other)

    def __le__(self, other):
        """<="""
        return self.__base_cpm('__le__', other)

    def __lt__(self, other):
        """<"""
        return self.__base_cpm('__lt__', other)

    def __ge__(self, other):
        """>="""
        return self.__base_cpm('__ge__', other)

    def __gt__(self, other):
        """>"""
        return self.__base_cpm('__gt__', other)

    def __base_cpm(self, method, other):
        if not isinstance(other, Version):  # 5.9 for example
            other = Version(other)
        m = getattr(version.parse(repr(self)), method)
        return m(version.parse(repr(other)))

    def __str__(self):
        return f'{self.major}.{self.minor}'

    def __repr__(self):
        return f'{self.major}.{self.minor}.{self.micro}-{self.build}'

    def get(self):
        self.__init__(self.cp_obj.get_version(), cp_obj=self.cp_obj)
        return str(self)

    def set(self, version):
        self.__init__(version, cp_obj=self.cp_obj)


class Credentials():
    def __init__(self, conf_obj):
        # TODO - generate automatically
        self.ssh_user = conf_obj.ssh_user
        self.ssh_password = conf_obj.ssh_password
        self.ssh_key_path = conf_obj.ssh_key_path
        self.license_key = conf_obj.license_key
        self.license_server = conf_obj.license_server
        self.api_token = conf_obj.api_token
        self.cp_version = conf_obj.cp_version


class Variables:
    pass


class TEngine(RequestHandler, ApiDocGenerator):
    """
    Used for have/get information/data about current testing environment.
    From test object (test = TEngin()) you will be have an access to any self
    attribute and method.
    Attributes:
        * env - environment obj
        * onapp_settings - onapp settings obj
        * use_public_network - set True to use public network in test
        * use_cloud_boot_hv - set True to use cloud boot hypervisors
        * use_two_network_joins - Find a hv/hvz with two or more network joins
        * migrate_server - set True to get environment to migration server
        * migrate_disk - set True to get environment to disk migration
        * executable_file_name - hold executable file name
        * wd - working directory
        * hv_types - list of hypervisor types
        * hv_distros - list of hypervisor distros
        * server_types - list of hypervisor server types
        * ds_types - list of datastore types
        * host - control panel host
        * login - login to control panel via ssh
        * password - password to control panel via ssh
        * log_path - path to log directory
        * doc_path - path to doc directory
        * gen_api_doc - set True to generate api documentation
        * cp_release - control panel release
        * cp_version - control panel version object
        * api_version - control panel api version
        * cp - control panel obj
    """
    instance = None
    initialized = False

    def __new__(cls):
        if cls.instance is None:
            cls.instance = super(TEngine, cls).__new__(cls)
        return cls.instance

    def __init__(self):
        if not self.initialized:
            # Define additional test variables
            self.env = None
            self.onapp_settings = None
            self.use_public_network = False
            self.use_cloud_boot_hv = False
            self.variables = Variables()  # variables obj to store some test variables
            # Find a hv/hvz with two or more network joins
            self.use_two_network_joins = False
            # Migration parameters. Used to find hvz/dsz with 2 or more
            # attached resources.
            self.migrate_server = False
            self.migrate_disk = False
            # Extended config
            self.ssh_port = 22
            self.license_key = ''
            self.licensing_server = ''
            self.clb_net_ip = ''
            # CP attributes
            build = None
            self.api_version = None
            self.cp_release = 0

            self.executable_file_name = ''

            #  Get executable file name for doc and log file name
            for arg in sys.argv:
                exe_file = findall("[.\/0-9a-zA-Z_]*\.py", arg)
                if exe_file:
                    self.executable_file_name = path.basename(exe_file[0]).split('.')[0]
                    break

            # working directory
            self.wd = environ['PYTHONPATH'].split(pathsep)[-1]

            # Define paths to config files
            self.global_config = config.GlobalConfig()
            self.test_config = config.TestConfig()
            self.clouds_config = config.CloudsConfig()

            vsphere_config_path = path.join(self.wd, 'conf/vsphere.cfg')

            # init config obj
            self.extended_config = ConfigParser()
            self.vsphere_config = ConfigParser()

            # Read config files

            # Create Log directory
            self.log_path = path.join(getcwd(), 'log')
            if not path.exists(self.log_path):
                makedirs(self.log_path, 0o777)

            log_level = self.test_config.log_level.upper()
            self.log = Logger().logger
            self.log.setLevel(log_level)

            # Read Configuration
            # from environment variables
            cloud_key = ''
            if environ.get('CLOUD'):
                cloud_key = environ.get('CLOUD')
                self.log.warning(
                    'The local configuration would be used!'
                )
                self.read_env_variables()
            # from config file
            elif path.isfile(self.global_config.config_path):
                cloud_key = self.global_config.cloud
                self.log.warning(
                    'The global configuration would be used!'
                )
                self.read_global_conf_variables()
            else:
                exit(
                    self.time_stamp(),
                    "Please set environment variables or check global.cfg file..."
                )

            # Initialize data to search testing environment
            self.hv_types = self.hv_types.split(',') if self.hv_types else []
            self.hv_distros = self.hv_distros.split(',') if self.hv_distros else []
            self.server_types = self.server_types.split(',') if self.server_types else []
            self.ds_types = self.ds_types.split(',') if self.ds_types else []

            self.log.info("HV type - {0}".format(self.hv_types))
            self.log.info("HV distro - {0}".format(self.hv_distros))
            self.log.info("Server Type - {0}".format(self.server_types))
            self.log.info("DS type - {0}".format(self.ds_types))
            self.log.info("Manager ID - {0}".format(self.template_manager_id))

            # Read clouds config
            self.clouds_config.section = cloud_key
            self.host = self.clouds_config.host
            self.login = self.clouds_config.login
            self.password = self.clouds_config.password

            self.ssh_port = int(
                self.clouds_config.ssh_port
            ) if self.clouds_config.ssh_port else 22
            self.license_key = self.clouds_config.license_key
            self.licensing_server = self.clouds_config.licensing_server
            self.clb_net_ip = self.clouds_config.clb_net_ip

            # Read vsphere config if one exists
            if path.isfile(vsphere_config_path):
                self.vsphere_config.read(vsphere_config_path)

                self.vcenter_ip_address = self.vsphere_config.get(
                    'credentials', 'ip_address'
                ) if self.vsphere_config.has_option(
                    section='credentials', option='ip_address'
                ) else ''

                self.vcenter_host = self.vsphere_config.get(
                    'credentials', 'host'
                ) if self.vsphere_config.has_option(
                    section='credentials', option='host'
                ) else ''

                self.vcenter_login = self.vsphere_config.get(
                    'credentials', 'login'
                ) if self.vsphere_config.has_option(
                    section='credentials', option='login'
                ) else ''

                self.vcenter_password = self.vsphere_config.get(
                    'credentials', 'password'
                ) if self.vsphere_config.has_option(
                    section='credentials', option='password'
                ) else ''
            # Configure documentation directory
            self.doc_path = path.join(getcwd(), 'doc')
            if not path.exists(self.doc_path):
                mkdir(self.doc_path, 0o777)

            # Create doc file
            self.doc_file_name = self.executable_file_name + '.doc'
            if path.isfile(path.join(self.doc_path, self.doc_file_name)):
                self.doc_file_name = ''

            self.gen_api_doc = False

            # Create session object
            self.session = Session(
                self.host,
                self.login,
                self.password
            )

            if self.clouds_config.scheme:
                self.session.scheme = self.clouds_config.scheme

            if self.clouds_config.port:
                self.session.port = self.clouds_config.port

            self.log.info('#' * 80)
            self.log.info('Start')
            self.log.info(
                'Tests will be executed on "{0}" cloud...'.format(self.host)
            )

            # Init JIRA obj
            self.jira = Jira(
                self.test_config.jira_server,
                self.test_config.jira_user,
                self.test_config.jira_password
            )

            # Get onapp version from CP
            self.cp_version = Version(None)
            if self.session.method_handler('/version.json'):
                response = ''
                try:
                    response = self.session.response.json()
                except json.decoder.JSONDecodeError as e:
                    self.log.error(f"JSONDecodeError - {e}")
                except:
                    message = self.session.response.content.decode()
                    self.log.error(
                        f"Can't decode string obj ({message}) to json"
                    )
                if 'version' in response:
                    version = response['version']
                    self.cp_release = findall(
                        '\d+.\d+.\d+', version
                    )[0]
                    build = ''
                    if '-' in version:
                        build = version.split('-')[-1]
                    # self.cp_version = float(self.cp_release.rsplit('.', 1)[0])
                    self.cp_version = Version(version)
                    if 'None' in str(self.api_version):
                        self.api_version = Version(version)
                elif 'error' in response:
                    raise SystemError(response)
            elif self.session.error:
                self.log.error(self.session.error)
                # print('Looks like no connection to CP or you trying to
                # install a new CP.')

            # try:
            #     self.session.method_handler('/version.json')
            #     response = self.session.response.json()
            #     if 'version' in response:
            #         version = response['version']
            #         self.cp_release = findall(
            #             '\d+.\d+.\d+', version
            #         )[0]
            #         build = ''
            #         if '-' in version:
            #             build = version.split('-')[-1]
            #         self.cp_version = float(self.cp_release.rsplit('.', 1)[0])
            #         if not self.api_version:
            #             self.api_version = self.cp_version
            #     elif 'error' in response:
            #         raise SystemError(response)
            # except ConnectionError as e:
            #     print(e)
            #     #print('Looks like no connection to CP or you trying to
            #     # install a new CP.')

            if self.cp_version.build:
                self.log.info("ONAPP CP BUILD - {0}".format(self.cp_version.build))
            self.log.info("ONAPP CP RELEASE - {0}.{1}".format(
                self.cp_version.major, self.cp_version.minor
            ))
            self.log.info("ONAPP CP VERSION - {0}".format(self.cp_version))
            self.log.info("ONAPP API VERSION - {0}".format(self.api_version))

            # Initialize control panel object
            self.cp = CP(
                host=self.host,
                user=self.login,
                password=self.password,
                clb_net_ip=self.clb_net_ip,
                ssh_port=self.ssh_port
            )

            self.log.info('*' * 80)
            self.log.info(
                "Current test will be running on {0} by {1} ip address...".format(
                    cloud_key, self.host
                )
            )
            self.log.info('*' * 80)
            self.cp_version.cp_obj = self.cp
            self.initialized = True

    def load_env(
            self,
            hv=None,
            ds=None,
            migrate_server=False,
            migrate_disk=False,
            use_public_network=False,
            use_two_network_joins=False,
            use_cloud_boot_hv=False
    ):
        """
        Loading CP environment according to HV and DS parameters.
        :param hv: dict of hv params, for example: {"id": [1,2,3],
        "hypervisor_type": ['xen',]}
        :param ds: dict of ds params
        :return: environment object as env.
            As result we are getting access to:
            * ds
            * hv
            * hvz
            * dsz
            * net
            * netz
            * ip_address - an ip address which you can use during server
                creation through env variable.
        """

        from engine.lib.cp_env import CPEnv
        env = CPEnv()

        if not hv:
            hv = {
                "hypervisor_type": self.hv_types,
                "distro": self.hv_distros,
                "server_type": self.server_types
            }
        hv = dict([(k, v) for k, v in hv.items() if v])

        if not ds:
            ds = {
                "data_store_type": self.ds_types
            }
        ds = dict([(k, v) for k, v in ds.items() if v])

        self.env = env.load_env(
            hv,
            ds,
            migrate_server=migrate_server,
            migrate_disk=migrate_disk,
            use_public_network=use_public_network,
            use_two_network_joins=use_two_network_joins,
            use_cloud_boot_hv=use_cloud_boot_hv
        )
        if env.error:
            self.log.error(env.error)
        return self.env

    def start_new_session(self, login, password):
        """Start a new session with new login and password"""
        self.log.warning(
            "'start_new_session' method would be deprecated in near future so "
            "please use 'execute_as'")
        self.session.login = login
        self.session.password = password

    def execute_as(self, login, password):
        """Start to execute test with new login and password"""
        self.session.login = login
        self.session.password = password

    def read_env_variables(self):
        """
        Read env variables you have specified when running test.
        :return:
        """
        self.hv_types = environ.get('HV_TYPE')
        self.hv_distros = environ.get('HV_DISTRO')
        # virtual, smart, baremetal
        self.server_types = environ.get('SERVER_TYPE')
        self.ds_types = environ.get('DS_TYPE')
        self.template_manager_id = environ.get('TEMPLATE_MANAGER_ID')
        try:
            self.api_version = Version(
                float(environ.get('ONAPP_API_VERSION'))
            )
        except TypeError:
            self.log.warning("ONAPP_API_VERSION is not specified.")

    def read_global_conf_variables(self):
        """
        Read test configuration from config file.
        :return:
        """
        self.hv_types = self.global_config.hv_type
        self.hv_distros = self.global_config.hv_distro
        # virtual, smart, baremetal
        self.server_types = self.global_config.server_type
        self.ds_types = self.global_config.ds_type
        self.template_manager_id = self.global_config.template_manager_id
        try:
            self.api_version = Version(
                float(self.global_config.onapp_api_version)
            )
        except TypeError:
            self.log.warning("ONAPP_API_VERSION is not specified.")

    def generate_password(self, size=6, use_settings=True, chars_usage='1111'):
        """
        Generate password

        :param size: password size
        :param use_settings: use or not onapp settings to generate a valid
            password
        :param chars_usage: binary code of usage as string.\n
            Example: '1111' - uppercase, digits, lowercase, symbols

        :return: password
        """
        uppercase = ''
        digits = ''
        lowercase = ''
        symbols = ''

        if chars_usage[0] == '1':
            uppercase = string.ascii_uppercase
        if chars_usage[1] == '1':
            digits = string.digits
        if chars_usage[2] == '1':
            lowercase = string.ascii_lowercase
        if chars_usage[3] == '1':
            symbols = "~!@#$*_-+=`\{}[]:;',.?/"

        chars = ''.join((uppercase, digits, lowercase, symbols))
        password = ''

        if use_settings:
            if not self.onapp_settings:
                self.load_onapp_settings()
            size = int(self.onapp_settings.password_minimum_length)

            if self.onapp_settings.password_upper_lowercase:
                password += rand_choice(uppercase)
                password += rand_choice(lowercase)

            if self.onapp_settings.password_letters_numbers:
                password += rand_choice(''.join((uppercase, lowercase)))
                password += rand_choice(digits)

            if self.onapp_settings.password_symbols:
                password += rand_choice(symbols)

        password += ''.join(
            rand_choice(chars) for _ in range(size - len(password))
        )

        return password

    def load_onapp_settings(self):
        """
        Update self onapp_settings attribute
        :return: onapp_settings obj
        """
        from onapp_helper.settings import Settings
        self.onapp_settings = Settings().get()
        return self.onapp_settings

    @staticmethod
    def init_mail(msg_from='', msg_to='', subject='', message=''):
        """
        Return the email object is ready to send message to remote host
        via smtp.
        """
        return Email(
            msg_from=msg_from, msg_to=msg_to, subject=subject, message=message
        )

    def load_ha_env(self):
        #  Initialise env for HA
        from onapp_helper.infra.ha.host import Host
        from onapp_helper.infra.ha.communication_interface import CommunicationInterface
        self.communication_ring = CommunicationInterface()
        self.ha_config = config.HAConfig()

        self.ha_hosts = []
        self.ha_cluster_names = [
            'UI',
            'LOAD_BALANCER',
            'DATABASE',
            'REDIS',
            'MESSAGE_QUEUE',
            'DAEMON',
            'CLOUD_BOOT'
        ]

        self.ha_credentials = Credentials(self.ha_config)
        self.communication_ring._load_from_config(self.ha_config)

        hostnames = self.ha_config.hostnames.split(',')
        ip_addresses = self.ha_config.ip_addresses.split(',')
        for hostname, ip in zip(hostnames, ip_addresses):
            self.ha_hosts.append(Host(hostname=hostname, ip=ip))

    def move_envs_to_sutable_attributes_names(self):
        """
        Example: 'kvm' and 'centos6' => kvm6
        Mostly for console usage
        :return:
        """
        for env in self.envs:
            key = ''.join((env.hv.hypervisor_type, env.hv.distro[-1]))
            self.__dict__[key] = env

    def run_at(self, hour=None, minutes=None):
        """
        Run test at specific time. Is useful for billing tests.
        Notice: Execute test at specific time if both parameters set, in
        case only minutes specified run test if current minutes less then or
        equal to specified.
        :param hour:
        :param minutes: set minutes from 4
        :return: True when condition success, otherwise False
        """
        if hour and minutes:
            self.log.warning(
                "Test will be running at {:02}:{:02}".format(
                    hour, minutes
                )
            )
            while (
                        (time.localtime(time.time()).tm_hour != hour) and
                        (time.localtime(time.time()).tm_min != minutes)
            ):
                time.sleep(30)
        elif minutes:
            if time.localtime(time.time()).tm_min > minutes:
                self.log.warning("Test will be running in next hour.")
            while not 4 <= time.localtime(time.time()).tm_min <= minutes:
                time.sleep(30)
        else:
            self.log.error('Method get wrong parameters...')
            return False
        return True

    def wait_for_action(self, action, *args, timeout=300, step=1, **kwargs):
        """
        Waiting for executing some action.
        :param action: func obj (if expression use lambda: expression)
        :param timeout: time out in seconds
        :param step: time interval in seconds
        :return: result of executed action or False if time is out
        """

        # For example we have timeout 60 sec and want to do some action each
        # 10 sec, in this case timeout=60, step=10

        while timeout > 0:
            result = action(*args, *kwargs)

            if result:
                return result

            timeout -= step
            time.sleep(step)
        # raise TimeoutError("{} executing timeout.".format(action_name))
        self.log.error('Waiting time out...')
        return False

    def port_is_open(self, host=None, port=22, timeout=60):

        if not host and self.host:
            host = self.host
        self.log.info('Check if port {} is open on {} host'.format(port, host))
        connection = False
        try:
            socket.setdefaulttimeout(timeout)
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.connect((host, port))
            connection = True
        except socket.error as e:
            self.log.error(e)
        finally:
            sock.close()

        return connection

    def ping(self, address, timeout):
        cmd = f"ping -ot {timeout} {address}"
        self.log.info(cmd)
        return system(cmd) == 0

    @staticmethod
    def clean_up_resources(attributes, obj):
        """
        Allow to clean up obj resources, described in attributes,
        more correctly in case setup class failed,
        teardown class method should be running,

        :param attributes: a typle of attribute names as string
        :param obj: an obj to which the attributes are related.

        :return: Nothing
        """
        for attr in attributes:
            if hasattr(obj, attr):
                test_obj = getattr(obj, attr)
                if hasattr(test_obj, 'locked') \
                        and test_obj.get() \
                        and test_obj.locked:
                    test_obj.unlock()
                if not isinstance(test_obj, bool) and test_obj.id:
                    test_obj.delete()

    def hide_output(self):
        """
            Allows to hide print output until show_output

        :return: Nothing
        """
        self.saveout = sys.stdout
        self.devnull = open('/dev/null', 'w')
        sys.stdout = self.devnull

    def show_output(self):
        """
            Allows to get output back

        :return: Nothing
        """
        sys.stdout = self.saveout
        self.devnull.close()

    def write(self, s, time_stamp=False):
        """
        Write string to specific file
        :param file_name: file name, actually you can find this file in log
            folder
        :param s: string
        :param time_stamp: Set True if you need to add time to your message
        :return:
        """
        with open(path.join(
                self.log_path,
                f"{self.executable_file_name}.txt"
        ), '+a') as f:
            if time_stamp:
                s = f"{self.time_stamp()} {s}"
            f.write(f"{s}\n")
            f.close()

    def not_supported_msg(self, obj):
        """
        Return a message when test case is not supported by current cp version
        :param obj: helper object
        :return: msg
        """
        if hasattr(obj, '__since__') and hasattr(obj, '__till__'):
            if self.cp_version < obj.__since__:
                return "Supported since {}, the current cp version is {}".format(
                    obj.__since__, self.cp_version
                )

            if self.cp_version > obj.__till__:
                return "Supported till {}, the current cp version is {}".format(
                    obj.__till__, self.cp_version
                )
        elif hasattr(obj, '__since__'):
            if self.cp_version < obj.__since__:
                return "Supported since {}, the current cp version is {}".format(
                    obj.__since__, self.cp_version
                )
        elif hasattr(obj, '__till__'):
            if self.cp_version > obj.__till__:
                return "Supported till {}, the current cp version is {}".format(
                    obj.__till__, self.cp_version
                )
        else:
            return "Is not supported by {} cp version".format(self.cp_version)

    @staticmethod
    def time_stamp():
        return time.ctime()

    @staticmethod
    def get_time_str(shift=0, utc=False):
        """
        Get time as string in suitable for onapp format
        :param shift: integer, time shift in seconds, can be positive and
          negative
        :param utc: Set True to return time in UTC time zone
        :return: string like "2018-06-05T08:57:29.000+00:00"
        """

        current_time_in_sec = time.time() + shift
        if utc:
            time_tuple = time.gmtime(current_time_in_sec)
        else:
            time_tuple = time.localtime(current_time_in_sec)
        return time.strftime("%Y-%m-%dT%H:%M:%S.000+00:00", time_tuple)

    @staticmethod
    def get_time_sec(time_str):
        """
        Get time in seconds since Epoch from onapp time string
        :param time_str: time like "%Y-%m-%dT%H:%M:%S.000+00:00"
        :return: float
        """

        time_tuple = time.strptime(time_str, "%Y-%m-%dT%H:%M:%S.000+00:00")
        return time.mktime(time_tuple)
