import jenkins
import os

test_file_paths = []
server = jenkins.Jenkins('http://10.0.24.24:8080', username='qaaz', password='M]AEiXPtWXDc6r8Uc')
config_folder_xml = '<?xml version=\'1.0\' encoding=\'UTF-8\'?>\n<com.cloudbees.hudson.plugins.folder.Folder plugin="cloudbees-folder@5.13">\n  <properties/>\n  <views>\n    <hudson.model.AllView>\n      <owner class="com.cloudbees.hudson.plugins.folder.Folder" reference="../../.."/>\n      <name>All</name>\n      <filterExecutors>false</filterExecutors>\n      <filterQueue>false</filterQueue>\n      <properties class="hudson.model.View$PropertyList"/>\n    </hudson.model.AllView>\n  </views>\n  <viewsTabBar class="hudson.views.DefaultViewsTabBar"/>\n  <healthMetrics>\n    <com.cloudbees.hudson.plugins.folder.health.WorstChildHealthMetric/>\n  </healthMetrics>\n  <icon class="com.cloudbees.hudson.plugins.folder.icons.StockFolderIcon"/>\n</com.cloudbees.hudson.plugins.folder.Folder>'
config_xml = '<?xml version=\'1.0\' encoding=\'UTF-8\'?>\n<project>\n  <actions/>\n  <description></description>\n  <hasCustomWorkspace>true</hasCustomWorkspace>\n  <customWorkspace>/home/onapp/ote</customWorkspace>\n  <keepDependencies>false</keepDependencies>\n  <properties/>\n  <scm class="hudson.scm.NullSCM"/>\n  <canRoam>true</canRoam>\n  <disabled>false</disabled>\n  <blockBuildWhenDownstreamBuilding>false</blockBuildWhenDownstreamBuilding>\n  <blockBuildWhenUpstreamBuilding>false</blockBuildWhenUpstreamBuilding>\n  <triggers/>\n  <concurrentBuild>false</concurrentBuild>\n  <builders>\n    <hudson.tasks.Shell>\n      <command>source /home/onapp/ote/venv/ote3.5/bin/activate\nexport PYTHONPATH=&quot;$PYTHONPATH:/home/onapp/ote&quot;\npy.test -s --junitxml ./{}.xml ./test_suites/{}</command>\n    </hudson.tasks.Shell>\n  </builders>\n  <publishers>\n    <hudson.tasks.junit.JUnitResultArchiver plugin="junit@1.19">\n      <testResults>{}.xml</testResults>\n      <keepLongStdio>false</keepLongStdio>\n      <healthScaleFactor>1.0</healthScaleFactor>\n      <allowEmptyResults>false</allowEmptyResults>\n    </hudson.tasks.junit.JUnitResultArchiver>\n  </publishers>\n  <buildWrappers/>\n</project>'

for path, subdirs, files in os.walk('./test_suites'):
    for name in files:
        test_file_path = os.path.join(path, name)
        if '.py' == test_file_path[-3:] and '__' not in test_file_path and 'own_usage' not in test_file_path:
            test_file_paths.append(test_file_path)

for tfp in test_file_paths:
    tfpl = tfp.split('/')[2:]
    # print(tfpl)
    job_names = []
    for job in tfpl:
        if '.py' not in job:
            job_names.append(''.join([j.capitalize() for j in job.split('_')]))
        else:
            job_names.append(''.join([j.capitalize() for j in job[:-3].split('_')]))
        job_name = '/'.join(job_names)
        try:
            server.assert_job_exists(job_name)
            # server.delete_job(job_name)
            print('Job {} Exist'.format(job_name))
        except jenkins.JenkinsException as err:
            if 'does not exist' in err.args[0]:
                if '.py' == job[-3:]:
                    junit_file_path = '/'.join(tfpl).split('.')[0]

                    server.create_job(
                        job_name, config_xml.format(
                            junit_file_path,
                            '/'.join(tfpl),
                            junit_file_path
                        )
                    )
                    # pass
                    print('Create', job_name, '/'.join(tfpl))
                else:
                    server.create_job(job_name, config_folder_xml)
                    # pass
                    print('Create', job_name)
