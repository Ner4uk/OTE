import os
import sys
import csv
import time
import gspread
from oauth2client.service_account import ServiceAccountCredentials

env = sys.argv[1]
onapp_version = 5.9
BASE_PATH = "./reports/{}/".format(env)
HEAD = "Case;Status;Reason"

label = '{} Jenkins regression report ({})'.format(onapp_version, env)

# https://www.youtube.com/watch?v=vISRn5qFrkM
scope = [
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/drive"
]
creds = ServiceAccountCredentials.from_json_keyfile_name(
    "./conf/OnAppReport-fe0b6d14521b.json",
    scope
)
client = gspread.authorize(creds)

print("Preparing data:")
print("    -collect paths;")

# 1. Get all files path
report_dirs = os.listdir(BASE_PATH)

report_files = []

for d in report_dirs:
    files = os.listdir(os.path.join(BASE_PATH, d))
    for file in files:
        if '.txt' in file:
            report_files.append(
                os.path.join(
                    BASE_PATH, d, file
                )
            )

# 2. Parse report file and  write data to csv file
google_doc_report_csv = './doc/google_doc_report.csv'

print("    -generate csv file ({});".format(google_doc_report_csv))
with open(google_doc_report_csv, 'w', newline='') as csvfile:
    for f_name in report_files:
        f_read = []
        with open(f_name) as f:
            f_read = f.readlines()
        case = ''
        status = ''
        reason = []

        test_data = f_read[0].split("::")
        test_name = test_data[-3] if len(test_data) > 2 else test_data[0][2:-3]
        writer = csv.writer(csvfile, delimiter=',', quoting=csv.QUOTE_MINIMAL)
        writer.writerow([test_name, ])
        for s in f_read:
            if s[0] == '.':
                if reason:
                    writer.writerow([case, status, ''.join(reason)])
                    reason = []
                status = 'Success'

                case = s.split("::")[-1]
                if '\n' in case:
                    case = case.split('\n')[0]
                writer.writerow([case, status, ''.join(reason)])
            elif s[0] == 's':
                if reason:
                    writer.writerow([case, status, ''.join(reason)])
                    reason = []
                status = 'Skipped'

                case = s.split("::")[-1]
                if '\n' in case:
                    case = case.split('\n')[0]

            elif s[0] == 'F':
                if reason:
                    writer.writerow([case, status, ''.join(reason)])
                    reason = []
                status = 'Failed'

                case = s.split("::")[-1]
                if '\n' in case:
                    case = case.split('\n')[0]

            else:
                reason.append(s)
        if reason:
            writer.writerow([case, status, ''.join(reason)])
            reason = []

# 3. load csv to google docs
try:
    # If it is possible to open we should edit data
    sheet = client.open(label).worksheet(label)
    # print(sheet.id)
    # client.del_spreadsheet(sheet.id)
    # print('deleted')
    # import pdb;pdb.set_trace()
    print("Open sheet with an id {} for editing".format(sheet.id))
    statuses = sheet.col_values(2)
    # print(statuses)
    filtered_csv_data = [] # Contain success tests
    with open(google_doc_report_csv) as f:
        data = csv.reader(f, delimiter=',')
        for d in data:
            if len(d) > 1 and d[1] == 'Success':
                filtered_csv_data.append(d[0])
    # print(filtered_csv_data)
    for value, status in enumerate(statuses, start=1):
        if status and status != 'Success':
            try:
                test_name = sheet.cell(value, 1).value
            except gspread.exceptions.APIError as e:
                print(e)
                time.sleep(60)
                test_name = sheet.cell(value, 1).value
            # print(test_name)
            if test_name in filtered_csv_data:
                try:
                    sheet.update_cell(value, 2, 'Success')
                    sheet.update_cell(value, 3, '')
                    print("    -test case {} has been changed;".format(test_name))
                except gspread.exceptions.APIError as e:
                    print(e)
                    time.sleep(60)
                    sheet.update_cell(value, 2, 'Success')
                    sheet.update_cell(value, 3, '')

    # Analise data and change state from false/skip to success
except gspread.exceptions.SpreadsheetNotFound:
    # Create a new one, import csv data to google sheets
    sheet = client.create(label) #.worksheet(
    # print(sheet.id)
    print("Open sheet with an id {} for importing scv file".format(sheet.id))
    client.insert_permission(
        sheet.id,
        'qa@onapp.com',
        perm_type='group',
        role='writer',
        notify=False
    )
    with open(google_doc_report_csv) as f:
        data = f.read()
        client.import_csv(sheet.id, data)

print("Finish!")

