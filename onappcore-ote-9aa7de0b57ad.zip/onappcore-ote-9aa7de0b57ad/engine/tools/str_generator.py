
import string
import random


def name(size=5, char=string.ascii_uppercase):
    return ''.join(random.choice(char) for _ in range(size))


def login(size=6, char=string.ascii_letters):
    return ''.join(random.choice(char) for _ in range(size))


def password(size=8, char=string.ascii_uppercase + string.digits):
    return ''.join(random.choice(char) for _ in range(size))


def mail(size=6, char=string.ascii_letters+string.digits):
    return (''.join(random.choice(char) for _ in range(size))+'@mail.com')