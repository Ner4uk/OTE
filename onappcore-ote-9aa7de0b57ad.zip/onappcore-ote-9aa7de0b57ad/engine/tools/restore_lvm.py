from onapp_helper.data_store import DataStore
from onapp_helper.disk import Disk
from onapp_helper.hypervisor import Hypervisor
from onapp_helper.backup_server import BackupServer

targets = [
    bs for bs in BackupServer().get_all()
    if bs.enabled
    ]
if not targets:
    hv = [
        hv for hv in Hypervisor().get_all()
        if hv.hypervisor_type in ['xen', 'kvm'] and hv.online and hv.enabled
    ][0]
    targets.append(hv)

for target in targets:
    lvs_disks = target.execute('lvs -o lv_name').replace(' ', '').split('\n')
    cloud_data_stores = DataStore().get_all()
    fake_ds_ids = [ds.id for ds in cloud_data_stores if 'fake' in ds.label.lower()]
    disks = (
        d for d in Disk().get_all()
        if d.identifier not in lvs_disks and
           d.identifier != '2000' and
           d.data_store_id not in fake_ds_ids
    )

    datastores = {}
    for ds in cloud_data_stores:
        datastores[str(ds.id)] = ds

    disks_for_create = ((d, datastores[str(d.data_store_id)]) for d in disks)

    # [
    #     print('lvcreate {} -L1G -n {} --yes'.format(ds.identifier, d.identifier))
    #     for d, ds in disks_for_create
    #     ]

    [
        target.execute(
            'lvcreate {} -L1G -n {} --yes'.format(ds.identifier, d.identifier),
        ) for d, ds in disks_for_create
        ]