# ignore
__author__ = 'zhuk'
__doc__ = """Save CP configuration to file"""


import sys
from onapp_helper import test
from onapp_helper.hypervisor import Hypervisor
from onapp_helper.hypervisor_zone import HypervisorZone
from onapp_helper.data_store import DataStore
from onapp_helper.data_store_zone import DataStoreZone
from onapp_helper.data_store_join import DataStoreJoin
from onapp_helper.networks import Network
from onapp_helper.network_zone import NetworkZone
from onapp_helper.network_join import NetworkJoin
from onapp_helper.ip_network import IpNetwork
from onapp_helper.ip_range import IpRange
from onapp_helper.location_group import LocationGroup
from onapp_helper.backup_server import BackupServer
from onapp_helper.bsz import BSZ
from onapp_helper.backup_server_join import BackupServerJoin

CSV_PATH = f'./conf/dump_cp_config_{test.host}.csv'

# Store HVZs
hvz_keys = [
    "label",
    "server_type",
    "location_group_id",
    "release_resource_type",
    "max_vms_start_at_once",
    "recovery_type",
    "failover_timeout",
    "run_sysprep",
    "default_gateway",
    "vlan",
    "cpu_units",
]

hv_keys = [
    "label",
    "ip_address",
    "backup_ip_address",
    "hypervisor_type",
    "enabled",
    "disable_failover",
    "collect_stats",
    "hypervisor_group_id",
]

# Store DSZs
dsz_keys = [
    "label",
    "server_type",
    "location_group_id",
]

# Store DSs
ds_keys = [
    "label",
    "identifier",
    "data_store_group_id",
    "local_hypervisor_id",
    "ip",
    "enabled",
    "data_store_size",
    "data_store_type",
]

# Store DS Joins
ds_join_keys = [
    "data_store_id",
    "target_join_type",
    "target_join_id",
]

# Store NetworkZones
ntz_keys = [
    "label",
    "server_type",
    "location_group_id",
]

# Store Networks
net_keys = [
    "label",
    "network_group_id",
    "vlan",
    "type",
]

# Store NetworkJoins
net_join_keys = [
    "network_id",
    "interface",
    "target_join_id",
    "target_join_type",
]

# IpNetworks
ip_network_keys = [
    "default_gateway",
    "network_address",
    "network_mask",
    "label",
    "network_label"
]

# Store IpRanges
ip_range_keys = [
    "start_address",
    "end_address",
    "default_gateway",
    "network_label",
    "ip_net_label"
]

# Store LocationGroups
location_group_keys = [
    "country",
    "city",
    "id",
]

# Backup servers
backup_server_keys = [
    "label",
    "enabled",
    "capacity",
    "ip_address",
    "backup_ip_address",
    "backup_server_group_id"
]

# Backup server zone keys
bsz_keys = [
    "label",
    "server_type",
    "location_group_id",
]

# Store Backup Server Joins
bs_join_keys = [
    "backup_server_id",
    "target_join_id",
    "target_join_type",
]


def dump():
    global hv_keys, dsz_keys, ds_keys, ds_join_keys, ntz_keys, \
        net_keys, net_join_keys, ip_network_keys, ip_range_keys, \
        backup_server_keys, location_group_keys, bsz_keys, bs_join_keys
    with open(CSV_PATH, 'w') as cp_cfg:
        vals = []
        # Store HVZ
        cp_cfg.write(f"{';'.join([''] + hvz_keys)}\n")
        for hvz in HypervisorZone().get_all():
            vals = ['hvz']
            for key in hvz_keys:
                vals.append(str(hvz.__dict__[key]))
            cp_cfg.write(f"{';'.join(vals)}\n")

        # Store HVs
        cp_cfg.write(f"{';'.join([''] + hv_keys)}\n")
        for hv in Hypervisor().get_all():
            vals = ['hv']
            for key in hv_keys:
                if key == 'hypervisor_group_id':
                    vals.append(str(HypervisorZone(id=hv.__dict__[key]).label))
                else:
                    vals.append(str(hv.__dict__[key]))
            cp_cfg.write(f"{';'.join(vals)}\n")

        # Store DSZ
        cp_cfg.write(f"{';'.join([''] + dsz_keys)}\n")
        for dsz in DataStoreZone().get_all():
            vals = ['dsz']
            for key in dsz_keys:
                if key == 'location_group_id' and dsz.__dict__[key]:
                    vals.append(LocationGroup(id=dsz.__dict__[key]).city)
                else:
                    vals.append(str(dsz.__dict__[key]))
            cp_cfg.write(f"{';'.join(vals)}\n")

        # Store DS
        cp_cfg.write(f"{';'.join([''] + ds_keys)}\n")
        for ds in DataStore().get_all():
            vals = ['ds']
            for key in ds_keys:
                if key == "data_store_group_id" and ds.__dict__[key]:
                    vals.append(DataStoreZone(id=ds.__dict__[key]).label)
                elif key == "local_hypervisor_id" and ds.__dict__[key]:
                    vals.append(Hypervisor(id=ds.__dict__[key]).label)
                else:
                    vals.append(str(ds.__dict__[key]))
            cp_cfg.write(f"{';'.join(vals)}\n")

        # Store DS Joins
        cp_cfg.write(f"{';'.join([''] + ds_join_keys)}\n")
        for hvz in HypervisorZone().get_all():
            for ds_join in DataStoreJoin(parent_obj=hvz).get_all():
                vals = ['ds_join']
                for key in ds_join_keys:
                    if key == "target_join_id":
                        vals.append(HypervisorZone(id=ds_join.__dict__[key]).label)
                    elif key == 'data_store_id':
                        vals.append(DataStore(id=ds_join.__dict__[key]).label)
                    else:
                        vals.append(str(ds_join.__dict__[key]))
                cp_cfg.write(f"{';'.join(vals)}\n")

        for hv in Hypervisor().get_all():
            for ds_join in DataStoreJoin(parent_obj=hv).get_all():
                vals = ['ds_join']
                for key in ds_join_keys:
                    if key == "target_join_id":
                        vals.append(Hypervisor(id=ds_join.__dict__[key]).label)
                    elif key == 'data_store_id':
                        vals.append(DataStore(id=ds_join.__dict__[key]).label)
                    else:
                        vals.append(str(ds_join.__dict__[key]))
                cp_cfg.write(f"{';'.join(vals)}\n")

        # Store Network Zones
        cp_cfg.write(f"{';'.join([''] + ntz_keys)}\n")
        for ntz in NetworkZone().get_all():
            vals = ['ntz']
            for key in ntz_keys:
                if key == 'location_group_id' and ntz.__dict__[key]:
                    vals.append(LocationGroup(id=ntz.__dict__[key]).city)
                else:
                    vals.append(str(ntz.__dict__[key]))
            cp_cfg.write(f"{';'.join(vals)}\n")

        # Store Networks
        cp_cfg.write(f"{';'.join([''] + net_keys)}\n")
        for net in Network().get_all():
            vals = ['net']
            for key in net_keys:
                if key == "network_group_id":
                    vals.append(NetworkZone(id=net.__dict__[key]).label)
                else:
                    vals.append(str(net.__dict__[key]))
            cp_cfg.write(f"{';'.join(vals)}\n")

        # Store Network Joins
        cp_cfg.write(f"{';'.join([''] + net_join_keys)}\n")
        for hvz in HypervisorZone().get_all():
            for net_join in NetworkJoin(parent_obj=hvz).get_all():
                vals = ['net_join']
                for key in net_join_keys:
                    if key == "target_join_id":
                        vals.append(HypervisorZone(id=net_join.__dict__[key]).label)
                    elif key == "network_id":
                        vals.append(Network(id=net_join.__dict__[key]).label)
                    else:
                        vals.append(str(net_join.__dict__[key]))
                cp_cfg.write(f"{';'.join(vals)}\n")

        for hv in Hypervisor().get_all():
            for net_join in NetworkJoin(parent_obj=hv).get_all():
                vals = ['net_join']
                for key in net_join_keys:
                    if key == "target_join_id":
                        vals.append(Hypervisor(id=net_join.__dict__[key]).label)
                    elif key == "network_id":
                        vals.append(Network(id=net_join.__dict__[key]).label)
                    else:
                        vals.append(str(net_join.__dict__[key]))
                cp_cfg.write(f"{';'.join(vals)}\n")

        # Store Ip Networks
        cp_cfg.write(f"{';'.join([''] + ip_network_keys)}\n")
        for net in Network().get_all():
            for ip_net in IpNetwork(parent_obj=net).get_all():
                vals = ['ip_net']
                for key in ip_network_keys:
                    if key == "network_label":
                        vals.append(net.label)
                    else:
                        vals.append(str(ip_net.__dict__[key]))
                cp_cfg.write(f"{';'.join(vals)}\n")

        # Store Ip Range
        cp_cfg.write(f"{';'.join([''] + ip_range_keys)}\n")
        for net in Network().get_all():
            for ip_net in IpNetwork(parent_obj=net).get_all():
                for ip_range in IpRange(parent_obj=ip_net).get_all():
                    vals = ['ip_range']
                    for key in ip_range_keys:
                        if key == "network_label":
                            vals.append(net.label)
                        elif key == "ip_net_label":
                            vals.append(ip_net.label)
                        else:
                            vals.append(str(ip_range.__dict__[key]))
                    cp_cfg.write(f"{';'.join(vals)}\n")

        # Store Location Groups
        cp_cfg.write(f"{';'.join([''] + location_group_keys)}\n")
        for lg in LocationGroup().get_all():
            vals = ['lg']
            for key in location_group_keys:
                vals.append(str(lg.__dict__[key]))
            cp_cfg.write(f"{';'.join(vals)}\n")

        # Store Backup Servers
        cp_cfg.write(f"{';'.join([''] + backup_server_keys)}\n")
        for bs in BackupServer().get_all():
            vals = ['bs']
            for key in backup_server_keys:
                if key == 'backup_server_group_id':
                    vals.append(BSZ(id=bs.backup_server_group_id).label)
                else:
                    vals.append(str(bs.__dict__[key]))
            cp_cfg.write(f"{';'.join(vals)}\n")

        # Store Backup Server Zones
        cp_cfg.write(f"{';'.join([''] + bsz_keys)}\n")
        for bsz in BSZ().get_all():
            vals = ['bsz']
            for key in bsz_keys:
                if key == 'location_group_id' and bsz.__dict__[key]:
                    vals.append(LocationGroup(id=bsz.__dict__[key]).city)
                else:
                    vals.append(str(bsz.__dict__[key]))
            cp_cfg.write(f"{';'.join(vals)}\n")

        # Store Backup Server Joins
        cp_cfg.write(f"{';'.join([''] + bs_join_keys)}\n")
        for hvz in HypervisorZone().get_all():
            for bs_join in BackupServerJoin(parent_obj=hvz).get_all():
                vals = ['bs_join']
                for key in bs_join_keys:
                    if key == "target_join_id":
                        vals.append(HypervisorZone(id=bs_join.__dict__[key]).label)
                    elif key == "backup_server_id":
                        vals.append(BackupServer(id=bs_join.__dict__[key]).label)
                    else:
                        vals.append(str(bs_join.__dict__[key]))
                cp_cfg.write(f"{';'.join(vals)}\n")

        for hv in Hypervisor().get_all():
            for bs_join in BackupServerJoin(parent_obj=hv).get_all():
                vals = ['bs_join']
                for key in bs_join_keys:
                    if key == "target_join_id":
                        vals.append(Hypervisor(id=bs_join.__dict__[key]).label)
                    elif key == "backup_server_id":
                        vals.append(BackupServer(id=bs_join.__dict__[key]).label)
                    else:
                        vals.append(str(bs_join.__dict__[key]))
                cp_cfg.write(f"{';'.join(vals)}\n")

        cp_cfg.close()


def roll_out(csv_config_file_path):
    global hvz_keys, hv_keys, dsz_keys, ds_keys, ds_join_keys, ntz_keys, \
        net_keys, net_join_keys, ip_network_keys, ip_range_keys, \
        backup_server_keys, location_group_keys, bsz_keys, bs_join_keys

    with open(csv_config_file_path) as f:
        cp_cfg = f.readlines()
        cp_cfg = [line.replace('\n', '') for line in cp_cfg]

    # HVZ
    hvzs = [line.split(';') for line in cp_cfg if line.split(';')[0] == 'hvz']
    for hvz in hvzs:
        obj = HypervisorZone()
        for index, key in enumerate(hvz_keys):
            value = hvz[index + 1]
            if value.lower() in ['true', 'false']:
                value = True if value.lower() == 'true' else False
            obj.__dict__[key] = value
        obj.create()

    # HV
    hvs = [line.split(';') for line in cp_cfg if line.split(';')[0] == 'hv']
    for hv in hvs:
        obj = Hypervisor()
        for index, key in enumerate(hv_keys):
            value = hv[index + 1]
            if value.lower() in ['true', 'false']:
                value = True if value.lower() == 'true' else False
            if key == 'hypervisor_group_id' and value != 'None':
                value = [
                    hvz.id for hvz in HypervisorZone().get_all()
                    if hvz.label == value
                ][0]
            obj.__dict__[key] = value
        obj.create()

    # DSZ
    dszs = [line.split(';') for line in cp_cfg if line.split(';')[0] == 'dsz']
    for dsz in dszs:
        obj = DataStoreZone()
        for index, key in enumerate(dsz_keys):
            value = dsz[index + 1]
            if value.lower() in ['true', 'false']:
                value = True if value.lower() == 'true' else False
            elif value == 'None':
                value = None

            if key == 'location_group_id':
                if value == 'None':
                    value = None
                else:
                    lg_ids = [
                        lg.id for lg in LocationGroup().get_all()
                        if lg.city == value
                    ]
                    value = lg_ids[0] if lg_ids else None

            obj.__dict__[key] = value
        obj.create()

    # DS
    dss = [line.split(';') for line in cp_cfg if line.split(';')[0] == 'ds']
    for ds in dss:
        obj = DataStore()
        for index, key in enumerate(ds_keys):
            value = ds[index + 1]
            if value.lower() in ['true', 'false']:
                value = True if value.lower() == 'true' else False

            if value == 'None':
                value = None

            if key == 'data_store_group_id' and value:
                value = [
                    dsz.id for dsz in DataStoreZone().get_all()
                    if dsz.label == value
                ][0]
            obj.__dict__[key] = value
        obj.create()
        # Change identifier in DB
        identifier = ds[ds_keys.index('identifier') + 1]
        label = ds[ds_keys.index('label') + 1]
        test.cp.mysql_execute(
            f"UPDATE data_stores SET identifier='{identifier}' WHERE label='{label}'"
        )

    # DS Joins
    ds_joins = [line.split(';') for line in cp_cfg if line.split(';')[0] == 'ds_join']
    for ds_join in ds_joins:
        target_join_type = ds_join[ds_join_keys.index('target_join_type') + 1]
        target_join_label = ds_join[ds_join_keys.index('target_join_id') + 1]
        ds_label = ds_join[ds_join_keys.index('data_store_id') + 1]
        target_obj = Hypervisor if target_join_type == 'Hypervisor' else HypervisorZone
        parent_objs = [
            o for o in target_obj().get_all() if o.label == target_join_label
        ]
        if parent_objs:
            obj = DataStoreJoin(
                parent_obj=parent_objs[0]
            )
            for index, key in enumerate(ds_join_keys):
                value = ds_join[index + 1]
                obj.__dict__[key] = value
            data_store = [
                ds for ds in DataStore().get_all() if ds.label == ds_label
            ][0]
            obj.add(data_store)

    # NTZ
    ntzs = [line.split(';') for line in cp_cfg if line.split(';')[0] == 'ntz']
    for ntz in ntzs:
        obj = NetworkZone()
        for index, key in enumerate(ntz_keys):
            value = ntz[index + 1]
            if value.lower() in ['true', 'false']:
                value = True if value.lower() == 'true' else False
            elif value == 'None':
                value = None

            if key == 'location_group_id':
                if value == 'None':
                    value = None
                else:
                    lg_ids = [
                        lg.id for lg in LocationGroup().get_all()
                        if lg.city == value
                    ]
                    value = lg_ids[0] if lg_ids else None

            obj.__dict__[key] = value
        obj.create()

    # Network
    nets = [line.split(';') for line in cp_cfg if line.split(';')[0] == 'net']
    for net in nets:
        obj = Network()
        for index, key in enumerate(net_keys):
            value = net[index + 1]
            if value.lower() in ['true', 'false']:
                value = True if value.lower() == 'true' else False

            if value == 'None':
                value = None

            if key == 'network_group_id':
                value = [
                    z.id for z in NetworkZone().get_all()
                    if z.label == value
                ][0]
            obj.__dict__[key] = value
        obj.create()

    # Net Join
    net_joins = [line.split(';') for line in cp_cfg if line.split(';')[0] == 'net_join']
    for net_join in net_joins:
        target_join_type = net_join[net_join_keys.index('target_join_type') + 1]
        target_join_label = net_join[net_join_keys.index('target_join_id') + 1]
        net_label = net_join[net_join_keys.index('network_id') + 1]
        interface = net_join[net_join_keys.index('interface') + 1]
        target_obj = Hypervisor if target_join_type == 'Hypervisor' else HypervisorZone
        parent_objs = [
            o for o in target_obj().get_all() if o.label == target_join_label
        ]
        if parent_objs:
            obj = NetworkJoin(
                parent_obj=parent_objs[0]
            )
            network = [
                net for net in Network().get_all() if net.label == net_label
            ][0]
            obj.interface = interface
            obj.add(network)

    # IP Net
    ip_nets = [line.split(';') for line in cp_cfg if line.split(';')[0] == 'ip_net']
    for ip_net in ip_nets:
        network_label = ip_net[ip_network_keys.index('network_label') + 1]
        parent_objs = [
                    n for n in Network().get_all() if n.label == network_label
                ]
        if parent_objs:
            obj = IpNetwork(parent_obj=parent_objs[0])
            for index, key in enumerate(ip_network_keys):
                value = ip_net[index + 1]
                if value.lower() in ['true', 'false']:
                    value = True if value.lower() == 'true' else False

                if value == 'None':
                    value = None

                obj.__dict__[key] = value
            obj.create()

    # IP Range
    ip_ranges = [line.split(';') for line in cp_cfg if line.split(';')[0] == 'ip_range']
    for ip_range in ip_ranges:
        network_label = ip_range[ip_range_keys.index('network_label') + 1]
        ip_net_label = ip_range[ip_range_keys.index('ip_net_label') + 1]
        network_parent_objs = [
            n for n in Network().get_all() if n.label == network_label
        ]
        if network_parent_objs:
            ip_net = [
                ip_net for ip_net in IpNetwork(
                    parent_obj=network_parent_objs[0]
                ).get_all()
                if ip_net.label == ip_net_label
            ][0]
            obj = IpRange(parent_obj=ip_net)
            for index, key in enumerate(ip_range_keys):
                value = ip_range[index + 1]
                if value.lower() in ['true', 'false']:
                    value = True if value.lower() == 'true' else False

                if value == 'None':
                    value = None

                obj.__dict__[key] = value
            obj.create()

    # BSZ
    bszs = [line.split(';') for line in cp_cfg if line.split(';')[0] == 'bsz']
    for bsz in bszs:
        obj = BSZ()
        for index, key in enumerate(bsz_keys):
            value = bsz[index + 1]
            if value.lower() in ['true', 'false']:
                value = True if value.lower() == 'true' else False
            elif value == 'None':
                value = None

            if key == 'location_group_id':
                if value == 'None':
                    value = None
                else:
                    lg_ids = [
                        lg.id for lg in LocationGroup().get_all()
                        if lg.city == value
                    ]
                    value = lg_ids[0] if lg_ids else None

            obj.__dict__[key] = value
        obj.create()

    # BS
    bss = [line.split(';') for line in cp_cfg if line.split(';')[0] == 'bs']
    for bs in bss:
        obj = BackupServer()
        for index, key in enumerate(backup_server_keys):
            value = bs[index + 1]
            if value.lower() in ['true', 'false']:
                value = True if value.lower() == 'true' else False

            if value == 'None':
                value = None

            if key == 'backup_server_group_id':
                value = [
                    bsz.id for bsz in BSZ().get_all()
                    if bsz.label == value
                ][0]
            obj.__dict__[key] = value
        obj.create()

    # BS Joins
    bs_joins = [line.split(';') for line in cp_cfg if line.split(';')[0] == 'bs_join']
    for bs_join in bs_joins:
        target_join_type = bs_join[bs_join_keys.index('target_join_type') + 1]
        target_join_label = bs_join[bs_join_keys.index('target_join_id') + 1]
        backup_server_label = bs_join[bs_join_keys.index('backup_server_id') + 1]
        target_obj = Hypervisor if target_join_type == 'Hypervisor' else HypervisorZone
        obj = BackupServerJoin(
            parent_obj=[
                o for o in target_obj().get_all() if o.label == target_join_label
            ][0]
        )
        for index, key in enumerate(bs_join_keys):
            value = bs_join[index + 1]
            obj.__dict__[key] = value
        backup_server = [
            bs for bs in BackupServer().get_all() if bs.label == backup_server_label
        ][0]
        obj.add(backup_server)


if __name__ == '__main__':
    if sys.argv[1] == '-d':  # dump
        dump()
    elif sys.argv[1] == '-r':  # roll out
        if input(
                f'Make sure that your ssh key is present on CP before rolling out\n'
                f'You really want to roll out configuration on {test.host} CP?\n'
                f'If so please type "yes":'
        ) == 'yes':
            roll_out(sys.argv[2])
    else:
        print("Undefined argument ")
        sys.exit()
