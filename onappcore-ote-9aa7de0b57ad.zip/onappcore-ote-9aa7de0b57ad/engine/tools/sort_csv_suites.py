import sys
import csv

if len(sys.argv) < 2:
    sys.exit('Error: Please enter the path to csv file.')

csv_path = sys.argv[1]
tmp = []

with open(csv_path) as f:
    data = csv.reader(f, delimiter=',')
    for d in data:
        s, n, du, de = d
        tmp.append([n, s, du, de])

tmp.sort()

csv_sorted = './doc/suites_csv_sorted.csv'
with open(csv_sorted, 'w', newline='') as csvfile:
    writer = csv.writer(csvfile, delimiter=',', quoting=csv.QUOTE_MINIMAL)
    for s in tmp:
        writer.writerow(s)