__doc__ = """
Generate multi jobs like:

    phase('PYTHON. Templates', 'ALWAYS') {
      phaseJob('STABLE /Templates/TestTemplateAbilities')
    }
    phase('PYTHON. Tickets', 'ALWAYS') {
      phaseJob('STABLE /Tickets/TestRakeTaskUpgradeCheck')
      phaseJob('STABLE /Tickets/Core-5564/TestCore5564')
    }

"""

import os
from sys import version_info

TEST_ENVS = [
    'OTE_UNSTABLE_37',
    'OTE_STABLE_38',
    'OTE_OSTACK233',
    'OTE_DEV5',
    'OTE_QA1',
    'OTE_STORAGE_178'
]
test_envs = TEST_ENVS
V_ENV_VERSION = '{}.{}'.format(version_info.major, version_info.minor)

current_directory = os.getcwd()
# test_envs = os.environ.get('TEST_ENV').split(',')

SEQUENTIALLY_PHASES = [
    "ApplicationServer",
    "Backups",
    "Lb",
    "Ova",
    "VirtualServer",
    "Iso",
]


def jobs_filter(env, tfp):
    return (
                   env in [
               'OTE_UNSTABLE_37',
               'OTE_STABLE_38',
               'OTE_DEV5',
               'OTE_QA1'
           ] and ('openstack' not in tfp or 'baremetal' not in tfp)
            or (env in ['OTE_OSTACK233'] and 'openstack' in tfp) or (env in ['OTE_STORAGE_178'] and 'baremetal' in tfp)
    )

test_file_paths = []

for path, subdirs, files in os.walk('./test_suites'):
    for name in files:
        test_file_path = os.path.join(path, name)
        if '.py' == test_file_path[-3:] \
                and '__' not in test_file_path \
                and 'own_usage' not in test_file_path \
                and 'conftest.py' not in test_file_path:
            test_file_paths.append(test_file_path)
#print(test_file_paths)
for env in test_envs:
    # Daily
    daily_multi_jobs_path = './doc/daily_multi_jobs_{}'.format(env)
    daily_multi_jobs = open(daily_multi_jobs_path, 'w')
    # Regressions (weekly)
    regressions_multi_jobs_path = './doc/regressions_multi_jobs_{}'.format(env)
    regressions_multi_jobs = open(regressions_multi_jobs_path, 'w')

    # Write head
    # Put before customWorkspace:
    # triggers {{
    #   timerTrigger {{
    #     spec('30 14 * * 1-5')
    #   }}
    # }}

    daily_multi_jobs.write(
        """multiJob('Daily Regular Aggregator on the {env} Env') {{
  customWorkspace('{work_space}')
  steps {{
    shell('rm -rfv ./reports/{env}/allure-results/*')\n""".format(
            work_space=current_directory, env=env
        )
    )

    # Put before customWorkspace:
    # triggers {{
    #   timerTrigger {{
    #     spec('5 1 * * 6')
    #   }}
    # }}
    regressions_multi_jobs.write(
        """multiJob('Regression tests on the {env} Env') {{
  customWorkspace('{work_space}')
  steps {{
    shell('rm -rfv ./reports/{env}/allure-results/*')\n""".format(
            work_space=current_directory, env=env
        )
    )

    daily_existed_phases = []
    daily_phase_jobs = []
    regression_existed_phases = []
    regression_phase_jobs = []
    use_close_path_brase_for_daily_jobs = False
    use_close_path_brase_for_regression_jobs = False
    at_least_one_daily_job_is_present = False
    at_least_one_regression_job_is_present = False

    test_file_paths.sort()

    for tfp in test_file_paths:
        if jobs_filter(env, tfp):
            tfpl = tfp.split('/')[2:]
            job_names = []  # ['Lb', 'TestLbCluster']
            tag = ''
            for name in tfpl:
                if '.py' not in name:
                    job_names.append(
                        ''.join([j.capitalize() for j in name.split('_')])
                    )
                else:
                    with open(tfp) as test_file:
                        tag = test_file.readline()
                    job_names.append(
                        ''.join([j.capitalize() for j in name[:-3].split('_')])
                    )
                job_name = '/'.join(job_names)  # each job name like Lb/TestLbCluster
                phase = job_names[0]

            if 'daily' in tag and phase not in daily_existed_phases:
                #print('    }')
                if use_close_path_brase_for_daily_jobs:
                    daily_multi_jobs.write('    }\n')  # close phase
                else:
                    use_close_path_brase_for_daily_jobs = True
                daily_existed_phases.append(phase)
                s = "    phase('OTE. {}', 'ALWAYS') {{\n".format(phase)

                #print(s)
                daily_multi_jobs.write(s)  # write phase
                if phase in SEQUENTIALLY_PHASES:
                    daily_multi_jobs.write("      executionType('SEQUENTIALLY')\n")

                if not at_least_one_daily_job_is_present:
                    at_least_one_daily_job_is_present = True

            if 'ignore' not in tag and phase not in regression_existed_phases:
                #print('    }')
                if use_close_path_brase_for_regression_jobs:
                    regressions_multi_jobs.write('    }\n')  # close phase
                else:
                    use_close_path_brase_for_regression_jobs = True
                regression_existed_phases.append(phase)
                s = "    phase('OTE. {}', 'ALWAYS') {{\n".format(phase)
                #print(s)
                regressions_multi_jobs.write(s)  # write phase
                if phase in SEQUENTIALLY_PHASES:
                    regressions_multi_jobs.write(
                        "      executionType('SEQUENTIALLY')\n"
                    )

                if not at_least_one_regression_job_is_present:
                    at_least_one_regression_job_is_present = True

            s = "      phaseJob('{}/{}')\n".format(env, job_name)
            #print(s)
            if 'daily' in tag:
                daily_multi_jobs.write(s)  # write job
            if 'ignore' not in tag:
                regressions_multi_jobs.write(s)

    #print('    }')
    #daily_multi_jobs.write('    }\n  }\n}\n')  # close phase
    if at_least_one_daily_job_is_present:
        daily_multi_jobs.write("    }")

    daily_multi_jobs.write(
        """}}

  publishers {{
    allure {{
      results {{
        resultsConfig {{
          path('reports/{env}/allure-results')
        }}
      }}
      report('reports/{env}_daily_reports')
    }}
    postBuildTask {{
      task('Allure report was successfully generated.', 'source {work_space}/venv/ote{v_env_version}/bin/activate; export PYTHONPATH="$PYTHONPATH:{work_space}"; python ./engine/tools/load_reports_to_google_docs.py {env}')
    }}
  }}
}}
""".format(
            env=env,
            v_env_version=V_ENV_VERSION,
            work_space=current_directory
        )
    )

    if at_least_one_regression_job_is_present:
        regressions_multi_jobs.write("    }")

    regressions_multi_jobs.write(
        """}}

  publishers {{
    allure {{
      results {{
        resultsConfig {{
          path('reports/{env}/allure-results')
        }}
      }}
      report('reports/{env}_regression_reports')
    }}
    postBuildTask {{
      task('Allure report was successfully generated.', 'source {work_space}/venv/ote{v_env_version}/bin/activate; export PYTHONPATH="$PYTHONPATH:{work_space}"; python ./engine/tools/load_reports_to_google_docs.py {env}')
    }}
  }}
}}
""".format(
            env=env,
            v_env_version=V_ENV_VERSION,
            work_space=current_directory
        )
    )

    daily_multi_jobs.close()
    regressions_multi_jobs.close()

    print(
        'You can see generated multi jobs here:\n\t {}\n\t {}'.format(
            daily_multi_jobs_path, regressions_multi_jobs_path
        )
    )

