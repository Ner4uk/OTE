import os
import sys

from onapp_helper import test

dump_name = sys.argv[-1] + '.sql.gz'
test.cp.db_init()
test.log.info("Execute mysqldump")
test.cp.mysql_dump(dump_name)
scp_command = 'scp root@{}:/tmp/{} {}'.format(
    test.host, dump_name, os.path.join(test.wd, 'log')
)
test.log.info("Execute {}".format(scp_command))
os.system(scp_command)
test.log.info("Delete dump on CP")
test.cp.ssh.execute('rm -rfv /tmp/{}'.format(dump_name))