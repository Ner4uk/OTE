import os
from shutil import rmtree

test_file_paths = []

current_directory = os.getcwd()

if not os.path.exists(os.path.join(current_directory, 'doc')):
    os.mkdir(os.path.join(current_directory, 'doc'))

for path, subdirs, files in os.walk('./test_suites'):
    for name in files:
        test_file_path = os.path.join(path, name)
        if '.py' == test_file_path[-3:] \
                and '__' not in test_file_path\
                and 'own_usage' not in test_file_path\
                and 'conftest.py' not in test_file_path:
            test_file_paths.append(test_file_path)


#groovy_jobs_path = './doc/groovy_jobs_{}_{}'.format(cloud, env)
#groovy_jobs = open(groovy_jobs_path, 'w')
existed_folders = []

# Write head


test_file_paths.sort()
#print(test_file_paths)

test_plan_path = os.path.join(current_directory, 'doc', 'test_plan')
# Clear directory
rmtree(test_plan_path)
if not os.path.exists(test_plan_path):
    os.mkdir(test_plan_path)

for tfp in test_file_paths:
    tfpl = tfp.split('/')[2:]
    plan = open(os.path.join(test_plan_path, tfpl[0]), 'a')
    test_fo = open(tfp)
    test = test_fo.readlines()
    test_names = [l.split(' ')[1] for l in test if 'class ' in l]
    if test_names:
        test_name = test_names[0].split('(')[0]
    else:
        test_name = ''.join([w.capitalize() for w in tfpl[-1][:-3].split('_')])
    test_cases = [
        l.lstrip().split(' ')[1][5:].split('(')[0] for l in test if 'def test_' in l
        ]

    plan.write("{}\n".format(test_name))
    [plan.write("{}\n".format(case)) for case in test_cases]
    plan.write('\n')

    plan.close()
    test_fo.close()

    # job_names = []
    # for name in tfpl:
    #     if '.py' not in name:
    #         job_names.append(''.join([j.capitalize() for j in name.split('_')]))
    #     else:
    #         job_names.append(''.join([j.capitalize() for j in name[:-3].split('_')]))
    #     job_name = '/'.join(job_names)
    #     print(job_name)
#
#         if '.py' == name[-3:]:
#
#             print(job)
#             #groovy_jobs.write(job)
#         elif job_name not in existed_folders:
#             job = """
# folder("$topName/{}") {{
# description 'This Folder contains all {} tests'
# }}""".format(job_name, job_name)
#             existed_folders.append(job_name)
#             #print(job)
#             #groovy_jobs.write(job)
#         else:
#             pass
# #groovy_jobs.close()
# #print('You can see generated groovy jobs here: {}'.format(groovy_jobs_path))
