import os
from engine.lib.config import TestConfig
from sys import version_info

test_config = TestConfig()

JENKINS_HOST = test_config.jenkins_host
JENKINS_PORT = test_config.jenkins_port

clouds = ['dev37', 'dev38', 'ostack233', 'dev5', 'qa1', 's_178']
envs = [
    'OTE_UNSTABLE_37',
    'OTE_STABLE_38',
    'OTE_OSTACK233',
    'OTE_DEV5',
    'OTE_QA1',
    'OTE_STORAGE_178'
]
# clouds = os.environ.get('CLOUD').split(',')
# envs = os.environ.get('TEST_ENV').split(',')
data = list(zip(clouds, envs))

V_ENV_VERSION = '{}.{}'.format(version_info.major, version_info.minor)

test_file_paths = []

current_directory = os.getcwd()


def jobs_filter(cloud, tfp):
    return (
                   cloud in ['dev37', 'dev38', 'dev5', 'qa1']
                   and ('openstack' not in tfp or 'baremetal' not in tfp)
            or (cloud in ['ostack233'] and 'openstack' in tfp) or (cloud in ['s_178'] and 'baremetal' in tfp)
    )

# Create allure report directories
for env in envs:
    sub_dirs = 'reports/{}/allure-results'.format(env)
    path = os.path.join(
                current_directory,
                sub_dirs
            )
    if os.path.isfile(path):
        os.remove(path)
    if not os.path.exists(path):
        os.makedirs(path)

if not os.path.exists(os.path.join(current_directory, 'doc')):
    os.mkdir(os.path.join(current_directory, 'doc'))

for path, subdirs, files in os.walk('./test_suites'):
    for name in files:
        test_file_path = os.path.join(path, name)
        if '.py' == test_file_path[-3:] \
                and '__' not in test_file_path\
                and 'own_usage' not in test_file_path\
                and 'conftest.py' not in test_file_path:
            test_file_paths.append(test_file_path)


for cloud, env in data:
    groovy_jobs_path = './doc/groovy_jobs_{}_{}'.format(cloud, env)
    groovy_jobs = open(groovy_jobs_path, 'w')

    tests_table_path = './doc/tests_located_on_{}_{}'.format(cloud, env)
    tests_table = open("{}.csv".format(tests_table_path), 'w')
    tests_table.write(
        "Note - original files located on http://{}:{}/job/OTE_SEED/ws/doc/tests_located_on_*\n".format(
            JENKINS_HOST, JENKINS_PORT
        )
    )

    existed_folders = []

    # Write head
    groovy_jobs.write(
        """
String topName     = '{}'

//create following config files:
//dayly run configuration
//weekly run configuration
//regression run
//templates test execution including trigger by url

folder(topName) {{
 description 'This Folder contains all stable tests'
}}""".format(env)
    )

    test_file_paths.sort()

    for tfp in test_file_paths:
        tfpl = tfp.split('/')[2:]
        job_names = []
        for name in tfpl:
            if '.py' not in name:
                job_names.append(''.join([j.capitalize() for j in name.split('_')]))
            else:
                job_names.append(''.join([j.capitalize() for j in name[:-3].split('_')]))
            job_name = '/'.join(job_names)

            if '.py' == name[-3:] and jobs_filter(cloud, tfp):
                junit_file_path = '/'.join(tfpl).split('.')[0]
                job = """
job("$topName/{job_name}"){{
    customWorkspace('{work_space}')
    wrappers {{
        colorizeOutput(colorMap = 'xterm')
    }}
    steps{{
        shell('source {work_space}/venv/ote{v_env_version}/bin/activate; export PYTHONPATH="$PYTHONPATH:{work_space}"; CLOUD={CLOUD} HV_TYPE=xen,kvm py.test -s --resultlog=./reports/{ENV}/{test_file_name}/{test_file_name}.txt --alluredir=./reports/{ENV}/{test_file_name}/allure-results ./test_suites/{test_path}')
    }}
    publishers {{
        postBuildTask {{
            task('Status', 'mv -v ./reports/{ENV}/{test_file_name}/allure-results/*.xml ./reports/{ENV}/allure-results/')
        }}
    }}
}}
                """.format(
                    work_space=current_directory,
                    job_name=job_name,
                    v_env_version=V_ENV_VERSION,
                    CLOUD=cloud,
                    ENV=env,
                    test_file_name=tfpl[-1][:-3],
                    test_path='/'.join(tfpl)
                )
                #print(job)
                groovy_jobs.write(job)

                # Create doc with test locations
                test_url = os.path.join(
                    "http://{}:{}/job/{}/job".format(
                        JENKINS_HOST, JENKINS_PORT, env
                    ),
                    "/job/".join(job_names)
                )
                tests_table.write("{};{};\n".format(tfpl[-1][:-3], test_url))

            elif job_name not in existed_folders and jobs_filter(cloud, tfp):
                job = """
folder("$topName/{}") {{
    description 'This Folder contains all {} tests'
}}""".format(job_name, job_name)
                existed_folders.append(job_name)
                #print(job)
                groovy_jobs.write(job)
                tests_table.write("{}\n".format(job_name))
            else:
                pass
    groovy_jobs.close()
    print('You can see generated groovy jobs here: {}'.format(groovy_jobs_path))
