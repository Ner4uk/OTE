import os
import sys
from engine.lib.config import OteConfig

PYTHON_VERSION = OteConfig(section='env').python_version


def execute(python_release):
    python_version = python_release[:3]
    if os.system('python%s --version' % python_version):
        # Skip download process if archive exist
        if not os.system('ls -l | grep Python-%s.tgz' % python_release):
            os.system('printf "\n\nDownload python %s\n"' % python_release)
            if os.system(
                'wget https://www.python.org/ftp/python/%s/Python-%s.tgz' % (
                            python_release, python_release
                    )
            ):
                sys.exit()

        # Define package manager
        package_manager = ''
        if not os.system('yum --version'):
            package_manager = 'sudo yum'
        elif not os.system('apt-get --version'):
            package_manager = 'sudo apt-get'
        elif not os.system('brew --version'):
            package_manager = 'brew'

        if not package_manager:
            sys.exit('No package manager found.')

        # Install required packages (checked for Centos)
        if os.system('gcc --version'):
            os.system('printf "\n\nInstall dependency: gcc\n"')
            os.system('%s install gcc build-essential' % package_manager)

        # For ubuntu, linux mint
        # https://tecadmin.net/install-python-3-6-ubuntu-linuxmint/
        if 'apt-get' in package_manager:
            os.system('printf "\n\nInstall dependency:\n"')
            os.system("sudo apt-get install build-essential checkinstall")
            packages = [
                "libreadline-gplv2-dev",
                "libncursesw5-dev",
                "libssl-dev",
                "libsqlite3-dev",
                "tk-dev",
                "libgdbm-dev",
                "libc6-dev",
                "libbz2-dev"
            ]
            os.system("sudo apt-get install %s" % ' '.join(packages))

        os.system('printf "\n\nInstall dependency: zlib-devel\n"')
        os.system('%s install zlib-devel zlib1g-dev' % package_manager)

        os.system('printf "\n\nInstall dependency: openssl-devel\n"')
        os.system('%s install openssl-devel' % package_manager)

        # Install python
        os.system('printf "\n\nInstall python %s"' % python_release)
        os.system('printf "\nUnpack archive.\n"')
        if os.system('tar -zxvf ./Python-%s.tgz' % python_release):
            sys.exit()

        os.system('printf "\n\nChange dir to ./Python-%s\n"' % python_release)
        os.chdir('./Python-%s' % python_release)

        os.system('printf "\n\nConfigure...\n"')
        if os.system('./configure'):
            sys.exit()

        os.system('printf "\n\nmake...\n"')
        if os.system('make'):
            sys.exit()

        os.system('printf "\n\nmake test...\n"')
        if os.system('make test'):
            sys.exit()

        os.system('printf "\n\nsudo make install...\n"')
        if os.system('sudo make install'):
            sys.exit()

        os.system('printf "\n\nChange dir to %s\n"' % os.getcwd())
        os.chdir('..')

        os.system('printf "\n\nRemove archive with unpacked files\n"')
        os.system('rm -rfv ./Python-%s*' % python_release)
    else:
        os.system(
            'printf "Python %s has already been installed."' % python_version
        )

    os.system('printf "\n\nUpgrade PIP\n"')
    if os.system('pip%s install --upgrade pip' % python_version):
        sys.exit()

    os.system('printf "\n\nCreate virtual environment.\n"')
    if os.system(
        'python%s -m venv --prompt=ote%s ./venv/ote%s' % (
            python_version, python_version, python_version
        )
    ):
        sys.exit()

    os.system('printf "\n\nInstall requirements\n"')
    if os.system(
        '. ./venv/ote%s/bin/activate && '
        'pip install -r requirements.txt && '
        'ipython profile create ote' % python_version
    ):
        if os.system(
                '. ./venv/ote%s/bin/activate && '
                'pip install -r requirements.txt && '
                'ipython profile create ote' % python_version
        ):
            exit()

    os.system('printf "\n\nConfigure..."')
    if 'PYTHONPATH' not in os.environ:
        if os.system(
            '\necho "export PYTHONPATH=%s" >> ~/.bashrc' % os.getcwd()
        ):
            sys.exit()
    elif os.getcwd() not in os.environ['PYTHONPATH']:
        if os.system(
            '\necho "export PYTHONPATH=\"$PYTHONPATH:%s\"" >> ~/.bashrc' % os.getcwd()
        ):
            sys.exit()

    if os.getcwd() not in os.environ['PATH']:
        if os.system(
            '\necho "export PATH=\"$PATH:%s\"" >> ~/.bashrc' % os.getcwd()
        ):
            sys.exit()

    dst = os.path.join(
        os.environ['HOME'],
        '.ipython/profile_ote/ipython_config.py'
    )
    s1 = "c.InteractiveShellApp.exec_lines.append('%load_ext autoreload')\n"
    s2 = "c.InteractiveShellApp.exec_lines.append('%autoreload 2')\n"

    ipython_config = open(dst, 'r+')
    r = ipython_config.read()
    if s1 not in r:
        ipython_config.write(s1)
    if s2 not in r:
        ipython_config.write(s2)
    ipython_config.close()

    os.system(
        'printf "\n\nOTE has been successfully installed and configured...\n"'
    )

    os.system(
        'printf \'Please re login to your console to apply a new bashrc records.\'\n'
    )

    os.system(
        'printf \'Execute \"source ./venv/ote%s/bin/activate\" to activate '
        'your virtual environment.\n\'' % python_version
    )


if __name__ == '__main__':
    execute(PYTHON_VERSION)
