from ruamel import yaml
from sys import version_info
import os

WORKSPACE = os.getcwd()

scripts_dir = os.path.join(WORKSPACE, 'scripts')
if not os.path.exists(scripts_dir):
    os.mkdir(scripts_dir)

V_ENV_VERSION = '{}.{}'.format(version_info.major, version_info.minor)

jobs_config = yaml.safe_load(open('./conf/jenkins_jobs.yml'))
groovy_jobs = open("./doc/jenkins_jobs", 'w')

for cloud in jobs_config.keys():
    groovy_jobs.write(
        """
folder('{cloud}') {{
  description 'For executing on {cloud}'
}}""".format(cloud=cloud)
    )
    for job in jobs_config[cloud]:
        label = job['label']
        rules = job['rules']
        update_cp_cmd = job['update_cp_cmd'] if 'update_cp_cmd' in job else ''
        schedule = job['schedule'] if 'schedule' in job else ''

        allure_results_dir = "reports/{cloud}/{label}/allure-results".format(
            cloud=cloud, label='_'.join(label.split(' '))
        )
        if not os.path.exists(allure_results_dir):
            os.makedirs(allure_results_dir)

        allure_report_dir = "reports/{cloud}/{label}/allure-reports".format(
            cloud=cloud, label='_'.join(label.split(' '))
        )
        if not os.path.exists(allure_report_dir):
            os.makedirs(allure_report_dir)

        tests_runner_script = ['#!/bin/sh']

        tests_runner_script.append(
            "rm -rfv {path}/*".format(
                path=allure_results_dir, cloud=cloud, label=label
            )
        )
        tests_runner_script.append(
            "rm -rfv {path}/*".format(
                path=allure_report_dir, cloud=cloud, label=label
            )
        )
        tests_runner_script.append(
            'source ./venv/ote{v_env_version}/bin/activate'.format(
                v_env_version=V_ENV_VERSION
            )
        )
        tests_runner_script.append(
            'export PYTHONPATH="$PYTHONPATH:{work_space}"'.format(
                work_space=WORKSPACE
            )
        )

        if update_cp_cmd:
            tests_runner_script.append(
                f'./ote -C {cloud} -u "{update_cp_cmd}"'
            )

        for rule in rules:
            pytest_configuration = [
                'CLOUD={cloud}'.format(cloud=cloud),
                'HV_TYPE=xen,kvm',
                'py.test',
                '-n auto --dist=loadfile' if 'parallel' in rule else '',
                '-m "{rule}"'.format(rule=rule),
                '--continue-on-collection-errors',
                '--alluredir={path}'.format(
                    path=allure_results_dir, cloud=cloud, label='_'.join(label.split(' '))
                ),
                './test_suites',
                '|| true'  # to ignore non 0 status code
            ]

            tests_runner_script.append(' '.join(pytest_configuration))

            tests_runner_script.append(
                'mv -v {path_results}/* {path_reports}/ || true'.format(
                    path_results=allure_results_dir,
                    path_reports=allure_report_dir
                )
            )  # '|| true' to ignore 'No such file or directory' error

        script_path = os.path.join(scripts_dir, f'{cloud}_{label}.sh')
        with open(script_path, 'w') as script:
            script.writelines([f'{l}\n' for l in tests_runner_script])

        allure_publisher = """allure {{
      results {{
        resultsConfig {{
          path('{path}')
        }}
      }}
      report('reports/{cloud}_{label}')
    }}""".format(
            path=allure_report_dir, cloud=cloud, label='_'.join(label.split(' '))
        )

        wrapper = "colorizeOutput(colorMap = 'xterm')"

        job = """
job("{cloud}/{job_name}") {{
  customWorkspace('{work_space}')
  triggers {{
    cron('{schedule}')
  }}
  wrappers {{
    {wrapper}
  }}
  steps {{
    {steps}
  }}
  publishers {{
    {allure_publisher}
  }}
}}""".format(
            cloud=cloud,
            job_name='_'.join(label.split(' ')),
            work_space=WORKSPACE,
            schedule=schedule,
            wrapper=wrapper,
            steps=f'shell("bash -ex {script_path}")',
            allure_publisher=allure_publisher
        )

        groovy_jobs.write(job)
