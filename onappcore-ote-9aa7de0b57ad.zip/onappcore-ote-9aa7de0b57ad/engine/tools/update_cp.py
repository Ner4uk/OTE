__author__ = 'zhuk'
__doc__ = """Update CP to the latest rpm version."""

import re
import sys

from onapp_helper import test

FULL_VERSION_PATTERN = r'\d+.\d+.\d+-\d+'

cmd = ' '.join(sys.argv[1:])

exit_status, data = test.cp.ext_execute('yum check-update onapp-cp')

if exit_status:
    rpm_version = re.findall(string=data, pattern=FULL_VERSION_PATTERN)[0]
    print(f'Current CP version is: {test.cp_version.full()}')
    print(f'Current rpm version is: {rpm_version}')
    test.cp.execute(cmd)
else:
    print("No need to update CP")
