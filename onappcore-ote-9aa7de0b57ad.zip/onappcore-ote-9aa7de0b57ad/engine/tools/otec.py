#! /usr/bin/env python
import os


def generate_imports_file():
    helper_file_paths = []

    for path, subdirs, files in os.walk('./onapp_helper'):
        for name in files:
            test_file_path = os.path.join(path, name)
            if '.py' == test_file_path[-3:] \
                    and '__init__' not in test_file_path:
                helper_file_paths.append(test_file_path)

    with open('./engine/tools/otec_imports.py', 'w') as imports:
        imports.write('try:\n')
        imports.write('    from onapp_helper import test\n')
        imports.write('    from engine.lib.cp import CP\n')

        for p in helper_file_paths:
            imports.write(
                ' '.join(
                    ["    from", '.'.join(p.split('.')[1].split('/')[1:]),
                     'import *\n']
                )
            )

        imports.write('except ImportError as e:\n')
        imports.write('    print(\'\\n\\n\', e, \'please execute "ote '
                      '--upgrade-packages"\')\n')
        imports.write('    exit()\n')


def execute(params):
    generate_imports_file()
    os.system(
        'ln -f ./engine/tools/otec_imports.py ~/.ipython/profile_ote/startup/00-ote.py'
    )
    print('{} ipython --profile=ote'.format(' '.join(params)))
    os.system('{} ipython --profile=ote'.format(' '.join(params)))
