# For Python 3.5+
# https://stackoverflow.com/questions/67631/how-to-import-a-module-given-the-full-path

import importlib.util
import re


def generate_test_plan(test_path):
    """

    :param test_path:
    :return:
    """
    spec = importlib.util.spec_from_file_location(
        "module.name", test_path
    )
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)

    with open(test_path) as t:
        test_file = t.read()
        test_cases = re.findall(pattern='test_[a-zA-Z0-9_]+', string=test_file)
        test = re.findall(pattern='Test[A-Za-z]+', string=test_file)[0]

    cls = m.__dict__[test]

    print(cls.__name__)
    print(cls.__doc__)
    print(cls.setup_class.__name__)
    print(cls.setup_class.__doc__)
    for test_case in test_cases:
        if test_case in cls.__dict__:
            print(test_case)
            print(cls.__dict__[test_case].__doc__)

    print(cls.teardown_class.__name__)
    print(cls.teardown_class.__doc__)