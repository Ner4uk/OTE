from os import path
from time import strftime
import json


class RequestHandler:
    #  Something like wrapper between OnApp API and requests session methods.
    ###########################################################################
    def get_object(self, obj, url=None, data=None):
        if not url:
            url = '/{}.json'.format(obj._set_route())
        if self.session.method_handler(url=url, data=data):
            return self._handler(obj, self.session.response)
        obj.error = self.session.error
        return False

    def post_object(self, obj, url=None, data=None):
        # self.clear_obj_attr(obj, data)
        if not url:
            url = '/{}.json'.format(obj._set_route())
        if self.session.method_handler(url=url, data=data, method='POST'):
            return self._handler(obj, self.session.response)
        obj.error = self.session.error
        return False

    def patch_object(self, obj, url=None, data=None):
        # self.clear_obj_attr(obj, data)
        if not url:
            url = '/{}.json'.format(obj._set_route())
        if self.session.method_handler(url=url, data=data, method='PATCH'):
            return self._handler(obj, self.session.response)
        obj.error = self.session.error
        return False

    def put_object(self, obj, url=None, data=None):
        # self.clear_obj_attr(obj, data)
        if not url:
            url = '/{}/{}.json'.format(obj._set_route(), obj.id)
        if self.session.method_handler(url=url, data=data, method='PUT'):
            return self._handler(obj, self.session.response)
        obj.error = self.session.error
        return False

    def delete_object(self, obj, url=None, data=None):
        if not url:
            url = '/{}/{}.json'.format(obj._set_route(), obj.id)
        if self.session.method_handler(url=url, data=data, method='DELETE'):
            return self._handler(obj, self.session.response)
        obj.error = self.session.error
        return False

    def update_object(self, obj, url=None):
        #  Allow do not update resource without id like settings, cloud config etc.
        if hasattr(obj, 'id') and obj.id:
            if self.session.method_handler(url=obj._url()):
                return self._handler(obj, self.session.response)
        elif url:
            if self.session.method_handler(url=url):
                return self._handler(obj, self.session.response)
        elif not url:
            url = '/{}.json'.format(obj._set_route())
            if self.session.method_handler(url=url):
                return self._handler(obj, self.session.response)
        obj.error = self.session.error
        return False

    def get_curl(self):
        method = self.session.response.request.method
        url = self.session.response.request.url
        data = self.session.response.request.body

        if data != '{}':
            return "curl -i -X {0} -u '{1}:{2}' --url {3} "\
                "-H 'Accept: application/json'" \
                   " -H 'Content-type: application/json' "\
                "-d '{4}'\n".format(
                    method,
                    '******',
                    '******',
                    url,
                    data
                )
        else:
            return "curl -i -X {0} -u '{1}:{2}' --url {3} "\
                "-H 'Accept: application/json' " \
                   "-H 'Content-type: application/json'\n".format(
                    method,
                    '******',
                    '******',
                    url
                )

    # Too many work required...
    # @staticmethod
    # def clear_obj_attr(obj, data):
    #     """
    #     As we have some issue with obj attributes we have to clear them before
    #     request.
    #
    #     Scheme:
    #     obj->attr->data->request
    #                         |
    #     obj<-attr<-data<-response
    #
    #     So if no response - no data and we can't update attributes
    #
    #     For example:
    #     1. Set obj.attr = 100500
    #     2. Try to execute POST/PUT method
    #     3. Method above for example has not been executed
    #     4. Check obj.attr, actual result 100500, but request has been failed
    #
    #     That is why we have to clear obj attr before request, in this case
    #     obj.attr would be None which is more correctly
    #
    #     :param obj:
    #     :param data:
    #     :return:
    #     """
    #
    #     # {
    #     #     "resource": {
    #     #         "resource_class": "Resource::Acceleration",
    #     #         "billing_plan_id": 7926,
    #     #         "target_id": null,
    #     #         "target_type": null,
    #     #         "limits": {
    #     #             "limit": -10,
    #     #             "limit_free": 0
    #     #         },
    #     #         "prices": {
    #     #             "price": 0
    #     #         }
    #     #     }
    #     # }
    #
    #     if data:
    #         root_key = list(data.keys())[0]
    #         attributes = data[root_key]
    #         if isinstance(attributes, dict):
    #             for key, value in attributes.items():
    #                 #         "resource_class": "Resource::Acceleration",
    #                 #         "billing_plan_id": 7926,
    #                 #         "target_id": null,
    #                 #         "target_type": null,
    #                 #         "limits": {
    #                 #             "limit": -10,
    #                 #             "limit_free": 0
    #                 #         },
    #                 #         "prices": {
    #                 #             "price": 0
    #                 #         }
    #                 if hasattr(obj, key) and (
    #                             isinstance(obj.__dict__[key], list) or
    #                                 isinstance(obj.__dict__[key], str) or
    #                                 isinstance(obj.__dict__[key], int) or
    #                                 isinstance(obj.__dict__[key], float) or
    #                                 obj.__dict__[key] is None
    #                 ):
    #                     obj.__setattr__(key, None)
    #                 else:
    #                     for key2, value2 in data[root_key][key].items():
    #                         # "limit": -10,
    #                         # "limit_free": 0
    #                         if hasattr(obj.__dict__[key], key2):
    #                             obj.__dict__[key].__setattr__(key2, None)
    #
    #             # [
    #             #     obj.__setattr__(key, None) for key, value in
    #             #     attributes.items() if hasattr(obj, key)
    #             # ]
    ###########################################################################

    def _handle_500_status_code(self, response):
        log_path = path.join(self.log_path, '500_on_{}.log'.format(self.host))
        with open(log_path, 'a') as log500:
            msg = ' '.join(
                [
                    strftime('[%Y-%m-%d %H:%M:%S]'),
                    response.request.method,
                    str(response.status_code),
                    response.request.url,
                    response.request.body,
                    str(response.content),
                    '\n'
                ]
            )
            log500.write(msg)
            # backtrace = self.cp.execute(
            #     command='tail -n 500 /onapp/interface/log/production.log',
            #     verbose=False
            # )
            # start_index = backtrace.index(
            #     'Started {} "/{}"'.format(
            #         response.request.method,
            #         response.request.url.split('/', 3)[-1]
            #     )
            # )
            #
            # tmp_index = backtrace.index('Completed 500', start_index)
            #
            # try:
            #     end_index = backtrace.index('Started', tmp_index)
            # except ValueError:
            #     end_index = -1
            #
            # backtrace = backtrace[start_index:end_index]
            backtrace = self.log_parser(
                '/onapp/interface/log/production.log',
                'Completed 500',
                'Started {} "/{}"'.format(
                    response.request.method,
                    response.request.url.split('/', 3)[-1]
                ),
                'Started'

            )

            self.log.error(backtrace)

            log500.write('*'*80 + '\n')
            log500.write(backtrace)
            log500.write('*'*80 + '\n\n\n')
            # raise SystemError(self.error)

    def log_parser(self, log_file_path, phrase, start, stop, depth=500):
        """
        Search text element in CP log file
        :param log_file_path: Path to log file
        :param phrase: Phrase we are looking for
        :param start: string since we start looking for a phrase
        :param stop: string till we looking a phrase
        :param depth: how much lines we should grep
        :return: string
        """
        backtrace = self.cp.execute(
            command='tail -n {} {}'.format(depth, log_file_path),
            verbose=False
        )
        start_index = backtrace.index(start)

        tmp_index = backtrace.index(phrase, start_index)

        try:
            end_index = backtrace.index(stop, tmp_index)
        except ValueError:
            end_index = -1

        return backtrace[start_index:end_index]

    def _collect_error(self, response):
        with open(
                path.join(self.log_path, 'errors_collector.log'), 'a'
        ) as ec:
            msg = ' '.join(
                [
                    strftime('[%Y-%m-%d %H:%M:%S]'),
                    response.request.method,
                    str(response.status_code),
                    response.request.url,
                    response.request.body,
                    str(response.content),
                    '\n'
                ]
            )
            ec.write(msg)

    def _handler(self, obj, response):
        """
        Provide an request and handling the response with updating self
        attributes if possible.
        :param response: response obj
        :return: True if success else False
        """
        obj.error = {}
        obj.response = {}
        try:
            obj.raw_response = response.content.decode()
        except UnicodeDecodeError as e:
            obj.raw_response = ''
            self.log.error(e)
        obj.status_code = response.status_code
        obj.headers = response.headers  # using for pagination

        self.response = {}

        if self.log.level == 10:
            self.log.debug(self.get_curl())

        #  Convert response to python like obj from json
        if response.content:
            try:
                obj.response = self.response = response.json()
            except json.JSONDecodeError as e:  # Mostly during updating settings.
                self.log.error(
                    "Can't decode json:'{}'. Status code - {}".format(
                        e, obj.status_code
                    )
                )
            except ValueError as e:
                self.log.error(
                    "Can't decode json:'{}'. Status code - {}".format(
                        e, obj.status_code
                    )
                )

        # Generate API documentation.
        if self.gen_api_doc:
            self.generate_api_doc(response)

        # Logging 500 status code info into separate file.
        if obj.status_code == 500:
            self._handle_500_status_code(response)

        # if response type is dict - update obj attributes, if list - returns the response as is.
        if obj.response:
            if type(obj.response) == dict:
                response_root_tags = list(obj.response.keys())

                #  root tag can be != obj.root_tag for some response
                response_root_tag = obj.root_tag \
                    if obj.root_tag in response_root_tags \
                    else response_root_tags[0]

                #  Handling errors
                if response_root_tag in ['errors', 'error']:
                    self._collect_error(response)
                    obj.error = obj.response[response_root_tag]
                    #  Actually we have 2 types of errors - list and dict.
                    error_type = type(obj.error)
                    if error_type == list:
                        obj.error.append(obj.__class__.__name__)
                    elif error_type == dict:
                        obj.error['helper_name'] = obj.__class__.__name__
                    else:
                        self.log.warning('Unhandled error type.')

                    self.log.error(obj.error)
                    return False

                if type(obj.response[response_root_tag]) is dict:
                    obj.__dict__.update(obj.response[response_root_tag])
                else:
                    obj.__dict__.update(obj.response)
            return True
        # If self.response is empty and no errors return True, it is means that all is OK
        elif not obj.response and \
                response.request.method != "PUT" and \
                self.session.response.ok:
            return True
        elif not obj.response and \
                response.request.method == "PUT" and \
                self.session.response.ok:
            # Update resource.
            # It does not matter successfully or not return True (Some resources does not support GET request)
            # Possible situation:
            # DEBUG    [2016-12-26 15:49:23,464] PUT - http://109.123.91.18/service_addons/7/events/14.json
            # DEBUG    [2016-12-26 15:49:23,465]     DATA - {'service_addon_event': {'recipe_id': 16}}
            # DEBUG    [2016-12-26 15:49:23,776]     Status - 204
            # DEBUG    [2016-12-26 15:49:23,776] GET - http://109.123.91.18/service_addons/7/events/14.json
            # DEBUG    [2016-12-26 15:49:24,157]     Status - 404
            # DEBUG    [2016-12-26 15:49:24,157]         Content - b'{"errors":["Server error."]}'
            self.update_object(obj, response.url)
            return True
        return False
