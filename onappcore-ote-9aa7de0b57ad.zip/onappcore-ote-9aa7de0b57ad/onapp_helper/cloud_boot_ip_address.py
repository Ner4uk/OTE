from onapp_helper import test
from onapp_helper.base_helper import BaseHelper


class CloudBootIpAddress(BaseHelper):
    root_tag = 'ip_address'
    route = 'cloud_boot_ip_addresses'

    def __init__(self):
        self.assets = Assets()
        self.address = ""

    def get_all_free(self):
        """
        Get all free ip addresses
        :return: a list of ip address objects.
        """
        test.log.info("Get all free cloud booted ip addresses")
        ip_addresses = [ip for ip in self.get_all() if not ip.hypervisor_id]
        return ip_addresses

    def create(self):
        data = {
            self.root_tag: {
                "address": self.address
            }
        }
        test.log.info("Create a new cloud boot ip addresses")
        return test.post_object(self, data=data)


class Assets(BaseHelper):
    """
    Assets - available cloudbooted resources for a hv creation
    presented by set of pairs {mac_addresses,occupied_ip}
    {"asset":{"mac":"00:50:56:9f:56:31","ip":"10.0.52.2"}}
    """
    root_tag = 'asset'
    route = 'settings/assets'
