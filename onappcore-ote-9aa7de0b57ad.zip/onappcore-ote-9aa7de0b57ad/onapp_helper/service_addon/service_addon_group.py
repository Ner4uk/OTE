#  Since 5.3
from onapp_helper.base_helper import BaseHelper
from onapp_helper import test


class RelationGroupAddon(BaseHelper):
    def __init__(self, service_addon_group):
        self.parent_obj = service_addon_group
        self.root_tag = 'service_addon_group_relation'
        self.id = 0
        self.service_addon_id = 0
        self.price = 0

    def attach_addon_to_group(self, service_addon_id=None, price=0):
        """
        Attach service addon to the server.
        :param service_addon_id: an id of service addon
        :param price: service addon price
        :return: True if success otherwise False
        """
        test.log.info("Attach addon to group...")
        if not service_addon_id:
            service_addon_id = self.service_addon_id
        data = {
            self.root_tag: {
                "service_addon_id": service_addon_id
            }
        }

        if test.cp_version < 5.6:
            data[self.root_tag]["price"] = price

        return test.post_object(self, data=data)

    def edit(self):
        test.log.info(
            "Edit service addon group relation {}...".format(self.id)
        )
        data = {
            self.root_tag: {
                "price": self.price
            }
        }
        return test.put_object(self, data=data)

    def attached_addons(self):
        """ Return an array of attached templates to a group"""
        test.log.info("Attached addons...")
        return self._get_objects()

    def detach_addon_from_group(self, related_addon_id=None):
        test.log.info("Detach addon from group...")
        if not related_addon_id:
            related_addon_id = self.id
        url = "/{0}/{1}.json".format(self.route(), related_addon_id)
        return test.delete_object(self, url=url)

    def route(self):
        return '{0}/{1}/service_addon_group_relations'.format(
            self.parent_obj.route, self.parent_obj.id
        )


class ServiceAddonGroup(BaseHelper):
    root_tag = 'service_addon_group'
    route = 'service_addon_groups'

    def __init__(self, id=None):
        self.id = id
        self.label = self.__class__.__name__
        # self.relation_group_addon = RelationGroupAddon(self)

        if self.id:
            test.update_object(self)

    def get_any(self):
        test.log.info("Get any addon store...")
        self.__dict__.update(self.get_all()[0].__dict__)
        return True

    def get_by_label(self, label):
        test.log.info("Get addon store by label...")
        a_store = [
            store for store in self.get_all()
            if label.lower() in store.label.lower()
        ]
        if a_store:
            self.__dict__.update(a_store[0].__dict__)
            return True
        return False

    def get(self):
        test.log.info("Get addon stores...")
        return test.get_object(self)

    def create(self, parent_id=""):
        test.log.info("Create addon store...")
        data = {
            self.root_tag: {
                "label": self.label,
                "parent_id": parent_id
            }
        }
        return test.post_object(self, data=data)

    def edit(self):
        test.log.info("Edit addon store...")
        data = {
            self.root_tag: {
                "label": self.label
            }
        }
        return test.put_object(self, data=data)
