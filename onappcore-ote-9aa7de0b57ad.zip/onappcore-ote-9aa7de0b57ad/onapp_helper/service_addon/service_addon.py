#  Since 5.3
from onapp_helper.base_helper import BaseHelper
from onapp_helper import test


class EventType:
    on_add_event = "on_add_event"
    on_remove_event = "on_remove_event"
    on_vm_rebuild = "on_vm_rebuild"
    on_vm_destroy = "on_vm_destroy"


class Compatibility:
    unix = 'unix'
    windows = 'windows'


# class ActionType():
#     def __init__(self):
#         self.recipes = "run_recipe"


class Destination:
    """
    Since 5.5
    """
    run_on_vm = 'run_on_vm'
    run_on_cp = 'run_on_cp'


class ServiceAddon(BaseHelper):
    COMPATIBLE_WITH = Compatibility
    root_tag = 'service_addon'
    route = 'service_addons'

    def __init__(self, id=None):
        self.id = id
        self.label = self.__class__.__name__
        self.user_id = None
        self.compatible_with = []
        self.description = ''
        if test.cp_version >= 5.5:
            self.available_on_vm_provisioning = False
        # self.event = ServiceAddonEvent(self)

        # a list of executed events during on add/remove action
        self.executed_events_ids = []

        if self.id:
            test.update_object(self)

    def create(self):
        data = {
            self.root_tag: {
                "label": self.label,
                "description": self.description,
                "compatible_with": self.compatible_with
            }
        }
        if test.cp_version >= 5.5:
            data[self.root_tag]['available_on_vm_provisioning'] = self.available_on_vm_provisioning

        test.log.info('Create a new {}'.format(self.__class__.__name__))
        return test.post_object(self, data=data)

    def edit(self):
        data = {
            self.root_tag: {
                "label": self.label,
                "description": self.description,
                "compatible_with": self.compatible_with
            }
        }
        if test.cp_version >= 5.5:
            data[self.root_tag]['available_on_vm_provisioning'] = self.available_on_vm_provisioning

        test.log.info('Edit {} {}'.format(self.__class__.__name__, self.id))
        return test.put_object(self, data=data)

    def assign_to_server(self, server):
        data = {
            "service_addon_id": self.id
        }
        url = '/{}/{}/service_addons.json'.format(server.route, server.id)

        test.log.info(
            'Assign {} to {} {}'.format(
                self.__class__.__name__, server.__class__.__name__, server.id
            )
        )
        if test.post_object(self, url=url, data=data):
            if ServiceAddonEvent(self).get_on_add_events():
                return self.handling_on_add_transactions(server)
            return True
        return False

    def unassign_from_server(self, server):
        url = '/{}/{}/service_addons/{}.json'.format(
            server.route, server.id, self.id
        )

        test.log.info(
            'Unassign {} from {} {}'.format(
                self.__class__.__name__, server.__class__.__name__, server.id
            )
        )
        if test.delete_object(self, url=url):
            if ServiceAddonEvent(self).get_on_add_events():
                return self.handling_on_remove_transactions(server)
            return True
        return False

    def get_service_addons_assigned_to_server(self, server):
        test.log.info(
            'Get {}s assigned to {} {}'.format(
                self.__class__.__name__, server.__class__.__name__, server.id
            )
        )
        return self._get_objects(
            route='{}/{}/service_addons'.format(server.route, server.id)
        )

    def applied_to_vs(self):
        test.log.info(
            'Get {}s applied to servers'.format(
                self.__class__.__name__
            )
        )
        url = '/{}/{}/applied_to_vs.json'.format(self.route, self.id)
        return test.get_object(self, url=url)

    def handling_on_add_transactions(self, server):
        """
        Handling transaction for specified event type
        :param server: server obj
        :return: True if success else False
        """
        if self._handling_event_transactions(server, EventType.on_add_event):
            if self.transaction_handler(
                self.TRANSACTION_ACTION.service_addons_complete, server.id
            ):
                return True
        return False

    def handling_on_remove_transactions(self, server):
        """
        Handling transaction for specified event type
        :param server: server obj
        :return: True if success else False
        """
        return self._handling_event_transactions(
            server, EventType.on_remove_event
        )

    def handling_on_vm_rebuild_transactions(self, server):
        """
        Handling transaction for specified event type
        :param server: server obj
        :return: True if success else False
        """
        if self._handling_event_transactions(server, EventType.on_vm_rebuild):
            if self.transaction_handler(
                self.TRANSACTION_ACTION.service_addons_complete, server.id
            ):
                return True
        return False

    def handling_on_vm_destroy_transactions(self, server):
        """
        Handling transaction for specified event type
        :param server: server obj
        :return: True if success else False
        """
        if self._handling_event_transactions(server, EventType.on_vm_destroy):
            if self.transaction_handler(
                self.TRANSACTION_ACTION.service_addons_complete, server.id
            ):
                return True
        return False

    def _handling_event_transactions(self, server, event_type):
        """
        Handling event transactions depends on service addon events.
        Getting all events with defined event_type, after that waiting for
        transaction related to this event.
          If not events for transaction return True.

        :param server: server obj
        :param event_type: Event type as string.
        :return: True if success else False
        """
        self.executed_events_ids = []
        events = [
            event for event in ServiceAddonEvent(self).get_all()
            if event.event_type == event_type
            ]

        if not events:
            return True

        events_executed = False
        for event in events:
            action = ''
            params_keys = None  # is using just for notification event

            # Recipe event
            if event.recipe_id:
                action = "run_recipe_event_on_vm"
                if test.cp_version >= 5.5 and event.destination == 'run_on_cp':
                    action = "run_recipe_event_on_cp"
            # Notification event
            elif event.topic_id:
                action = "send_event_notification"
                params_keys = ['event', 'service_addon_event', 'id']

            if action:
                if self.transaction_handler(
                        action, parent_id=server.id, pages=5,
                        params_keys=params_keys,
                        param_value=event.id
                ):
                    events_executed = True
                    self.executed_events_ids.append(event.id)

            if not events_executed:
                return False
        return events_executed


class ServiceAddonEvent(BaseHelper):
    EVENT_TYPE = EventType
    DESTINATION = Destination
    # ACTION_TYPE = ActionType()

    def __init__(self, service_addon):
        self.root_tag = "service_addon_event"
        self.parent_obj = service_addon
        # self.action_type = ""
        #
        # self.service_addon_id = None
        self.recipe_id = None
        self.event_type = None

        # Since 5.5
        self.destination = None
        self.topic_id = None

    def add_recipe(
            self, recipe_id, event_type, destination=DESTINATION.run_on_vm
    ):
        """
        event_type - set as ServiceAddonEvent.ON_ADD_EVENT or ServiceAddonEvent.ON_REMOVE_EVENT
        :param recipe_id: recipe id
        :param event_type: event type use self.EVENT_TYPE
        :param destination: use Destination class, available since 5.5
        :return: True if success else False
        """
        data = {
            self.root_tag: {
                "recipe_id": recipe_id,
                "event_type": event_type
            }
        }
        # https://onappdev.atlassian.net/browse/CORE-8692
        if test.cp_version >= 5.5:
            data[self.root_tag]['destination'] = destination

        test.log.info('Add recipe to service addon event')

        url = '/{}/recipes.json'.format(self.route())
        return test.post_object(self, url=url, data=data)

    def add_notification(self, topic_id, event_type):
        """
        Supported since 5.5 (https://onappdev.atlassian.net/browse/CORE-8690)
        Add a new event - notification.
        :param topic_id: topic id
        :param event_type: event type use self.EVENT_TYPE
        :return: True if success else False
        """
        data = {
            self.root_tag: {
                "topic_id": topic_id,
                "event_type": event_type
            }
        }
        test.log.info('Add notification to service addon event')

        url = '/{}/notifications.json'.format(self.route())
        return test.post_object(self, url=url, data=data)

    def edit(self, recipe_id):
        """
        :param recipe_id:
        :return:
        """
        data = {
            self.root_tag: {
                "recipe_id": recipe_id
            }
        }
        test.log.info('Edit service addon event')
        return test.put_object(self, data=data)

    def route(self):
        return "{}/{}/events".format(
            self.parent_obj.route, self.parent_obj.id
        )

    def get_on_add_events(self):
        test.log.info('Get {}'.format(self.EVENT_TYPE.on_add_event))
        return self._get_events(event_type=self.EVENT_TYPE.on_add_event)

    def get_on_remove_events(self):
        test.log.info('Get {}'.format(self.EVENT_TYPE.on_remove_event))
        return self._get_events(event_type=self.EVENT_TYPE.on_remove_event)

    def get_on_vm_rebuild_events(self):
        test.log.info('Get {} event'.format(self.EVENT_TYPE.on_vm_destroy))
        return self._get_events(event_type=self.EVENT_TYPE.on_vm_destroy)

    def get_on_vm_destroy_events(self):
        test.log.info('Get {} event'.format(self.EVENT_TYPE.on_vm_destroy))
        return self._get_events(event_type=self.EVENT_TYPE.on_vm_destroy)

    def _get_events(self, event_type=None):
        if event_type:
            return [
            event for event in self.get_all() if
            event.event_type == event_type
            ]
        else:
            return self.get_all()