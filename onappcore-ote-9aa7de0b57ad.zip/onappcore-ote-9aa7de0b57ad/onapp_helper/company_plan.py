from onapp_helper.base_helper import BaseHelper
from onapp_helper.company_resource.company_resource_base import CompanyRBase
from onapp_helper import test


class CompanyPlan(BaseHelper):
    route = 'billing/company/plans'
    root_tag = 'company_plan'

    def __init__(self, bp_id=None):
        """ bp_id - company plan id."""
        self.id = bp_id
        self.label = "zaza_company_plan_test"
        self.monthly_price = 0
        self.currency_code = "USD"
        #self._setup()
        if self.id:
            test.update_object(self)

    def create(self):
        """
        Default values:
            label = "zaza_billing_test"
            currency_code = "USD"
            monthly_price = "0.0"
        """
        test.log.info("Create company billing plan...")
        data = {
            self.root_tag: {
                "label": self.label,
                "currency_code": self.currency_code,
                "monthly_price": self.monthly_price
            }
        }
        return test.post_object(self, data=data)

    def edit(self):
        test.log.info("Edit company billing plan...")
        data = {
            self.root_tag: {
                "label": self.label,
                "currency_code": self.currency_code,
                "monthly_price": self.monthly_price
            }
        }
        return test.put_object(self, data=data)

    def resource_in_company_plan(self, target_id):
        """
        Check if resource with target_id is present on company plan
        :param target_id: resource target id
        :return: True if resource with target id is present in company plan else
        False
        """
        return target_id in CompanyRBase(
            {'company_plan': self}
        ).get_key_values('target_id')

    # def _setup(self):
    #     if test.cp_version >= 4.2:
    #         self.route = 'billing/company/plans'
    #         self.root_tag = 'company_plan'
    #     else:
    #         raise SystemError('Is not supported by current CP version.')

