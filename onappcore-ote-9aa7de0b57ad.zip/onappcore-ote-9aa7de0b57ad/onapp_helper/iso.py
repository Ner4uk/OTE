from onapp_helper.base_helper import BaseHelper
from onapp_helper import test


class OperatingSystem:
    LINUX = 'linux'
    FREE_BSD = 'freebsd'
    WINDOWS = 'windows'


class OperatingSystemDistro:
    UBUNTU = 'ubuntu'
    ARCH_LINUX = 'archlinux'
    GENTOO = 'gentoo'
    SLACKWARE = 'slackware'
    OPEN_SUSE = 'opensuse'
    RHEL = 'rhel'


class ISO(BaseHelper):
    route = 'template_isos'
    root_tag = 'image_template_iso'

    OPERATING_SYSTEM = OperatingSystem
    OPERATING_SYSTEM_DISTRO = OperatingSystemDistro

    def __init__(self, id=None):
        self.id = id
        self.make_public = False
        self.label = 'LinuxMintAT'
        self.min_memory_size = 128
        self.min_disk_size = 5
        self.version = '1.0'
        self.operating_system = ''
        self.operating_system_distro = ''
        self.virtualization = ["xen", "kvm"]
        self.file_url = ''
        self.user_id = None
        self.min_disk_size = 5
        self.file_name = ''
        if test.cp_version >= 5.5:
            self.allowed_hot_migrate = False
        if self.id:
            test.update_object(self)

    def create(self):
        test.log.info("Create ISO...")
        data = {
            self.root_tag: {
                "make_public": self.make_public,
                "label": self.label,
                "min_memory_size": self.min_memory_size,
                "min_disk_size": self.min_disk_size,
                "version": self.version,
                "operating_system": self.operating_system,
                "operating_system_distro": self.operating_system_distro,
                "virtualization": self.virtualization,
                "file_url": self.file_url
            }
        }
        if test.cp_version >= 5.5:
            data[self.root_tag]['allowed_hot_migrate'] = self.allowed_hot_migrate

        test.log.info("Start to upload ISO...")
        if test.post_object(self, data=data):
            if self.transaction_handler("download_iso", self.id):
                return True
        return False

    def update(self):
        test.log.info("Update ISO...")
        data = {
            self.root_tag: {
                "label": self.label,
                "min_memory_size": self.min_memory_size,
                "min_disk_size": self.min_disk_size,
                "version": self.version,
                "operating_system": self.operating_system,
                "operating_system_distro": self.operating_system_distro,
                "virtualization": self.virtualization
            }
        }
        if test.cp_version >= 5.5:
            data[self.root_tag]['allowed_hot_migrate'] = self.allowed_hot_migrate

        test.log.info("Start to update ISO...")
        return test.put_object(self, data=data)

    def make_iso_public(self):
        test.log.info("Make public ISO {}...".format(self.id))
        url = '/{0}/{1}/make_public.json'.format(self.route, self.id)
        return test.post_object(self, url=url)

    def get_own(self):
        """
        Get current user iso
        :return:
        """
        test.log.info("Get ISOs for current user...")
        route = '{0}/own'.format(self.route)
        return self._get_objects(route=route)

    def get_users(self):
        test.log.info("Get user ISOs...")
        route = '{0}/user'.format(self.route)
        return self._get_objects(route=route)

    def get_public(self):
        test.log.info("Get public (system) ISOs...")
        route = '{0}/system'.format(self.route)
        return self._get_objects(route=route)

    def get_user(self, user_id):
        test.log.info("Get particular user ISOs...")
        route = '{0}/user/{1}'.format(self.route, user_id)
        return self._get_objects(route=route)

    def delete(self):
        test.log.info("Delete ISO...")
        if test.delete_object(self):
            if self.transaction_handler("destroy_iso", self.id):
                return True
        return False

    def search(self, query=None):
        """
        Search templates
        :param query: string obj, template label, etc...
        :return: array of templates
        """
        if query:
            query = query.replace(' ', '+')
        templates = self._base_search(query=query)
        if templates:
            return [t for t in templates if t.state == 'active']
        return []

    def _base_search(
            self,
            query=None
    ):
        """
        Search templates
        :param query: string obj, template label, etc...
        :return: array of templates
        """
        test.log.info(f"Search {query} iso template...")

        search_keys = {
            'query': 'search_filter[query]',
        }

        return self._search(
            search_keys=search_keys
        )
