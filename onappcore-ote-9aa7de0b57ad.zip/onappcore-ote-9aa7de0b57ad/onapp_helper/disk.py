from onapp_helper.base_helper import BaseHelper
from onapp_helper.stats.usage import Usage
from onapp_helper.schedule import Schedule
from onapp_helper.data_store import DataStore
from onapp_helper import test


class FileSystem:
    ext2 = 'ext2'
    ext3 = 'ext3'
    ext4 = 'ext4'
    ntfs = 'ntfs'
    ufs2 = 'ufs2'
    xfs = 'xfs'
    coreos = 'coreos'
    swap = 'swap'


class Disk(BaseHelper):
    FILE_SYSTEM = FileSystem
    route = 'settings/disks'
    root_tag = 'disk'

    def __init__(self, parent_obj=None, id=None):
        self.parent_obj = parent_obj
        self.primary = 0
        self.disk_size = 1
        self.file_system = 'ext3'
        self.label = ''
        self.require_format_disk = False
        self.data_store_id = None
        self.mount_point = ''
        self.hot_attach = False
        self.is_swap = False
        self.min_iops = 100
        self.mounted = "0"  # Since 4.3 instead of 'add_to_linux_fstab' and 'add_to_freebsd_fstab'
        self.schedule = Schedule(target=self)
        self.id = id
        self.data = {}
        if self.id:
            test.update_object(self)

    # def get(self):
    #     return test.update_object(self)

    def create(self, **kwargs):
        """Disk:
                - primary (0)
                - disk_size (1)
                - file_system (ext3)
                - label ('')
                - require_format_disk (False)
                - mount_point ('')
                - hot_attach (False)
                - mounted ( False)
            Swap:
                - disk_size (1)
                - label ('')
                - require_format_disk (False)
                - hot_attach (False)
                - is_swap (False)

            Disk for OVA template:
                - label
                - data_store_id
                - disk_size

        """

        if not self.parent_obj.id:
            test.update_object(self.parent_obj)

        data_store_id = self.data_store_id
        if not data_store_id:
            data_store_id = self.parent_obj.associated_datastores_ids()[0]

        ds = DataStore(id=data_store_id)

        test.log.info("Create disk...")
        if kwargs:
            self.data = {self.root_tag: kwargs}
        else:
            if self.is_swap:
                self.data = {
                    self.root_tag: {
                        "disk_size": self.disk_size,
                        "data_store_id": data_store_id,
                        "label": self.label,
                        "require_format_disk": self.require_format_disk,
                        "hot_attach": self.hot_attach,
                        "is_swap": self.is_swap
                    }
                }
            elif self.parent_obj.template.type == "ImageTemplateOva":
                self.data = {
                    self.root_tag: {
                        "label": self.label,
                        "data_store_id": data_store_id,
                        "disk_size": self.disk_size
                    }
                }
            else:
                self.data = {
                    self.root_tag: {
                        "primary": self.primary,
                        "disk_size": self.disk_size,
                        "file_system": self.file_system,
                        "data_store_id": data_store_id,
                        "label": self.label,
                        "require_format_disk": self.require_format_disk,
                        "mount_point": self.mount_point,
                        "hot_attach": self.hot_attach
                    }
                }

                if (self.parent_obj.operating_system == 'freebsd') and (
                            'file_system' in self.data[self.root_tag]
                ):
                    self.data[self.root_tag].pop('file_system')

        # Set 'mount' parameter explicitly for swap/not swap disks.
        # It is caused by https://onappdev.atlassian.net/browse/CORE-7316.
        # UI is sending this parameter automatically:
        # Parameters: {
        #   "disk"=>{
        #       "label"=>"",
        #       "data_store_id"=>"1",
        #       "disk_size"=>"1",
        #       "is_swap"=>"1",
        #       "require_format_disk"=>"0",
        #       "mounted"=>"0",
        #       "min_iops"=>"100"
        # }, "virtual_machine_id"=>"v48lry0zai5m5x"}
        # Before this issue the 'mount' parameter had been sending only for not swap disk,
        # that is why current issue has not been caught.
        self._api_dependency()

        if ds.data_store_type == 'solidfire':
            self.data[self.root_tag]["min_iops"] = self.min_iops
        url = '/{0}/{1}/disks.json'.format(self.parent_obj.route, self.parent_obj.id)
        if test.post_object(self, url=url, data=self.data):
            if self.transaction_handler(self._build_disk_action(), self.id):
                test.update_object(self)
                return True
        return False

    def edit(self):
        """
        Edit the following parameters:
        Disk:

            * disk_size (1)
            * file_system (ext3)
            * label ('')
            * require_format_disk (False)
            * mount_point ('')

        Swap:

            * disk_size
            * label

        :return: True if success else False
        """
        test.log.info("Edit disk...")
        if self.is_swap:
            self.require_format_disk = False  # is not supported for swap
            self.data = {
                self.root_tag: {
                    "disk_size": self.disk_size,
                    "label": self.label
                }
            }
        elif self.parent_obj.template.type == "ImageTemplateOva":
            self.require_format_disk = False  # is not supported for ova
            self.data = {
                self.root_tag: {
                    "label": self.label,
                    "disk_size": self.disk_size
                }
            }
        else:
            self.data = {
                self.root_tag: {
                    "disk_size": self.disk_size,
                    "file_system": self.file_system,
                    "label": self.label,
                    "require_format_disk": self.require_format_disk,
                    "mount_point": self.mount_point
                }
            }

            if (self.parent_obj.operating_system == 'freebsd') and (
                        'file_system' in self.data[self.root_tag]
            ):
                self.data[self.root_tag].pop('file_system')

        self._api_dependency()

        if test.env.ds.data_store_type == 'solidfire':
            self.data[self.root_tag]["min_iops"] = self.min_iops
        test.update_object(self.parent_obj)  # To have actual server status

        if test.put_object(self, data=self.data):
            if self.parent_obj.booted:
                if self.require_format_disk:
                    transactions_chain = [
                        ("stop_virtual_machine", self.parent_obj.id),
                        ('format_disk', self.id),
                        ("startup_virtual_machine", self.parent_obj.id)
                    ]
                else:
                    transactions_chain = [
                        ("stop_virtual_machine", self.parent_obj.id),
                        ('resize_disk', self.id),
                        ("startup_virtual_machine", self.parent_obj.id)
                    ]
            else:
                if self.require_format_disk:
                    transactions_chain = [
                        ("format_disk", self.id),
                    ]
                else:
                    transactions_chain = [
                        ("resize_disk", self.id),
                    ]

            self.transactions_handler(transactions_chain)

            if not self.error:
                test.update_object(self)
                test.update_object(self.parent_obj)
                return True
        return False

    def disk_hourly_stat(self):
        """
        Get disk hourly statistics
        :return: list of disk usage objects
        """
        test.log.info('Get disk hourly statistics')
        return Usage()._get_objects(
            route='{}/{}/usage'.format(self.route, self.id),
            root_tag='disk_hourly_stat'
        )

    def migrate(self, data_store_id=None, type=None):
        """
        Migrate disk to data store with specified id
        :param data_store_id: specified data store id
        :param type: hot or cold (since 5.8) https://onappdev.atlassian.net/browse/CORE-10617
        :return: True if success else False
        """
        test.log.info("Migrate disk...")
        root_tag = 'disk_migration' if test.api_version >= 5.8 else self.root_tag
        route = 'migration' if test.api_version >= 5.8 else 'migrate'

        data = {
            root_tag: {
                "data_store_id": data_store_id
            }
        }
        if test.api_version >= 5.8:
            data[root_tag]['type'] = type

        url = '/{0}/{1}/disks/{2}/{3}.json'.format(
            self.parent_obj.route, self.parent_obj.id, self.id, route
        )
        if test.post_object(self, url=url, data=data):
            if self.transaction_handler("migrate_disk", self.id):
                test.update_object(self)
                return True
        return False

    def enable_auto_backups(self):
        """
        Enable disk auto backups.
        :return: list of backup objects
        """
        test.log.info("Enable disk auto backups...")
        backups = []
        url = '/{0}/{1}/autobackup_enable.json'.format(self.route, self.id)
        if test.post_object(self, url=url):
            if self.has_autobackups and len(self.schedule.get_all()) == 4:
                # wait for transactions
                if self.wait_for_action(
                    lambda: len(
                        [
                            b for b in self.parent_obj.get_image_backups()
                            if b.initiated != 'manual'
                        ]
                    ) == 4,
                    timeout=120,
                    step=5
                ):
                    # wait for all take backup transactions has been finished
                    backups = [
                        b for b in self.parent_obj.get_image_backups()
                        if b.initiated != 'manual'
                    ]

                    for b in backups:
                        b.transaction_handler('take_backup', b.id)
                        test.update_object(b)
        return backups

    def disable_auto_backup(self):
        """
        Disable auto backups
        :return: boolean
        """
        test.log.info("Disable disk auto backups...")
        url = '/{0}/{1}/autobackup_disable.json'.format(self.route, self.id)
        return test.post_object(self, url=url)

    def assign_to_server(self, server_id):
        """
        https://onappdev.atlassian.net/browse/CORE-7984
        :param server_id: server id
        :return: True if success else False
        """
        data = {self.root_tag: {"temporary_virtual_machine_id": server_id}}
        url = f"/{self.route}/{self.id}/assign.json"
        if test.post_object(self, url=url, data=data):
            transactions_chain = [
                ('stop_virtual_machine', self.parent_obj.id),
                ('assign_disk_to_virtual_machine', self.id)
            ]
            return self.transactions_handler(transactions_chain)
        return False

    def unassign_from_server(self):
        """
        https://onappdev.atlassian.net/browse/CORE-7984
        :return: True if success else False
        """
        url = f"/{self.route}/{self.id}/assign.json"
        if test.delete_object(self, url=url):
            return self.transaction_handler(
                'startup_virtual_machine', parent_id=self.parent_obj.id
            )
        return False

    # def get_schedules(self):
    #     test.log.info("Get schedules...")
    #     self._get_handler('/{0}/{1}/schedules.json'.format(self.route, self.id))
    #     return self.response

    def delete(self):
        """
        Delete disk
        :return: True if success else False.
        """
        test.log.info("Delete disk...")
        test.update_object(self.parent_obj)
        if test.delete_object(self):
            if self.transaction_handler(self._delete_disk_action(), self.id):
                return test.update_object(self.parent_obj)
        return False

    def remove_zombie_lv(self, lv_path=None):
        """
        Remove zombie logical volume by lv_path.
        :param lv_path: for example '/dev/onapp-thwtvobzibatia/bjxevemizkkmkr'
        :return: True if success else False
        """
        ds_id = [
            ds.id for ds in DataStore().get_all() if ds.identifier in lv_path
            ][0]

        data = {
            "lv_path": lv_path
        }
        url = "/disks/remove_zombie_lv.json"
        if test.delete_object(self, url=url, data=data):
            return self.transaction_handler(
                "remove_logical_volume", parent_id=ds_id
            )

    def _api_dependency(self):
        """
        Describe API dependency.
        :return:
        """
        if test.api_version is None or test.api_version >= 4.3:
            self.data[self.root_tag]['mounted'] = self.mounted
        elif test.api_version < 4.3 and self.parent_obj.operating_system == 'linux':
            self.data[self.root_tag]['add_to_linux_fstab'] = self.mounted
        elif test.api_version < 4.3 and self.parent_obj.operating_system == 'freebsd':
            self.data[self.root_tag]['add_to_freebsd_fstab'] = self.mounted
        else:
            raise SystemError('"api_version" parameter misconfigured.')

    def _delete_disk_action(self):
        """
        According to vs and disk parameters calculate transaction action name
        :return: action name
        """
        if not self.parent_obj.booted or self.parent_obj.operating_system == 'freebsd':  # or not self.hot_attach:
            action = 'destroy_disk'
        else:
            if 'kvm_virtio' in self.parent_obj.template.virtualization and \
                            test.env.hv.distro != "centos5" and \
                            test.env.hv.hypervisor_type == 'kvm':
                action = 'detach_disk'
            else:
                action = 'destroy_disk'
        return action

    def _build_disk_action(self):
        """
        According to vs and disk parameters calculate transaction action name
        :return: action name
        """
        if not self.parent_obj.booted or not self.hot_attach:
            action = 'build_disk'
        else:
            if self.is_hot_operations_possible():
                action = 'attach_disk'
            else:
                action = 'build_disk'
        return action

    def get_all(self):
        if self.parent_obj:
            test.log.info(
                'Get all {} disks'.format(self.parent_obj.__class__.__name__)
            )
            return self._get_objects(
                route='{}/{}/disks'.format(self.parent_obj.route, self.parent_obj.id),
                parent_obj=self.parent_obj
            )
        else:
            test.log.info('Get all disks')
            return self._get_objects()

    def is_hot_operations_possible(self):
        return 'kvm_virtio' in self.parent_obj.template.virtualization and \
                            test.env.hv.distro != "centos5" and \
                            test.env.hv.hypervisor_type == 'kvm'

    def contain_negative_stat_value(self):
        """Check if negative value is present on usage statistics, if yes
        return True else Fasle"""
        return True if [
            usage for usage in self.disk_hourly_stat()
            if usage.data_read < 0
            or usage.data_written < 0
            or usage.reads_completed < 0
            or usage.writes_completed < 0
        ] else False
