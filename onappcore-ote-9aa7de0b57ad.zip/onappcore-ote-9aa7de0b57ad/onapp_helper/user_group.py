from onapp_helper import test
from onapp_helper.base_helper import BaseHelper
from onapp_helper.payment import Payment


class UserGroup(BaseHelper):
    route = 'user_groups'
    root_tag = route[:-1]

    def __init__(self, id=None):
        self.id = id
        self.label = ''
        self.assign_to_vcloud = False
        self.hypervisor_id = 0  # vCloud Owner
        self.billing_plan_ids = []
        self.role_ids = []
        self.outstanding_amount = 0
        self.paid_amount = 0
        self.total_amount = 0
        self.monthly_price = 0
        self.bucket_id = None
        # Since 5.7 https://onappdev.atlassian.net/browse/CORE-10885
        self.discount_due_to_free = 0
        self.total_amount_with_discount = 0

        if test.api_version < 5.6:
            self.company_billing_plan_id = 0
        else:
            self.bucket_id = 0

        if self.id:
            test.update_object(self)

        self.monthly_bills = MonthlyBill(parent_obj=self)
        self.service_addons_stats = ServiceAddonStat(parent_obj=self)
        self.report = Report(parent_obj=self)

    def create(self):
        test.log.info("Create UserGroup...")
        if not self.assign_to_vcloud:
            data = {
                self.root_tag: {
                    "label": self.label,
                    "role_ids": self.role_ids,
                    "billing_plan_ids": self.billing_plan_ids,
                    "bucket_id": self.bucket_id
                }
            }
            return test.post_object(self, data=data)
        else:
            data = {
                self.root_tag: {
                    "label": self.label,
                    "assign_to_vcloud": self.assign_to_vcloud,
                    "hypervisor_id": self.hypervisor_id,
                    "billing_plan_ids": self.billing_plan_ids
                }
            }

            if test.api_version >= 5.6:
                data[self.root_tag]["bucket_id"] = self.bucket_id
            else:
                data[self.root_tag]["company_billing_plan_id"] = self.company_billing_plan_id

            if test.post_object(self, data=data):
                if test.cp_version < 5.8 and not self.transaction_handler(
                        'create_user_group', self.id
                ):  # if transaction has failed
                    return False
                return True
        return False

    def edit(self):
        test.log.info("Edit UserGroup...")
        if not self.assign_to_vcloud:
            data = {
                self.root_tag: {
                    "label": self.label,
                    "role_ids": self.role_ids,
                    "billing_plan_ids": self.billing_plan_ids,
                    "bucket_id": self.bucket_id
                }
            }
        else:
            data = {
                self.root_tag: {
                    "label": self.label,
                    "company_billing_plan_id": self.company_billing_plan_id,
                    "billing_plan_ids": self.billing_plan_ids
                }
            }
        test.log.info("Edit UserGroup...")
        return test.put_object(self, data=data)

    def delete(self):
        test.log.info("Delete UserGroup...")
        if self.assign_to_vcloud and test.cp_version < 5.8:
            if test.delete_object(self):
                if self.transaction_handler(
                    'delete_user_group', self.id
                ):
                    return True
        else:
            return test.delete_object(self)
        return False

    def get_payments(self):
        """
        Get all user group payments
        :return: a list of payment objects
        """
        test.log.info("Get {} payments".format(self.__class__.__name__))
        return Payment()._get_objects(
            route='{}/{}/payments'.format(self.route, self.id)
        )

    #  Uncomment if getting user groups will take a lot of time.
    def get_all(self):
        """
        Return the array of objects
        """
        per_page = 10
        test.log.info("Get all user groups...")
        objects = []
        if test.get_object(
                self,
                url='/{0}.json/page/1/per_page/{1}'.format(self.route, per_page)
        ):
            x_total = int(self.headers['X-Total'])
            for u in self.response:
                obj = UserGroup()
                obj.__dict__.update(u[self.root_tag])
                objects.append(obj)

            if x_total > per_page:
                for page in range(2, int(x_total/per_page) + 2):
                    if test.get_object(
                            self,
                            url='/{0}.json/page/{1}/per_page/{2}'.format(
                                self.route, page, per_page
                            )
                    ):
                        if int(self.headers['X-Page']) != page:
                            break
                        for u in self.response:
                            obj = UserGroup()
                            obj.__dict__.update(u[self.root_tag])
                            objects.append(obj)

        return objects

    # def get(self, id):
    #     """
    #     Return the array of objects
    #     """
    #     test.log.info("Get all users...")
    #     if test.update_object(self):
    #         self.__dict__.update(self.response[self.root_tag])
    #         return True
    #     return False


class MonthlyBill(BaseHelper):
    month = None
    cost = None
    root_tag = 'billing_company_statistics_monthly_stat'

    def __init__(self, parent_obj=None):
        self.parent_obj = parent_obj

    def route(self):
        return '{}/{}/monthly_bills'.format(
            self.parent_obj.route, self.parent_obj.id
        )


class ServiceAddonStat(BaseHelper):
    def __init__(self, parent_obj=None):
        self.parent_obj = parent_obj

    def route(self):
        return '{}/{}/service_addons_stats'.format(
            self.parent_obj.route, self.parent_obj.id
        )


class Report(BaseHelper):
    root_tag = 'billing_user_group_report'

    def __init__(self, parent_obj=None):
        self.parent_obj = parent_obj

    def route(self):
        return '{}/{}/report'.format(
            self.parent_obj.route, self.parent_obj.id
        )