from onapp_helper import test
from onapp_helper.base_helper import BaseHelper



class Host(BaseHelper):
    route = 'settings/availability/hosts'
    root_tag = 'availability_host'

    def __init__(self, id=None, hostname=None, ip=None):
        self.id = id
        self.hostname = hostname
        self.ip = ip
        if self.id:
            test.update_object(self)

    def add(self):
        data = {
            self.root_tag: {
                "hostname": self.hostname
            }
        }
        return test.post_object(self, data=data)

    def edit(self):
        data = {
            self.root_tag: {
                "hostname": self.hostname
            }
        }
        return test.put_object(self, data=data)
