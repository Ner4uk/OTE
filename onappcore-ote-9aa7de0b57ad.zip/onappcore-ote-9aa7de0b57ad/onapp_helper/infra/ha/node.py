from onapp_helper import test
from onapp_helper.base_helper import BaseHelper



class Node(BaseHelper):
    def __init__(self, cluster=None, id=None):
        self.id = id
        self.cluster = cluster
        self.route = '{}/{}/nodes'.format(self.cluster.route, self.cluster.id)
        self.root_tag = 'availability_node'
        self.host_id = ''
        self.interface = ''
        self.ip_address = ''
        self.priority = ''
        if self.id:
            test.update_object(self)

    def add(self):
        data = {
            self.root_tag: {
                "host_id": self.host_id,
                "interface": self.interface,
                "ip_address": self.ip_address,
                "priority": self.priority
            }
        }
        return test.post_object(self, data=data)

    def edit(self):
        data = {
            self.root_tag: {
                "host_id": self.host_id,
                "interface": self.interface,
                "ip_address": self.ip_address,
                "priority": self.priority
            }
        }
        return test.post_object(self, data=data)
