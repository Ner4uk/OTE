from onapp_helper import test
from onapp_helper.base_helper import BaseHelper
import time



class HA(BaseHelper):
    route = 'settings/availability'
    # root_tag = 'availability_host'

    def __init__(self, host):
        self.host = host

    def enable(self):
        url = '/{}/enable.json'.format(self.route)
        if test.put_object(self, url=url):
            time.sleep(120)
            test.cp.ssh.execute('crm resource unmanage lsyncd-cluster')
            test.cp.ssh.execute('/etc/init.d/lsyncd stop')
            return self.transaction_handler('init_ha', self.host.id)

    def disable(self):
        url = '/{}/disable.json'.format(self.route)
        return test.put_object(self, url=url)

    def apply_changes(self):
        url = '/{}/apply_changes.json'.format(self.route)
        return test.put_object(self, url=url)