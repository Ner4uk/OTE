from onapp_helper import test
from onapp_helper.base_helper import BaseHelper


class CommunicationInterface(BaseHelper):
    route = 'settings/availability/communication_rings'
    root_tag = 'communication_ring'  # or just 'ring'

    def __init__(self, id=None):
        self.id = id
        self.bindnetaddr = ''
        self.mcastaddr = ''
        self.mcastport = ''
        self.ttl = ''
        if self.id:
            test.update_object(self)

    def add(self):
        data = {
            "ring": {
                "bindnetaddr": self.bindnetaddr,
                "mcastaddr": self.mcastaddr,
                "mcastport": self.mcastport,
                "ttl": self.ttl
            }
        }
        return test.post_object(self, data=data)

    def edit(self):
        data = {
            "ring": {
                "bindnetaddr": self.bindnetaddr,
                "mcastaddr": self.mcastaddr,
                "mcastport": self.mcastport,
                "ttl": self.ttl,
                "members": self.members
            }
        }
        return test.put_object(self, data=data)

    def switch_to_unicast(self):
        return test.put_object(self, url='/{}/unicast.json'.format(self.route))

    def set_members(self):
        data = {
            "ring": {
                "members": self.members
            }
        }
        return test.put_object(self, data=data)

    def apply(self):
        """
        Apply Changes to Multicast Configuration
        :return:
        """
        return test.put_object(self, url='/{}/apply.json'.format(self.route))

    def _load_from_config(self, conf_obj):
        self.bindnetaddr = conf_obj.get_network()
        self.mcastaddr = conf_obj.get_multicast_ip_address()
        self.mcastport = conf_obj.get_multicast_port()
        self.members = conf_obj.get_members()
        self.ttl = conf_obj.get_ttl()
        self.network_method = conf_obj.get_network_method()
