from onapp_helper import test
from onapp_helper.base_helper import BaseHelper
from onapp_helper.infra.ha.node import Node


class Cluster(BaseHelper):
    route = 'settings/availability/clusters'
    root_tag = 'availability_cluster'

    def __init__(self, id=None, name=None, virtual_ip=None):
        """
        :param id:
        :param name: DAEMON, UI, CLOUD_BOOT, LB, DB, REDIS, MQ
        :param virtual_ip: the virtual IP address of the cluster.
            This IP address should be unique.
        """
        self.id = id
        self.name = name
        if self.name:
            self._ha_config = getattr(test.ha_config, self.name.lower())
            self.virtual_ip = self._ha_config.ip
            self.status = self._ha_config.status
            self.prefix = self._ha_config.prefix
        # if self.id:
        #     test.update_object(self)

    def add(self):
        data = {
            self.root_tag: {
                'name': self.name,
                'virtual_ip': self.virtual_ip
            }
        }
        return test.post_object(self, data=data)

    def edit(self):
        data = {
            self.root_tag: {
                "virtual_ip": self.virtual_ip
                # "port": "",
                # "prefix":

            }
        }
        return test.put_object(self, data=data)

    def activate(self):
        url = '/{}/{}/recreate.json'.format(self.route, self.id)
        return test.put_object(self, url=url)

    def deactivate(self):
        url = '/{}/{}/deactivate.json'.format(self.route, self.id)
        return test.put_object(self, url=url)

    def load_nodes(self):
        """
        Load nodes from config file.
        :return:
        """
        nodes_ips = self._ha_config.nodes_ips.split(',')
        nodes_interfaces = self._ha_config.nodes_interfaces.split(',')
        nodes_priority = self._ha_config.nodes_priority.split(',')
        self.nodes = []
        for i in range(len(nodes_ips)):
            node = Node(cluster=self)
            node.ip_address = nodes_ips[i]
            node.interface = nodes_interfaces[i]
            node.priority = nodes_priority[i]
            self.nodes.append(node)

        return self.nodes

    def get_cluster_nodes(self):
        return self._get_objects(
            route='{}/{}'.format(self.route, self.id),
            root_tag='availability_node',
            parent_obj=self
        )

