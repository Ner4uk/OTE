# TODO use API; if it is able

from engine.lib.cp import CP
from onapp_helper import test

# test.load_env()


class TopicList(object):
    def __init__(self,):
        self.cp = CP(host=test.host)
        try:
            self.topics = [topic.split('\t') for topic in self.cp.mysql_execute('select id, name from messaging_topics')]
        except AssertionError as e:
            self.topics = []
            exit(e)


class Topic:
    def __init__(self):
        id = None
        name = ''

    def get_all(self):
        topics_from_db = test.cp.mysql_execute(
            'select id, name from messaging_topics'
        )
        topics = []
        for topic in topics_from_db:
            t = Topic()
            id, t.name = topic.split()
            t.id = int(id)
            topics.append(t)
        return topics


