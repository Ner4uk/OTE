from onapp_helper import test
from onapp_helper.base_helper import BaseHelper



class TemplateList(BaseHelper):
    def __init__(self, id=None):
        self.id = id
        self.route = 'messaging/notification_templates'
        self.root_tag = 'messaging_notification_template'
        self.name = ''
        self.template = ''
        if self.id:
            test.update_object(self)

    def create(self):
        test.log.info("Create template_lists...")
        data = {
            self.root_tag: {
                "name": self.name,
                "template": self.template,
            }
        }
        return test.post_object(self, data=data)

    def update(self):
        test.log.info("Update template_lists...")
        data = {
            self.root_tag: {
                "name": self.name,
                "template": self.template,
            }
        }
        return test.put_object(self, data=data)


