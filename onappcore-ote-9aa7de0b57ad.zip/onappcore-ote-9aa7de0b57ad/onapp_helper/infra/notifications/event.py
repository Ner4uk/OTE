from onapp_helper import test
from onapp_helper.base_helper import BaseHelper


class Event(BaseHelper):
    def __init__(self, id=None, type=None):
        self.id = id
        self.type = type
        self.route = 'messaging/events'
        self.root_tag = 'messaging_message'
        self.topic = ''
        self.text = ''
        if self.id:
            test.update_object(self)

    def create(self):
        test.log.info("Create event...")
        data = {
            self.root_tag: {
                "topic": self.topic,
                "text": self.text,
            }
        }
        return test.post_object(self, data=data)

    def get_system_events(self, page=1, events_per_page=100):
        return self._get_objects(
            query='/page/{}/per_page/{}?category=system_topics'.format(
                page, events_per_page
            )
        )

    def get_custom_events(self, page=1, events_per_page=100):
        return self._get_objects(
            query='/page/{}/per_page/{}?category=custom_topics'.format(
                page, events_per_page
            )
        )

    def find_event_by_text(self, text, page=1, events_per_page=100):
        events = self._get_objects(
            query='page/{}/per_page/{}'.format(page, events_per_page)
        )

        for event in events:
            if test.cp_version >= 5.7:
                if 'message' in event.data and event.data['message'] == text:
                    return event
            else:
                if event.text == text:
                    return event
        return None
