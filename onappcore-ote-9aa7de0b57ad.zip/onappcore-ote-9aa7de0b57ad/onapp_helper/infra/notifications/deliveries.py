from onapp_helper.base_helper import BaseHelper
from onapp_helper import test
import time



class Deliveries(BaseHelper):
    route = '/messaging/deliveries'
    root_tag = 'messaging_delivery'

    def __init__(self, id=None):
        self.recipient_id = ''
        self.subscription_id = ''
        self.message_id = ''
        self.destination = ''
        self.subscriber_name = ''
        self.status = ''
        self.log_output = ''
        self.subscription_name = ''
        self.cause_of_failure = ''
        self.error = {}
        self.id = id
        if self.id:
            test.update_object(self)

    def awaiting_delivery(self, topic_name):
        for attempt in range(10):
            delivery = [item for item in self.get_all() if item.subscription_name == topic_name][0]
            if 'complete' in delivery.status:
                test.log.info("Message has been delivered")
                break
            elif 'failed' in delivery.status:
                test.log.error("Delivery has been failed")
            elif 'pending' in delivery.status:
                test.log.warning("Awating for delivery ....")
                time.sleep(10)
            else:
                test.log.error(f"Undefined status:{delivery.status}")
        return delivery.status
