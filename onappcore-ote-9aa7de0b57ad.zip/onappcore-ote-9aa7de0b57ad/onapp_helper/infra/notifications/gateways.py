from onapp_helper import test
from onapp_helper.base_helper import BaseHelper


class DeliveryMethod(object):
    smtp = 'SMTP'
    internal = 'INTERNAL'
    sendmail = 'SENDMAIL'

class SmtpAuth(object):
    plain = 'plain'
    login = 'login'
    cram_md5 = 'cram_md5'


class Gateway(BaseHelper):

    DELIVERY_METHOD = DeliveryMethod()
    SMTP_AUTH = SmtpAuth()

    def __init__(self, id=None):
        self.id = id
        self.route = 'messaging/gateways'
        self.root_tag = 'messaging_gateway'
        self.delivery_method = ''
        self.email = ''
        self.host = ''
        self.smtp_address = ''
        self.smtp_port = ''
        self.smtp_domain = ''
        self.smtp_user_name = ''
        self.smtp_password = ''
        self.smtp_authentication = ''
        self.smtp_enable_starttls_auto = ''
        if self.id:
            test.update_object(self)

    def create(self):
        test.log.info("Create gateway...")
        data = {
            self.root_tag: {
                "name": self.name,
                "delivery_method": self.delivery_method,
                "options": {
                    'from': self.email,
                    'host':self.host,
                    'smtp_address':self.smtp_address,
                    'smtp_port': self.smtp_port,
                    'smtp_domain': self.smtp_domain,
                    'smtp_user_name':self.smtp_user_name,
                    'smtp_password' :self.smtp_password,
                    'smtp_authentication': self.smtp_authentication,
                }
            }
        }
        return test.post_object(self, data=data)

    def update(self):
        test.log.info("Update gateway...")
        data = {
            self.root_tag: {
                "name": self.name,
                "delivery_method": self.delivery_method,
                "options": {
                    'from': self.email,
                    'host': self.host,
                    'smtp_address': self.smtp_address,
                    'smtp_port': self.smtp_port,
                    'smtp_domain': self.smtp_domain,
                    'smtp_user_name': self.smtp_user_name,
                    'smtp_password': self.smtp_password,
                    'smtp_authentication': self.smtp_authentication,
                }
            }
        }
        return test.put_object(self, data=data)