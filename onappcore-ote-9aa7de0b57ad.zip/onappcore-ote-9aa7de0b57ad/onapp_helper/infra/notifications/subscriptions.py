from onapp_helper import test
from onapp_helper.base_helper import BaseHelper



class Subscriptions(BaseHelper):
    def __init__(self, id=None):
        self.id = id
        self.route = 'messaging/subscriptions'
        self.root_tag = 'messaging_subscription'
        self.name = ''
        self.topic = ''
        self.recipients_list = ''
        self.notification_template = ''
        self.gateway =''
        if self.id:
            test.update_object(self)

    def create(self):
        test.log.info("Create subscriptions...")
        data = {
            self.root_tag: {
                "name": self.name,
                "topic": self.topic,
                "recipients_list": self.recipients_list,
                "notification_template": self.notification_template,
                "gateway": self.gateway,
            }
        }
        return test.post_object(self, data=data)


