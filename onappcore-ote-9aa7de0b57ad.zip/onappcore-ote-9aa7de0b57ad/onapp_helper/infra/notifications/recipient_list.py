from onapp_helper import test
from onapp_helper.base_helper import BaseHelper



class RecipientList(BaseHelper):
    def __init__(self, id=None):
        self.id = id
        self.route = 'messaging/recipients_lists'
        self.root_tag = 'messaging_recipients_list'
        self.name = ''
        self.user_ids = []
        if self.id:
            test.update_object(self)

    def create(self):
        test.log.info("Create recipients_lists...")
        data = {
            self.root_tag: {
                "name": self.name,
                "recipient_ids": self.user_ids,
            }
        }
        return test.post_object(self, data=data)

    def update(self):
        test.log.info("Update rerecipients_lists...")
        data = {
            self.root_tag: {
                "name": self.name,
                "recipient_ids": self.user_ids,
            }
        }
        return test.post_object(self, data=data) # PUT has not been implemented


