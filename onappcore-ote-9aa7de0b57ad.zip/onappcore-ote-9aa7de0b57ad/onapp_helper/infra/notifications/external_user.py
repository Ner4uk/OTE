from onapp_helper import test
from onapp_helper.base_helper import BaseHelper



class ExternalUser(BaseHelper):
    def __init__(self, id=None):
        self.id = id
        self.route = 'messaging/external_users'
        self.root_tag = 'messaging_external_user'
        self.name = ''
        self.email = ''
        self.phone = ''
        if self.id:
            test.update_object(self)

    def create(self):
        test.log.info("Create external user...")
        data = {
            self.root_tag: {
                "name": self.name,
                "email": self.email,
                "phone": self.phone,
            }
        }
        return test.post_object(self, data=data)

    def update(self):
        test.log.info("Update external user...")
        data = {
            self.root_tag: {
                "name": self.name,
                "email": self.email,
                "phone": self.phone,

            }
        }
        return test.put_object(self, data=data)


