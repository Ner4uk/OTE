from random import randint
from onapp_helper import test
from onapp_helper.base_helper import BaseHelper


class Template(BaseHelper):
    route = 'templates'
    root_tag = 'image_template'

    def __init__(self, id=None):
        self.state = ''
        self.id = id
        self.type = None
        self.manager_id = None
        self.allowed_swap = None
        self.label = ''
        self.file_name = ''
        self.version = None
        self.min_disk_size = None
        self.min_memory_size = None
        self.allowed_hot_migrate = False
        if self.id:
            test.update_object(self)

    def edit(self):
        data = {
            self.root_tag: {
                "label": self.label,
                "file_name": self.file_name,
                "version": self.version,
                "min_disk_size": self.min_disk_size,
                "min_memory_size": self.min_memory_size
            }
        }
        test.log.info("Edit template")
        if test.cp_version >= 5.5:
            data[self.root_tag]['allowed_hot_migrate'] = self.allowed_hot_migrate

        return test.put_object(self, data=data)

    def make_template_public(self):
        test.log.info("Make template with an id - {} public".format(self.id))
        url = '/{}/{}/make_public.json'.format(self.route, self.id)
        return test.post_object(self, url=url)

    def find_any(self, template):
        test.log.info(
            "Find template matching - '{0}'...".format(template)
        )
        all_templates = self.find_all(template)
        if all_templates:
            self.__dict__.update(all_templates[0].__dict__)
            return True
        return False

    def search(self, query=None, os=None, virtualization=None, arch=None):
        """
        Search templates
        :param query: string obj, template label, etc...
        :param os: linux, windows, freebsd
        :param virtualization: xen, kvm, virtio ('xen' or 'xen,kvm')
        :param arch: x64, x86 ('x64' or 'x64,x86')
        :return: array of templates
        """
        if query:
            query = query.replace(' ', '+')
        templates = self._base_search(
            query=query, os=os, virtualization=virtualization, arch=arch
        )
        if templates:
            return [t for t in templates if t.state == 'active']
        return []

    def find_all(self, template):
        """Return an array of template obj."""
        test.log.info(
            "Find all templates matching - '{0}'...".format(template)
        )
        if template:
            template = template.replace(' ', '+')
        templates = self._get_objects(
            query='search_filter[query]={0}'.format(template)
        )
        if templates:
            return [t for t in templates if t.state == 'active' and not t.draas]
        return []

    def get_by_id(self, id):
        test.log.info("Get template by id...")
        url = '/{0}/{1}.json'.format(self.route, id)
        if test.get_object(self, url=url):
            self.__dict__.update(self.response[self.root_tag])
            return True
        return False

    def get_not_system(self, keyword=None):
        test.log.info("Get not system template...")
        templates = self.search(query=keyword)
        if templates:
            rez = [t for t in templates
                   if t.operating_system_distro != 'lbva'
                   and t.manager_id != 'cdn' and not t.user_id]
            if rez:
                return rez[0]
        return None

    def get_by_manager_id(self, manager_id):
        test.log.info("Get template by manager id - {}".format(manager_id))
        templates = self.get_all()
        templates = [t for t in templates if t.manager_id == manager_id]
        if templates:
            self.__dict__.update(templates[0].__dict__)
            return self
        test.log.info(
            "Template with manager_id - '{0}' does not exist...".format(
                manager_id
            )
        )
        self.error['template'] = f"Template with manager id '{manager_id}' does not exist."
        return False

    def upgrade(self):
        test.log.info("Upgrade template...")
        url = '/{0}/{1}/upgrade.json'.format(self.route, self.id)
        if test.put_object(self, url=url):
            id = int(
                test.cp.mysql_execute(
                    'SELECT id from templates ORDER BY id DESC LIMIT 1'
                )[0]
            )
            transaction_actions_chain = [
                ("download_template", id),
                ("test_checksum", id),
                ("distribute_template", id),
                ("cleanup_template", id)
            ]
            return self.transactions_handler(
                transactions_chain=transaction_actions_chain
            )
        return False

    def restart(self):
        test.log.info("Restart installing a new template...")
        url = '/{0}/installs/{1}/restart.json'.format(self.route, self.id)
        if test.post_object(self, url=url):
            if self.transaction_handler("cleanup_template", self.id):
                return True
        return False

    def delete(self):
        test.log.info("Delete template...")
        url = '/{0}/{1}.json'.format(self.route, self.id)
        if test.delete_object(self, url=url):
            if self.transaction_handler(
                    'destroy_{0}'.format(self.route[:-1]), self.id
            ):
                return True
        return False

    def all(self):
        """ Get all templates"""
        log_msg = "Get all templates..."
        return self._get_templates(log_msg=log_msg)

    def installed(self, query=None, os=None, virtualization=None, arch=None):
        """ Get installed templates"""
        route = '{0}/system'.format(self.route)

        return self._base_search(
            query=query,
            route=route,
            os=os, virtualization=virtualization, arch=arch
        )

    def available(self, query=None, os=None, virtualization=None, arch=None):
        """ Get available templates"""
        route = '{0}/available'.format(self.route)

        return self._base_search(
            query=query,
            route=route,
            root_tag='remote_template',
            os=os, virtualization=virtualization, arch=arch
        )

    def upgrades(self, query=None, os=None, virtualization=None, arch=None):
        """ Get templates available for upgrade"""
        route = '{0}/upgrades'.format(self.route)

        return self._base_search(
            query=query,
            route=route,
            root_tag='remote_template',
            os=os, virtualization=virtualization, arch=arch
        )

    def installations(self, query=None, os=None, virtualization=None, arch=None):
        """ Get templates of active installations."""
        route = '{0}/installs'.format(self.route)

        return self._base_search(
            query=query,
            route=route,
            os=os, virtualization=virtualization, arch=arch
        )

    def my_templates(self, query=None, os=None, virtualization=None, arch=None):
        """ Get current user templates."""
        route = '{0}/own'.format(self.route)

        return self._base_search(
            query=query,
            route=route,
            os=os, virtualization=virtualization, arch=arch
        )

    def user_templates(self, query=None, os=None, virtualization=None, arch=None):
        """ Get users templates."""
        route = '{0}/user'.format(self.route)

        return self._base_search(
            query=query,
            route=route,
            os=os, virtualization=virtualization, arch=arch
        )

    def inactive(self, query=None, os=None, virtualization=None, arch=None):
        """ Get inactive templates."""
        route = '{0}/inactive'.format(self.route)

        return self._base_search(
            query=query,
            route=route,
            os=os, virtualization=virtualization, arch=arch
        )

    def _get_templates(self, route=None, root_tag=None, log_msg=None):
        """ Return an array of template objects"""
        test.log.info(log_msg)
        return self._get_objects(route=route, root_tag=root_tag)

    def download(self, manager_id=None, backup_server_id=""):
        if not manager_id:
            manager_id = self.manager_id

        test.log.info("Download template - '{0}'...".format(manager_id))
        data = {
            self.root_tag: {
                "manager_id": manager_id,
                "backup_server_id": backup_server_id
            }
        }
        if test.post_object(self, data=data):
            transaction_actions_chain = [
                ("download_template", self.id),
                ("test_checksum", self.id),
                ("distribute_template", self.id),
                ("cleanup_template", self.id)
            ]
            if manager_id == self.manager_id and 'win' in manager_id:
                k = 1800  # ~ speed
                timeout = int(self.template_size / k)
            else:
                timeout = 300

            return self.transactions_handler(
                transactions_chain=transaction_actions_chain,
                timeout=timeout
            )
        return False

    def get_for_server(self, label, obj_route=None, **kwargs):
        # ToDO add for others types of servers
        """
        Find template by 'label', and set it as server template.
        :param label: Template label, can be for example as "Debian 5.0 x86",
          "Debian" or "Debian 5.0", if not specified - get random template
        :param obj_route: for example 'virtual_machines' or
          'application_servers', etc... will find a template for particular
          server type
        :param kwargs: any other template attributes: virtualization="xen",
          allowed_hot_migrate=True, etc
        :return: True if success else False.
        """
        test.log.info("Get template for create...")
        # Get templates for concrete server type
        templates = self.find_all(label) if label else self.get_all()
        templates = [
            t for t in templates
            if (
                   test.env.hv.hypervisor_type in t.virtualization
                   and 'fake' not in t.label.lower()
               ) and (
                (
                    obj_route == 'virtual_machines'
                    and t.operating_system_distro != "lbva"
                    and not t.application_server
                    and not t.cdn
                    and not t.remote_id
                ) or (
                    obj_route == 'application_servers'
                    and t.operating_system_distro != "lbva"
                    and t.application_server
                    and not t.remote_id
                ) or (
                    obj_route == 'container_servers'
                    and t.operating_system_distro == "coreos"
                    and not t.cdn
                    and not t.remote_id
                ) or (
                    obj_route == 'smart_servers'
                    and t.operating_system_distro != "lbva"
                    and not t.application_server
                    and not t.cdn
                    and not t.remote_id
                    and t.smart_server
                ) or (
                    obj_route == 'baremetal_servers'
                    and t.operating_system_distro != "lbva"
                    and not t.application_server
                    and not t.cdn
                    and not t.remote_id
                    and t.baremetal_server
                ) or (
                    obj_route == 'load_balancing_clusters'
                    and t.operating_system_distro == "lbva"
                    and not t.application_server
                    and not t.cdn
                    and not t.remote_id
                ) or (
                    obj_route == 'openstack_servers'
                    and "openstack" in t.virtualization
                    and not t.remote_id
                )
            )
        ]
        sorted_templates = []
        # Get templates satisfying kwargs
        if templates and kwargs:
            sorted_templates = self._filter_templates_by_kwargs(
                templates, kwargs
            )
        else:
            sorted_templates = templates
        # Select random template from scope
        if sorted_templates:
            self.__dict__.update(
                sorted_templates[randint(0, len(sorted_templates) - 1)].__dict__
            )
            return True
        test.log.info(
            "The template with label - {0} can not be found. "
            "Please see method 'Template.get_for_server'".format(
                label
            )
        )
        return False

    @staticmethod
    def template_ids_allocated_to_group():
        return test.cp.mysql_execute(
            "select templates.id from templates "
            "INNER JOIN relation_group_templates ON "
            "templates.id = relation_group_templates.template_id"
        )

    def _base_search(
            self,
            query=None,
            route=None,
            root_tag=None,
            os=None,
            virtualization=None,
            arch=None
    ):
        """
        Search templates
        :param query: string obj, template label, etc...
        :param route: route to templates (available, upgrades, etc...)
        :param os: linux, windows, freebsd
        :param virtualization: xen, kvm, virtio ('xen' or 'xen,kvm')
        :param arch: x64, x86 ('x64' or 'x64,x86')
        :return: array of templates
        """
        test.log.info(
            "Search from {} templates...".format('all' if not route else route)
        )

        search_keys = {
            'query': 'search_filter[query]',
            'os': 'search_filter[os][]',
            'virtualization': 'search_filter[virtualization][]',
            'arch': 'search_filter[arch][]'
        }

        return self._search(
            search_keys=search_keys,
            route=route,
            root_tag=root_tag,
            query=query,
            os=os,
            virtualization=virtualization,
            arch=arch
        )

    def get_ungrouped(self):
        grouped_template_ids = set(test.cp.mysql_execute(
            'SELECT template_id from relation_group_templates'
        ))
        return [
            t for t in Template().installed()
            if str(t.id) not in grouped_template_ids
        ]

    @staticmethod
    def _filter_templates_by_kwargs(templates, kwargs):
        """Filter templates by kwargs"""
        sorted_templates = []
        for t in templates:
            suitable_template = True
            for key, value in kwargs.items():
                # Both elements are list
                if isinstance(t.__dict__[key], list) and isinstance(
                        value, list
                ):
                    if value != t.__dict__[key]:
                        suitable_template = False
                        break

                # Template attribute is list
                elif isinstance(t.__dict__[key], list) and not isinstance(
                        value, list
                ):
                    if value not in t.__dict__[key]:
                        suitable_template = False
                        break

                # kwarg argument is list
                elif not isinstance(t.__dict__[key], list) and isinstance(
                        value, list
                ):
                    if t.__dict__[key] not in value:
                        suitable_template = False
                        break

                # kwarg argument and template argument are equal
                else:
                    if t.__dict__[key] != value:
                        suitable_template = False
                        break
                        
            if suitable_template:
                sorted_templates.append(t)
        return sorted_templates

    @property
    def centos5(self):
        """
        Check if current template is centos5
        :return: True if centos5 else False
        """
        # Try easy logic )
        return 'centos5' in self.manager_id
