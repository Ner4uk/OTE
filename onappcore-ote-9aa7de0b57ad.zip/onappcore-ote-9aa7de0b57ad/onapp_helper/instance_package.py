from onapp_helper.base_helper import BaseHelper
from onapp_helper import test


class InstancePackage(BaseHelper):
    route = 'instance_packages'
    root_tag = route[:-1]

    def __init__(self):
        self.id = 0
        self.label = ''
        self.cpus = 1
        self.memory = 128
        self.disk_size = 6
        self.bandwidth = 1
        self._setup()

    def get_by_label(self, label):
        test.log.info("Get InstancePackage list by label...")
        instance_package = [
            instance for instance in self.get_all()
            if label.lower() in instance.label.lower()
            ]
        if instance_package:
            self.__dict__.update(instance_package[0].__dict__)
            return True
        return False

    def create(self):
        test.log.info("Create InstancePackage...")
        data = {
            self.root_tag: {
                "label": self.label,
                "cpus": self.cpus,
                "memory": self.memory,
                "disk_size": self.disk_size,
                "bandwidth": self.bandwidth
            }
        }
        return test.post_object(self, data=data)

    def edit(self):
        test.log.info("Edit InstancePackage...")
        data = {
            self.root_tag: {
                "label": self.label,
                "cpus": self.cpus,
                "memory": self.memory,
                "disk_size": self.disk_size,
                "bandwidth": self.bandwidth
            }
        }
        return test.put_object(self, data=data)

    def _setup(self):
        if test.api_version is None or test.api_version >= 4.3:
            self.route = 'instance_packages'
            self.root_tag = self.route[:-1]
        elif test.api_version == 4.2:
            self.route = 'instance_types'
            self.root_tag = self.route[:-1]
        else:
            raise SystemError('"api_version" parameter misconfigured.')

    def sync_with_openstack(self):
        test.log.info("Sync with openstack")
        url = '/instance_packages/sync_with_openstack.json'
        return test.post_object(self, url=url)

    def get_openstack_only(self):
        """
        returns a list of packages imported from openstack
        (only those can be used for openstack servers)
        :return: list
        """
        test.log.info("Get openstack instance packages")
        return [ip for ip in self.get_all() if ip.openstack_id]

    def get_instance_packages_for_template(self, template, ipackages=[]):
        """
        been given a template object returns a list of packages with suitable ram and disk sizes
        if instance packages not given, it takes all from CP
        """
        test.log.info(
            "Get instance packages for template {}".format(template.label)
        )
        if not ipackages:
            ipackages = self.get_all()

        ipacks = [
            p for p in ipackages
            if p.disk_size >= template.min_disk_size and p.memory >= template.min_memory_size
        ]
        return ipacks
