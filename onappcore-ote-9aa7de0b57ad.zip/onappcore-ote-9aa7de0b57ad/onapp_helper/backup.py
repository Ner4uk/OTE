import time
from onapp_helper.base_helper import BaseHelper
from onapp_helper.template import Template
from onapp_helper import test


class Type:
    normal = 'normal'
    incremental = 'incremental'


class Backup(BaseHelper):
    TYPE = Type
    route = 'backups'
    root_tag = route[:-1]

    def __init__(self, parent_obj=None, id=None):
        self.parent_obj = parent_obj
        self.label = ''
        self.id = id
        self.backup_type = None
        if self.id:
            test.update_object(self)
        self.backup_size = 0

    def create(self, disk=None, **kwargs):
        """
        Create backup
        :param disk: If disk is None the primary disk will be using for normal backup.
        You can take a backup for an additional disk just passing the disk object.
        :param kwargs: note - str, force_windows_backup - boolean
        :return:
        """
        self.disk = disk
        if not self.parent_obj.id:
            test.update_object(self.parent_obj)
        #  If backup type is not defined - get backup type from settings.
        if not self.backup_type:
            if test.onapp_settings.get().allow_incremental_backups:
                self.backup_type = self.TYPE.incremental
            else:
                self.backup_type = self.TYPE.normal

        test.log.info("Create {0} backup...".format(self.backup_type))
        # Create a backup
        if self._backup_creator(**kwargs):
            if self._backup_response_handler():
                test.update_object(self)
                return True
        return False

    # # todo
    def create_for_all_disks(self):
        backups = []
        if not test.onapp_settings.get().allow_incremental_backups:
            url = '/{}/{}/{}'.format(
                self.parent_obj.route, self.parent_obj.id, self.route
            )
            if test.post_object(self, url=url):
                for backup_dict in self.response:
                    if not self.transaction_handler(
                        "take_backup", backup_dict[self.root_tag]['id']
                    ):

                        return backups
                    else:
                        backups.append(
                            Backup(
                                parent_obj=self.parent_obj,
                                id=backup_dict[self.root_tag]['id']
                            )
                        )
        return backups

    def restore(self, force_restore=False):
        """
        Restore a backup
        :param force_restore: since 5.9 (https://onappdev.atlassian.net/browse/CORE-12149)
        :return: True if success else False
        """
        test.log.info("Restore {0} backup...".format(self.backup_type))
        url = '/{0}/{1}/restore.json'.format(self.route, self.id)
        action = ''
        data = {}
        if self.backup_type == self.TYPE.normal:
            action = 'restore_backup'
        elif self.backup_type == self.TYPE.incremental:
            action = 'restore_incremental_backup'
            data = {
                "force_restore": force_restore
            }
        else:
            test.log.warning("UNDEFINED BACKUP TYPE!")

        if test.post_object(self, url=url, data=data):
            if self.parent_obj.booted:
                if self.transaction_handler(
                    'stop_{0}'.format(self.parent_obj.server_type),
                    self.parent_obj.id
                ):
                    if self.transaction_handler(action):
                        self.transaction_handler(
                            'startup_{0}'.format(self.parent_obj.server_type),
                            self.parent_obj.id
                        )
            else:
                self.transaction_handler(action)

            if not self.error:
                test.update_object(self)
                test.update_object(self.parent_obj)
                return True
        return False

    def convert(self, label=None):
        """
        converting a backup method return a new template obj.
        If POST return some errors they stored in template obj
        To see transaction details use backup obj

        :return: template obj
        """
        self.label = label
        if not self.label:
            self.label = 'backup_auto_test_{0}'.format(
                time.strftime('%d%m%Y%H%M%S')
            )
        test.log.info("Convert {0} backup...".format(self.backup_type))
        data = {
            "backup": {
                "label": self.label,
                "min_disk_size": self.parent_obj.template.min_disk_size,
                "min_memory_size": self.parent_obj.template.min_memory_size
            }
        }
        url = '/{0}/{1}/convert.json'.format(self.route, self.id)
        self.template = Template()
        if test.post_object(self.template, url=url, data=data):
            if self.template.transaction_handler('convert_backup', self.id):
                test.update_object(self.template)
                return self.template
        return False

    def get_all(self):
        """
        If parent_obj passed return all backups related to parent object
        :return: backups objects
        """
        if self.parent_obj:
            test.log.info(
                "Get all {} backups.".format(self.parent_obj.__class__.__name__)
            )
            return self._get_objects(
                route='{}/{}/backups'.format(
                    self.parent_obj.route,
                    self.parent_obj.id
                ),
                parent_obj=self.parent_obj
            )
        else:
            test.log.error("Please set parent_obj to get backups.")
            self.error['parent_obj'] = "Please set parent_obj to get backups"
            return []

    def delete(self):
        test.log.info("Delete {0} backup...".format(self.backup_type))
        if test.delete_object(self):
            if self.transaction_handler('destroy_backup', self.id):
                return True
        return False

    def _backup_creator(self, **kwargs):
        data = {"backup": kwargs} if kwargs else kwargs

        if self.backup_type == self.TYPE.normal:
            if not self.disk:
                self.disk = self.parent_obj.get_primary_disk()

            # Wait for server and disk be unlocked
            test.wait_for_action(
                lambda: test.update_object(self.parent_obj) and not
                self.parent_obj.locked,
                timeout=60,
                step=10
            )
            test.wait_for_action(
                lambda: test.update_object(self.disk) and not
                self.disk.locked,
                timeout=60,
                step=10
            )

            url = '/{0}/{1}/backups.json'.format(self.disk.route, self.disk.id)

        elif self.backup_type == self.TYPE.incremental:
            url = '/{0}/{1}/backups.json'.format(
                self.parent_obj.route, self.parent_obj.id
            )

        else:
            raise SystemError('Undefined backup type...')

        return test.post_object(self, url=url, data=data)

    def _backup_response_handler(self):
        #self.id = self.response['backup']['id']
        if self.backup_type == self.TYPE.normal:
            action = 'take_backup'
        elif self.backup_type == self.TYPE.incremental:
            action = 'take_incremental_backup'
        else:
            raise SystemError('Undefined backup type...')
        if self.transaction_handler(action, self.id):
            return True

        return False
