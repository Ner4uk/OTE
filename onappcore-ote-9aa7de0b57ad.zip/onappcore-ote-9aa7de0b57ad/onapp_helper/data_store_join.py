from onapp_helper.base_helper import BaseHelper
from onapp_helper import test


class DataStoreJoin(BaseHelper):
    def __init__(self, parent_obj=None, id=None):
        """Where obj is HV or HVZ object"""
        self.parent_obj = parent_obj
        self.id = id
        self.root_tag = 'data_store_join'
        if self.id:
            test.update_object(self)

    def add(self, ds):
        test.log.info("Add data store join...")
        data = {
            "data_store_id": ds.id
        }
        return test.post_object(self, data=data)

    def remove(self):
        test.log.info("Remove data store join...")
        return test.delete_object(self)

    def route(self):
        return '{0}/{1}/data_store_joins'.format(
            self.parent_obj.route, self.parent_obj.id
        )
