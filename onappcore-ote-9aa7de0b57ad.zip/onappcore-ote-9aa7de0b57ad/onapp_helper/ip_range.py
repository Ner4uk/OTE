#  Since 5.4
from onapp_helper.base_helper import BaseHelper
from onapp_helper import test


class IpRange(BaseHelper):
    root_tag = 'ip_range'

    def __init__(self, parent_obj=None, id=None):
        """

        :param parent_obj: ip network obj
        :param id: ip range id
        """
        self.parent_obj = parent_obj
        self.default_gateway = ''
        self.ip_net_id = ''
        self.start_address = ''
        self.end_address = ''
        self.id = id
        if self.id:
            test.update_object(self)

    def create(self):
        test.log.info("Create ip_range...")
        data = {
            self.root_tag: {
                "start_address": self.start_address,
                "end_address": self.end_address,
                "default_gateway": self.default_gateway
            }
        }
        return test.post_object(self, data=data)

    def edit(self):
        test.log.info("Edit ip_range...")
        data = {
            self.root_tag: {
                "start_address": self.start_address,
                "end_address": self.end_address,
                "default_gateway": self.default_gateway
            }
        }
        return test.put_object(self, data=data)

    def list_ip_ranges_by_ip_net(self, ip_net_id):
        """
        Get list of ip_ranges assigned to ip_networks
        :param ip_net_id: can be or ip_network id or a list of ip_network ids
        :return: list of ip_ranges
        """
        test.log.info("Get list of ip panges by ip net")
        data = {'ip_net_id': ip_net_id}
        #url = '/{0}.json?ip_net_id[]=1&ip_net_id[]=2'.format(self.route)
        #data = {'network_id': 1}
        return self._get_objects(data=data)

    def route(self):
        return '{}/{}/ip_ranges'.format(
            self.parent_obj.route(), self.parent_obj.id
        )
