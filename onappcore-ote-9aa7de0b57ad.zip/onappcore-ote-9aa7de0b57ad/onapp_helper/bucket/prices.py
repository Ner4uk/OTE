__since__ = 5.6


class AcceleratedServersPrices():
    def __init__(self, server_type):
        self.limit_free = 0
        self.price = 0


class AutoscaledServersPrices():
    def __init__(self, server_type):
        if server_type in ['virtual']:
            self.limit_free = 0
            self.price = 0


class BackupServerZonePrices():
    def __init__(self, server_type):
        if server_type in ['virtual']:
            self.limit_backup_free = 0
            self.limit_backup_disk_size_free = 0
            self.limit_template_free = 0
            self.limit_template_disk_size_free = 0
            self.limit_ova_free = 0
            self.limit_ova_disk_size_free = 0

            self.price_backup = 0
            self.price_template = 0
            self.price_template_disk_size = 0
            self.price_backup_disk_size = 0
            # OVA available since 5.2
            self.price_ova = 0
            self.price_ova_disk_size = 0
        elif server_type in ['smart']:
            self.limit_backup_free = 0
            self.limit_backup_disk_size_free = 0
            self.limit_template_free = 0
            self.limit_template_disk_size_free = 0

            self.price_backup = 0
            self.price_template = 0
            self.price_template_disk_size = 0
            self.price_backup_disk_size = 0


class BackupsPrices():
    def __init__(self, server_type):
        if server_type in ['virtual', 'smart']:
            self.limit_free = 0
            self.price = 0


class ComputeResourceStoringPrices():
    def __init__(self, server_type):
        if server_type in ['virtual', 'smart']:
            self.limit_free = 0
            self.price = 0


class ComputeZonePrices():
    def __init__(self, server_type):
        if server_type in ['virtual', 'smart']:
            self.limit_free_cpu = 0
            self.limit_free_cpu_share = 0
            self.limit_free_cpu_units = 0
            self.limit_free_memory = 0

            self.price_on_cpu = 0
            self.price_off_cpu = 0
            self.price_on_cpu_share = 0
            self.price_off_cpu_share = 0
            self.price_on_memory = 0
            self.price_off_memory = 0
            self.price_on_cpu_units = 0
            self.price_off_cpu_units = 0
        elif server_type in ['vpc']:
            self.limit_free_allocation_cpu_allocation = 0
            self.limit_free_allocation_cpu_resources_guaranteed = 0
            self.limit_free_allocation_cpu_used = 0
            self.limit_free_allocation_memory_allocation = 0
            self.limit_free_allocation_memory_resources_guaranteed = 0
            self.limit_free_allocation_memory_used = 0
            self.limit_free_allocation_vcpu_speed = 0
            self.limit_free_reservation_cpu_allocation = 0
            self.limit_free_reservation_memory_allocation = 0
            self.limit_free_pay_as_you_go_cpu_limit = 0
            self.limit_free_pay_as_you_go_memory_limit = 0
            self.limit_free_pay_as_you_go_cpu_used = 0
            self.limit_free_pay_as_you_go_memory_used = 0
            self.limit_free_vs_cpu = 0
            self.limit_free_vs_memory = 0
            self.price_allocation_cpu_allocation = 0
            self.price_allocation_cpu_resources_guaranteed = 0
            self.price_allocation_cpu_used = 0
            self.price_allocation_memory_allocation = 0
            self.price_allocation_memory_resources_guaranteed = 0
            self.price_allocation_memory_used = 0
            self.price_allocation_vcpu_speed = 0
            self.price_reservation_cpu_allocation = 0
            self.price_reservation_memory_allocation = 0
            self.price_pay_as_you_go_cpu_limit = 0
            self.price_pay_as_you_go_memory_limit = 0
            self.price_pay_as_you_go_cpu_used = 0
            self.price_pay_as_you_go_memory_used = 0
            self.price_pay_as_you_go_cpu_limit_unlimited = 0
            self.price_pay_as_you_go_memory_limit_unlimited = 0
            self.price_on_vs_cpu = 0
            self.price_off_vs_cpu = 0
            self.price_on_vs_memory = 0
            self.price_off_vs_memory = 0


class DataStoreZonePrices():
    def __init__(self, server_type):
        if server_type in ['virtual', 'smart']:
            self.limit_free = 0
            self.limit_data_read_free = 0
            self.limit_data_written_free = 0
            self.limit_reads_completed_free = 0
            self.limit_writes_completed_free = 0
            self.limit_free_monthly = 0
            self.limit_data_read_free_monthly = 0
            self.limit_data_written_free_monthly = 0
            self.limit_reads_completed_free_monthly = 0
            self.limit_writes_completed_free_monthly = 0

            self.price_data_read = 0
            self.price_data_written = 0
            self.price_on = 0
            self.price_off = 0
            self.price_writes_completed = 0
            self.price_reads_completed = 0
        elif server_type in ['vpc']:
            # https://onappdev.atlassian.net/browse/CORE-11717
            # Use this:
            self.limit_free_disk_size = 0
            self.limit_free_disk_size_used = 0
            self.limit_free_vs_disk_size = 0
            self.limit_free_vs_data_read = 0
            self.limit_free_vs_data_written = 0
            self.limit_free_vs_reads_completed = 0
            self.limit_free_vs_writes_completed = 0
            self.price_vs_data_read = 0
            self.price_vs_data_written = 0
            self.price_vs_reads_completed = 0
            self.price_vs_writes_completed = 0
            self.price_disk_size = 0
            self.price_disk_size_used = 0
            self.price_disk_size_unlimited = 0
            self.price_vs_disk_size_on = 0
            self.price_vs_disk_size_off = 0

            # # instead of this:
            # self.limit_free_disk_size = 0
            # self.limit_free_disk_size_used = 0
            # self.limit_free_vs_disk_size = 0
            # self.price_disk_size = 0
            # self.price_disk_size_used = 0
            # self.price_disk_size_unlimited = 0
            # self.price_vs_disk_size_on = 0
            # self.price_vs_disk_size_off = 0


class DRaaSPrices():
    def __init__(self, server_type):
        self.price_disk_size = 0
        self.price_memory = 0
        self.price_cpus = 0
        self.price_cpu_shares = 0
        self.price_cpu_units = 0
        self.price_nodes = 0


class EdgeGroupPrices():
    def __init__(self, server_type):
        if server_type in ['other']:
            self.price = 0


class InstancePackagePrices():
    def __init__(self, server_type):
        self.price_on = 0
        self.price_off = 0
        self.price_overused_bandwidth = 0


class ISOTemplatesPrices():
    def __init__(self, server_type):
        if server_type in ['virtual', 'smart']:
            self.limit_free = 0
            self.price = 0


class NetworkZonePrices():
    def __init__(self, server_type):
        if server_type in ['virtual', 'smart']:
            # https://onappdev.atlassian.net/browse/CORE-11751
            # free_limit for port speed - one of the free-parameters,
            # which relates to each network interface instead of zone
            self.limit_rate_free = 0  # has different behaviour
            self.limit_ip_free = 0
            self.limit_data_sent_free = 0
            self.limit_data_received_free = 0
            self.limit_ip_free_monthly = 0
            self.limit_data_sent_free_monthly = 0
            self.limit_data_received_free_monthly = 0

            self.price_ip_on = 0
            self.price_ip_off = 0
            self.price_rate_on = 0
            self.price_rate_off = 0
            self.price_data_sent = 0
            self.price_data_received = 0
        elif server_type in ['vpc']:
            self.limit_free_ip = 0
            self.limit_free_data_sent = 0
            self.limit_free_data_received = 0
            self.limit_free_vs_ip = 0
            self.limit_free_vs_data_sent = 0
            self.limit_free_vs_data_received = 0
            self.price_ip = 0
            self.price_data_sent = 0
            self.price_data_received = 0
            self.price_vs_ip_on = 0
            self.price_vs_ip_off = 0
            self.price_vs_data_sent = 0
            self.price_vs_data_received = 0
        elif server_type in ['baremetal']:
            self.limit_ip_free = 0
            self.price_ip = 0


class ServiceAddonPrices():
    def __init__(self, server_type):
        self.price = 0
        self.price_cpu = 0
        self.price_memory = 0
        self.price_disk_size = 0


# class ServiceAddonGroupsPrices():
#     def __init__(self, server_type):
#         self.price = 0
#         self.price_cpu = 0
#         self.price_memory = 0
#         self.price_disk_size = 0


class SolidfireDataStoreZonePrices():
    def __init__(self, server_type):
        self.limit_free = 0
        self.price_on = 0
        self.price_off = 0


class TemplatePrices:
    def __init__(self, server_type):
        self.price = 0


class TemplatesPrices():
    def __init__(self, server_type):
        if server_type in ['virtual', 'smart']:
            self.limit_free = 0
            self.price = 0
