from onapp_helper.base_helper import BaseHelper
from onapp_helper import test


class Bucket(BaseHelper):
    __since__ = 5.6
    route = 'billing/buckets'
    root_tag = 'bucket'

    def __init__(self, id=None):
        self.id = id
        self.label = "BOT(BucketOTETest)"
        self.currency_code = "USD"
        self.monthly_price = 0.0
        self.allows_kms = "false"
        self.allows_mak = "true"
        self.allows_own = "false"
        self.show_price = None
        self.type = None
        self.associated_with_users = 0
        if self.id:
            test.update_object(self)

    def create(self):
        """
        Default values:
            label = "zaza_billing_test"
            currency_code = "USD"
            monthly_price = "0.0"
            allows_kms = "false"
            allows_mak = "true"
            allows_own = "false"
        """
        test.log.info("Create {}...".format(self.__class__.__name__))
        data = {
            self.root_tag: {
                "label": self.label,
                "currency_code": self.currency_code,
                "monthly_price": self.monthly_price,
                "allows_kms": self.allows_kms,
                "allows_mak": self.allows_mak,
                "allows_own": self.allows_own
            }
        }
        return test.post_object(self, data=data)

    def edit(self):
        test.log.info("Edit {}...".format(self.__class__.__name__))
        data = {
            self.root_tag: {
                "label": self.label,
                "currency_code": self.currency_code,
                "monthly_price": self.monthly_price,
                "allows_kms": self.allows_kms,
                "allows_mak": self.allows_mak,
                "allows_own": self.allows_own
            }
        }
        return test.put_object(self, data=data)

    def clone(self, dst=None):
        """
        Return a new bucket obj or update dst

        :param dst: destination bucket obj

        :return: Cloned bucket object.
        """
        test.log.info("Clone {}...".format(self.__class__.__name__))
        url = "/{}/{}/clone.json".format(self.route, self.id)
        bucket = dst if dst else Bucket()
        test.post_object(bucket, url=url)
        return bucket

    def get_all_access_controls(self):
        url = '/{}/{}/access_controls.json'.format(self.route, self.id)
        test.get_object(self, url=url)
