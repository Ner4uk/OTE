__since__ = 5.6

from onapp_helper import test


class ServerType:
    virtual = 'virtual'
    smart = 'smart'
    baremetal = 'baremetal'
    vpc = 'vpc'
    ocm = 'ocm'
    other = 'other'
    infrastructure = 'infrastructure'


class TimingStrategy:
    hourly = 'hourly'
    monthly = 'monthly'


class BaseResource:
    E_GREATER_OR_EQUAL_TO_0 = 'must be between 0 and Infinity'
    # Since 5.9 should be 2 different errors
    # E_MUST_BE_BETWEEN_ZERO_AND_INFINITY = 'must be between 0 and Infinity'
    # E_GREATER_OR_EQUAL_TO_0 = 'must be greater than or equal to 0'
    E_WRONG_TARGET_ID = 'could not be found'
    E_INCORRECT_TARGET = 'the target server type is inappropriate for the request'

    def get(self):
        """
        Get (update) obj details.
        :return: True if success else False
        """
        test.log.info(
            "Get {} - {}...".format(self.__class__.__name__, self.type)
        )

        data = {
            self.root_tag: {
                "type": self.type,
                "bucket_id": self.parent_obj.id,
                "server_type": self.server_type,
                "target_id": self.target_id
            }
        }

        url = '/{}.json'.format(self.route()[:-1])

        if test.get_object(self, data=data, url=url):
            self._dict_to_class(self.response)
            return self
        else:
            test.log.error("Can't get object...")
        return False

    def delete(self):
        """
        Delete obj without transaction.
        :return: True if success else False
        """
        test.log.info(
            "Delete {} - {}...".format(self.__class__.__name__, self.type)
        )

        data = {
            self.root_tag: {
                "type": self.type,
                "bucket_id": self.parent_obj.id,
                "server_type": self.server_type,
                "target_id": self.target_id
            }
        }
        return test.delete_object(
            self,
            url="/{}/delete.json".format(self.route()),
            data=data
        )

    # def search(self):
    #     if hasattr(self, 'target_id'):
    #         target_id = self.target_id
    #     else:
    #         target_id = None
    #
    #     resources = [
    #         resource for resource in self._get_objects(
    #             parent_obj=self.parent_obj
    #         ) if resource.type == self.type and (
    #             resource.target_id == target_id if hasattr(
    #                 resource, 'target_id'
    #             ) else True
    #         )
    #     ]
    #
    #     if resources:
    #         if len(resources) == 1:
    #             self.__dict__.update(resources[0].__dict__)
    #             self._dict_to_class()
    #             return True
    #         test.log.warning(
    #             "There is more than one resource with type - {} and target_id - {}".format(
    #                 self.type, self.target_id
    #             )
    #         )
    #     return False

    def _dict_to_class(self, dic):
        """
        Convert dict (response) to class attributes for limits, prices,
        and preferences
        :return: self
        """
        if self.root_tag == 'access_control' and (self.limits or self.preferences):
            if self.limits:
                self.limits = self._limits.__new__(self._limits.__class__)
                self.limits.__dict__.update(dic[self.root_tag]["limits"])  # dict to class attributes
            if self.preferences:
                self.preferences = self._preferences.__new__(
                    self._preferences.__class__
                )
                self.preferences.__dict__.update(dic[self.root_tag]["preferences"])  # dict to class attributes

        elif self.root_tag == 'access_control' and not (
                    self.limits or self.preferences
        ):
            pass

        elif self.root_tag == 'rate_card':
            # prices = self.prices
            self.prices = self._prices.__new__(self._prices.__class__)
            self.prices.__dict__.update(dic[self.root_tag]["prices"])  # dict to class attributes
        else:
            test.log.error('Undefined root tag - {}'.format(self.root_tag))
        return self
