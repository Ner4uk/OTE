__since__ = 5.6

from random import randint
from onapp_helper import test
from onapp_helper.base_helper import BaseHelper
from onapp_helper.bucket.prices import *
from onapp_helper.bucket.resource_base import *


SERVER_TYPE = ServerType
TIMING_STRATEGY = TimingStrategy

UNSUPPORTED_SERVER_TYPES = [
    SERVER_TYPE.ocm,
    SERVER_TYPE.smart,
    SERVER_TYPE.baremetal
]


class BasePrices:
    pass


class RateCardBase(BaseResource, BaseHelper):
    root_tag = 'rate_card'
    SERVER_TYPE = ServerType

    def __init__(
            self,
            parent_obj=None,
            target_id=None,
            server_type=SERVER_TYPE.virtual
    ):
        """
        :param parent_obj: bucket object
        :param target_id: an id of target obj (HVZ, DSZ, NetZ, etc...) or
        service addon id / template id for "Limits for Service Add-on Groups"
        / "Limits for Template Store"
        :param server_type: zone server type
        """

        self.parent_obj = parent_obj
        self.target_id = target_id
        self.server_type = server_type
        self.timing_strategy = TIMING_STRATEGY.hourly
        self.create_access_control = False
        self.apply_to_all_resources_in_the_bucket = False

    def create(self):
        data = {
            self.root_tag: {
                "target_id": self.target_id,
                "type": self.type,
                "bucket_id": self.parent_obj.id,
                "server_type": self.server_type,
                "create_access_control": self.create_access_control,
                "apply_to_all_resources_in_the_bucket": self.apply_to_all_resources_in_the_bucket
            }
        }

        if hasattr(self, "prices"):
            data[self.root_tag]["prices"] = self.prices.__dict__

        if self.server_type == SERVER_TYPE.vpc:
            data[self.root_tag]["timing_strategy"] = self.timing_strategy

        test.log.info(
            "Create {} - {}...".format(self.__class__.__name__, self.type)
        )
        if test.post_object(self, data=data):
            return self._dict_to_class(self.response)
        return False

    def edit(self):
        data = {
            self.root_tag: {
                "target_id": self.target_id,
                "type": self.type,
                "bucket_id": self.parent_obj.id,
                "server_type": self.server_type,
                "apply_to_all_resources_in_the_bucket": self.apply_to_all_resources_in_the_bucket
            }
        }

        if hasattr(self, "prices"):
            data[self.root_tag]["prices"] = self.prices.__dict__

        test.log.info(
            "Create {} - {}...".format(self.__class__.__name__, self.type)
        )
        if test.put_object(
            self, url="/{}.json".format(self.route()),
            data=data
        ):
            return self.get()
        return False

    def reset(self):
        self.prices.__init__(self.server_type)

    def route(self):
        return "{}/{}/rate_cards".format(
            self.parent_obj.route, self.parent_obj.id
        )


# TODO - generate automatically
class AcceleratedServersRC(RateCardBase):
    type = 'accelerated_servers_resource'

    def __init__(self, **kwargs):
        RateCardBase.__init__(self, **kwargs)
        self._prices = AcceleratedServersPrices(self.server_type)
        self.prices = self._prices


class ApplicationServersRC(RateCardBase):
    type = 'application_servers_resource'

    def __init__(self, **kwargs):
        RateCardBase.__init__(self, **kwargs)


class AutoscaledServersRC(RateCardBase):
    type = 'autoscaled_servers_resource'

    def __init__(self, **kwargs):
        RateCardBase.__init__(self, **kwargs)
        self._prices = AutoscaledServersPrices(self.server_type)
        self.prices = self._prices


class BackupServerZoneRC(RateCardBase):
    type = 'backup_server_zone_resource'

    def __init__(self, **kwargs):
        RateCardBase.__init__(self, **kwargs)
        self._prices = BackupServerZonePrices(self.server_type)
        self.prices = self._prices


class BackupsRC(RateCardBase):
    type = 'backups_resource'

    def __init__(self, **kwargs):
        RateCardBase.__init__(self, **kwargs)
        self._prices = BackupsPrices(self.server_type)
        self.prices = self._prices


class ComputeResourceStoringRC(RateCardBase):
    type = 'compute_resource_storing_resource'

    def __init__(self, **kwargs):
        RateCardBase.__init__(self, **kwargs)
        self._prices = ComputeResourceStoringPrices(self.server_type)
        self.prices = self._prices


class ComputeZoneRC(RateCardBase):
    type = 'compute_zone_resource'

    def __init__(self, **kwargs):
        RateCardBase.__init__(self, **kwargs)
        self._prices = ComputeZonePrices(self.server_type)
        self.prices = self._prices


class ContainerServersRC(RateCardBase):
    type = 'container_servers_resource'

    def __init__(self, **kwargs):
        RateCardBase.__init__(self, **kwargs)


class DataStoreZoneRC(RateCardBase):
    type = 'data_store_zone_resource'

    def __init__(self, **kwargs):
        RateCardBase.__init__(self, **kwargs)
        self._prices = DataStoreZonePrices(self.server_type)
        self.prices = self._prices


class DraasRC(RateCardBase):
    type = 'draas_resource'

    def __init__(self, **kwargs):
        RateCardBase.__init__(self, **kwargs)
        self._prices = DRaaSPrices(self.server_type)
        self.prices = self._prices


class EdgeGroupsRC(RateCardBase):
    type = 'edge_groups_resource'

    def __init__(self, **kwargs):
        RateCardBase.__init__(self, **kwargs)
        self._prices = EdgeGroupPrices(self.server_type)
        self.prices = self._prices


class InstancePackageRC(RateCardBase):
    type = 'preconfigured_servers_resource'

    def __init__(self, **kwargs):
        RateCardBase.__init__(self, **kwargs)
        self._prices = InstancePackagePrices(self.server_type)
        self.prices = self._prices


class ISOTemplatesRC(RateCardBase):
    type = 'iso_templates_resource'

    def __init__(self, **kwargs):
        RateCardBase.__init__(self, **kwargs)
        self._prices = ISOTemplatesPrices(self.server_type)
        self.prices = self._prices


class NetworkZoneRC(RateCardBase):
    type = 'network_zone_resource'

    def __init__(self, **kwargs):
        RateCardBase.__init__(self, **kwargs)
        self._prices = NetworkZonePrices(self.server_type)
        self.prices = self._prices


class OrchestrationModelRC(RateCardBase):
    """
    Actually is not supported, just for testing.
    """
    type = 'orchestration_model_resource'

    def __init__(self, **kwargs):
        RateCardBase.__init__(self, **kwargs)
        # self._prices = NetworkZonePrices(self.server_type)
        # self.prices = self._prices


class RecipeGroupsRC(RateCardBase):
    """
    Actually is not supported, just for testing.
    """
    type = 'recipe_groups_resource'

    def __init__(self, **kwargs):
        RateCardBase.__init__(self, **kwargs)


class ServiceAddonRC(RateCardBase):
    type = 'service_addon_resource'

    def __init__(self, **kwargs):
        RateCardBase.__init__(self, **kwargs)
        self._prices = ServiceAddonPrices(self.server_type)
        self.prices = self._prices


class SolidfireDataStoreZoneRC(RateCardBase):
    type = 'solidfire_data_store_zone_resource'

    def __init__(self, **kwargs):
        RateCardBase.__init__(self, **kwargs)
        self._prices = SolidfireDataStoreZonePrices(self.server_type)
        self.prices = self._prices


class TemplateRC(RateCardBase):
    """
    Relates to Template Group
    """
    type = 'template_resource'

    def __init__(self, **kwargs):
        RateCardBase.__init__(self, **kwargs)
        self._prices = TemplatePrices(self.server_type)
        self.prices = self._prices


class TemplatesRC(RateCardBase):
    """
    Relates to Templates
    """
    type = 'templates_resource'

    def __init__(self, **kwargs):
        RateCardBase.__init__(self, **kwargs)
        self._prices = TemplatesPrices(self.server_type)
        self.prices = self._prices


class VirtualServerRC(RateCardBase):
    type = 'virtual_servers_resource'

    def __init__(self, **kwargs):
        RateCardBase.__init__(self, **kwargs)


def set_prices_to_bucket(bucket, random=True):
    """
    Set random prices and free limits to RC
    :param bucket: bucket obj
    :param random: Set True to set random prices else False to set 0.0
    :return:
    """
    from onapp_helper.hypervisor_zone import HypervisorZone
    from onapp_helper.data_store_zone import DataStoreZone
    from onapp_helper.network_zone import NetworkZone
    from onapp_helper.bsz import BSZ
    from onapp_helper.template_store import TemplateStore
    from onapp_helper.service_addon.service_addon_group import ServiceAddonGroup
    from onapp_helper.recipe.recipe_groups import RecipeGroup

    test.log.info(
        "Set random prices to {}({}) bucket Rate Cards, please wait...".format(
            bucket.label, bucket.id
        )
    )
    log_level = test.log.level
    test.log.setLevel(50)
    resources = []
    # Compute Zones
    for hv_zone in HypervisorZone().get_all():
        hvz_rc = ComputeZoneRC(
            parent_obj=bucket,
            server_type=hv_zone.server_type,
            target_id=hv_zone.id
        )
        if hv_zone.server_type not in UNSUPPORTED_SERVER_TYPES and not hvz_rc.get():
            hvz_rc.create()
        resources.append(hvz_rc)

    # Data Store Zones
    for ds_zone in DataStoreZone().get_all():
        dsz_rc = DataStoreZoneRC(
            parent_obj=bucket,
            server_type=ds_zone.server_type,
            target_id=ds_zone.id
        )
        if ds_zone.server_type not in UNSUPPORTED_SERVER_TYPES and not \
                dsz_rc.get():
            dsz_rc.create()
        resources.append(dsz_rc)

    # Network Zones
    for net_zone in NetworkZone().get_all():
        netz_rc = NetworkZoneRC(
            parent_obj=bucket,
            server_type=net_zone.server_type,
            target_id=net_zone.id
        )
        if net_zone.server_type not in UNSUPPORTED_SERVER_TYPES and not \
                netz_rc.get():
            netz_rc.create()
        resources.append(netz_rc)

    # BSZ Zones
    for bsz in BSZ().get_all():
        bsz_rc = BackupServerZoneRC(
            parent_obj=bucket,
            server_type=bsz.server_type,
            target_id=bsz.id
        )
        if bsz.server_type not in UNSUPPORTED_SERVER_TYPES and not bsz_rc.get():
            bsz_rc.create()
        resources.append(bsz_rc)

    # backups
    backups_rc = BackupsRC(
        parent_obj=bucket,
        server_type=BackupsRC.SERVER_TYPE.virtual
    )
    if not backups_rc.get():
        backups_rc.create()
    resources.append(backups_rc)

    # templates
    templates_rc = TemplatesRC(
        parent_obj=bucket,
        server_type=TemplatesRC.SERVER_TYPE.virtual
    )
    if not templates_rc.get():
        templates_rc.create()
    resources.append(templates_rc)

    # ISO
    iso_rc = ISOTemplatesRC(
        parent_obj=bucket,
        server_type=ISOTemplatesRC.SERVER_TYPE.virtual
    )
    if not iso_rc.get():
        iso_rc.create()
    resources.append(iso_rc)

    # Compute resource storing
    compute_resource_storing_rc = ComputeResourceStoringRC(
        parent_obj=bucket,
        server_type=ComputeResourceStoringRC.SERVER_TYPE.virtual
    )
    if not compute_resource_storing_rc.get():
        compute_resource_storing_rc.create()
    resources.append(compute_resource_storing_rc)

    for resource in resources:
        _set_price(resource, random)

    test.log.setLevel(log_level)
    test.log.info('Thanks!')


def _set_price(obj, random):
    for key, value in obj.prices.__dict__.items():
        if 'price' in key or 'free' in key:
            price = randint(1, 100) if random else 0.0
            obj.prices.__dict__.update({key: price})
            obj.edit()
