__since__ = 5.6

from onapp_helper.base_helper import BaseHelper
from onapp_helper.bucket.limits import *
from onapp_helper.bucket.preferences import *
from onapp_helper.bucket.resource_base import *


SERVER_TYPE = ServerType
TIMING_STRATEGY = TimingStrategy

UNSUPPORTED_SERVER_TYPES = [
    SERVER_TYPE.ocm,
    SERVER_TYPE.smart,
    SERVER_TYPE.baremetal,
    SERVER_TYPE.infrastructure
]


class AccessControlBase(BaseResource, BaseHelper):
    root_tag = 'access_control'
    SERVER_TYPE = ServerType

    def __init__(
            self,
            parent_obj=None,
            target_id=None,
            server_type=SERVER_TYPE.virtual
    ):
        """
        :param parent_obj: bucket object
        :param target_id: an id of target obj (HVZ, DSZ, NetZ, etc...)
        :param server_type: zone server type
        """

        self.parent_obj = parent_obj
        self.target_id = target_id
        self.server_type = server_type
        self.timing_strategy = TIMING_STRATEGY.hourly
        self.create_rate_card = False
        self.apply_to_all_resources_in_the_bucket = False

    def create(self):
        data = {
            self.root_tag: {
                "bucket_id": self.parent_obj.id,
                "server_type": self.server_type,
                "target_id": self.target_id,
                "create_rate_card": self.create_rate_card,
                "type": self.type,
                "apply_to_all_resources_in_the_bucket": self.apply_to_all_resources_in_the_bucket
            }
        }

        if hasattr(self, "limits") and not isinstance(self.limits, dict):
            data[self.root_tag]["limits"] = self.limits.__dict__

        if hasattr(self, "preferences") and not isinstance(self.preferences, dict):
            data[self.root_tag]["preferences"] = self.preferences.__dict__
            # data[self.root_tag].update(self.preferences.__dict__)

        test.log.info(
            "Create {} - {}...".format(self.__class__.__name__, self.type)
        )
        if test.post_object(self, data=data):
            return self._dict_to_class(self.response)
        return False

    def edit(self):
        data = {
            self.root_tag: {
                "type": self.type,
                "bucket_id": self.parent_obj.id,
                "server_type": self.server_type,
                "target_id": self.target_id,
                "apply_to_all_resources_in_the_bucket": self.apply_to_all_resources_in_the_bucket
            }
        }

        if hasattr(self, "limits") and self.limits:
            data[self.root_tag]["limits"] = self.limits.__dict__

        if hasattr(self, "preferences") and self.preferences:
            data[self.root_tag]["preferences"] = self.preferences.__dict__

        test.log.info(
            "Edit {} - {}...".format(self.__class__.__name__, self.type)
        )
        if test.put_object(
            self, url="/{}.json".format(self.route()),
            data=data
        ):
            return self.get()
        return False

    def reset(self):
        if hasattr(self, 'limits') and not isinstance(self.limits, dict):
            self.limits.__init__(self.server_type)
        if hasattr(self, 'preferences') and not isinstance(self.preferences, dict):
            self.preferences.__init__(self.server_type)

    def route(self):
        return "{}/{}/access_controls".format(
            self.parent_obj.route, self.parent_obj.id
        )


# TODO - Generate access control objects automatically
class AcceleratedServersAC(AccessControlBase):
    type = 'accelerated_servers_resource'

    def __init__(self, **kwargs):
        AccessControlBase.__init__(self, **kwargs)
        self._limits = AccelerationLimits(self.server_type)
        self.limits = self._limits


class ApplicationServersAC(AccessControlBase):
    type = 'application_servers_resource'

    def __init__(self, **kwargs):
        AccessControlBase.__init__(self, **kwargs)
        self._limits = ApplicationServersLimits(self.server_type)
        self.limits = self._limits


class AutoscaledServersAC(AccessControlBase):
    type = 'autoscaled_servers_resource'

    def __init__(self, **kwargs):
        AccessControlBase.__init__(self, **kwargs)
        self._limits = AutoscaledServersLimits(self.server_type)
        self.limits = self._limits


class BackupServerZoneAC(AccessControlBase):
    type = 'backup_server_zone_resource'

    def __init__(self, **kwargs):
        AccessControlBase.__init__(self, **kwargs)
        self._limits = BackupServerZoneLimits(self.server_type)
        self.limits = self._limits


class BackupsAC(AccessControlBase):
    type = 'backups_resource'

    def __init__(self, **kwargs):
        AccessControlBase.__init__(self, **kwargs)
        self._limits = BackupsLimits(self.server_type)
        self.limits = self._limits


class BaremetalServerAC(AccessControlBase):
    type = 'bare_metal_servers_resource'

    def __init__(self, **kwargs):
        AccessControlBase.__init__(self, **kwargs)
        self._limits = BaremetalServersLimits(self.server_type)
        self.limits = self._limits


class ComputeResourceStoringAC(AccessControlBase):
    type = 'compute_resource_storing_resource'

    def __init__(self, **kwargs):
        AccessControlBase.__init__(self, **kwargs)
        self._limits = ComputeResourceStoringLimits(self.server_type)
        self.limits = self._limits


class ComputeZoneAC(AccessControlBase):
    type = 'compute_zone_resource'

    def __init__(self, **kwargs):
        AccessControlBase.__init__(self, **kwargs)
        self._limits = ComputeZoneLimits(self.server_type)
        self.limits = self._limits


class ContainerServersAC(AccessControlBase):
    type = 'container_servers_resource'

    def __init__(self, **kwargs):
        AccessControlBase.__init__(self, **kwargs)
        self._limits = ContainerServersLimits(self.server_type)
        self.limits = self._limits


class DataStoreZoneAC(AccessControlBase):
    type = 'data_store_zone_resource'

    def __init__(self, **kwargs):
        AccessControlBase.__init__(self, **kwargs)
        self._limits = DataStoreZoneLimits(self.server_type)
        self.limits = self._limits


class DraasAC(AccessControlBase):
    type = 'draas_resource'

    def __init__(self, **kwargs):
        AccessControlBase.__init__(self, **kwargs)


class EdgeGroupsAC(AccessControlBase):
    type = 'edge_groups_resource'

    def __init__(self, **kwargs):
        AccessControlBase.__init__(self, **kwargs)


class InstancePackageAC(AccessControlBase):
    type = 'preconfigured_servers_resource'

    def __init__(self, **kwargs):
        AccessControlBase.__init__(self, **kwargs)
        self._preferences = InstancePackagePreferences(self.server_type)
        self.preferences = self._preferences


class ISOTemplatesAC(AccessControlBase):
    type = 'iso_templates_resource'

    def __init__(self, **kwargs):
        AccessControlBase.__init__(self, **kwargs)
        self._limits = ISOLimits(self.server_type)
        self.limits = self._limits


class NetworkZoneAC(AccessControlBase):
    type = 'network_zone_resource'

    def __init__(self, **kwargs):
        AccessControlBase.__init__(self, **kwargs)
        self._limits = NetworkZoneLimits(self.server_type)
        self.limits = self._limits


class OrchestrationModelAC(AccessControlBase):
    type = 'orchestration_model_resource'

    def __init__(self, **kwargs):
        AccessControlBase.__init__(self, **kwargs)


# class PreconfiguredAC(AccessControlBase):
#     def __init__(self, **kwargs):
#         AccessControlBase.__init__(self, **kwargs)
#         self.type = 'preconfigured_servers_resource'


class RecipeGroupsAC(AccessControlBase):
    type = 'recipe_groups_resource'

    def __init__(self, **kwargs):
        AccessControlBase.__init__(self, **kwargs)


class ServiceAddonsGroupsAC(AccessControlBase):
    type = 'service_addon_groups_resource'

    def __init__(self, **kwargs):
        AccessControlBase.__init__(self, **kwargs)


class SmartServerAC(AccessControlBase):
    type = 'smart_servers_resource'

    def __init__(self, **kwargs):
        AccessControlBase.__init__(self, **kwargs)
        self._limits = SmartServersLimits(self.server_type)
        self.limits = self._limits


class SolidfireDataStoreZoneAC(AccessControlBase):
    type = 'solidfire_data_store_zone_resource'

    def __init__(self, **kwargs):
        AccessControlBase.__init__(self, **kwargs)
        self._limits = SolidfireDataStoreZoneLimits(self.server_type)
        self.limits = self._limits


class TemplateGroupsAC(AccessControlBase):
    type = 'template_groups_resource'

    def __init__(self, **kwargs):
        AccessControlBase.__init__(self, **kwargs)


class TemplatesAC(AccessControlBase):
    type = 'templates_resource'

    def __init__(self, **kwargs):
        AccessControlBase.__init__(self, **kwargs)
        self._limits = TemplatesLimits(self.server_type)
        self.limits = self._limits


class VirtualServerAC(AccessControlBase):
    type = 'virtual_servers_resource'

    def __init__(self, **kwargs):
        AccessControlBase.__init__(self, **kwargs)
        self._limits = VirtualServerLimits(self.server_type)
        self.limits = self._limits


def add_env_to_bucket(bucket):
    """
    Add resources from environment to buckets
    :param bucket: bucket obj
    :return: True if success else False
    """
    if not test.env:
        test.log.error("No environment available")
        return False

    from onapp_helper.bsz import BSZ
    from onapp_helper.template_store import TemplateStore
    from onapp_helper.service_addon.service_addon_group import ServiceAddonGroup
    from onapp_helper.recipe.recipe_groups import RecipeGroup

    test.log.info(
        "Load env resources to {}({}) bucket Access Controls, please wait...".format(
            bucket.label, bucket.id
        )
    )
    log_level = test.log.level
    test.log.setLevel(50)

    # Compute Zones
    hvz_ac = ComputeZoneAC(
        parent_obj=bucket,
        server_type=test.env.hvz.server_type,
        target_id=test.env.hvz.id
    )
    if test.env.hvz.server_type not in UNSUPPORTED_SERVER_TYPES and not hvz_ac.get():
        hvz_ac.create()

    # Data Store Zones
    dsz_ac = DataStoreZoneAC(
        parent_obj=bucket,
        server_type=test.env.dsz.server_type,
        target_id=test.env.dsz.id
    )
    if test.env.dsz.server_type not in UNSUPPORTED_SERVER_TYPES and not dsz_ac.get():
        dsz_ac.create()

    # Network Zones
    netz_ac = NetworkZoneAC(
        parent_obj=bucket,
        server_type=test.env.netz.server_type,
        target_id=test.env.netz.id
    )
    if test.env.netz.server_type not in UNSUPPORTED_SERVER_TYPES and not netz_ac.get():
        netz_ac.create()

    # BSZ Zones
    if test.env.backup_servers:
        bss = [bs for bs in test.env.backup_servers if bs.enabled]
        if bss:
            bsz = BSZ(id=bss[-1].backup_server_group_id)
            bsz_ac = BackupServerZoneAC(
                parent_obj=bucket,
                server_type=bsz.server_type,
                target_id=bsz.id
            )
            if bsz.server_type not in UNSUPPORTED_SERVER_TYPES and not bsz_ac.get():
                bsz_ac.create()

    # Template Store
    for ts in TemplateStore().get_all():
        ts_ac = TemplateGroupsAC(
            parent_obj=bucket,
            server_type=TemplateGroupsAC.SERVER_TYPE.other,
            target_id=ts.id
        )
        if not ts_ac.get():
            ts_ac.create()

    # Service Addon Group
    for sa in ServiceAddonGroup().get_all():
        sa_ac = ServiceAddonsGroupsAC(
            parent_obj=bucket,
            server_type=TemplateGroupsAC.SERVER_TYPE.other,
            target_id=sa.id
        )
        if not sa_ac.get():
            sa_ac.create()

    # Recipe Group
    for rg in RecipeGroup().get_all():
        rg_ac = RecipeGroupsAC(
            parent_obj=bucket,
            server_type=RecipeGroupsAC.SERVER_TYPE.other,
            target_id=rg.id
        )
        if not rg_ac.get():
            rg_ac.create()

    # VS
    vs_ac = VirtualServerAC(
        parent_obj=bucket,
        server_type=VirtualServerAC.SERVER_TYPE.virtual
    )
    if not vs_ac.get():
        vs_ac.create()

    # VS vpc
    vs_vpc_ac = VirtualServerAC(
        parent_obj=bucket,
        server_type=VirtualServerAC.SERVER_TYPE.vpc
    )
    if not vs_vpc_ac.get():
        vs_vpc_ac.create()

    # AppS
    apps_ac = ApplicationServersAC(
        parent_obj=bucket,
        server_type=ApplicationServersAC.SERVER_TYPE.virtual
    )
    if not apps_ac.get():
        apps_ac.create()

    # CS
    cs_ac = ContainerServersAC(
        parent_obj=bucket,
        server_type=ContainerServersAC.SERVER_TYPE.virtual
    )
    if not cs_ac.get():
        cs_ac.create()

    # BS
    # bs_ac = BaremetalServerAC(
    #     parent_obj=bucket,
    #     server_type=BaremetalServerAC.SERVER_TYPE.baremetal
    # )
    # if not bs_ac.get():
    #     bs_ac.create()

    # SS
    # ss_ac = SmartServerAC(
    #     parent_obj=bucket,
    #     server_type=SmartServerAC.SERVER_TYPE.smart
    # )
    # if not ss_ac.get():
    #     ss_ac.create()

    # backups
    backups_ac = BackupsAC(
        parent_obj=bucket,
        server_type=BackupsAC.SERVER_TYPE.virtual
    )
    if not backups_ac.get():
        backups_ac.create()

    # templates
    templates_ac = TemplatesAC(
        parent_obj=bucket,
        server_type=TemplatesAC.SERVER_TYPE.virtual
    )
    if not templates_ac.get():
        templates_ac.create()

    # Compute resource storing
    compute_resource_storing_ac = ComputeResourceStoringAC(
        parent_obj=bucket,
        server_type=ComputeResourceStoringAC.SERVER_TYPE.virtual
    )
    if not compute_resource_storing_ac.get():
        compute_resource_storing_ac.create()

    # Autoscaling
    as_ac = AutoscaledServersAC(
        parent_obj=bucket,
        server_type=BackupsAC.SERVER_TYPE.virtual
    )
    if not as_ac.get():
        as_ac.create()

    # ISO
    iso_ac = ISOTemplatesAC(
        parent_obj=bucket,
        server_type=ISOTemplatesAC.SERVER_TYPE.virtual
    )
    if not iso_ac.get():
        iso_ac.create()

    test.log.setLevel(log_level)

    test.log.info('Thanks!')
    return True


def add_all_resources_to_bucket(bucket):
    """
    Add all resources on the cloud to assess controls
    :param bucket: bucket obj
    :return:
    """
    from onapp_helper.hypervisor_zone import HypervisorZone
    from onapp_helper.data_store_zone import DataStoreZone
    from onapp_helper.network_zone import NetworkZone
    from onapp_helper.bsz import BSZ
    from onapp_helper.template_store import TemplateStore
    from onapp_helper.service_addon.service_addon_group import ServiceAddonGroup
    from onapp_helper.recipe.recipe_groups import RecipeGroup

    test.log.info(
        "Load all resources to {}({}) bucket Access Controls, please wait...".format(
            bucket.label, bucket.id
        )
    )
    log_level = test.log.level
    test.log.setLevel(50)
    # Compute Zones
    for hv_zone in HypervisorZone().get_all():
        hvz_ac = ComputeZoneAC(
            parent_obj=bucket,
            server_type=hv_zone.server_type,
            target_id=hv_zone.id
        )
        if hv_zone.server_type not in UNSUPPORTED_SERVER_TYPES and not hvz_ac.get():
            hvz_ac.create()

    # Data Store Zones
    for ds_zone in DataStoreZone().get_all():
        dsz_ac = DataStoreZoneAC(
            parent_obj=bucket,
            server_type=ds_zone.server_type,
            target_id=ds_zone.id
        )
        if ds_zone.server_type not in UNSUPPORTED_SERVER_TYPES and not dsz_ac.get():
            dsz_ac.create()

    # Network Zones
    for net_zone in NetworkZone().get_all():
        netz_ac = NetworkZoneAC(
            parent_obj=bucket,
            server_type=net_zone.server_type,
            target_id=net_zone.id
        )
        if net_zone.server_type not in UNSUPPORTED_SERVER_TYPES and not netz_ac.get():
            netz_ac.create()

    # BSZ Zones
    for bsz in BSZ().get_all():
        bsz_ac = BackupServerZoneAC(
            parent_obj=bucket,
            server_type=bsz.server_type,
            target_id=bsz.id
        )
        if bsz.server_type not in UNSUPPORTED_SERVER_TYPES and not bsz_ac.get():
            bsz_ac.create()

    # Template Store
    for ts in TemplateStore().get_all():
        ts_ac = TemplateGroupsAC(
            parent_obj=bucket,
            server_type=TemplateGroupsAC.SERVER_TYPE.other,
            target_id=ts.id
        )
        if not ts_ac.get():
            ts_ac.create()

    # Service Addon Group
    for sa in ServiceAddonGroup().get_all():
        sa_ac = ServiceAddonsGroupsAC(
            parent_obj=bucket,
            server_type=TemplateGroupsAC.SERVER_TYPE.other,
            target_id=sa.id
        )
        if not sa_ac.get():
            sa_ac.create()

    # Recipe Group
    for rg in RecipeGroup().get_all():
        rg_ac = RecipeGroupsAC(
            parent_obj=bucket,
            server_type=RecipeGroupsAC.SERVER_TYPE.other,
            target_id=rg.id
        )
        if not rg_ac.get():
            rg_ac.create()

    # VS
    vs_ac = VirtualServerAC(
        parent_obj=bucket,
        server_type=VirtualServerAC.SERVER_TYPE.virtual
    )
    if not vs_ac.get():
        vs_ac.create()

    # VS vpc
    vs_vpc_ac = VirtualServerAC(
        parent_obj=bucket,
        server_type=VirtualServerAC.SERVER_TYPE.vpc
    )
    if not vs_vpc_ac.get():
        vs_vpc_ac.create()

    # AppS
    apps_ac = ApplicationServersAC(
        parent_obj=bucket,
        server_type=ApplicationServersAC.SERVER_TYPE.virtual
    )
    if not apps_ac.get():
        apps_ac.create()

    # CS
    cs_ac = ContainerServersAC(
        parent_obj=bucket,
        server_type=ContainerServersAC.SERVER_TYPE.virtual
    )
    if not cs_ac.get():
        cs_ac.create()

    # BS
    # bs_ac = BaremetalServerAC(
    #     parent_obj=bucket,
    #     server_type=BaremetalServerAC.SERVER_TYPE.baremetal
    # )
    # if not bs_ac.get():
    #     bs_ac.create()

    # SS
    # ss_ac = SmartServerAC(
    #     parent_obj=bucket,
    #     server_type=SmartServerAC.SERVER_TYPE.smart
    # )
    # if not ss_ac.get():
    #     ss_ac.create()

    # backups
    backups_ac = BackupsAC(
        parent_obj=bucket,
        server_type=BackupsAC.SERVER_TYPE.virtual
    )
    if not backups_ac.get():
        backups_ac.create()

    # templates
    templates_ac = TemplatesAC(
        parent_obj=bucket,
        server_type=TemplatesAC.SERVER_TYPE.virtual
    )
    if not templates_ac.get():
        templates_ac.create()

    # ISO
    iso_ac = ISOTemplatesAC(
        parent_obj=bucket,
        server_type=ISOTemplatesAC.SERVER_TYPE.virtual
    )
    if not iso_ac.get():
        iso_ac.create()

    # Compute resource storing
    compute_resource_storing_ac = ComputeResourceStoringAC(
        parent_obj=bucket,
        server_type=ComputeResourceStoringAC.SERVER_TYPE.virtual
    )
    if not compute_resource_storing_ac.get():
        compute_resource_storing_ac.create()

    test.log.setLevel(log_level)
    test.log.info('Thanks!')