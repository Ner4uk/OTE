__since__ = 5.6


class AccelerationLimits():
    def __init__(self, server_type):
        if server_type in ['virtual', 'smart', 'baremetal']:
            self.limit = None


class ApplicationServersLimits():
    def __init__(self, server_type):
        if server_type in ['virtual', 'smart', 'baremetal', 'vpc']:
            self.limit = None


class AutoscaledServersLimits():
    def __init__(self, server_type):
        if server_type in ['virtual']:
            self.limit = None


class BackupServerZoneLimits():
    def __init__(self, server_type):
        if server_type in ['virtual']:
            self.limit_backup = None
            self.limit_backup_disk_size = None
            self.limit_template_disk_size = None
            self.limit_template = None
            # OVA available since 5.2
            self.limit_ova = None
            self.limit_ova_disk_size = None
        elif server_type in ['smart']:
            self.limit_backup = None
            self.limit_backup_disk_size = None
            self.limit_template_disk_size = None
            self.limit_template = None


class BackupsLimits():
    def __init__(self, server_type):
        if server_type in ['virtual', 'smart']:
            self.limit = None


class BaremetalServersLimits():
    def __init__(self, server_type):
        if server_type in ['baremetal']:
            self.limit = None


class ComputeResourceStoringLimits():
    def __init__(self, server_type):
        if server_type in ['virtual', 'smart']:
            self.limit = None


class ComputeZoneLimits:
    def __init__(self, server_type):
        if server_type in ['virtual', 'ocm']:
            self.limit_cpu = None
            self.limit_memory = None
            self.limit_cpu_share = None
            self.limit_cpu_units = None
            self.limit_default_cpu = 1
            self.limit_min_cpu = 1
            self.limit_min_memory = 128
            self.limit_default_cpu_share = 100
            self.limit_min_cpu_priority = 1
            self.use_cpu_units = False
            self.use_default_cpu = False
            self.use_default_cpu_share = False
        elif server_type in ['smart']:
            self.limit_cpu = None
            self.limit_cpu_share = None
            self.limit_memory = None
            self.use_cpu_units = False
        elif server_type in ['vpc']:
            self.limit_min_allocation_cpu_allocation = None
            self.limit_min_allocation_cpu_resources_guaranteed = None
            self.limit_min_allocation_memory_allocation = None
            self.limit_min_allocation_memory_resources_guaranteed = None
            self.limit_min_allocation_vcpu_speed = None

            self.limit_allocation_cpu_allocation = None
            self.limit_allocation_cpu_resources_guaranteed = None
            self.limit_allocation_memory_allocation = None
            self.limit_allocation_memory_resources_guaranteed = None
            self.limit_allocation_vcpu_speed = None

            self.limit_min_reservation_cpu_allocation = None
            self.limit_min_reservation_memory_allocation = None
            self.limit_reservation_cpu_allocation = None
            self.limit_reservation_memory_allocation = None

            self.limit_min_pay_as_you_go_cpu_limit = None
            self.limit_min_pay_as_you_go_memory_limit = None
            self.limit_pay_as_you_go_cpu_limit = None
            self.limit_pay_as_you_go_memory_limit = None

            self.limit_vs_cpu = None
            self.limit_vs_memory = None


class ContainerServersLimits():
    def __init__(self, server_type):
        if server_type in ['virtual']:
            self.limit = None


class DataStoreZoneLimits:
    def __init__(self, server_type):
        if server_type in ['virtual', 'smart', 'ocm']:
            self.limit = None
        elif server_type in ['vpc']:
            self.limit_min_disk_size = None
            self.limit_disk_size = None
            self.limit_vs_disk_size = None
            # self.limit_min_disk_size = None
            # self.limit_min_disk_size_used = None
            # self.limit_disk_size = None
            # self.limit_disk_size_used = None


class ISOLimits():
    def __init__(self, server_type):
        if server_type in ['virtual', 'smart']:
            self.limit = None


class NetworkZoneLimits:
    def __init__(self, server_type):
        if server_type in ['virtual', 'smart', 'ocm']:
            self.limit_ip = None
            self.limit_rate = None
        elif server_type in ['vpc']:
            self.limit_ip = None
            self.limit_vs_ip = None
        elif server_type in ['baremetal']:
            self.limit_ip = None


class SmartServersLimits:
    def __init__(self, server_type):
        if server_type in ['smart']:
            self.limit = None


class SolidfireDataStoreZoneLimits():
    def __init__(self, server_type):
        if server_type in ['virtual']:
            self.limit = None


class TemplatesLimits():
    def __init__(self, server_type):
        if server_type in ['virtual']:
            self.limit = None


class VirtualServerLimits():
    def __init__(self, server_type):
        if server_type in ['virtual', 'vpc']:
            self.limit = None
