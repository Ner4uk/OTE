__since__ = 5.6


class InstancePackagePreferences:
    def __init__(self, server_type):
        if server_type in ['virtual', 'smart']:
            self.hypervisor_group_ids = []
            self.data_store_group_ids = []
            self.network_group_ids = []
