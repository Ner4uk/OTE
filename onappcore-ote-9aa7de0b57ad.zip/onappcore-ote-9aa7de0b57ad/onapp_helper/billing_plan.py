from onapp_helper.base_helper import BaseHelper
from onapp_helper.br_helper.br_base import BaseResource
from onapp_helper import test


class BillingPlan(BaseHelper):
    __till__ = 6.1

    if test.api_version is None or test.api_version >= 4.2:
        route = 'billing/user/plans'
        root_tag = 'user_plan'
    elif test.api_version == 4.1:
        route = 'billing_plans'
        root_tag = route[:-1]

    def __init__(self, bp_id=None):
        self.id = bp_id
        self.label = "zaza_billing_test"
        self.currency_code = "USD"
        self.monthly_price = "0.0"
        self.allows_kms = "false"
        self.allows_mak = "true"
        self.allows_own = "false"
        self._setup()
        if self.id:
            test.update_object(self)

    def create(self):
        """
        Default values:
            label = "zaza_billing_test"
            currency_code = "USD"
            monthly_price = "0.0"
            allows_kms = "false"
            allows_mak = "true"
            allows_own = "false"
        """
        test.log.info("Create billing plan...")
        self._compare_api_versions()
        data = {
            self.root_tag: {
                "label": self.label,
                "currency_code": self.currency_code,
                "monthly_price": self.monthly_price,
                "allows_kms": self.allows_kms,
                "allows_mak": self.allows_mak,
                "allows_own": self.allows_own
            }
        }
        return test.post_object(self, data=data)

    def edit(self):
        test.log.info("Edit billing plan...")
        self._compare_api_versions()
        data = {
            self.root_tag: {
                "label": self.label,
                "currency_code": self.currency_code,
                "monthly_price": self.monthly_price,
                "allows_kms": self.allows_kms,
                "allows_mak": self.allows_mak,
                "allows_own": self.allows_own
            }
        }
        return test.put_object(self, data=data)

    def clone(self, user_id, bp_id):
        """
        The obj attributes is going to be updated after executing,
        so to avoid some errors please execute this method for a new obj!!!

        Example:
        bp_for_user2 = BillingPlan()
        assert bp_for_user2.clone(user2.id, billing_plan.id)

        :param user_id: an id of user to which a new billing plan is going to be created.
        :param bp_id: an id on billing plan which is going to be cloned
        :return: True is success otherwise False.
        """
        url = "/users/{}/billing/user/plans/{}/clone.json".format(user_id, bp_id)
        return test.post_object(self, url=url)

    def create_copy(self):
        """
        Since 5.5
        :return: A new billing plan object
        """
        if test.cp_version < 5.5:
            test.log.warning('Create copy is supported since 5.5 version')
            return None
        url = "/{}/{}/create_copy.json".format(self.route, self.id)
        bp_copy = BillingPlan()
        if test.post_object(bp_copy, url=url):
            return bp_copy
        return None

    def delete(self):
        test.log.info("Delete billing plan...")
        self._compare_api_versions()
        return test.delete_object(self)

    def get_base_resources(self):
        return BaseResource(billing_plan=self).get_all()

    def get_base_resources_by_resource_name(self, resource_name=None):
        return BaseResource(billing_plan=self).get_by_resource_name(
            resource_name=resource_name
        )

    def _setup(self):
        self.api_version = test.api_version
        if test.api_version is None or test.api_version >= 4.2:
            self.route = 'billing/user/plans'
            self.root_tag = 'user_plan'
        elif test.api_version == 4.1:
            self.route = 'billing_plans'
            self.root_tag = self.route[:-1]
        else:
            raise SystemError('"api_version" parameter misconfigured.')

    def _compare_api_versions(self):
        """
        If api version has been changed during testing - reset required attributes.
        :return:
        """
        if self.api_version != test.api_version:
            self._setup()

    def get_testing_billing_plans(self):
        return [
            bp for bp in self.get_all()
            if 'Test' in bp.label and ' ' not in bp.label
            ]