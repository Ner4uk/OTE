
__doc__ = """ This helper (module) describe backup plugin components
"""
__since__ = 5.8
from onapp_helper import test
from onapp_helper.base_helper import BaseHelper

ROUTE = 'settings/backups/resources'

HOURLY = 'hourly'
DAILY = 'daily'
WEEKLY = 'weekly'
MONTHLY = 'monthly'
YEARLY = 'yearly'


class Preset(BaseHelper):
    __since__ = 5.8
    root_tag = "auto_backup_preset"

    def __init__(self, parent_obj, id=None):
        """

        :param parent_obj: Resource obj
        :param id:
        """
        self.parent_obj = parent_obj

        # Common attributes
        self.day_to_run_on = None
        self.days_to_run_on = list()
        self.enabled = True

        # the frequency of how often the auto backup preset is run.
        # For example, set 1 to run the auto backup preset every day,
        # 2 - every second day, 3 - every third day, etc.
        self.frequency = None
        self.max_recovery_points = 1
        self.period = ''
        self.resource_id = None
        self.week_to_run_on = None
        self.start_time = ''

        if id:
            self.id = id
            test.update_object(self)

    def create(self, **kwargs):
        """
        Create preset
        :param kwargs: enabled and period are common
            For:
            hourly: max_recovery_points
            daily: frequency, max_recovery_points, start_time
            weekly: days_to_run_on, max_recovery_points, start_time
            monthly: day_to_run_on, week_to_run_on, max_recovery_points, start_time
            yearly: max_recovery_points
        :return: True if success else False
        """
        data = {
            "resource_id": self.parent_obj.id
        }
        data.update(kwargs)
        test.log.info(f"Create {data['period']} preset")
        return test.post_object(self, data=data)

    def edit(self, **kwargs):
        """
        Edit preset
        :param kwargs: For:
            hourly: max_recovery_points, enabled
            daily: frequency, max_recovery_points, enabled
            weekly: days_to_run_on, max_recovery_points, enabled
            monthly: day_to_run_on, week_to_run_on, max_recovery_points, enabled
            yearly: max_recovery_points, enabled
        :return: True if success else False
        """
        test.log.info(f"Edit {kwargs['period']} preset")
        return test.put_object(self, data=kwargs)

    def route(self):
        return f"{ROUTE}/{self.parent_obj.id}/auto_backup_presets"


class AdvancedOption(BaseHelper):
    __since__ = 5.8
    root_tag = "advanced_options"

    def __init__(self, parent_obj, id=None):
        """

        :param parent_obj: Resource obj
        :param id:
        """
        self.parent_obj = parent_obj

        if id:
            self.id = id
            test.update_object(self)

    def edit(self, **kwargs):
        data = {
            self.root_tag: kwargs
        }

        test.log.info(f"Edit advanced option f{self.id}")
        return test.put_object(self, data=data)

    def route(self):
        return f"{ROUTE}/{self.parent_obj.id}/advanced_options"


class RecoveryPoint(BaseHelper):
    __since__ = 5.8
    root_tag = 'recovery_point'

    def __init__(self, parent_obj, id=None):
        """

        :param parent_obj: Server obj
        :param id:
        """
        self.parent_obj = parent_obj

        delattr(self, 'delete')

        if id:
            self.id = id
            test.update_object(self)

    def create(self, resource_id):
        test.log.info(
            f"Create recovery point on resource with an id {resource_id}"
        )
        data = {
            self.root_tag: {
                "resource_id": resource_id
            }
        }
        if test.post_object(self, data=data):
            return self.transaction_handler(
                "immediate_virtual_machine_backup",
                parent_id=self.parent_obj.id
            )
        return False

    def restore(self):
        url = f"/{self.route()}/{self.id}/restore.json"
        test.log.info(f"Restore recovery point {self.id}")
        if test.post_object(self, url=url):
            return self.transaction_handler(
                'restore_recovery_point',
                parent_id=self.parent_obj.id
            )
        return False

    @staticmethod
    def sync():
        """
        Force sync info about servers recovery points
        :return: True if success else False
        """
        code, res = test.cp.rails_execute('Backups::RecoveryPointsSyncer.call')
        return True if code == 0 else False

    def route(self):
        return f"{self.parent_obj.route}/{self.parent_obj.id}/backups/recovery_points"


class Resource(BaseHelper):
    __since__ = 5.8
    root_tag = 'resource'
    route = 'settings/backups/resources'

    def __init__(
            self,
            id=None,
            label=None,
            enabled=None,
            plugin=None,
            primary_host=None,
            secondary_host=None,
            username=None,
            password=None,
            resource_zone_id=None
    ):
        """

        :param id:
        """
        self.label = label
        self.enabled = enabled
        self.plugin = plugin
        self.primary_host = primary_host
        self.secondary_host = secondary_host
        self.username = username
        self.password = password
        self.resource_zone_id = resource_zone_id

        if id:
            self.id = id
            test.update_object(self)

    def create(self):
        data = {
            "label": self.label,
            "enabled": self.enabled,
            "plugin": self.plugin,
            "primary_host": self.primary_host,
            "secondary_host": self.secondary_host,
            "username": self.username,
            "password": self.password,
            "resource_zone_id": self.resource_zone_id
        }

        test.log.info(f"Create resource")
        return test.post_object(self, data=data)

    def edit(self, **kwargs):
        test.log.info(f"Edit resource")
        return test.put_object(self, data=kwargs)

    def add_to_server(self, server_obj):
        test.log.info(
            f"Add backup resource {self.id} to "
            f"{server_obj.__class__.__name__} - {server_obj.id}"
        )
        if test.post_object(
            self,
            url=f'/{server_obj.route}/{server_obj.id}'
                f'/backups/resources/{self.id}.json'
        ):
            return self.transaction_handler(
                'enable_backup_resource_for_virtual_server',
                parent_id=server_obj.id
            )
        return False

    def allocated_to_server(self, server_obj):
        test.log.info(
            f"Get backup resources allocated to "
            f"{server_obj.__class__.__name__} - {server_obj.id}"
        )
        return test.get_object(
            self,
            url=f'/{server_obj.route}/{server_obj.id}'
                f'/backups/resources/{self.id}.json'
        )

    def remove_from_server(self, server_obj):
        test.log.info(
            f"Remove backup resource {self.id} from "
            f"{server_obj.__class__.__name__} - {server_obj.id}"
        )
        if test.delete_object(
            self,
            url=f'/{server_obj.route}/{server_obj.id}'
                f'/backups/resources/{self.id}.json'
        ):
            return self.transaction_handler(
                'disable_backup_resource_for_virtual_server',
                parent_id=server_obj.id
            )
        return False


class ResourceZone(BaseHelper):
    __since__ = 5.8
    route = 'settings/backups/resource_zones'
    root_tag = 'resource_zone'

    def __init__(self, label=None, location_group_id=None, id=None):
        self.label = label
        self.location_group_id = location_group_id

        if id:
            self.id = id
            test.update_object(self)

    def create(self):
        data = {
            self.root_tag: {
                "label": self.label,
                "location_group_id": self.location_group_id
            }
        }

        test.log.info(f"Create resource zone")
        return test.post_object(self, data=data)

    def edit(self, **kwargs):
        """

        :param kwargs: label, location_group_id
        :return:
        """
        data = {
            self.root_tag: kwargs
        }

        test.log.info(f"Edit resource zone")
        return test.put_object(self, data=data)

    def attach_backup_resource(self, resource_id):
        url = f"/{self.route}/{self.id}/resources/{resource_id}/attach.json"

        test.log.info(
            f"Attach backup resource {resource_id} to resource zone {self.id}"
        )
        return test.post_object(self, url=url)

    def detach_backup_resource(self, resource_id):
        url = f"/{self.route}/{self.id}/resources/{resource_id}/detach.json"

        test.log.info(
            f"Detach backup resource {resource_id} from resource zone {self.id}"
        )
        return test.post_object(self, url=url)

    def get_list_attached_to_compute_zone(self, compute_zone_id):
        """
        Get the list of backup resource zones attached to a compute zone
        :param compute_zone_id: compute zone id
        :return: list of backup resource zones attached to compute zone
        """
        route = f"settings/compute_zones/{compute_zone_id}/backups/resource_zones"

        test.log.info(
            f"Get the list of backup resource zones attached to a compute zone {compute_zone_id}"
        )
        return self._get_objects(route=route)

    def attach_to_compute_zone(self, compute_zone_id):
        """
        Attach a backup resource zone to a compute zone
        :param compute_zone_id: compute zone id
        :return: True if success else False
        """
        url = f"/settings/compute_zones/" \
              f"{compute_zone_id}/backups/resource_zones/{self.id}.json"

        test.log.info(
            f"Attach a backup resource zone {self.id} to compute zone {compute_zone_id}"
        )
        return test.post_object(self, url=url)

    def detach_from_compute_zone(self, compute_zone_id):
        """
        Detach a backup resource zone from a compute zone
        :param compute_zone_id: compute zone id
        :return: True if success else False
        """
        url = f"/settings/compute_zones/" \
              f"{compute_zone_id}/backups/resource_zones/{self.id}.json"

        test.log.info(
            f"Detach a backup resource zone {self.id} from compute zone {compute_zone_id}"
        )
        return test.delete_object(self, url=url)
