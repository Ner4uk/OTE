from onapp_helper import test
from onapp_helper.hypervisor import Hypervisor
from test_helper.generatorTH import generate_name


class CloudBooted(Hypervisor):
    def __init__(self, id=None):
        self.label = self.__class__.__name__ + '-' + generate_name()
        self.pxe_ip_address_id = ''
        self.server_type = ''
        self.backup = False
        self.disks_per_storage_controller = 3
        self.storage_controller_memory_size = 2048
        self.mtu = 1500
        self.custom_config = ''
        self.apply_hypervisor_group_custom_config = False
        self.storage_bonding_mode = 'balance-rr'
        self.cloud_boot_os = 'centos6'
        super().__init__(id=id)

    def _create(self, mac=None):
        test.log.info("Create cloudboot hypervisor...")
        data = {
            self.root_tag: {
                "label": self.label,
                "hypervisor_type": self.hypervisor_type,
                "cloud_boot_os": self.cloud_boot_os,
                "enabled": self.enabled,
                "hypervisor_group_id": self.hypervisor_group_id,
                "format_disks": False,
                "mtu": self.mtu,
                "storage_controller_memory_size": self.storage_controller_memory_size,
                "backup": self.backup,
                "disks_per_storage_controller": self.disks_per_storage_controller,
                "pxe_ip_address_id": self.get_pxe_ip_address_id(),
                "custom_config": self.custom_config,
                "disable_failover": self.disable_failover,
                "storage_bonding_mode": self.storage_bonding_mode,
                "collect_stats": self.collect_stats,
                "apply_hypervisor_group_custom_config": self.apply_hypervisor_group_custom_config
            }
        }
        if test.cp_version < 5.6:
            del data[self.root_tag]['apply_hypervisor_group_custom_config']
        if test.post_object(self, url=f"/settings/assets/{mac}/hypervisors", data=data):
            if self.transaction_handler('create_hypervisor'):
                if self.wait_till_online():
                    return test.update_object(self)
        return False

    def _mac_to_id(self, macs):
        for item in self.response:
            if 'hypervisor_network_interface_device' in item:
                if item['hypervisor_network_interface_device']['mac'] in macs:
                    return item['hypervisor_network_interface_device']['id']

    def create(self, asset_mac=None):
        """
        Create server.
        To set specific parameters for creating you need to set appropriate
        attributes before creation.
        """
        res = self._create(mac=asset_mac)
        return res

    def get_devices(self):
        test.log.info("Fetching devices info from hypervisor...")
        data = {self.root_tag: self.id}
        res = test.post_object(self, url=f"/settings/hypervisors/{self.id}/devices/refresh", data=data)
        return res

    def pass_devices_to_storage(self, disk_ids=None, nic_ids=None, assign_all=False):
        test.log.info("Edit hypervisor...")
        disk_params = {'format': True, 'status': 1}
        devices = {}

        if assign_all:
            self.get_devices()
            if not disk_ids:
                disk_ids = [i['hypervisor_disk_device']['id'] for i in self.response if 'hypervisor_disk_device' in i]
            if not nic_ids:
                nic_ids = [i['hypervisor_network_interface_device']['id'] for i in self.response if
                           'hypervisor_network_interface_device' in i]
            else:
                nic_ids = [self._mac_to_id(nic_ids)]
            self.pass_devices_to_storage(disk_ids=disk_ids, nic_ids=nic_ids)
        else:
            for disk in disk_ids:
                devices.update({str(disk): disk_params})
            nic_params = {'status': 1}
            for nic in nic_ids:
                devices.update({str(nic): nic_params})
        data = {'hypervisor_devices': devices, "hypervisor_id": self.id}
        if test.put_object(self, url=f"/settings/hypervisors/{self.id}/devices", data=data):
            if self.transaction_handler('apply_hypervisor_device_changes'):
                return True
        return False

    def get_pxe_ip_address_id(self):
        # get a free ip address from the cloudboot ip addresses list.
        test.get_object(self, url='/cloud_boot_ip_addresses.json')
        for ip_address in self.response:
            #pdb.set_trace()
            if not ip_address['ip_address']['hypervisor_id']:
                return ip_address['ip_address']['id']
