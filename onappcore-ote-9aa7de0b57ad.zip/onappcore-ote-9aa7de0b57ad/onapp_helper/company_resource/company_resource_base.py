from onapp_helper.base_helper import BaseHelper
from onapp_helper import test


class Empty:
    pass


class CompanyRBase(BaseHelper):
    def __init__(self, kwargs):
        """

        :param kwargs: company_plan, id, user, target_id.
        where:
            - company_plan - company_plan object
            - id - base resource id
            - user - user object
            - target_id - an id of target obj (HVZ, DSZ, NetZ, etc...)
        """
        self.id = None
        self.target_id = None
        for key, value in list(kwargs.items()):
            self.__dict__[key] = value
        self.target_type = 'Pack'
        self.limit_type = 'hourly'
        self.error = ''

        self.route = 'billing/company/resources'
        self.root_tag = 'resource'
        if self.id:
            test.update_object(self)

    def create(self):
        test.log.info("Create company base resource {0}...".format(self.resource_class))
        data = {
            self.root_tag: {
                "resource_class": "Billing::Company::Resource::VCloud::{0}".format(self.resource_class),
                "target_id": self.target_id,
                "target_type": self.target_type,
                "limits": self.limits.__dict__,
                "prices": self.prices.__dict__,
                "limit_type": self.limit_type
            }
        }

        url = '/billing/company/plans/{0}/resources.json'.format(self.company_plan.id)
        if test.post_object(self, url=url, data=data):
            return self._dict_to_class()

    def edit(self):
        test.log.info("Edit company base resource {0}...".format(self.resource_class))
        data = {
            self.root_tag: {
                "limits": self.limits.__dict__,
                "prices": self.prices.__dict__
            }
        }

        # Temporary string to check ticket https://onappdev.atlassian.net/browse/CORE-5980
        data[self.root_tag]["target_id"] = self.target_id
        data[self.root_tag]["target_type"] = self.target_type

        url = '/{0}/{1}.json'.format(self.route, self.id)
        if test.put_object(self, url=url, data=data):
            return self._dict_to_class()

    def get_all(self):
        test.log.info("Get all company resources...")
        return [
            o._dict_to_class() for o in self._get_objects(
                route='{0}/{1}/{2}s'.format(
                    self.company_plan.route,
                    self.company_plan.id, self.root_tag
                ),
                kwargs={'company_plan': self.company_plan}
            )
        ]

    def _dict_to_class(self):
        """
        Convert dict to class attributes for limits, prices, and preferences
        :return:
        """
        if hasattr(self, 'id') and self.id:  # Allow do not update resource without id like settings, cloud config etc.
            # response = self.response
            # if not response:
            #     test.update_object(self)
            limits = self.limits
            self.limits = Empty()
            self.limits.__dict__.update(limits)  # dict to class attributes

            prices = self.prices
            self.prices = Empty()
            self.prices.__dict__.update(prices)  # dict to class attributes

            if hasattr(self, 'preferences'):
                preferences = self.preferences
                self.preferences = Empty()
                self.preferences.__dict__.update(preferences)  # dict to class attributes
            return self
        return False
