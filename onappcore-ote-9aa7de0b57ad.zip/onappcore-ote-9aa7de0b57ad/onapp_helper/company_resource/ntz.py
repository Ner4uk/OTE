#  Parameters: {"resource"=>{"resource_class"=>"Billing::Company::Resource::VCloud::NetworkZone", "target_type"=>"Pack", "target_id"=>"2", "limit_type"=>"hourly"}, "humanized"=>"true", "plan_id"=>"163"}

from onapp_helper.company_resource.company_resource_base import CompanyRBase
from onapp_helper.company_resource.limits import ntz_limits
from onapp_helper.company_resource.prices import ntz_prices
#from preferences import hvz_preferences


class CompanyNTZBR(CompanyRBase):
    def __init__(self, **kwargs):
        CompanyRBase.__init__(self, kwargs)
        self.resource_class = 'NetworkZone'
        self.limits = ntz_limits.CompanyNTZLimits()
        self.prices = ntz_prices.CompanyNTZPrices()

    def reset(self):
        self.limits = ntz_limits.CompanyNTZLimits()
        self.prices = ntz_prices.CompanyNTZPrices()
        #self.own_preferences = hvz_preferences.HVZPreferences()
        #self.in_bucket_zone = False
        #self.in_template_zone = False
