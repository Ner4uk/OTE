

class CompanyDSZLimits():
    def __init__(self):
        self.limit_free_disk_size = 0
        self.limit_min_disk_size = None
        self.limit_disk_size = None