

class CompanyNTZLimits():
    def __init__(self):
        self.limit_ip = None
        self.limit_free_ip = 0
        self.limit_free_data_sent = 0
        self.limit_free_data_received = 0