

class CompanyHVZLimits():
    def __init__(self):
        self.limit_free_allocation_cpu_allocation = 0
        self.limit_free_allocation_cpu_resources_guaranteed = 0
        self.limit_free_allocation_memory_allocation = 0
        self.limit_free_allocation_memory_resources_guaranteed = 0
        #self.limit_free_allocation_vcpu_speed = 0
        self.limit_min_allocation_cpu_allocation = None
        self.limit_min_allocation_cpu_resources_guaranteed = None
        self.limit_min_allocation_memory_allocation = None
        self.limit_min_allocation_memory_resources_guaranteed = None
        #self.limit_min_allocation_vcpu_speed = None
        self.limit_allocation_cpu_allocation = None
        self.limit_allocation_cpu_resources_guaranteed = None
        self.limit_allocation_memory_allocation = None
        self.limit_allocation_memory_resources_guaranteed = None
        #self.limit_allocation_vcpu_speed = None

        self.limit_free_reservation_cpu_allocation = 0
        self.limit_free_reservation_memory_allocation = 0
        self.limit_min_reservation_cpu_allocation = None
        self.limit_min_reservation_memory_allocation = None
        self.limit_reservation_cpu_allocation = None
        self.limit_reservation_memory_allocation = None

        self.limit_free_pay_as_you_go_cpu_limit = 0
        self.limit_free_pay_as_you_go_memory_limit = 0
        self.limit_free_pay_as_you_go_cpu_used = 0
        self.limit_free_pay_as_you_go_memory_used = 0
        self.limit_min_pay_as_you_go_cpu_limit = None
        self.limit_min_pay_as_you_go_memory_limit = None
        self.limit_pay_as_you_go_cpu_limit = None
        self.limit_pay_as_you_go_memory_limit = None