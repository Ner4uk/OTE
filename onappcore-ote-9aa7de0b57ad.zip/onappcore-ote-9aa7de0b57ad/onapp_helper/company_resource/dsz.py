# {"resource"=>{"resource_class"=>"Billing::Company::Resource::VCloud::DataStoreZone", "target_type"=>"Pack", "target_id"=>"1", "limit_type"=>"hourly"}, "humanized"=>"true", "plan_id"=>"163"}

from onapp_helper.company_resource.company_resource_base import CompanyRBase
from onapp_helper.company_resource.limits import dsz_limits
from onapp_helper.company_resource.prices import dsz_prices
#from preferences import hvz_preferences


class CompanyDSZBR(CompanyRBase):
    def __init__(self, **kwargs):
        CompanyRBase.__init__(self, kwargs)
        self.resource_class = 'DataStoreZone'
        self.limits = dsz_limits.CompanyDSZLimits()
        self.prices = dsz_prices.CompanyDSZPrices()

    def reset(self):
        self.limits = dsz_limits.CompanyDSZLimits()
        self.prices = dsz_prices.CompanyDSZPrices()
        #self.own_preferences = hvz_preferences.HVZPreferences()
        #self.in_bucket_zone = False
        #self.in_template_zone = False