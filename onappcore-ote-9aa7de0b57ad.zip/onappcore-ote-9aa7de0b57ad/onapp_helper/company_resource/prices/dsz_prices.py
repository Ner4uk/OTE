

class CompanyDSZPrices():
    def __init__(self):
        self.price_disk_size = 0