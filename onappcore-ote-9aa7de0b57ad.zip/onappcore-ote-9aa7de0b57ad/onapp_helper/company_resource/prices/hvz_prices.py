

class CompanyHVZPrices():
    def __init__(self):
        self.price_allocation_cpu_allocation = 0
        self.price_allocation_cpu_resources_guaranteed = 0
        self.price_allocation_memory_allocation = 0
        self.price_allocation_memory_resources_guaranteed = 0
        #self.price_allocation_vcpu_speed = 0
        self.price_reservation_cpu_allocation = 0
        self.price_reservation_memory_allocation = 0

        self.price_pay_as_you_go_cpu_limit = 0
        self.price_pay_as_you_go_memory_limit = 0
        self.price_pay_as_you_go_cpu_used = 0
        self.price_pay_as_you_go_memory_used = 0
        self.price_pay_as_you_go_cpu_limit_unlimited = 0
        self.price_pay_as_you_go_memory_limit_unlimited = 0