

class CompanyNTZPrices():
    def __init__(self):
        self.price_ip = 0
        self.price_data_sent = 0
        self.price_data_received = 0