from onapp_helper.base_helper import BaseHelper
from onapp_helper import test


class SysadminTools(BaseHelper):
    route = 'sysadmin_tools'

    def daemon_status(self):
        test.log.info("Get daemon status")
        url = '/{}/daemon/status.json'.format(self.route)
        return test.get_object(self, url=url)

    def daemon_start(self):
        test.log.info("Get start daemon")
        url = '/{}/daemon/start.json'.format(self.route)
        return test.post_object(self, url=url)

    def daemon_stop(self):
        test.log.info("Get stop daemon")
        url = '/{}/daemon/stop.json'.format(self.route)
        return test.post_object(self, url=url)

    def daemon_reload(self):
        test.log.info("Get reload daemon")
        url = '/{}/daemon/reload.json'.format(self.route)
        return test.post_object(self, url=url)

    def add_zabbix_server(self, ip_address):
        test.log.info("Add zabbix server")
        data = {"zabbix_setup": {"ip_address": ip_address}}
        url = f'/{self.route}/infrastructure/{ip_address}.json'
        return test.post_object(self, url=url, data=data)
