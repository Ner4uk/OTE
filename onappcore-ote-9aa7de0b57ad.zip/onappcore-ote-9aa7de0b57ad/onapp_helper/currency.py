from onapp_helper.base_helper import BaseHelper
from onapp_helper import test


class Currency(BaseHelper):
    """
    :param name: the currency label
    :param unit: a currency symbol ($, €, £, etc. )
    :param format: how the currency is displayed in the control panel.
        The following parameters are used: %n ( for the digits),
        %u ( for the currency symbol)
    :param code: three-character currency code that is generally used to represent the currency
    :param separator: a character used to format decimal numbers, e.g.: 100.99
    :param precision: the number of digits after the delimiter to display the costs
    :param precision_for_unit: the numberof digits after the delimiter to display the prices for resources
    :param delimiter: a grouping character used to separate thousands, e.g.: 100,000,000.
    """
    def __init__(self, id=None):
        """
        :param id: currency id
        """
        self.route = 'settings/currencies'
        self.root_tag = 'currency'
        self.name = ''
        self.unit = ''
        self.format = ''
        self.code = ''
        self.separator = ''
        self.precision = ''
        self.precision_for_unit = ''
        self.delimiter = ''
        self.id = id
        if self.id:
            test.update_object(self)

    def create(self):
        """
        Create a new currency.

        :return: True if success, else False
        """
        test.log.info("Create {}...".format(self.__class__.__name__))
        data = {
            self.root_tag: {
                "name": self.name,
                "unit": self.unit,
                "format": self.format,
                "code": self.code,
                "separator": self.separator,
                "precision": self.precision,
                "precision_for_unit": self.precision_for_unit,
                "delimiter": self.delimiter
            }
        }
        return test.post_object(self, data=data)

    def edit(self):
        """
        Edit currency.

        :return: True if success, else False
        """
        test.log.info("Edit {}...".format(self.__class__.__name__))
        data = {
            self.root_tag: {
                "name": self.name,
                "unit": self.unit,
                "format": self.format,
                "code": self.code,
                "separator": self.separator,
                "precision": self.precision,
                "precision_for_unit": self.precision_for_unit,
                "delimiter": self.delimiter
            }
        }
        return test.put_object(self, data=data)
