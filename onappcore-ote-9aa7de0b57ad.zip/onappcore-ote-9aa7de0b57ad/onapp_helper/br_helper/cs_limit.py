from onapp_helper.br_helper.br_base import BRBase
from onapp_helper.br_helper.limits import cs_limit


class CSLimit(BRBase):
    def __init__(self, **kwargs):
        BRBase.__init__(self, kwargs)
        self.resource_class = 'ContainerServerLimit'
        self.resource_name = 'container_server_limit'
        self.limits = cs_limit.CsLimits()