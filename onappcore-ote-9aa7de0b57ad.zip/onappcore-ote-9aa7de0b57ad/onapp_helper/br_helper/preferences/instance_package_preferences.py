

class InstancePackagePreferences():
    def __init__(self):
        self.hypervisor_group_ids = []
        self.data_store_group_ids = []
        self.network_group_ids = []