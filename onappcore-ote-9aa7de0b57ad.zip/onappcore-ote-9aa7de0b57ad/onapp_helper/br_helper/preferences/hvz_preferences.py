

class HVZPreferences():
    def __init__(self):
        self.use_default_cpu = False
        self.use_default_cpu_share = False
        self.use_cpu_units = False