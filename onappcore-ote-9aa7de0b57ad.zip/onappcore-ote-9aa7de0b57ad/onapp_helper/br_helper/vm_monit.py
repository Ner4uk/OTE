from onapp_helper.br_helper.br_base import BRBase
from onapp_helper.br_helper.limits import vm_monit_limits
from onapp_helper.br_helper.prices import vm_monit_prices
from onapp_helper import test


class VmMonitBR(BRBase):
    def __init__(self, **kwargs):
        BRBase.__init__(self, kwargs)
        if test.cp_version <= 5.1:
            self.resource_class = 'VmMonit'
            self.resource_name = 'vm_monit'
        elif test.cp_version >= 5.2:
            self.resource_class = 'Autoscale'
            self.resource_name = 'autoscale'
        self.limits = vm_monit_limits.VmMonitLimits()
        self.prices = vm_monit_prices.VmMonitPrices()