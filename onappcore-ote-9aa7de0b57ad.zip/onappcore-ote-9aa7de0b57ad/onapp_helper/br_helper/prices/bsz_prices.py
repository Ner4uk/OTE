from onapp_helper import test


class BSZPrices():
    def __init__(self):
        self.price_backup = 0
        self.price_template = 0
        self.price_template_disk_size = 0
        self.price_backup_disk_size = 0
        # OVA available since 5.2
        if test.cp_version >= 5.2:
            self.price_ova = 0
            self.price_ova_disk_size = 0
