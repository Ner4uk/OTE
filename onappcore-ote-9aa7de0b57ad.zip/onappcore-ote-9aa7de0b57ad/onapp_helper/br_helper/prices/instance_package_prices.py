

class InstancePackagePrices():
    def __init__(self):
        self.price_on = 0
        self.price_off = 0
        self.price_overused_bandwidth = 0