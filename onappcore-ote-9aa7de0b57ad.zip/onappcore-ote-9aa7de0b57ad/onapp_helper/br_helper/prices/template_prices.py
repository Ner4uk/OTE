

class TemplatePrices():
    def __init__(self):
        self.price = 0