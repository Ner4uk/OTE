

class HVZPrices():
    def __init__(self):
        self.price_on_cpu = 0
        self.price_off_cpu = 0
        self.price_on_cpu_share = 0
        self.price_off_cpu_share = 0
        self.price_on_memory = 0
        self.price_off_memory = 0
        self.price_on_cpu_units = 0
        self.price_off_cpu_units = 0