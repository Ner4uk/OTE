

class DSZPrices():
    def __init__(self):
        self.price_data_read = 0
        self.price_data_written = 0
        self.price_on = 0
        self.price_off = 0
        self.price_writes_completed = 0
        self.price_reads_completed = 0