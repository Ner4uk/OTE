

class StorageDiskSizePrices():
    def __init__(self):
        self.price = 0