

class DRaaSPrices():
    def __init__(self):
        self.price_disk_size = 0
        self.price_memory = 0
        self.price_cpus = 0
        self.price_cpu_shares = 0
        self.price_cpu_units = 0
        self.price_nodes = 0