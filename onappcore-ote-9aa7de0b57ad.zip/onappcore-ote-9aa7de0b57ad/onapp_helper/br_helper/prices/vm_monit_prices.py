

class VmMonitPrices():
    def __init__(self):
        self.price = 0