

class NTZPrices():
    def __init__(self):
        self.price_ip_on = 0
        self.price_ip_off = 0
        self.price_rate_on = 0
        self.price_rate_off = 0
        self.price_data_sent = 0
        self.price_data_received = 0