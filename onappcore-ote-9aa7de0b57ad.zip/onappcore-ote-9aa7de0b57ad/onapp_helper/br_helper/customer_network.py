from onapp_helper.br_helper.br_base import BRBase
from onapp_helper.br_helper.limits import customer_network_limits
from onapp_helper.br_helper.prices import customer_network_prices


class CustomerNetworkBR(BRBase):
    def __init__(self, **kwargs):
        BRBase.__init__(self, kwargs)
        self.resource_class = 'CustomerNetwork'
        self.resource_name = 'customer_network'
        self.limits = customer_network_limits.CustomerNetworkLimits()
        self.prices = customer_network_prices.CustomerNetworkPrices()