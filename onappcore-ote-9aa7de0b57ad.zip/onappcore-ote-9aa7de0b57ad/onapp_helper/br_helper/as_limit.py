from onapp_helper.br_helper.br_base import BRBase
from onapp_helper.br_helper.limits import as_limit


class ASLimit(BRBase):
    def __init__(self, **kwargs):
        BRBase.__init__(self, kwargs)
        self.resource_class = 'ApplicationServer'
        self.resource_name = 'application_server'
        self.limits = as_limit.AsLimits()