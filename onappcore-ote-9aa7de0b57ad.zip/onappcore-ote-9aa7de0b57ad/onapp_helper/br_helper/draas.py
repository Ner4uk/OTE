from onapp_helper.br_helper.br_base import BRBase
from onapp_helper.br_helper.prices import draas_prices


class DRaaSBR(BRBase):
    def __init__(self, **kwargs):
        BRBase.__init__(self, kwargs)
        self.resource_class = 'DRaaS'
        self.resource_name = 'draas'
        self.prices = draas_prices.DRaaSPrices()