from onapp_helper.br_helper.br_base import BRBase


class RecipeGroupBR(BRBase):
    def __init__(self, **kwargs):
        BRBase.__init__(self, kwargs)
        self.resource_class = 'RecipeGroup'
        self.target_type = 'RecipeGroup'
        self.resource_name = 'recipe_group'
        self.label = ''