from onapp_helper.br_helper.br_base import BRBase


class TemplateStoreBR(BRBase):
    def __init__(self, **kwargs):
        BRBase.__init__(self, kwargs)
        self.resource_class = 'TemplateGroup'
        self.target_type = 'ImageTemplateGroup'
        self.resource_name = 'template_group'
        self.label = ''