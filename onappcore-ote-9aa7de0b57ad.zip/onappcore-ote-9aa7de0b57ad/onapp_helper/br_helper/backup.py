from onapp_helper.br_helper.br_base import BRBase
from onapp_helper.br_helper.limits import backup_limits
from onapp_helper.br_helper.prices import backup_prices


class BackupBR(BRBase):
    def __init__(self, **kwargs):
        BRBase.__init__(self, kwargs)
        self.resource_class = 'Backup'
        self.resource_name = 'backup'
        self.limits = backup_limits.BackupLimits()
        self.prices = backup_prices.BackupPrices()