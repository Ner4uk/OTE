from onapp_helper.br_helper.limits.base_limit import BaseLimits
from onapp_helper.br_helper.prices.base_price import BasePrices
from onapp_helper.br_helper.preferences.base_preferences import BasePreferences
from onapp_helper.base_helper import BaseHelper
from onapp_helper import test


class BRBase(BaseHelper):
    if test.cp_version < 5.8:
        E_VALIDATION_VALUE = 'must be greater than or equal to 0'
    else:
        E_VALIDATION_VALUE = 'must be between 0 and Infinity'

    def __init__(self, kwargs):
        """

        :param kwargs: billing_plan, id, user, target_id.
            where:
                * billing_plan - billing_plan object
                * id - base resource id
                * user - user object
                * target_id - an id of target obj (HVZ, DSZ, NetZ, etc...)
        """
        self.id = None
        self.user = None
        self.target_id = None
        for key, value in list(kwargs.items()):
            self.__dict__[key] = value
        self.resource_class = ''
        self.limits = BaseLimits()
        self.prices = BasePrices()
        self.preferences = BasePreferences()
        self.target_type = None
        self.billing_plan_id = self.billing_plan.id
        self._setup()
        if self.id:
            test.update_object(self)

    def create(self):
        test.log.info("Create base resource {0}...".format(self.resource_class))
        self._compare_api_versions()

        data = {
            self.root_tag: {
                "resource_class": "Resource::{0}".format(self.resource_class),
                "billing_plan_id": self.billing_plan_id,
                "target_id": self.target_id,
                "target_type": self.target_type,
                "limits": self.limits.__dict__,
                "prices": self.prices.__dict__
            }
        }

        # Set/delete parameters depending on resources
        if self.resource_class == 'HypervisorGroup':
            data[self.root_tag]["preferences"] = self.preferences.__dict__
            # API versioning:
            if test.api_version >= 4.2:
                data[self.root_tag]["in_master"] = self.in_master_zone
            elif test.api_version == 4.1:
                data[self.root_tag]["in_bucket_zone"] = self.in_bucket_zone

        elif self.resource_class == 'DataStoreGroup' or self.resource_class == 'NetworkGroup':
            data[self.root_tag]["limit_type"] = self.limit_type
            # API versioning:
            if test.api_version >= 4.2:
                data[self.root_tag]["in_master"] = self.in_master_zone
            elif test.api_version == 4.1:
                data[self.root_tag]["in_template_zone"] = self.in_template_zone

        elif self.resource_class in ['InstanceType', 'InstancePackage']:
            data[self.root_tag]["preferences"] = self.preferences.__dict__
            data[self.root_tag].pop('limits')
        # remove prices
        elif self.resource_class in ['VmLimit', 'ApplicationServer']:
            data[self.root_tag].pop('prices')
        # remove limits and prices
        elif self.resource_class in [
            'TemplateGroup',
            'RecipeGroup',
            'ServiceAddonGroup'
        ]:
            data[self.root_tag].pop('limits')
            data[self.root_tag].pop('prices')
        # remove limits
        elif self.resource_class in ['EdgeGroup', 'DRaaS']:
            data[self.root_tag].pop('limits')
        # Create
        if test.api_version < 4.2:
            url = '/{0}.json'.format(self.route)
        else:
            url = '/billing/user/plans/{0}/resources.json'.format(
                self.billing_plan.id
            )
        if test.post_object(self, url=url, data=data):
            return self._dict_to_class()

    def edit(self):
        test.log.info("Edit base resource {0}...".format(self.resource_class))
        self._compare_api_versions()

        data = {self.root_tag: {}}
        data[self.root_tag].update(
            dict(
                list(self.limits.__dict__.items()) +
                list(self.prices.__dict__.items())
            )
        )

        # Set/delete parameters depending on resources
        if self.resource_class == 'HypervisorGroup':
            data[self.root_tag]["preferences"] = self.preferences.__dict__
            # API versioning:
            if test.api_version >= 4.2:
                data[self.root_tag]["in_master_zone"] = self.in_master_zone
            elif test.api_version == 4.1:
                data[self.root_tag]["in_bucket_zone"] = self.in_bucket_zone

        elif self.resource_class == 'DataStoreGroup' or self.resource_class == 'NetworkGroup':
            # API versioning:
            if test.api_version >= 4.2:
                data[self.root_tag]["in_master_zone"] = self.in_master_zone
            elif test.api_version == 4.1:
                data[self.root_tag]["in_template_zone"] = self.in_template_zone

        elif self.resource_class in ['InstanceType', 'InstancePackage']:
            data[self.root_tag].update(self.preferences.__dict__)
            data[self.root_tag].pop('limit')
            data[self.root_tag].pop('limit_free')
        # remove prices
        elif self.resource_class in ['VmLimit', 'ApplicationServer']:
            data[self.root_tag].pop('price')
        # remove limits
        elif self.resource_class in ['EdgeGroup', 'DRaaS']:
            data[self.root_tag].pop('limit')
            data[self.root_tag].pop('limit_free')

        url = '/{0}/{1}.json'.format(self.route, self.id)
        if test.put_object(self, url=url, data=data):
            return self._dict_to_class()

    def delete(self):
        test.log.info("Delete base resource {0}...".format(self.resource_class))
        self._compare_api_versions()
        return test.delete_object(self)
        
    def get_all(self):
        test.log.info("Get all base resources...")
        self._compare_api_versions()
        route = '{0}/{1}/{2}s'.format(
            self.billing_plan.route,
            self.billing_plan.id,
            self.root_tag
        )
        return self._get_objects(
            route=route,
            billing_plan=self.billing_plan
        )

        # self._get_handler(url)
        # return [
        #     BRBase(
        #         {
        #             'billing_plan': self.billing_plan,
        #             'id': br[self.root_tag]['id']
        #         }
        #     )
        #     for br in self.response
        #     if br[self.root_tag]['resource_name'].replace('_', '') == self.resource_class.lower()
        # ]

    def get_by_resource_name(self, resource_name=None):
        """
        Get base resources by resource_name

        :param resource_name: resource name, if not specified get for current
            resource

        :return: a list of selected resources.
        """
        if not resource_name:
            resource_name = self.resource_name

        return [br._dict_to_class() for br in self.get_all() if
                br.resource_name == resource_name]

    def _setup(self):
        #  This is used for checking deprecated API requests to change routes during testing.
        self.api_version = test.api_version
        if test.api_version is None or test.api_version >= 4.2:
            #  Should be checked additionally
            if self.user:
                self.route = 'users/{0}/billing_plans/{1}/base_resources'.format(
                    self.user.id, self.billing_plan.id
                )
            else:
                self.route = 'billing/user/resources'
            self.root_tag = 'resource'
            self.in_master_zone = False
        elif test.api_version == 4.1:
            if self.user:
                self.route = 'users/{0}/billing_plans/{1}/base_resources'.format(
                    self.user.id, self.billing_plan.id
                )
            else:
                self.route = 'billing_plans/{0}/base_resources'.format(self.billing_plan.id)
            self.root_tag = 'base_resource'
            self.in_bucket_zone = False
            self.in_template_zone = False
        else:
            raise SystemError('"api_version" parameter misconfigured.')

    def _compare_api_versions(self):
        """
        If api version has been changed during testing - reset required attributes.
        :return:
        """
        if self.api_version != test.api_version:
            self._setup()

    def _dict_to_class(self):
        """
        Convert dict (response) to class attributes for limits, prices,
        and preferences
        :return:
        """
        if hasattr(self, 'id') and self.id:  # Allow do not update resource without id like settings, cloud config etc.
            response = self.response
            if not response:
                test.update_object(self)
            limits = self.limits
            self.limits = BaseLimits()
            self.limits.__dict__.update(limits)  # dict to class attributes

            prices = self.prices
            self.prices = BasePrices()
            self.prices.__dict__.update(prices)  # dict to class attributes

            preferences = self.preferences
            self.preferences = BasePreferences()
            self.preferences.__dict__.update(preferences)  # dict to class attributes
            return self
        return False


class BaseResource(BRBase):
    def __init__(self, **kwargs):
        BRBase.__init__(self, kwargs)