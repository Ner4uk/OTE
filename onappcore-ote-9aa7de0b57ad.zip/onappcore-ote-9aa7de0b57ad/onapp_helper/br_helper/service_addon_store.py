from onapp_helper.br_helper.br_base import BRBase


class ServiceAddonStoreBR(BRBase):
    def __init__(self, **kwargs):
        """
        :param kwargs: billing_plan, id, user, target_id.
        where:
            - billing_plan - billing_plan object
            - id - base resource id
            - user - user object
            - target_id - an id of target obj (HVZ, DSZ, NetZ, etc...)
        """
        BRBase.__init__(self, kwargs)
        self.resource_class = 'ServiceAddonGroup'
        self.target_type = 'ServiceAddonGroup'
        self.resource_name = 'service_addon_group'
        self.label = ''