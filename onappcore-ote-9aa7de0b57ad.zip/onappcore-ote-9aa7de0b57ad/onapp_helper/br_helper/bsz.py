from onapp_helper.br_helper.br_base import BRBase
from onapp_helper.br_helper.limits import bsz_limits
from onapp_helper.br_helper.prices import bsz_prices


class BSZBR(BRBase):
    def __init__(self, **kwargs):
        BRBase.__init__(self, kwargs)
        self.resource_class = 'BackupServerGroup'
        self.target_type = 'Pack'
        self.resource_name = 'backup_server_group'
        self.limits = bsz_limits.BSZLimits()
        self.prices = bsz_prices.BSZPrices()