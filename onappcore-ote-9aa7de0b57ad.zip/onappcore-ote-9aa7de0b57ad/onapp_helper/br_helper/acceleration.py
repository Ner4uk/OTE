from onapp_helper.br_helper.br_base import BRBase
from onapp_helper.br_helper.limits import acceleration_limits
from onapp_helper.br_helper.prices import acceleration_prices


class AccelerationBR(BRBase):
    def __init__(self, **kwargs):
        BRBase.__init__(self, kwargs)
        self.resource_class = 'Acceleration'
        self.resource_name = 'acceleration'
        self.limits = acceleration_limits.AccelerationLimits()
        self.prices = acceleration_prices.AccelerationPrices()