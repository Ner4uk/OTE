from onapp_helper.br_helper.br_base import BRBase


class EdgeGroupBR(BRBase):
    def __init__(self, **kwargs):
        BRBase.__init__(self, kwargs)
        self.resource_class = 'EdgeGroup'
        self.target_type = 'EdgeGroup'
        self.resource_name = 'edge_group'
        self.label = ''