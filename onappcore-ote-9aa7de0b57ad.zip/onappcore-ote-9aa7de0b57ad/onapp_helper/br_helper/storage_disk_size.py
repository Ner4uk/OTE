from onapp_helper.br_helper.br_base import BRBase
from onapp_helper.br_helper.limits import storage_disk_size_limits
from onapp_helper.br_helper.prices import storage_disk_size_prices


class StorageDiskSizeBR(BRBase):
    def __init__(self, **kwargs):
        BRBase.__init__(self, kwargs)
        self.resource_class = 'StorageDiskSize'
        self.resource_name = 'storage_disk_size'
        self.limits = storage_disk_size_limits.StorageDiskSizeLimits()
        self.prices = storage_disk_size_prices.StorageDiskSizePrices()