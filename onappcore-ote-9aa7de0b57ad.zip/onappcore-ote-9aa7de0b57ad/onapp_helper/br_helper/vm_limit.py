from onapp_helper.br_helper.br_base import BRBase
from onapp_helper.br_helper.limits import vm_limit


class VMLimit(BRBase):
    def __init__(self, **kwargs):
        BRBase.__init__(self, kwargs)
        self.resource_class = 'VmLimit'
        self.resource_name = 'vm_limit'
        self.limits = vm_limit.VmLimits()