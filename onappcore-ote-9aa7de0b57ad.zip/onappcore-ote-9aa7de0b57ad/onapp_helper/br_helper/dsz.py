from onapp_helper.br_helper.br_base import BRBase
from onapp_helper.br_helper.limits import dsz_limits
from onapp_helper.br_helper.prices import dsz_prices


class DSZBR(BRBase):
    def __init__(self, **kwargs):
        BRBase.__init__(self, kwargs)
        self.resource_class = 'DataStoreGroup'
        self.target_type = 'Pack'
        self.limit_type = 'hourly'
        self.resource_name = 'data_store_group'
        self.limits = dsz_limits.DSZLimits()
        self.prices = dsz_prices.DSZPrices()

    def reset(self):
        self.limits = dsz_limits.DSZLimits()
        self.prices = dsz_prices.DSZPrices()