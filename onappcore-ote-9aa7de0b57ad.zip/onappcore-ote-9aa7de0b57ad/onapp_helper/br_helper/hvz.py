from onapp_helper.br_helper.br_base import BRBase
from onapp_helper.br_helper.limits import hvz_limits
from onapp_helper.br_helper.prices import hvz_prices
from onapp_helper.br_helper.preferences import hvz_preferences


class HVZBR(BRBase):
    def __init__(self, **kwargs):
        BRBase.__init__(self, kwargs)
        self.resource_class = 'HypervisorGroup'
        self.target_type = 'Pack'
        self.resource_name = 'hypervisor_group'
        self.limits = hvz_limits.HVZLimits()
        self.prices = hvz_prices.HVZPrices()
        self.preferences = hvz_preferences.HVZPreferences()

    def reset(self):
        self.limits = hvz_limits.HVZLimits()
        self.prices = hvz_prices.HVZPrices()
        self.preferences = hvz_preferences.HVZPreferences()
        self.in_bucket_zone = False
        self.in_template_zone = False