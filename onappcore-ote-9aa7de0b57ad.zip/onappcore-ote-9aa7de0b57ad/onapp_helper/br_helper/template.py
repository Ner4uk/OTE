from onapp_helper.br_helper.br_base import BRBase
from onapp_helper.br_helper.limits import template_limits
from onapp_helper.br_helper.prices import template_prices


class TemplateBR(BRBase):
    def __init__(self, **kwargs):
        BRBase.__init__(self, kwargs)
        self.resource_class = 'Template'
        self.resource_name = 'template'
        self.limits = template_limits.TemplateLimits()
        self.prices = template_prices.TemplatePrices()