from onapp_helper.br_helper.br_base import BRBase
from onapp_helper.br_helper.limits import minIOPS_limits
from onapp_helper.br_helper.prices import minIOPS_prices


class MinIOPSBR(BRBase):
    def __init__(self, **kwargs):
        BRBase.__init__(self, kwargs)
        self.resource_class = 'SolidFire'
        self.target_type = 'Pack'
        self.resource_name = 'solid_fire'
        self.limits = minIOPS_limits.MinIOPSLimits()
        self.prices = minIOPS_prices.MinIOPSPrices()