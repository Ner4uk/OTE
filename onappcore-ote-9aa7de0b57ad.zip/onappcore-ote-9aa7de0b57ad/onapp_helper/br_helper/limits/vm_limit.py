

class VmLimits():
    def __init__(self):
        self.limit = None