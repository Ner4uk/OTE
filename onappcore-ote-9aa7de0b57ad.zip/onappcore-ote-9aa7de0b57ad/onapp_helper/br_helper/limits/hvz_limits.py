

class HVZLimits():
    def __init__(self):
        self.limit_free_cpu = 0
        self.limit_cpu = None
        self.limit_free_memory = 0
        self.limit_memory = None
        self.limit_free_cpu_share = 0
        self.limit_cpu_share = None
        self.limit_free_cpu_units = 0
        self.limit_cpu_units = None
        self.limit_default_cpu = 1
        self.limit_min_cpu = 1
        self.limit_min_memory = 128
        self.limit_default_cpu_share = 100
        self.limit_min_cpu_priority = 1