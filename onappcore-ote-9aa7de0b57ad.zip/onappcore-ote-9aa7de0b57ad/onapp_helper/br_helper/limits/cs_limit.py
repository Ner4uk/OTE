

class CsLimits():
    def __init__(self):
        self.limit = None