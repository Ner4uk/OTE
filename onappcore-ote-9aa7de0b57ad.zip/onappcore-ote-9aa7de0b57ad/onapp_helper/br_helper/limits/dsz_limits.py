

class DSZLimits():
    def __init__(self):
        self.limit_free = 0
        self.limit = None
        self.limit_data_written_free = 0
        self.limit_data_read_free = 0
        self.limit_reads_completed_free = 0
        self.limit_writes_completed_free = 0