

class AsLimits():
    def __init__(self):
        self.limit = None