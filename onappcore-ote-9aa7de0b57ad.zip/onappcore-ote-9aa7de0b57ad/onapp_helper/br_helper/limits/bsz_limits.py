from onapp_helper import test


class BSZLimits():
    def __init__(self):
        self.limit_backup_free = 0
        self.limit_backup = None
        self.limit_backup_disk_size_free = 0
        self.limit_backup_disk_size = None
        self.limit_template_disk_size = None
        self.limit_template = None
        self.limit_template_free = 0
        self.limit_template_disk_size_free = 0
        # OVA available since 5.2
        if test.cp_version >= 5.2:
            self.limit_ova = None
            self.limit_ova_disk_size = None
            self.limit_ova_free = 0
            self.limit_ova_disk_size_free = 0
