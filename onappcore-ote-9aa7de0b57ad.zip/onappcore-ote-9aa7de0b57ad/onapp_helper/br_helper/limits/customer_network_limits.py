

class CustomerNetworkLimits():
    def __init__(self):
        self.limit = None
        self.limit_free = 0