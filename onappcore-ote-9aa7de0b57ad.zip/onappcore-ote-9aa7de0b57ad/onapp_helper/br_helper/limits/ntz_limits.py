

class NTZLimits():
    def __init__(self):
        self.limit_ip = None
        self.limit_ip_free = 0
        self.limit_data_sent_free = 0
        self.limit_data_received_free = 0
        self.limit_rate = None
        self.limit_rate_free = 0