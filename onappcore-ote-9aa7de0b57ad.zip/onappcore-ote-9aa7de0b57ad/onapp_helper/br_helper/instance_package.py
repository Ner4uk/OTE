from onapp_helper.br_helper.br_base import BRBase
from onapp_helper.br_helper.prices import instance_package_prices
from onapp_helper.br_helper.preferences import instance_package_preferences
from onapp_helper import test


class InstancePackageBR(BRBase):
    def __init__(self, **kwargs):
        """
        You can set up ids, as string, for hypervisor_group, data_store_group, network_group:
        hypervisor_group_ids = ''
        data_store_group_ids = ''
        network_group_ids = ''
        """
        BRBase.__init__(self, kwargs)
        if test.api_version < 4.3:
            self.resource_class = 'InstanceType'
            self.target_type = 'InstanceType'
            self.resource_name = 'instance_type'
        elif test.api_version >= 4.3:
            self.resource_class = 'InstancePackage'
            self.target_type = 'InstancePackage'
            self.resource_name = 'instance_package'
        else:
            test.log.warning("Unsupported API version - {0}".format(test.api_version))

        self.prices = instance_package_prices.InstancePackagePrices()
        self.preferences = instance_package_preferences.InstancePackagePreferences()
        #self.hypervisor_group_ids = ''
        #self.data_store_group_ids = ''
        #self.network_group_ids = ''