from onapp_helper.br_helper.br_base import BRBase
from onapp_helper.br_helper.limits import ntz_limits
from onapp_helper.br_helper.prices import ntz_prices


class NTZBR(BRBase):
    def __init__(self, **kwargs):
        BRBase.__init__(self, kwargs)
        self.resource_class = 'NetworkGroup'
        self.target_type = 'Pack'
        self.limit_type = 'hourly'
        self.resource_name = 'network_group'
        self.limits = ntz_limits.NTZLimits()
        self.prices = ntz_prices.NTZPrices()

    def reset(self):
        self.limits = ntz_limits.NTZLimits()
        self.prices = ntz_prices.NTZPrices()