"""
Represents all the diagnostic health checks classes which relates to the disk_health section

:route: storage/compute_zone_id/health_checks
"""
from onapp_helper import test
from onapp_helper.base_helper import BaseHelper
from onapp_helper.base_helper import Transaction
from onapp_helper.storage.diagnostic import bash_runner


class BaseHealthCheck(BaseHelper):
    """
    This class represents common interface for all the child classes

    Disk Health:
        degraded disks
        disks with partial memberlist
        disks with no stripe replicas	    # doesn't work since 3.3
        disks with no redundancy
        partially online disks
        zombie snapshots
        zombie disks
        disks in other degraded states
        stale cache volumes                 TODO: get rid of a hv reboot
        disks with inactive cache

    Drive Health:
        partial nodes
        inactive nodes
        nodes with delayed ping
        nodes with high utilization
        out of space nodes
        missing drives
        extra drives
        inactive controllers
        unreferenced NBDs
        reused NBDs
        dangling device mappers
        SMART errors
        SMART warnings

    """

    root_tag = 'not implemented for parent class'
    parent_type = 'not implemented for parent class'
    action = 'not implemented for parent class'

    def _get_failed_items(self):
        self.get()
        if hasattr(self, 'failed_items'):
            if self.root_tag == 'disks_with_other_degradations':
                return [item['disk']['id'] for item in self.failed_items['missing_active_members']]
            return [item[key]['id'] for item in self.failed_items for key in item.keys()]
        return []

    def _is_failed(self, item):
        return item in self._get_failed_items()

    def _is_repaired(self, item):
        return item in self._get_failed_items()

    def _is_cleaned(self):
        self.get_state()
        if self.state == 'success':
            return True
        self.repair_all()
        return False

    def get(self):
        """
        Get a diagnostic check status via API
        depends on what type of child class instance the method gets called on

        :return: response data if success otherwise self.error.
        """
        url = "/{}/health_checks/{}.json".format(self.route(), self.root_tag)
        return test.get_object(self, url=url)

    def get_state(self):
        """
        Get the state property value of response object

        :return: a string value of the state property
        """
        self.get()
        return self.state

    def wait_for_failed_status(self, item, timeout=420, step=5):
        """
         Wait when storage api update the check status after a breakage

        :return: True if item in failed items of response object otherwise False
         """
        status = self.wait_for_action(self._is_failed, item, timeout=timeout, step=step)
        return status

    def wait_for_repaired_status(self, item, timeout=420, step=5):
        """
        Wait when storage api update the check status after a breakage

        :return: True if item not in failed items of response object otherwise False
        """
        status = self.wait_for_action(self._is_repaired, item, timeout=timeout, step=step)
        return status

    def wait_for_cleaning(self, timeout=420, step=5):
        """
        Wait when all zombie snapshots or disks have been cleaned or fails after a while

        :return: return True if response state is 'success' otherwise False
         """
        status = self.wait_for_action(self._is_cleaned, timeout=timeout, step=step)
        return status

    def wait_for_failed_node(self, timeout=420, step=5):
        """
        Waits when failed node has been found on diagnostic page.

        :param timeout: int
        :param step: int
        :return: failed item, str
        """
        self.wait_for_action(self._get_failed_items, timeout=timeout, step=step)
        item = self._get_failed_items()[0]
        return item

    def find_parent_id(self):
        """
        Find parent_id param by querying a transaction with parent_type,
        should be deleted once parent_id is bounded and returned via OnApp API
        :route '/storage/health_checks/degraded_disks.json'

        :return: parent_id value if the transaction has been found otherwise False
        """
        transactions = Transaction()._get_transactions(page=1)
        try:
            return [t.parent_id
                    for t in transactions
                    if t.parent_type == self.parent_type][0]
        except IndexError:
            return False

    def fail_cache(self, ds_id, cache_enabled=0):
        """
        Enable caching for a data store
        :param ds_id:
        :param cache_enabled:
        :return:
        """
        url = "/settings/data_stores/{}.json".format(ds_id)
        data = {
            "data_store": {
                "auto_healing": "0",
                "integrated_storage_cache_enabled": "{}".format(cache_enabled),
                "integrated_storage_cache_settings":
                    {"cache_mode": "writethrough",
                     "cache_line_size": "512",
                     "migration_threshold": "128",
                     "cache_percentage": "10"}
            },
            "id": ds_id
        }
        return test.patch_object(self, url=url, data=data)

    def repair(self, ds_identifier, disk_identifier):
        """
        Repair a disk breakage via API

        :param ds_identifier: data store identifier
        :param disk_identifier: disk identifier
        :return: True if related transaction has been found an finished otherwise False
        """
        url = "/{}/data_stores/{}/disks/{}/repair.json".format(
            self.route(), ds_identifier, disk_identifier
        )
        if test.post_object(self, url=url):
            return self.transaction_handler(
                action=self.action,
                parent_id=self.find_parent_id())
        return False

    def repair_all(self):
        """
        Repair all disks breakages via API

        :return: True if related transactions have been found an finished otherwise False
        """
        url = "/{}/health_checks/{}/repair_all.json".format(
            self.route(), self.root_tag
        )
        if test.post_object(self, url=url):
            return self.transaction_handler(
                action=self.action,
                parent_id=self.find_parent_id()
            )
        return False

    def route(self):
        """
        Define parent route which is used to form full URl path for API calls

        :return: string of parent route, storage + compute zone ID
        """
        return "storage/{}".format(self.parent_obj.id)
