"""
Represents all the diagnostic health checks classes which relates to the drive_health section

:route: storage/compute_zone_id/health_checks
"""
from onapp_helper import test
from onapp_helper.disk import Disk
from onapp_helper.storage.diagnostic import bash_runner
from onapp_helper.storage.diagnostic.base_health_check import BaseHealthCheck


class PartialNodesCheck(BaseHealthCheck):
    """
    Represents partial nodes check on the diagnostic page.

    Attributes:
        parent_obj: compute_zone
    """
    root_tag = 'partial_nodes'
    parent_type = ''
    action = ''

    def __init__(self, parent_obj):
        self.parent_obj = parent_obj

    @staticmethod
    def fail():
        """
        kills all python processes and stops isd daemon on a storage contoller
        :return: full output, str
        """
        bash_runner.kill_all_python_processes()
        bash_runner.stop_isd_daemon()

    def repair(self):
        """
        repair failure via API call

        :return: self.response
        """
        url = "/{}/health_checks/{}/repairs.json".format(
            self.route(), self.root_tag)
        for node in self._get_failed_items():
            data = {
                "node_id": "{}".format(node)
            }
            test.post_object(self, url=url, data=data)


class InactiveNodesCheck(BaseHealthCheck):
    """
    Represents inactive nodes check on the diagnostic page.

    Attributes:
        parent_obj: compute_zone
    """
    root_tag = 'inactive_nodes'
    parent_type = ''
    action = ''

    def __init__(self, parent_obj):
        self.parent_obj = parent_obj

    @staticmethod
    def fail():
        """
        Stops SANcontroller daemon on a hv

        :return: full output, str
        """
        bash_runner.stop_san_controller()

    def repair(self):
        """
        Starts SANcontroller daemon on a hv

        :return:
        """
        bash_runner.start_san_controller()


class NodesWithDelayedPingCheck(BaseHealthCheck):
    """
    Represents nodes with delayed ping check on the diagnostic page.

    Attributes:
        parent_obj: compute_zone
    """
    root_tag = 'delayed_ping_nodes'
    parent_type = ''
    action = ''

    def __init__(self, parent_obj):
        self.parent_obj = parent_obj

    @staticmethod
    def fail():
        """
        Stops ISD daemon on a storage controller

        :return: full output, str
        """
        bash_runner.stop_isd_daemon()

    def repair(self):
        """
        Repair failure via API call

        :return: self.object
        """
        url = "/{}/health_checks/{}/repairs.json".format(
            self.route(), self.root_tag)
        for node in self._get_failed_items():
            data = {
                "node_id": "{}".format(node)
            }
            test.post_object(self, url=url, data=data)


class NodesWithHighUtilizationCheck(BaseHealthCheck):
    """
    Represents nodes with delayed ping check on the diagnostic page.

    Attributes:
        parent_obj: compute_zone
        additional_disk: Disk object
    """
    root_tag = 'high_utilization_nodes'
    parent_type = ''
    action = ''

    def __init__(self, parent_obj):
        self.parent_obj = parent_obj
        self.additional_disk = Disk()

    @staticmethod
    def _to_gb(size):
        gb_size = size / 1024 / 1024 / 1024
        return int(gb_size)

    def _max_disk_size(self, ds_identifier):
        url = "/{}/data_stores/{}.json".format(self.route(), ds_identifier)
        test.get_object(self, url=url)
        max_size = self.response['data_store']['maximum_disk_size']
        return self._to_gb(max_size)

    def create_additional_disk(self, vs, ds_identifier):
        """

        :param vs: virtual machine obj
        :param ds: datastore obj
        :return: full output, str
        """
        self.additional_disk.disk_size = self._max_disk_size(ds_identifier)
        self.additional_disk.parent_obj = vs
        self.additional_disk.require_format_disk = True
        self.additional_disk.mounted = True
        self.additional_disk.create()

    @staticmethod
    def fail(vs, mount_point):
        """
        Write data to a disk

        :param vs: virtual machine obj
        :param mount_point: montpoint path, str
        :return: full output, str
        """
        bash_runner.dwrapper(vs, mount_point)

    def repair_via_console(self):
        """
        Delete additional disk

        :return: full output, str
        """
        self.additional_disk.delete()


class OutOfSpaceNodesCheck(BaseHealthCheck):
    """
    This check is broken should be either fixed or deleted from the diagnostic page.
    """
    pass


class MissingDrivesCheck(BaseHealthCheck):
    """
    Represents missing drives check on the diagnostic page.

    Attributes:
        parent_obj: compute_zone
    """
    root_tag = 'missing_drives'
    parent_type = ''
    action = ''

    def __init__(self, parent_obj):
        self.parent_obj = parent_obj

    def _get_disk_name(self):
        self.get()
        try:
            return self.failed_items[0]["hypervisor_disk_device"]["name"]
        except (KeyError, AttributeError) as error:
            return error

    @staticmethod
    def fail():
        """
        Unassign drive device via diskhotplug tool on a hv

        :return: full output, str
        """
        bash_runner.unassign_drive()

    def repair_via_console(self):
        """
        Assign drive device via diskhotplug tool on a hv

        :return: full output ,str
        """
        bash_runner.assign_drive(self._get_disk_name())


class ExtraDriveCheck(BaseHealthCheck):
    """
    This check requires hot plugging new storage drive,
     should be either mocked somehow.
    """
    # TODO: find a way how to mock up fake new storage drive.
    pass


class InactiveControllersCheck(BaseHealthCheck):
    """
    Represents inactive controller check on the diagnostic page.

    Attributes:
        parent_obj: compute_zone
    """
    root_tag = 'inactive_controllers'
    parent_type = ''
    action = ''

    def __init__(self, parent_obj):
        self.parent_obj = parent_obj

    @staticmethod
    def fail():
        """
        Stop controller via virsh tool

        :return: full output, str
        """
        bash_runner.stop_controller()

    def repair(self):
        """
        repair failure via API call

        :return: self.response
        """
        url = "/{}/health_checks/{}/repairs.json".format(
            self.route(), self.root_tag)
        for item in self._get_failed_items():
            data = {
                "hypervisor_id": "{}".format(test.env.hv.id),
                "id": "{}".format(item)
            }
            test.post_object(self, url=url, data=data)


class UnreferencedNBDsCheck(BaseHealthCheck):
    """
    Represents unreferenced NBDs check on the diagnostic page.

    Attributes:
        parent_obj: compute_zone
    """
    root_tag = 'unreferenced_nbds'
    parent_type = ''
    action = ''

    def __init__(self, parent_obj):
        self.parent_obj = parent_obj

    @staticmethod
    def fail():
        """
        Create disk via onappstore tool,
        online created disk, via onappstore tool,
        remove device mapper of the onlined disk via dmsetup tool

        :return: full output, str
        """
        disk_identifier = bash_runner.create_disk_via_cli(test.env.ds.identifier)
        bash_runner.online_vdisk(disk_identifier)
        bash_runner.remove_device_mapper(disk_identifier)


class ReusedNBDsCheck(BaseHealthCheck):
    """
    Impossible to detect the failure, should be deleted from UI or fixed.
    """
    pass


class DanglingDeviceMappersCheck(BaseHealthCheck):
    """
    Represents dangling device mappers check on the diagnostic page.

    Attributes:
        parent_obj: compute_zone
    """
    root_tag = 'dangling_device_mappers'
    parent_type = ''
    action = ''

    def __init__(self, parent_obj):
        self.parent_obj = parent_obj

    @staticmethod
    def fail(disk_identifier):
        """
        Kill 3 nbd connections

        :param disk_identifier: str
        :return: full output, str
        """
        bash_runner.kill_three_nbds(disk_identifier)

class SMARTErrors(BaseHealthCheck):
    """
    Represents SMART Errors check on the diagnostic page.

    Attributes:
        parent_obj: compute_zone
    """
    # TODO: find a way to mock up virtual storage devices with SMART errors
    root_tag = 'smart_errors'
    parent_type = ''
    action = ''

class SMARTWarnings(BaseHealthCheck):
    """
    Represents SMART Warnings check on the diagnostic page.

    Attributes:
        parent_obj: compute_zone
    """
    # TODO: find a way to mock up virtual storage devices with SMART warnings
    root_tag = 'smart_warnings'
    parent_type = ''
    action = ''
