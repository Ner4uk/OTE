"""Represents all the diagnostic health checks classes which relates to the disk_health section

:route: storage/compute_zone_id/health_checks
"""
from onapp_helper.storage.diagnostic import bash_runner
from onapp_helper.storage.diagnostic.base_health_check import BaseHealthCheck
from onapp_helper import test


class DegradedDisksCheck(BaseHealthCheck):
    """
    Represents degraded disks check on the diagnostic page.

    Attributes:
        parent_obj: compute_zone
    """
    root_tag = 'degraded_disks'
    parent_type = 'Storage::Repair'
    action = 'repair_disk'

    def __init__(self, parent_obj):
        self.parent_obj = parent_obj

    @staticmethod
    def fail(disk_identifier):
        """
        Kill one nbd so a disk becomes degraded

        :param disk_identifier: str
        :return:
        """
        bash_runner.kill_one_nbd(disk_identifier)


class PartialMemberlistCheck(BaseHealthCheck):
    """
    Represents partial memberlist check on the diagnostic page.

    Attributes:
        parent_obj: compute_zone
    """
    root_tag = 'partial_memberlist_disks'
    parent_type = 'Storage::Repair'
    action = 'repair_disk'

    def __init__(self, parent_obj):
        self.parent_obj = parent_obj

    @staticmethod
    def fail(disk_identifier):
        """
        Forget one member so a disk has a partial member list

        :param disk_identifier: str
        """
        bash_runner.forget_member(disk_identifier)


class StripeReplicasCheck(BaseHealthCheck):
    """
    Represents stripe replicas check on the diagnostic page.

    Attributes:
        parent_obj: compute_zone
    """
    root_tag = 'disks_with_no_stripe_replicas'

    def __init__(self, parent_obj):
        self.parent_obj = parent_obj


class RedundancyCheck(BaseHealthCheck):
    """
    Represents disks with no redundancy check on the diagnostic page.

    Attributes:
        parent_obj: compute_zone
        disk_members: members which will be passed to the rebalance API call, no redundancy
        local_members: hypervisor local members
        initial_members: initial disk members, will be passed to the rebalance API call, repairing

    """
    root_tag = 'disks_with_no_redundancy'
    parent_type = 'Storage::Repair'
    action = 'rebalance_disk'

    def __init__(self, parent_obj):
        self.parent_obj = parent_obj
        self.disk_members = []
        self.local_members = []
        self.initial_members = []

    def _add_disk_members(self, disk_identifier):
        self.disk_members = bash_runner.get_disk_members(disk_identifier)

    def _add_local_members(self):
        self.local_members = bash_runner.get_local_members()

    def _add_initial_members(self):
        self.initial_members = list(self.disk_members)

    def set_up_members_to_rebalance(self, disk_identifier):
        """
        Create a list of nodes on which a disk will be rebalanced.

        :param disk_identifier: str
        :return: nodes, list
        """
        self._add_disk_members(disk_identifier)
        self._add_local_members()
        self._add_initial_members()

        # find remote member and it remove from the disk member list
        for member in self.disk_members:
            if member not in self.local_members:
                self.disk_members.remove(member)
                break

        # find unused local member and add it to the disk member list
        for member in self.local_members:
            if member not in self.disk_members:
                self.disk_members.append(member)
                break

        return self.disk_members

    def rebalance(self, ds_identifier, disk_identifier, nodes):
        """
        Rebalance a disk stripe to another member

        :param ds_identifier: str
        :param disk_identifier: str
        :param nodes: members to rebalance, list
        :return: boolean
        """
        url = "/{}/data_stores/{}/disks/{}/repair.json".format(
            self.route(), ds_identifier, disk_identifier
        )
        data = {
            'rebalance': True,
            'node_ids': nodes,
            'endpoint_id': self.parent_obj.id,
            'storage_disk_id': disk_identifier
        }

        if test.post_object(self, url=url, data=data):
            return self.transaction_handler(
                action=self.action,
                parent_id=self.find_parent_id()
            )
        return False


class PartiallyOnlineCheck(BaseHealthCheck):
    """
    Represents partially online disks check on the diagnostic page.

    Attributes:
        parent_obj: compute_zone
    """
    root_tag = 'partially_online_disks'
    parent_type = 'Storage::Repair'
    action = 'repair_disk'

    def __init__(self, parent_obj):
        self.parent_obj = parent_obj

    @staticmethod
    def fail(disk_identifier):
        """
        Kill two nbds so a disk becomes partially onlined

        :param disk_identifier:
        :return:
        """
        bash_runner.kill_two_nbds(disk_identifier)


class ZombieSnapshotCheck(BaseHealthCheck):
    """
    Represents zombie snapshots check on the diagnostic page.

    Attributes:
        parent_obj: compute_zone
    """
    root_tag = 'zombie_snapshots'
    parent_type = 'Pack'
    action = 'clean_zombie_snapshot'

    def __init__(self, parent_obj):
        self.parent_obj = parent_obj

    @staticmethod
    def fail(ds_identifier):
        """
        Create a zombie snapshot via CLI

        :param ds_identifier:
        :return:
        """
        zombie_snapshot = bash_runner.create_snapshot_via_cli(ds_identifier)
        return zombie_snapshot


class ZombieDisksCheck(BaseHealthCheck):
    """
    Represents zombie disks check on the diagnostic page.

    Attributes:
        parent_obj: compute_zone
    """
    root_tag = 'zombie_disks'
    parent_type = 'Pack'
    action = 'clean_zombie_storage'

    def __init__(self, parent_obj):
        self.parent_obj = parent_obj
        self.status = 'health'

    @staticmethod
    def fail(ds_identifier):
        """
        Create a zombie disk via CLI
        :param ds_identifier:
        :return:
        """
        zombie_disk = bash_runner.create_disk_via_cli(ds_identifier)
        return zombie_disk


class OtherDegradedStatesCheck(BaseHealthCheck):
    """
    Represents degraded disks check on the diagnostic page.

    Attributes:
        parent_obj: compute_zone
        node: local member(node) of a disk
        file_path: local node file path on a controller
    """
    root_tag = 'disks_with_other_degradations'
    parent_type = ''
    action = ''

    def __init__(self, parent_obj):
        self.parent_obj = parent_obj
        self.node = None
        self.file_path = ''

    def _set_node(self, disk_identifier):
        disk_members = bash_runner.get_disk_members(disk_identifier)
        local_members = bash_runner.get_local_members()

        # find local disk node
        for node in disk_members:
            if node in local_members:
                self.node = node
                break

    def _set_file_path(self, disk_identifier):
        self.file_path = bash_runner.get_node_file_path(self.node, disk_identifier)

    def fail(self, disk_identifier):
        """
        Remove node file on a controller to get other degraded disks state
        :param disk_identifier: str
        """
        self._set_node(disk_identifier)
        self._set_file_path(disk_identifier)
        bash_runner.remove_node_file(self.file_path)

    def repair_node_file(self):
        """
        Creates a node file which was previously deleted
        """
        bash_runner.create_node_file(self.file_path)


class StaleCacheVolumesCheck(BaseHealthCheck):
    """
    Represents stale cache volumes check on the diagnostic page.

    Attributes:
        parent_obj: compute_zone
    """
    root_tag = 'stale_cache_volumes'
    parent_type = ''
    action = ''

    def __init__(self, parent_obj):
        self.parent_obj = parent_obj

    def clean_cache_volume(self, disk_identifier):
        """
        Clean stale cache volume from hv

        :param disk_identifier: str
        :return: boolean
        """
        data = {
            'disk_id': disk_identifier,
            'node_id': bash_runner.get_frontend_uuid(),
            'endpoint_id': self.parent_obj.id,
        }
        url = "/{}/health_checks/{}/repair_all.json".format(
            self.route(), self.root_tag
        )
        return test.post_object(self, url=url, data=data)

    def clean_cache_volumes(self):
        """
        Clean all stale cache volumes from hv

        :return: boolean
        """
        super().repair_all()


class InactiveCacheCheck(BaseHealthCheck):
    """
    Represents inactive cache check on the diagnostic page.

    Attributes:
        parent_obj: compute_zone
    """
    root_tag = 'disks_with_inactive_cache'
    parent_type = ''
    action = ''

    def __init__(self, parent_obj):
        self.parent_obj = parent_obj
