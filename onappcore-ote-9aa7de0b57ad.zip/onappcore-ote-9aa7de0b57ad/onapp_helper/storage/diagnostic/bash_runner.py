"""
This module is implemented as a storage for bash commands,
 which are executed on an endpoint target node to get certain state of a disk or drive
"""
import re
from onapp_helper import test

HV = test.env.hv if hasattr(test.env, 'hv') else None
CP = test.cp


def run(command=None, pattern=None, endpoint=None, tunnel_host=None, timeout=60):
    """
     Output handler which returns certain data based on a command and pattern if passed in

    :param command: bash command, str
    :param pattern: regexp object, optional
    :param endpoint: a target node where a command gets executed e.g. test.env.HV
    :param tunnel_host: an ip address of tunnel host , str
    :param timeout: a timeout value before the command raise a TimeOut exception, int
    :return: formatted output as a list if there are more than one occurrence else string
    """
    # refactor when find a way to ssh into a VS via 22 or other port from outside of the OnApp internal network.
    if endpoint == test.cp:
        output = endpoint.execute(command=command, tunnel_host=tunnel_host, timeout=timeout)
    else:
        output = endpoint.execute(command=command)

    if not pattern:
        return output

    matches = pattern.finditer(output)

    # return all matched groups, good when finding items by different patterns
    result = [match.group(index+1)
              for match in matches
              for index, _ in enumerate(match.groups())]

    if not result:
        raise IndexError(
            'Potential IndexError, value is empty list, result: {}'.format(result)
        )

    # return a string when one occurrence has been found else list
    if len(result) == 1:
        return result[0]
    return result


def get_frontend_uuid():
    """
    Get frontend uuid

    :return: frontend_uuid, str
    """
    cmd = "onappstore getid"
    search_pattern = re.compile(r'uuid=([0-9]*)')  # find frontend uuid
    return run(command=cmd, pattern=search_pattern, endpoint=HV)


#  degraded disks
def get_bdev_connections(disk_identifier):
    """
    Get bdev connections of a disk

    :param disk_identifier: str
    :return: 4 bdev connections(PIDs), list
    """
    cmd = "ps ax | grep '[b]dev.*{}'".format(disk_identifier)
    search_pattern = re.compile(r'([0-9]*) \?')  # find PIDs of block dev connections
    return run(command=cmd, pattern=search_pattern, endpoint=HV)


def kill_one_nbd(disk_identifier):
    """
    Kill one ndb connection to get disk degraded

    :param disk_identifier: str
    :return: full output, str
    """
    pid = get_bdev_connections(disk_identifier)[0]
    cmd = 'kill -9 {}'.format(pid)
    return run(command=cmd, endpoint=HV)


#  partial member list
def get_member(disk_identifier):
    """
    Get a disk member to forget

    :param disk_identifier: str
    :return: member id, str
    """
    cmd = "onappstore diskinfo uuid={}".format(disk_identifier)
    search_pattern = re.compile(r'members=([0-9]*)')  # find one disk member
    return run(command=cmd, pattern=search_pattern, endpoint=HV)


def forget_member(disk_identifier):
    """
    Forget a disk member to get disk with partial member list

    :param disk_identifier: str
    :return: full output, str
    """
    member_id = get_member(disk_identifier)
    cmd = "onappstore forget forgetlist={} vdisk_uuid={}".format(member_id, disk_identifier)
    return run(command=cmd, endpoint=HV)


# disks with no redundancy, other degraded states
def get_local_members():
    """
    Get all local members(nodes) of a HV

    :return: local nodes, list
    """
    cmd = "diskhotplug list"
    search_pattern = re.compile(r'NodeID:([0-9]*)')
    return run(command=cmd, pattern=search_pattern, endpoint=HV)


def get_disk_members(disk_identifier):
    """
    Get all disk members(nodes)

    :param disk_identifier: str
    :return: disk members, list
    """
    cmd = "onappstore diskinfo uuid={}".format(disk_identifier)
    search_pattern = re.compile(r'members=([0-9]*),([0-9]*),([0-9]*),([0-9]*)')  # find all members
    return run(command=cmd, pattern=search_pattern, endpoint=HV)


# partially online disks, other degraded states
def get_controller_ip():
    """
     Get controller ip address

    :return: controller ip address, str
    """
    cmd = "onappstore getid"
    search_pattern = re.compile(r'backends=([0-9.]*)')  # find storage controller ip address
    return run(command=cmd, pattern=search_pattern, endpoint=HV)


def get_local_bdev_connections(disk_identifier):
    """
    Get bdev connections of a disk

    :param disk_identifier, str
    :return: bdev connections (PIDs), list
    """
    cmd = "ps ax | grep {0} | grep {1}'".format(get_controller_ip(), disk_identifier)
    search_pattern = re.compile(r'([0-9]*) \?')  # find PIDs of local block dev connections
    return run(command=cmd, pattern=search_pattern, endpoint=HV)


def kill_two_nbds(disk_identifier):
    """
    Kill two nbd connections

    :param disk_identifier: str
    :return: full output, str
    """
    pids = get_local_bdev_connections(disk_identifier)
    cmd = 'kill -9 {} {}'.format(pids[0], pids[1])
    return cmd


# zombie disks and zombie snapshots
def create_disk_via_cli(ds_identifier):
    """
    Create zombie disk via the storage CLI

    :param ds_identifier: str
    :return: disk_identifier, str
    """
    cmd = "onappstore create name=autotest_disk size=1024 Datastore={}".format(ds_identifier)
    search_pattern = re.compile(r'uuid=([a-z0-9]*)')  # find disk identifier
    return run(command=cmd, pattern=search_pattern, endpoint=HV)


def create_snapshot_via_cli(ds_identifier):
    """
    Create zombie snapshot via the storage CLI

    :param ds_identifier: str
    :return: snapshot_identifier, str
    """
    disk_identifier = create_disk_via_cli(ds_identifier)
    cmd = "onappstore snapshot uuid={}".format(disk_identifier)
    search_pattern = re.compile(r'uuid=([a-z0-9]*)')  # find snapshot identifier
    return run(command=cmd, pattern=search_pattern, endpoint=HV)


def online_vdisk(disk_identifier):
    """
    Online disk via onappstore tool

    :param disk_identifier: str
    :return: full output, str
    """
    frontend_uuid = get_frontend_uuid()
    cmd = "onappstore online uuid={} frontend_uuid={}".format(disk_identifier, frontend_uuid)
    return run(command=cmd, endpoint=HV)


# disks in other degraded states
def get_node_file_path(node_id, disk_identifier):
    """
    Get node file path on a controller

    :param disk_identifier: str
    :param node_id: str
    :return: node file path, str
    """
    cmd = "ssh -T -o StrictHostKeyChecking=no -q {} 'ls /DB/NODE-{}/{}*'".format(
        get_controller_ip(), node_id, disk_identifier)
    search_pattern = re.compile(r'(/DB/NODE-[0-9a-z/,-]*)')  # find node file path
    return run(command=cmd, pattern=search_pattern, endpoint=HV)


def remove_node_file(file_path):
    """
    Remove node file on a controller

    :param file_path: str
    :return: full output, str
    """
    cmd = "ssh -T -o StrictHostKeyChecking=no -q {} 'rm -rf {}'".format(
        get_controller_ip(), file_path)
    return run(command=cmd, endpoint=HV)


def create_node_file(file_path):
    """
    Create node file which was removed previously with the remove node file method

    :param file_path: str
    :return: full output, str
    """
    cmd = "ssh -T -o StrictHostKeyChecking=no -q {} 'touch {}'".format(
        get_controller_ip(), file_path)
    return run(command=cmd, endpoint=HV)


# partial nodes
def stop_isd_daemon():
    """
    Kill all python processes and stop ISD deamon on a controller so all local nodes become partial

    :return: full output, str
    """
    cmd = "ssh -T -o StrictHostKeyChecking=no -q {} '/etc/init.d/isd stop'".format(
        get_controller_ip()
    )
    return run(command=cmd, endpoint=HV)


def kill_all_python_processes():
    """
    Kill all python processes on a controller

    :return: full output, str
    """
    cmd = "ssh -T -o StrictHostKeyChecking=no -q {} 'killall python'".format(
        get_controller_ip())
    return run(command=cmd, endpoint=HV)


# inactive nodes
def stop_san_controller():
    """
    stop stop san controller so all local nodes become inactive

    :return: full output, str
    """
    cmd = "/etc/init.d/SANController stop"
    return run(command=cmd, endpoint=HV)


def start_san_controller():
    """
    start san controller so all local nodes become healthy

    :return: full output, str
    """
    cmd = "/etc/init.d/SANController start"
    return run(command=cmd, endpoint=HV)


# nodes with high utilization
def dwrapper(vs, mount_point):
    """
    Write random data to fill in a Vs disk entirely

    :param vs: a VirtualServer object
    :param mount_point: path where the dd command gets executed, str
    :return: full output, str
    """
    cmd = 'dd if=/dev/urandom of={}/target bs=10M && dd if=/dev/urandom of=/tmp/tmp bs=10M'.format(
        mount_point)
    return run(command=cmd, endpoint=CP, tunnel_host=vs.ip_address)


# missing drives
def unassign_drive():
    """
    unassigning drive from a controller slot

    :return: full output str
    """
    cmd = "diskhotplug unassign 0 0"
    return run(command=cmd, endpoint=HV)


def assign_drive(drive_name):
    """
    Assigning drive to a controller slot

    :param drive_name: str
    :return: full output, str
    """
    cmd = "diskhotplug assign 0 0 /dev/{}".format(drive_name)
    return run(command=cmd, endpoint=HV)


# inactive controllers
def _get_controller_id():
    """
    capture controller ID to online a custom created disk

    :return: ID, int
    """
    cmd = "virsh list"
    search_pattern = re.compile("(\d+).*STORAGENODE.*")
    return run(command=cmd, pattern=search_pattern, endpoint=HV)


def stop_controller():
    """
    Stops controller via virsh tool

    :return: full output, str
    """
    c_id = _get_controller_id()
    cmd = "virsh shutdown {}".format(c_id)
    return run(command=cmd, endpoint=HV)


# unreferenced NBDs
def remove_device_mapper(disk_identifier):
    """
    Removes device mapper of the passed disk

    :param disk_identifier: str
    :return: full output, str
    """
    cmd = "dmsetup remove {}".format(disk_identifier)
    return run(command=cmd, endpoint=HV)


# dangling device mappers
def kill_three_nbds(disk_identifier):
    """
    Kills thre ndb connections to get dangling device mapper faiulure

    :param disk_identifier: str
    :return: full output, str
    """
    pids = get_bdev_connections(disk_identifier)
    cmd = 'kill -9 {} {} {}'.format(pids[0], pids[1], pids[2])
    return run(command=cmd, endpoint=HV)
