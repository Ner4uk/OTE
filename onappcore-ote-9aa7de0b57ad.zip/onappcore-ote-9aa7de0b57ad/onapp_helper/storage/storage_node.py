from onapp_helper.base_helper import BaseHelper
from onapp_helper import test


class StorageNode(BaseHelper):
    """
    Represents Integrated Storage Node.

    Attributes:
        parent_obj: compute_zone ID
    """
    root_tag = 'node'

    def __init__(self, parent_obj=None, id=None):
        """
        :param id: self ID
        :param parent_obj: hvz ID
        """
        self.id = id
        self.parent_obj = parent_obj
        self.performance = 'low'

        if self.id:
            test.update_object(self)

    def get_by_id(self, id):
        """
        Find node
        :param id: node ID
        :return:
        """
        test.log.info("Get node by id...")
        url = '/{0}/{1}.json'.format(self.route(), id)
        if test.get_object(self, url=url):
            self.__dict__.update(self.response[self.root_tag])
            return True
        return False

    def set_performance(self, performance):
        """
        Set IO performance for a node choosing among ['low', 'normal', 'high']
        :param performance:
        :return: node object.
        """
        data = {
            "storage_node": {"performance": performance}
        }
        return test.put_object(self, data=data)

    def set_performance_all(self, performance='low'):
        """
        Set IO performance for all nodes available
        :param performance: a string choosing among ['low', 'normal', 'high']
        :return: values of each node, list of values.
        """
        for node in self.get_all():
            node.set_performance(performance=performance)
        return [node.performance for node in self.get_all()]

    def route(self):
        """
        Define parent route which is used to form full URl path for API calls

        :return: string of parent route, storage + compute zone ID + controller name
        """
        return "storage/{}/nodes".format(self.parent_obj.id)
