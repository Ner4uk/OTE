from onapp_helper.base_helper import BaseHelper
from onapp_helper import test
from onapp_helper.storage.storage_node import StorageNode


class StorageDataStore(BaseHelper):
    """
    Represents Integrated Storage data store.

    Attributes:
        parent_obj: compute_zone ID
    """
    root_tag = 'data_store'

    def __init__(self, parent_obj=None, id=None, replicas="2", stripes="2"):
        """
        by default 2r2s data store type is created.

        :param id: self ID
        :param parent_obj: hvz
        """
        self.id = id
        self.parent_obj = parent_obj
        self.name = 'auto generated data store'
        self.replicas = replicas
        self.stripes = stripes
        self.overcommit = "0"
        self.total_size = ""
        self.free_size = ""
        self.maximum_disk_size = ""
        self.performance = ""
        self.disk_count = ""
        self.nodes = []
        if self.id:
            test.update_object(self)

    def _get_node_ids(self):
        node = StorageNode(parent_obj=self.parent_obj)
        return node.get_key_values('id')

    def create(self):
        """Create IS data store"""
        test.log.info("Create IS data store...")
        data = {
            "storage_data_store": {
                "name": "OTE M{}-{}R-{}S".format(len(self._get_node_ids()), self.replicas, self.stripes),
                "replicas": self.replicas,
                "stripes": self.stripes,
                "overcommit": self.overcommit,
                "node_ids": self._get_node_ids(),
            },
            "endpoint_id": self.parent_obj.id
        }
        return test.post_object(self, data=data)

    def get_available(self):
        """Find available IS data store"""
        test.log.info("Find an IS data store...")

        try:
            return self.get_first()
        except IndexError:
            test.log.info("There is no available data store")
            return False

    def edit(self):
        """Edit IS data store"""
        data = {
            "storage_data_store": {
                "name": "OTE M{}-{}R-{}S".format(len(self.nodes), self.replicas, self.stripes),
                "replicas": self.replicas,
                "stripes": self.stripes,
                "overcommit": self.overcommit,
                "node_ids": self._get_node_ids(),
            },
            "endpoint_id": self.parent_obj.id
        }
        return test.put_object(self, data=data)

    def route(self):
        """
        Define parent route which is used to form full URl path for API calls

        :return: string of parent route, storage + compute zone ID + controller name
        """
        return "storage/{}/data_stores".format(self.parent_obj.id)
