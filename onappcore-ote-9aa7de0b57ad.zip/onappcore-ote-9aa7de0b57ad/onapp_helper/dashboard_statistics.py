# Since 5.0 https://onappdev.atlassian.net/browse/CORE-6699
import time
from onapp_helper.base_helper import BaseHelper
from onapp_helper import test


class DashboardStatistics(BaseHelper):
    def __init__(self):
        self.route = 'billing/dashboard_statistics'
        self.cpus = []
        self.memory = []
        self.disk_size = []
        self.iops = []
        self.bandwidth = []
        self.smart_servers = []
        self.baremetal_servers = []
        self.virtual_servers = []

    def get(self, stats_for=None, startdate='', enddate=''):
        """
        Get Dashboard statistics.

        :param stats_for: an array of resources for getting statistics
            [] - get stat for all resources;
            ["cpus", "barametal_servers"] - get stat for cpus and
                baremetal servers

            The names of resources for getting statistics:
            - cpus,
            - memory,
            - disk_size,
            - virtual_servers,
            - smart_servers,
            - baremetal_servers.
        :param startdate: looks like "2015-01-01"
        :param enddate: looks like "2015-01-01"

        :return: True if success else False
        """
        test.log.info('Get dashboard statistics')
        data = {}
        if stats_for:
            data['stats_for'] = stats_for
        if startdate or enddate:
            data['period'] = {}
        if startdate:
            data['period']["startdate"] = startdate
        if enddate:
            data['period']["enddate"] = enddate
        if test.get_object(self, data=data):
            return True
        return False
