import ipaddress

from onapp_helper import test
from engine.lib.ssh import SSH
from onapp_helper.backup import Backup
from onapp_helper.base_helper import BaseHelper, Transaction
from onapp_helper.ip_address_join import IpAddressJoin
from onapp_helper.network_interface import NetworkInterface
from onapp_helper.schedule import Schedule
from onapp_helper.service_addon.service_addon import ServiceAddon
from onapp_helper.stats.usage import Usage
from onapp_helper.template import Template
from onapp_helper.template_store import TemplateStore
from onapp_helper.virtual_machine_helper import VirtualMachineHelper


class FullMigrateDestination:
    def __init__(self):
        """
        Object is using for full server migrate.
        """
        self.hypervisor_group_id = None
        self.hypervisor_id = None
        self.disks_destinations = {}

    def pack(self):
        return {
            "hypervisor_group_id": self.hypervisor_group_id,
            "hypervisor_id": self.hypervisor_id,
            "disks_destinations": self.disks_destinations
        }


class NetworkShutdownType:
    hard = 'hard'
    graceful = 'graceful'
    soft = 'soft'


class VirtualMachine(VirtualMachineHelper, BaseHelper):
    NETWORK_SHUTDOWN_TYPE = NetworkShutdownType()
    route = 'virtual_machines'
    root_tag = route[:-1]
    server_type = route[:-1]  # virtual_machine as default.
    error = {}

    def __init__(self):
        """
            self.id should be defined in child class before parent
            initialization.

            Example:

                class ApplicationServer(VirtualMachine):
                    def __init__(self, server_id=None):
                        self.id = server_id
                        super(ApplicationServer, self).__init__()
        """
        #  Object attributes
        self.template = Template()
        self.template_id = None
        self.ssh = SSH()
        self.working_path = '/root'
        self.template_store = TemplateStore()
        self.build_transaction_actions = dict()
        self.full_migrate_destination = FullMigrateDestination()

        #  Server attributes
        self.user_id = None
        self.built = False
        self.booted = False
        self.suspended = False
        self.label = 'OTETEST'
        self.strict_virtual_machine_id = None
        if not self.id and test.env:
            self.data_store_group_primary_id = test.env.dsz.id
            self.data_store_group_swap_id = test.env.dsz.id
            self.hypervisor_group_id = test.env.hvz.id
            self.hypervisor_id = test.env.hv.id
            self.primary_network_group_id = test.env.netz.id
        self.swap_disk_size = 1
        self.required_virtual_machine_build = 1
        self.required_virtual_machine_startup = 1
        # self.selected_ip_address_id = None
        # self.selected_ip_address = ""
        if test.cp_version >= 5.4:
            self.selected_ip_address = None  # String of IP address. For example: "192.168.0.1"
        else:
            self.selected_ip_address_id = None
        self.required_ip_address_assignment = 1
        self.hostname = 'otetest'
        self.domain = "localdomain"
        self.identifier = ''
        self.rate_limit = 1
        self.cpus = 1
        self.cpu_shares = 1
        self.memory = 0
        self.initial_root_password = ''
        self.instance_package_id = None
        self.initial_root_password_encrypted = False
        self.primary_disk_size = 0
        self.primary_disk_min_iops = 100
        self.swap_disk_min_iops = 100
        self.enable_autoscale = False
        self.ip_address_join = IpAddressJoin(parent_obj=self)
        self.network_interface = NetworkInterface(parent_obj=self)
        self.ip_address = ''
        self.note = ''
        self.admin_note = ''
        self.cdboot = False
        # self.selected_ip_address = ''
        self.schedule = Schedule(target=self)
        self.initial_root_password_encryption_key = ''
        self.recipe_joins_attributes = []
        self.custom_recipe_variables = []

        self.iso_id = None
        self.recovery_mode = False
        self.transaction = Transaction()

        self.cpu_topology = False
        # If None - CPU Topology is disabled (?) more question to devs
        self.cpu_sockets = None
        self.cpu_threads = None

        # https://onappdev.atlassian.net/browse/CORE-14160
        self.virsh_console = None  # since 6.1

    def _create(self, data, approve=False):
        # Create
        test.log.info("Start to create a server...")
        if test.post_object(self, data=data):
            # To avoid paramiko.ssh_exception.BadHostKeyException issue
            self.ssh = SSH()
            self._set_ssh_params()

            if not approve:
                if self.transactions_handler(
                    self._get_server_cbr_transactions_chain('create')
                ) and self._service_addon_executing():
                    return True
            else:
                self.transaction_handler(
                    "schedule_build_virtual_machine",
                    parent_id=self.id,
                    pages=2,
                    timeout=5
                )
                return True
        return False

    def wait_for_transactions_chain(self, transaction_chain):
        """
        Waiting for transations chain executing
        :param transaction_chain: a list of (action, parent_id) parameters
        :return: True if success else False
        """
        for action, parent_id in transaction_chain:
            if not self.transaction_handler(action, parent_id=parent_id):
                return False
        return True

    def _service_addon_executing(self):
        # In case we have service addons during Virtual Server
        # Provisioning
        if hasattr(self, 'service_addon_ids') and self.service_addon_ids:
            from onapp_helper.service_addon.service_addon import \
                ServiceAddon
            for service_addon_id in self.service_addon_ids:
                service_addon = ServiceAddon(id=service_addon_id)
                if not service_addon.handling_on_add_transactions(self):
                    return False
        return True

    def _get_server_cbr_transactions_chain(self, server_action):
        """
        Build an array of a tuple like (action, parent_id)
        Note: Is using for create/build/rebuild server actions
        :param server_action: create/build/rebuild
        :return: an array of the tuples like (action, parent_id)
        """
        transactions_chain = []
        disks = []
        action = ''

        CREATE = ['create']
        BUILD_REBUILD = ['build', 'rebuild']

        # Add build or format disk transactions
        if self.route not in ['baremetal_servers', 'openstack_servers']:
            disks = self.disks()
            for disk in disks:
                if disk.primary or disk.is_swap:
                    if server_action in BUILD_REBUILD:
                        action = "format_disk"
                    elif server_action in CREATE:
                        action = "build_disk"
                    else:
                        test.log.error(
                            'Undefined server_action - {}'.format(
                                server_action
                            )
                        )

                    transactions_chain.append((action, disk.id))

        # Add build transactions
        if self.required_virtual_machine_build or server_action in BUILD_REBUILD:
            for action in self.build_transaction_actions:
                parent_id = self.id
                if disks and action == 'provisioning':
                    if not self.template.operating_system == "freebsd":
                        parent_id = [
                            disk.id for disk in disks if disk.primary
                            ][0]
                    else:
                        parent_id = [
                            disk.id for disk in disks if disk.is_swap
                            ][0]

                transactions_chain.append((action, parent_id))

        # Add startup server transaction
        if self.required_virtual_machine_startup and \
                        self.route not in ['baremetal_servers']:
            transactions_chain.append(('startup_virtual_machine', None))
        return transactions_chain

    def _initialise_additional_server_attributes(self):
        """
        Set additional server attributes
        :return:
        """
        test.update_object(self)
        self.ip_address = self.primary_ip_address()
        self._set_ssh_params()
        if self.required_virtual_machine_build and \
                self.required_virtual_machine_startup and \
                test.use_public_network and \
                ipaddress.IPv4Network(
                    u"{0}".format(self.ip_address)).is_global and not \
                self.built_from_iso:
            return self.ping(timeout=30)
        return True

    def edit(self, **kwargs):
        """Edit the server.
        :param kwargs:
            You can edit the following parameters:
            - label;
            - allow_migration - set True to migrate a VS to a compute resource
                with sufficient resources if a compute resource has
                insufficient space to resize. Otherwise, set False.
            - allow_cold_resize set True to switch to cold resize when hot
                resize failed
            - time_zone the time zone set for the VS. This parameter is
                applicable only to Windows virtual servers.
            - cpu_sockets - the number of CPU sockets
            - cpu_topology - set True to tie two or more vCPUs into a single
                socket. Otherwise, set False.

            For virtual servers built by selecting resources manually:
            memory -  the amount of RAM allocated to this VS in Mb
            cpus - the number of CPUs of this VS
            cpu_shares* - CPU priority percentage
            cpu_units - the amount of CPU units per core if the CPU priority is
                replaced with CPU units in user bucket.

            For virtual servers built using instance packages:
            instance_package_id - ID of the new instance package

        Old behaviour:
        To set specific parameters for editing you need to set appropriate
        attributes before creation.

        """
        test.log.info("Edit the server...")
        if kwargs:
            data = {
                self.root_tag: kwargs
            }
        elif self.instance_package_id:
            data = {
                self.root_tag: {
                    "label": self.label,
                    "instance_package_id": self.instance_package_id
                }
            }
        else:
            data = {
                self.root_tag: {
                    "label": self.label,
                    "memory": self.memory,
                    "cpus": self.cpus,
                    "cpu_shares": self.cpu_shares
                }
            }
        self.get()
        test.log.info("Start to edit server...")
        if test.put_object(self, data=data):
            # It is hard to know which action is going to be executed so
            # we have to check both of them... That is why a new parameter pages
            # has been implemented for _wait_for_transaction method.
            action_resize_virtual_machine = 'resize_{0}'.format(self.server_type)
            action_resize_vm_without_reboot = 'resize_vm_without_reboot'

            # Skip transaction if just label has been changed
            if self.instance_package_id:
                if self.transaction_handler(
                        action_resize_virtual_machine, pages=2
                ) or self.transaction_handler(
                    action_resize_vm_without_reboot, pages=2
                ):
                    return test.update_object(self)
            elif not kwargs and (
                    self.label != data[self.root_tag]["label"] or
                    self.label == data[self.root_tag]["label"]
            ) and self.memory == data[self.root_tag]["memory"]\
                    and self.cpus == data[self.root_tag]["cpus"] \
                    and self.cpu_shares == data[self.root_tag]["cpu_shares"]:
                return True
            elif kwargs and len(
                    [
                        key for key, value in kwargs.items()
                        if self.__dict__[key] == value or key == 'label'
                    ]
            ) == len(kwargs.keys()):
                return True
            else:
                if self.transaction_handler(
                        action_resize_virtual_machine, pages=2
                ) or self.transaction_handler(
                    action_resize_vm_without_reboot, pages=2
                ):
                    return test.update_object(self)
        return False

    def delete(self, destroy_all_backups=True):
        """
        Destroy the server.


        :param destroy_all_backups: set True to destroy all server backups
        :return: True is success else False
        """
        data = {
            'destroy_all_backups': destroy_all_backups
        }
        test.log.info("Start to destroy server...")

        if test.delete_object(self, data=data):
            # Handling Service addons evenets before destroy
            servers_service_addons = ServiceAddon().get_service_addons_assigned_to_server(self)
            if servers_service_addons:
                for service_addon in servers_service_addons:
                    if not service_addon.handling_on_vm_destroy_transactions(
                        self
                    ):
                        return False

            if self.transaction_handler(
                    'destroy_{0}'.format(self.server_type)
            ):
                return True
        return False

    # Power Actions
    def start(self):
        """Start up the server. Return True if success."""
        test.log.info("Start up the server...")
        url = '/{0}/{1}/startup.json'.format(self.route, self.id)
        if test.post_object(self, url=url):
            if self.transaction_handler('startup_{0}'.format(self.server_type)):
                test.update_object(self)
                return True
        return False

    def shutdown(self):
        """Shut down the server. Return True if success."""
        test.log.info("Shutdown the server...")
        url = '/{0}/{1}/shutdown.json'.format(self.route, self.id)
        if test.post_object(self, url=url):
            if self.transaction_handler('stop_{0}'.format(self.server_type)):
                test.update_object(self)
                return True
        return False

    def stop(self):
        """Stop the server. Return True if success."""
        test.log.info("Stop the server...")
        url = '/{0}/{1}/stop.json'.format(self.route, self.id)
        if test.post_object(self, url=url):
            if self.transaction_handler('stop_{0}'.format(self.server_type)):
                test.update_object(self)
                return True
        return False

    def reboot(self, mode=None, iso_id=None):
        """
        Reboot the server. .
        :param mode: None for regular reboot, "recovery" - to reboot the
        server in recovery mode.
        :param iso_id: provide the iso id to reboot the server from iso
        :return: Return True if success
        """
        log_msg = "Reboot the server"
        data = None
        if mode == 'recovery':
            data = {"mode": mode}
            log_msg += ' in to {} mode'.format(mode)
        elif iso_id:
            data = {"iso_id": iso_id}
            log_msg += ' from iso {}'.format(iso_id)

        test.log.info(log_msg)
        url = '/{0}/{1}/reboot.json'.format(self.route, self.id)
        if test.post_object(self, url=url, data=data):
            action = 'reboot' if self.booted else 'startup'
            if self.transaction_handler(f'{action}_{self.server_type}'):
                test.update_object(self)
                return True
        return False

    def reboot_from_inside(self):
        test.log.info(f'Reboot server (self.id) from inside')
        if self.execute('reboot &'):
            if test.cp_version >= 6.0 and not self.transaction_handler("update_qos_limit"):
                return False
            test.update_object(self)
            return True
        return False

    def rebuild(self, encrypt_phrase=None):
        """Rebuild the server. Return True if success."""
        test.log.info("Rebuild the server with id - {0}".format(self.id))
        if self.build(encrypt_phrase=encrypt_phrase):
            servers_service_addons = ServiceAddon().get_service_addons_assigned_to_server(self)
            if servers_service_addons:
                for service_addon in servers_service_addons:
                    if not service_addon.handling_on_vm_rebuild_transactions(
                        self
                    ):
                        return False
                return True
            return True
        return False

    def build(self, encrypt_phrase=None):
        """Build the server. Return True if success."""
        test.log.info("Build the server with id - {0}".format(self.id))
        # print("Build the server with id - {0}".format(self.id))
        self.template_id = self.template.id
        data = {
            self.root_tag: {
                "template_id": self.template_id,
                "required_startup": self.required_virtual_machine_startup,
                "initial_root_password_encryption_key": encrypt_phrase,
                "initial_root_password_encryption_key_confirmation": encrypt_phrase
            }
        }
        url = '/{0}/{1}/build.json'.format(self.route, self.id)
        if test.post_object(self, url=url, data=data):
            # Handling related transactions...
            if self.built:
                self.transaction_handler('stop_virtual_machine')

            if not self.transactions_handler(
                self._get_server_cbr_transactions_chain('build')
            ) and self._initialise_additional_server_attributes():
                return False

            test.update_object(self)
            # Update SSH settings
            if encrypt_phrase:
                self.decrypt_password(
                    initial_root_password_encryption_key=encrypt_phrase)
            # To avoid paramiko.ssh_exception.BadHostKeyException issue
            self.ssh = SSH()
            self._set_ssh_params()
            return True
        return False

    def suspend(self):
        """Suspend the server. Return True if success."""
        test.log.info("Suspend the server with id - {0}".format(self.id))
        # print("Suspend the server with id - {0}".format(self.id))
        url = '/{0}/{1}/suspend.json'.format(self.route, self.id)
        if test.post_object(self, url=url):
            if self.booted:
                if self.transaction_handler('stop_{0}'.format(self.server_type)):
                    test.update_object(self)
                    return True
                return False
            return True
        return False

    def unsuspend(self):
        """Unsuspend the server. Return True if success."""
        test.log.info("Unsuspend the server with id - {0}".format(self.id))
        # print("Unsuspend the server with id - {0}".format(self.id))
        url = '/{0}/{1}/suspend.json'.format(self.route, self.id)
        if test.post_object(self, url=url):
            test.update_object(self)
            return True
        return False

    def add_admin_note(self):
        test.log.info(f'Adding admin note to virtual machine-{self.id}...')
        data = {
            self.root_tag: {
                'admin_note': self.admin_note
            }
        }
        url = f'/{self.route}/{self.id}.json'
        return test.put_object(self, data=data, url=url)

    def edit_admin_note(self):
        test.log.info(f'Editing admin note on virtual machine-{self.id}...')
        data = {
            self.root_tag: {
                'admin_note': self.admin_note
            }
        }
        url = f'/{self.route}/{self.id}/admin_note.json'
        return test.put_object(self, data=data, url=url)

    def add_user_note(self):
        test.log.info(f'Adding user note to virtual machine-{self.id}...')
        data = {
            self.root_tag: {
                'note': self.note
            }
        }
        url = f'/{self.route}/{self.id}.json'
        return test.put_object(self, data=data, url=url)

    def edit_user_note(self):
        test.log.info(f'Editing user note on virtual machine-{self.id}...')
        data = {
            self.root_tag: {
                'note': self.note
            }
        }
        url = f'/{self.route}/{self.id}/note.json'
        return test.put_object(self, data=data, url=url)

    def disable_cd_boot(self):
        test.log.info(f'Disabling Boot from CD on virtual machine-{self.id}...')
        url = f'/{self.route}/{self.id}/cd_boot/disable.json'
        return test.post_object(self, url=url)

    def enable_cd_boot(self):
        test.log.info(f'Enabling Boot from CD on virtual machine-{self.id}...')
        url = f'/{self.route}/{self.id}/cd_boot/enable.json'
        return test.post_object(self, url=url)

    def enable_auto_backups(self):
        """ Return an array of backup objects"""
        test.log.info("Enable server auto backups...")
        backups = []
        if test.post_object(
                self, url='/{0}/{1}/autobackup_enable.json'.format(
                self.route, self.id
                )
        ):
            if len(self.schedule.get_all()) == 4:
                # wait for transactions
                if self.wait_for_action(
                    lambda: len(
                        [
                            b for b in self.get_incremental_backups()
                            if b.initiated != 'manual'
                        ]
                    ) == 4,
                    timeout=300,
                    step=5
                ):
                    backups = [
                        b for b in self.get_incremental_backups()
                        if b.initiated != 'manual'
                    ]

                    for b in backups:
                        b.transaction_handler('take_incremental_backup', b.id)
                        test.update_object(b)
        return backups

    def disable_auto_backup(self):
        """
        Disable auto backups
        :return: boolean
        """
        test.log.info("Disable servers auto backups...")
        url = '/{0}/{1}/autobackup_disable.json'.format(self.route, self.id)
        return test.post_object(self, url=url)

    def get_image_backups(self):
        """Get all image backups assigned to server."""
        test.log.info("Get Image Backups...")
        return Backup(parent_obj=self)._get_objects(
            route='{0}/{1}/backups/images'.format(self.route, self.id)
        )

    def get_incremental_backups(self):
        """Get all incremental backups assigned to server."""
        test.log.info("Get Incremental Backups...")
        return Backup(parent_obj=self)._get_objects(
            route='{0}/{1}/backups/files'.format(self.route, self.id)
        )

    def get_backups(self):
        """Get all backups assigned to server."""
        test.log.info("Get Backups...")
        return Backup(parent_obj=self)._get_objects(
            route='{0}/{1}/backups'.format(self.route, self.id)
        )

    def rebuild_network(
            self,
            force=False,
            is_shutdown_required=False,
            shutdown_type=NETWORK_SHUTDOWN_TYPE.graceful,
            required_startup=True
    ):
        """
        Rebuild server network.
        :param force:
        :param is_shutdown_required:
        :param shutdown_type:
        :param required_startup:
        :return: True if success else False
        """
        test.log.info("Rebuild network...")
        data = {
            "force": force,
            "is_shutdown_required": is_shutdown_required,
            "shutdown_type": shutdown_type,
            "required_startup": required_startup
        }
        url = '/{0}/{1}/rebuild_network.json'.format(self.route, self.id)
        if test.post_object(
            self,
            url=url,
            data=data
        ):
            return self.transaction_handler('rebuild_network')
        return False

    # def get_schedules(self):
    #     test.log.info("Get schedules...")
    #     self._get_handler('/{0}/{1}/schedules.json'.format(self.route, self.id))
    #     return self.response

    def autoscale_enable(self):
        test.log.info("Enable Autoscale...")
        test.log.warning(
            'Enable autoscaling transaction is not waiting for open ssh port'
        )
        self.ping()
        test.port_is_open(host=self.ip_address)
        if test.post_object(
            self,
            url='/{0}/{1}/autoscale_enable.json'.format(self.route, self.id)
        ):
            if self.transaction_handler("check_or_install_zabbix_agent"):
                if self.transaction_handler("enable_auto_scaling"):
                    return True
        return False

    def autoscale_disable(self):
        test.log.info("Disable Autoscale...")
        if test.post_object(
                self,
                url='/{0}/{1}/autoscale_disable.json'.format(
                    self.route, self.id
                )
        ):
            if self.transaction_handler("disable_auto_scaling"):
                return True
        return False

    def get_status(self):
        """
        Update self.__dict__
        """
        test.log.info("Get Status...")
        if test.get_object(
                self,
                url='/{0}/{1}/status.json'.format(self.route, self.id)
        ):
            return True
        return False

    def get_statuses(self):
        """
        Return the array of objects
        """
        test.log.info("Get Status...")
        return self._get_objects(route='{0}/status'.format(self.route))

    def get(self):
        test.log.info("Get server details ({0})...".format(self.id))
        if test.update_object(self):
            self.__dict__.update(self.response[self.root_tag])
            return True
        return False

    def cpu_hourly_stat(self, start_date=None, end_date=None):
        """
        Get CPU hourly statistics
        :param start_date: "YYYY-MM-DD+hh:mm:ss"
        :param end_date: "YYYY-MM-DD+hh:mm:ss"
        :return: an array of cpu usage objects
        """
        test.log.info("Get cpu_hourly_stat...")
        params = []
        if start_date:
            params.append("period[startdate]={}".format(start_date))
        if end_date:
            params.append("period[enddate]={}".format(end_date))

        query_str = '&'.join(params)
        return Usage()._get_objects(
            route='{}/{}/cpu_usage'.format(self.route, self.id),
            root_tag='cpu_hourly_stat',
            query=query_str
        )

    def find_by_label(self, label=''):
        """
        Find servers by label
        :param label: string
        :return: list of servers obj
        """
        servers = []
        test.log.info("Find server by label - {}".format(label))
        if test.get_object(
                self,
                url='/{0}.json?q={1}'.format(self.route, label)
        ):
            for vm in self.response:
                servers.append(vm[self.root_tag])
        return servers

    def change_owner(
            self,
            user_id,
            custom_recipes_action=None,
            backups_action=None
    ):
        """
        Change Server Owner

        :param user_id: an ID of a new VS owner
        :param custom_recipes_action: select one of the following options for
            virtual server's recipes:

                * none - recipes owner will not be changed
                * move - recipes owner will be changed
                * copy - recipes will be copied to new virtual servers owner

        :param backups_action: select one of the following options for
            virtual server's backups:

                * none - backup owner will not be changed
                * move - backup owner will be changed

        :return: True if success else False
        """
        test.log.info("Change owner to {0}...".format(user_id))
        url = '/{0}/{1}/change_owner.json'.format(self.route, self.id)
        data = {
            "user_id": user_id,
            "custom_recipes_action": custom_recipes_action,
            "backups_action": backups_action
        }

        return test.post_object(self, url=url, data=data)

    def _wait_for_create(self):
        """
        Waiting for server creation.
        :return: True if success else False
        """
        #  TODO redefine for each class separately
        test.log.info(
            "Wait for creating {}...".format(self.__class__.__name__)
        )
        if self.route not in ['baremetal_servers', 'openstack_servers']:
            disks = self.disks()
            for disk in disks:
                if not self.transaction_handler("build_disk", parent_id=disk.id):
                    return False
        for action in self.build_transaction_actions:
            parent_id = self.id
            if action == 'provisioning':

                if not self.template.operating_system == "freebsd":
                    parent_id = [disk.id for disk in disks if disk.primary][0]
                else:
                    parent_id = [disk.id for disk in disks if disk.is_swap][0]
            if not self.transaction_handler(action, parent_id=parent_id):
                return False
        return True

    def reset_root_password(self,
                            initial_root_password=None,
                            initial_root_password_encryption_key=None,
                            initial_root_password_encryption_key_confirmation=None):
        """
        Reset root password for VS.
        And encrypt root password Return True if success.
        :param initial_root_password: the new root password for a VS.
        It can consist of 6-32 characters, letters [A-Za-z], digits [0-9],
        dash [ - ] and lower dash [ _ ].
        You can use both lowercase and uppercase letters.
        :param initial_root_password_encryption_key: specify the password
        encryption passphrase.
        :return: True if success else False
        """
        test.log.info("Reset root password...")
        data = {
            self.root_tag: {
                "initial_root_password": initial_root_password,
                "initial_root_password_encryption_key": initial_root_password_encryption_key,
                "initial_root_password_encryption_key_confirmation": (
                    initial_root_password_encryption_key if not initial_root_password_encryption_key_confirmation else initial_root_password_encryption_key_confirmation
                )
            }
        }
        if test.post_object(
                self,
                url='/{0}/{1}/reset_password.json'.format(self.route, self.id),
                data=data
        ):
            if self.transaction_handler("reset_root_password"):
                self.wait_for_action(
                        lambda: test.update_object(self) and not self.locked,
                        timeout=60,
                        step=5
                )
                decrypted_password = None
                # Update SSH password
                if initial_root_password_encryption_key:
                    self.decrypt_password(
                        initial_root_password_encryption_key=initial_root_password_encryption_key
                    )
                    decrypted_password = self.initial_root_password
                    # To return encrypted initial_root_password
                    self.get()

                self.ssh.password = self.initial_root_password \
                    if not decrypted_password \
                    else decrypted_password
                return True
        return False

    def set_ssh_key(self):
        if test.post_object(self, url=f'/{self.route}/{self.id}/set_ssh_keys.json'):
            if self.transaction_handler('set_ssh_keys'):
                return True
        return False

    def set_template(self):
        # Only for virtual machines
        if self.route not in ['application_servers', 'storage_servers']:
            if test.template_manager_id:
                assert self.template.get_by_manager_id(test.template_manager_id)
            elif self.template_id:
                self.template.__init__(id=self.template_id)
            elif not self.template.id:
                # assert self.template.get_for_server(
                #     test.test_config.server_template,
                #     obj_route=self.route
                # )
                assert self.template.get_for_server(
                    test.test_config.server_template,
                    obj_route=self.route,
                    operating_system=["linux", "freebsd"]
                )
            else:
                test.log.warning('Looks like template has already found...')

            if not self.template_id:
                self.template_id = self.template.id
        test.log.info("Template label is {}".format(self.template.label))

    def decrypt_password(self, initial_root_password_encryption_key=None):
        """Decrypt root password for VS. Return True if success."""
        test.log.info("Decrypt for root password...")
        data = {
            self.root_tag: {
                "initial_root_password_encryption_key": initial_root_password_encryption_key
            }
        }
        return test.get_object(
            self,
            url='/{0}/{1}/with_decrypted_password.json'.format(
                self.route, self.id
            ),
            data=data
        )

    def migrate(
            self,
            destination=None,
            cold_migrate_on_rollback=True,
            migration_type=None
    ):
        """
        Migrate VS

        :param destination: the ID of a target compute resource where you
            migrate a VS OR dictionary, for full migrate, like:

            |    {
            |        "hypervisor_group_id": hypervisor_group_id,
            |        "hypervisor_id": hypervisor_id,
            |        "disks_destinations": {
            |            "3": data_store_id
            |        }
            |    }

            use self.full_migrate_destination obj to pass all required values.
            Use pack method for self.full_migrate_destination to generate valid
            dictionary.
        :param cold_migrate_on_rollback: set True if you wish to switch to a
            cold migration if hot migration fails, otherwise set False.
        :param migration_type:
            - set to hot_full if you want to run the hot full migration.
            - set to full if you want to run the full (cold) migration.
            - skip this parameter if you want to run the cold migration. (?)

        :return: True if success else False
        """
        test.log.info(
            "Migrate the server to HV with id - {}...".format(destination)
        )

        # pack destination data if needed
        if isinstance(destination, FullMigrateDestination):
            destination = destination.pack()

        data = {
            self.root_tag: {
                "destination": destination,
                "cold_migrate_on_rollback": cold_migrate_on_rollback
            }
        }

        if migration_type is not None:
            data[self.root_tag]['migration_type'] = migration_type

        # https://onappdev.atlassian.net/browse/CORE-8880
        if test.api_version >= 5.5:
            route = "migration"
        else:
            route = "migrate"

        url = '/{0}/{1}/{2}.json'.format(self.route, self.id, route)
        if test.post_object(self, url=url, data=data):
            # Supported since 5.4
            if isinstance(destination, dict):
                if migration_type == 'hot_full':
                    self.transaction_handler("hot_full_migrate")
                else:
                    if self.transaction_handler(
                        'stop_{0}'.format(self.server_type)
                    ):
                        if self.transaction_handler('full_migrate'):
                            self.transaction_handler('startup_{0}'.format(
                                    self.server_type)
                            )
            else:
                action = 'hot_migrate' if (
                    self.template.allowed_hot_migrate or
                    self.server_type == 'openstack_server'
                ) else 'cold_migrate'
                if not self.booted:
                    action = 'cold_migrate'
                self.transaction_handler(action)

            if not self.transaction.error:
                test.update_object(self)
                return True
        return False

    def full_migrate(self,
                     hypervisor_id,
                     hypervisor_group_id,
                     disks_destinations,
                     networks_destinations,
                     migration_type):
        """
        Migrate a server between zones:
            https://onappdev.atlassian.net/browse/CORE-13048 (6.1)
        :param hypervisor_id: a destination hypervisor id
        :param hypervisor_group_id: a destination hypervisor_group id
        :param disks_destinations: a dict of disk_id: destination_data_store_id
            "disks_destinations": {"460": "9", "461": "9"}

        :param networks_destinations: a dict of network destination parameters:
            "networks_destinations": {
                "232": {
                    "network_id": "2",
                    "ip_net_id": "1",
                    "ip_range_id": "8",
                    "ip_address": "10.30.0.17"
                }
            }
        :param migration_type: "hot_full", "full"
        :return: True if success else False
        """

        data = {
            self.root_tag: {
                "migration_type": migration_type,
                "destination": {
                    "hypervisor_group_id": hypervisor_group_id,
                    "hypervisor_id": hypervisor_id,
                    "disks_destinations": disks_destinations,
                    "networks_destinations": networks_destinations
                }
            }
        }
        url = f'/{self.route}/{self.id}/migration.json'

        self.get_status()
        if test.post_object(self, url=url, data=data):
            if self.booted and migration_type == "hot_full":
                return self.transaction_handler(action='hot_full_migrate')
            elif migration_type == 'full':
                if self.transaction_handler(f'stop_{self.server_type}'):
                    if self.transaction_handler('full_migrate'):
                        return self.transaction_handler(
                            f'startup_{self.server_type}'
                        )
            else:
                test.log.error(f'Undefined migration type - "{migration_type}"')
        return False

    def set_vip(self, vip=True):
        """
        Set VIP Status for VS
        :param vip: whether VIP status is enabled for the server or not.
        Set this parameter to 'true' to enable and to 'false' to disable the VIP status.
        :return: True if success else False
        """
        test.log.info(
            "Set VIP status as {} for server with id {}".format(vip, self.id)
        )
        data = {"vip": vip}
        url = '/{0}/{1}/set_vip.json'.format(self.route, self.id)
        return test.post_object(self, url=url, data=data)

    def segregate(self, strict_virtual_machine_id=None):
        """
        Segregate VS
        :param strict_virtual_machine_id: the ID of virtual server you wish to segregate from the given VS
        :return: True if success else False
        """
        test.log.info(
            "Segregate current server ({}) with server id {}".format(
                self.id, strict_virtual_machine_id
            )
        )
        data = {
            self.root_tag: {
                "strict_virtual_machine_id": strict_virtual_machine_id
            }
        }
        url = '/{0}/{1}/segregation.json'.format(self.route, self.id)
        return test.put_object(self, url=url, data=data)

    def desegregate(self, strict_virtual_machine_id=None):
        """
        Deegregate VS
        :param strict_virtual_machine_id: the ID of virtual server you wish to desegregate from the given VS
        :return: True if success else False
        """
        test.log.info(
            "Desegregate current server ({}) with server id {}".format(
                self.id, strict_virtual_machine_id
            )
        )
        data = {
            self.root_tag: {
                "strict_virtual_machine_id": strict_virtual_machine_id
            }
        }
        url = '/{0}/{1}/segregation.json'.format(self.route, self.id)
        return test.delete_object(self, url=url, data=data)

    def edit_fqdn(
            self,
            hostname='',
            domain='',
            force=False,
            required_startup=False,
            shutdown_type="graceful"
    ):
        """
        Edit VS FQDN
        :param hostname: new hostname for VS
        :param domain: new domain for VS
        :param force: if force true should specify the next 2 params
        :param required_startup: True or False
        :param shutdown_type: can be "graceful" or "hard"
        :return: True if success else False
        """
        test.log.info(
            "Edit FQDN for VS with id {}".format(
                self.id
            )
        )
        data = {
            self.root_tag: {
                "hostname": hostname if hostname else self.hostname,
                "domain": domain if domain else self.domain
            }
        }
        self.get()
        if not self.booted:
            data[self.root_tag]["required_startup"] = required_startup
        else:
            data[self.root_tag]["force"] = force
            data[self.root_tag]["required_startup"] = required_startup
            data[self.root_tag]["shutdown_type"] = shutdown_type

        url = '/{0}/{1}/fqdn.json'.format(self.route, self.id)
        if test.patch_object(self, url=url, data=data):
            if self.booted:
                if force:
                    if required_startup:
                        self.transaction_handler('stop_virtual_machine')
                        self.transaction_handler('update_fqdn')
                        return self.transaction_handler('startup_virtual_machine')
                    elif not required_startup:
                        self.transaction_handler('stop_virtual_machine')
                        return self.transaction_handler('update_fqdn')
                else:
                    return self.transaction_handler('update_fqdn')
            else:
                if required_startup:
                    self.transaction_handler('update_fqdn')
                    return self.transaction_handler('startup_virtual_machine')
                else:
                    return self.transaction_handler('update_fqdn')

        return False

    def get_transactions(self):
        """
        Get List of VS Transactions without Log Output (
        https://docs.onapp.com/apim/latest/transactions/get-list-of-vs-transactions-without-log-output
        )
        :return: a list of transaction objects
        """
        return self.transaction._get_objects(
            '{}/{}/{}'.format(self.route, self.id, self.transaction.route)
        )

    def search(
            self,
            query=None,
            user_id=None,
            hypervisor_id=None,
            vm_states=None,
            vm_os=None
    ):
        """
        Search VS
        :param query: for example label
        :param user_id: user id
        :param hypervisor_id: hypervisor id
        :param vm_states: powered_on, powered_off, suspended, pending,
        building, in_motion
        :param vm_os: linux, windows, freebsd, coreos, lbva, other
        :return: an array of VS.
        """
        search_keys = {
            'query': 'search_filter[{}]',
            'user_id': 'search_filter[{}]',
            'hypervisor_id': 'search_filter[{}]',
            'vm_states': 'search_filter[{}]',
            'vm_os': 'search_filter[{}]',
        }

        test.log.info("Search a virtual server")
        return self._search(
            search_keys,
            query=query,
            user_id=user_id,
            hypervisor_id=hypervisor_id,
            vm_states=vm_states,
            vm_os=vm_os
        )

    # Enable/Disable VirshConsole
    # https://onappdev.atlassian.net/browse/CORE-14160
    def enable_virsh_console(self):
        url = f'/{self.route}/{self.id}/virsh_console.json'
        if test.post_object(self, url=url):
            return self.transaction_handler('setup_virsh_console')
        return False

    def disable_virsh_console(self):
        url = f'/{self.route}/{self.id}/virsh_console.json'
        return test.delete_object(self, url=url)

