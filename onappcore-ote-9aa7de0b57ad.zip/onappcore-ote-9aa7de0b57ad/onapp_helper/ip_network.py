#  Since 5.4
from onapp_helper.base_helper import BaseHelper
from onapp_helper.ip_range import IpRange
from onapp_helper import test


class IpNetwork(BaseHelper):
    root_tag = 'ip_net'

    def __init__(self, parent_obj=None, id=None):
        """

        :param parent_obj: net object
        :param id: ip network id
        """
        self.label = 'IpNetwork'
        self.parent_obj = parent_obj
        self.network_address = ''
        self.network_mask = ''
        self.add_default_ip_range = 0
        self.id = id
        if self.id:
            test.update_object(self)

    def create(self):
        test.log.info("Create ip_network...")
        data = {
            self.root_tag: {
                "add_default_ip_range": self.add_default_ip_range,
                "network_address": self.network_address,
                "network_mask": self.network_mask,
                "label": self.label
            }
        }
        return test.post_object(self, data=data)

    def edit(self):
        test.log.info("Edit ip_network...")
        if IpRange(self).list_ip_ranges_by_ip_net(self.id):
            data = {
                self.root_tag: {
                    "label": self.label
                }
            }
        else:
            data = {
                self.root_tag: {
                    "network_address": self.network_address,
                    "network_mask": self.network_mask,
                    "label": self.label
                }
            }
        return test.put_object(self, data=data)

    def list_ip_nets_by_network(self, network_id=None):
        """
        Get list of ip_networks assigned to network
        :param network_id: can be or network id or a list of network ids
        :return: list of ip_networks
        """
        test.log.info("Get list of nets by network")
        if not network_id:
            network_id = self.parent_obj.id
        data = {'network_id': network_id}
        return self._get_objects(data=data)

    def route(self):
        return 'settings/networks/{}/ip_nets'.format(self.parent_obj.id)
