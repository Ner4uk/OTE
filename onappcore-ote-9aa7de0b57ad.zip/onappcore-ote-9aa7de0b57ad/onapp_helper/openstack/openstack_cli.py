import re
from time import sleep

import cinderclient.client
import glanceclient.client
import neutronclient.neutron.client
import novaclient.client
from keystoneauth1.identity import v3
from keystoneauth1.session import Session as KeySession
from keystoneclient.v3.client import Client as KeystoneClient

from onapp_helper import test

TIME_TO_COMPLETE_OPENSTACK_API_REQUEST = 10  # simple requests like  delete port, unmanage volume - they do not last long
NOVA_VERSION = '2.1'
CINDER_VERSION = '2'
GLANCE_VERSION = '2'
NEUTRON_VERSION = '2.0'




class OpenstackClient:
    """
    Client manages openstack entities by adopting the native openstack clients
    """

    def __init__(self):
        ostack_creds_fail, ostack_creds = test.cp.ext_execute('cat /onapp/interface/config/openstack/credentials-admin')
        ostack_project_fail, ostack_project = test.cp.ext_execute(
            "source /onapp/interface/config/openstack/credentials-admin && openstack project show admin -f shell")
        if not (ostack_creds_fail and ostack_project_fail):
            creds = re.compile(".*OS_PASSWORD=(.+)\n")
            ostack_password = creds.search(ostack_creds)[1]
            srch_id = re.compile("\nid=\"(.+)\"\n")
            ostack_project_id = srch_id.search(ostack_project)[1]
        else:
            raise Exception('Failed to get OpenStack credentials')
        password = v3.PasswordMethod(username='admin', password=ostack_password, user_domain_name='default')
        auth = v3.Auth(auth_url=f"http://{test.cp.host}:5000/v3", auth_methods=[password],
                       project_id=ostack_project_id)
        session = KeySession(auth=auth)
        self.keystone = KeystoneClient(session=session)
        self.nova = novaclient.client.Client(NOVA_VERSION, session=session)
        self.cinder = cinderclient.client.Client(CINDER_VERSION, session=session)
        self.glance = glanceclient.client.Client(GLANCE_VERSION, session=session)
        self.neutron = neutronclient.neutron.client.Client(api_version=NEUTRON_VERSION, session=session)

    def orphaned_volumes(self):
        return [v.id for v in self.cinder.volumes.list() if not v.attachments]

    def orphaned_ports(self):
        return [p['id'] for p in self.neutron.list_ports()['ports'] if not p['device_id']]

    def clean_up_orphaned_ports(self):
        test.log.info(f"Cleaning up orphaned ports in OpenStack...")
        count_of_cleaned_items = 0
        for port in self.orphaned_ports():
            self.neutron.delete_port(port)
            count_of_cleaned_items += 1
        if count_of_cleaned_items: sleep(TIME_TO_COMPLETE_OPENSTACK_API_REQUEST)
        if self.orphaned_ports():
            test.log.warning(f"Failed to clean up orphaned ports, tried to remove {count_of_cleaned_items} of them")
            return False
        test.log.warning(f"Cleaned up {count_of_cleaned_items} orphaned ports")
        return True

    def clean_up_orphaned_volumes(self):
        """Destroys all the volumes in openstack that are not attached to instances - BE CAREFUl !
        This merely deletes volumes in DB(unmanage) in case IS refuses to delete, and related volumes persist in IS"""
        test.log.info(f"Cleaning up orphaned volumes in OpenStack...")
        volumes = self.cinder.volumes
        self._wait_while_removing_disks()
        count_of_cleaned_items = 0
        for v in volumes.list():
            if not v.attachments and v.status not in ['error', 'error_deleting']:
                volumes.delete(v.id)
                count_of_cleaned_items += 1
        self._wait_while_removing_disks()
        for v in volumes.list():
            if not v.attachments and v.status == 'error_deleting':
                volumes.reset_state(state='error', volume=v.id)
                volumes.unmanage(v.id)
                count_of_cleaned_items += 1
        if count_of_cleaned_items: sleep(TIME_TO_COMPLETE_OPENSTACK_API_REQUEST)
        if self.orphaned_volumes():
            test.log.warning(f"Failed to clean up orphaned volumes, tried to remove {count_of_cleaned_items} of them")
            return False
        test.log.warning(f"Cleaned up {count_of_cleaned_items} orphaned volumes")
        return True

    def _wait_while_removing_disks(self):
        volumes = self.cinder.volumes
        removing_disk = True
        while removing_disk:
            removing_disk = False
            sleep(5)
            for v in volumes.list():
                if v.status == 'deleting':
                    removing_disk = True
                    test.log.warning(f"Waiting for {v.name} to disappear or to switch status to 'error_deleting'")

    @staticmethod
    def add_image(image_name, image_url, min_disk, min_ram):
        """
        Downloads image from image_url and creates image from it
        :param image_name: use simple names, without special characters etc. - eligible for filename
        :param image_url: see https://docs.openstack.org/image-guide/obtain-images.html
        :param min_disk: minimum disk size required by image(Gb)
        :param min_ram: minimum ram size required by image(Mb)
        :return: boolean
        """
        image_wget_status, image_wget_message = test.cp.ext_execute(
            f"wget {image_url} -O /tmp/{image_name}.tmp --tries=10 --progress=bar:force")
        if not image_wget_status:
            image_create_status, image_create_message = test.cp.ext_execute(
                f"source /onapp/interface/config/openstack/credentials-admin &&"
                f"glance image-create --name {image_name} --min-disk {min_disk} --min-ram {min_ram} --file "
                f"/tmp/{image_name}.tmp --visibility public --disk-format=qcow2 --container-format bare")
            if not image_create_status:
                return True
            else:
                test.log.error(f"Image import failed - {image_create_message}")
                return False
        test.log.error(f"Image download failed -{image_wget_message}")
        return False

    @staticmethod
    def add_network(segmentation_id, network_addr, gateway_addr):
        """
        :param segmentation_id: vxlan id, any integer up to 16 million
        :param network_addr: like 10.11.12.0/24
        :param gateway_addr: like 10.11.12.
        :return: boolean
        the  two commands similar to the following ones would be executed on the CP host:
        neutron net-create --provider:network_type vxlan --provider:segmentation_id 3030 net-3030
        neutron subnet-create --name sub-3030 net-3030 10.20.30.0/24 --gateway 10.20.30.1
        """
        network_create_status, network_create_message = test.cp.ext_execute(
            f"source /onapp/interface/config/openstack/credentials-admin &&"
            f" neutron net-create --provider:network_type vxlan --provider:segmentation_id {segmentation_id} "
            f"net-{segmentation_id}")
        if not network_create_status:
            subnet_create_status, subnet_create_message = test.cp.ext_execute(
                f"source /onapp/interface/config/openstack/credentials-admin && "
                f"neutron subnet-create --name sub-{segmentation_id} net-{segmentation_id} {network_addr} --gateway "
                f"{gateway_addr}")
            if not subnet_create_status:
                return True
            else:
                test.log.error(f"Failed to create subnet - {subnet_create_message}")
                return False
        test.log.error(f"Failed to create network{network_create_message}")
        return False
