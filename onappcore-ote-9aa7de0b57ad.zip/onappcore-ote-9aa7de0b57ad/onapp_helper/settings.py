import os
from ruamel import yaml
from onapp_helper.base_helper import BaseHelper
from onapp_helper import test

ONAPP_YAML = '/onapp/interface/config/on_app.yml'


class Settings(BaseHelper):
    route = 'settings'
    root_tag = 'settings'
    license_key = ''
    transaction_approvals = None
    id = None
    on_app_yaml = None
    backup = None

    def get(self):
        """
        Get onapp settings.

        :return: settings obj.
        """
        test.log.info("Get Settings...")
        test.get_object(self, url='/{0}/configuration.json'.format(self.route))
        return self

    def set(self, **kwargs):
        """
        Set a new settings.

        :param kwargs: see onapp.yml to get full list of possible keyword
            arguments.

        :return: True if success else False.
        """
        test.log.info(
            "Update Settings with following parameters: {}".format(
                kwargs
            )
        )
        data = {'configuration': {'license_key': self.license_key}}
        data['configuration'].update(**kwargs)
        url = '/{0}.json?restart=1'.format(self.route)
        if test.put_object(self, url=url, data=data):
            if test.cp_version >= 5.0:
                if self.transaction_handler("update_configuration", None):
                    self.get()
                    return True
            else:
                self.wait_for_action(
                    lambda: test.get_object(self, '/version.json') is True,
                    timeout=30
                )
                if self.status_code == 200:
                    return True
        elif self.error and self.status_code in [422, 500]:
            return False
        return False

    def set_license_key(self, key):
        """
        Set a new or edit existed license key

        :param key: License key

        :return: True if success else False
        """
        test.log.info("Set license key...")
        data = {'configuration': {'license_key': key}}
        url = '/{0}.json'.format(self.route)
        return test.put_object(self, url=url, data=data)

    def get_on_app_yaml(self):
        test.log.info("Get onapp.yml")
        # Get raw yml format
        on_app_yaml = test.cp.execute('cat {}'.format(ONAPP_YAML))

        self.on_app_yaml = yaml.round_trip_load(
            on_app_yaml,
            preserve_quotes=True
        )

    def update_on_app_yaml(self, **kwargs):
        # Convert python dict obj to raw yml format
        test.log.info("Update onapp.yml")
        tmp_file = '/tmp/on_app_yaml'

        if kwargs:
            self.on_app_yaml.update(kwargs)

        test.log.debug("Write data to {}".format(tmp_file))
        with open(tmp_file, 'w') as on_app_yaml:
            yaml.round_trip_dump(
                self.on_app_yaml,
                on_app_yaml,
                explicit_start=True
            )

        test.log.debug("Copy {} to CP".format(tmp_file))
        cmd = 'scp {} root@{}:{}'.format(
            tmp_file,
            test.host,
            ONAPP_YAML
        )
        test.log.debug("Executing {}".format(cmd))
        os.system(cmd)

        test.log.debug("Remove {}".format(tmp_file))
        os.system('rm -v {}'.format(tmp_file))
        test.log.debug("Done")

    def take_backup(self):
        test.log.info('Take onapp settings backup')
        try:
            self.get()
            self.backup = self.response[self.root_tag]
            return True
        except:
            return False

    def restore_backup(self):
        test.log.info('Restore onapp settings backup')
        if self.backup is None:
            self.error = "There's no saved settings currently!"
            return False
        return self.set(**self.backup)

    def _url(self):
        """
        Using for updating obj after PUT request.

        :return: url to send GET request.
        """
        return '/{0}/configuration.json'.format(self.route)
