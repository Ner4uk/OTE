from onapp_helper.base_helper import BaseHelper
from onapp_helper import test


class Resolver(BaseHelper):
    route = 'settings/nameservers'
    root_tag = 'nameserver'

    def __init__(self):
        self.id = None
        self.address = "8.8.8.8"
        self.network_id = 0

    def create(self):
        test.log.info("Create resolver...")
        data = {
            self.root_tag: {
                "address": self.address,
                "network_id": self.network_id
            }
        }
        return test.post_object(self, data=data)

    def edit(self):
        test.log.info("Edit resolver...")
        data = {
            self.root_tag: {
                "address": self.address,
                "network_id": self.network_id
            }
        }
        return test.put_object(self, data=data)
