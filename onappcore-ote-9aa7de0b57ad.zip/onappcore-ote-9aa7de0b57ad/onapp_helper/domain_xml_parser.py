from xml.etree.ElementTree import Element
import xml.etree.ElementTree as ET


class Clock:
    def __init__(self):
        self.offset = ''
        self.timezone = ''


class Vcpu:
    def __init__(self):
        self.current = ''
        self.value = ''


class Shares:
    def __init__(self):
        self.value = ''


class CpuTune:
    def __init__(self):
        self.shares = Shares()


class OSType:
    def __init__(self):
        self.arch = ''
        self.machine = ''
        self.value = ''


class OS:
    def __init__(self):
        self.type = OSType()
        self.boot = []


class Source:
    def __init__(self):
        self.file = ''
        self.dev = ''


class Target:
    def __init__(self):
        self.dev = ''
        self.bus = ''


class Driver:
    def __init__(self):
        self.type = ''
        self.name = ''
        self.cache = ''
        self.discard = ''


class Address:
    def __init__(self):
        self.type = ''
        self.controller = ''
        self.bus = ''
        self.target = ''
        self.unit = ''


class Disk:
    def __init__(self):
        self.type = ''
        self.device = ''
        self.source = Source()
        self.target = Target()
        self.driver = Driver()
        self.address = Address()
        self.readonly = None


class InterfaceSource:
    def __init__(self):
        self.bridge = ''


class Mac:
    def __init__(self):
        self.address = ''


class InterfaceTarget:
    def __init__(self):
        self.dev = ''


class Alias:
    def __init__(self):
        self.name = ''


class Model:
    def __init__(self):
        self.type = ''


class DeviceInterface:
    def __init__(self):
        self.source = InterfaceSource()
        self.mac = Mac()
        self.target = InterfaceTarget()
        self.alias = Alias()
        self.model = Model()


class ConsoleTarget:
    def __init__(self):
        self.type = ''
        self.port = ''


class Console:
    def __init__(self):
        self.target = ConsoleTarget()
        self.type = ''


class SerialTarget:
    def __init__(self):
        self.port = ''


class Serial:
    def __init__(self):
        self.target = SerialTarget()
        self.type = ''


class DeviceGraphics:
    def __init__(self):
        self.type = ''
        self.listen = ''
        self.passwd = ''


class DeviceInput:
    def __init__(self):
        self.type = ''
        self.bus = ''


class Vendor:
    def __init__(self):
        self.id = ''


class Product:
    def __init__(self):
        self.id = ''


class HostDevSource:
    def __init__(self):
        self.startupPolicy = ''
        self.vendor = Vendor()
        self.product = Product()


class Boot:
    def __init__(self):
        self.order = ''


class HostDev:
    """
    <hostdev mode='subsystem' type='usb'>
      <source startupPolicy='optional'>
        <vendor id='0x1234'/>
        <product id='0xbeef'/>
      </source>
      <boot order='2'/>
    </hostdev>
    """
    def __init__(self):
        self.model = ''
        self.type = ''
        self.source = HostDevSource()
        self.boot = Boot()


class Devices:
    def __init__(self):
        self.emulator = ''
        self.disks = []
        self.interface = DeviceInterface()
        self.console = Console()
        self.serial = Serial()
        self.graphics = DeviceGraphics()
        self.input = DeviceInput()
        self.host_dev = HostDev()


class DomainObj:
    def __init__(self):
        self.type = ''
        self.name = ''
        self.description = ''
        self.memory = ''
        self.currentMemory = ''
        self.clock = Clock()
        self.vcpu = Vcpu()
        self.cputune = CpuTune()
        self.features = []
        self.os = OS()
        self.devices = Devices()


class Domain:
    """
    Provide an access to work with xml config file.

    Example:
        In [8]: from onapp_helper.domain_xml_parser import Domain

        In [9]: d = Domain('zaza.xml')

        In [10]: d.memory
        Out[10]: '786432'

        In [11]: d.edit_memory(786432 / 2)

        In [12]: d.memory
        Out[12]: '393216.0'

        In [13]:

    """
    def __init__(self, xml_file=None):
        self._xml_file = xml_file

        self.type = ''
        self.name = ''
        self.description = ''
        self.memory = ''
        self.currentMemory = ''
        self.clock = Clock()
        self.vcpu = Vcpu()
        self.cputune = CpuTune()
        self.features = []
        self.os = OS()
        self.devices = Devices()

    def edit_memory(self, size):
        memory = [e for e in self.__root_tree if e.tag == 'memory'][0]
        memory.text = str(size)
        self.__tree.write(self._xml_file)
        self.read_xml()

    def edit_current_memory(self, size):
        current_memory = [
            e for e in self.__root_tree if e.tag == 'currentMemory'
            ][0]
        current_memory.text = str(size)
        self.__tree.write(self._xml_file)
        self.read_xml()

    def edit_cpu(self, size):
        vcpu = [
            e for e in self.__root_tree if e.tag == 'vcpu'
            ][0]
        if 'current' in vcpu.attrib:
            vcpu.attrib['current'] = str(size)
        else:
            vcpu.text = str(size)
        self.__tree.write(self._xml_file)
        self.read_xml()

    def edit_cpu_shares(self, size):
        cputune = [
            e for e in self.__root_tree if e.tag == 'cputune'
            ][0]

        shares = [
            e for e in cputune if e.tag == 'shares'
            ][0]
        shares.text = str(size)
        self.__tree.write(self._xml_file)
        self.read_xml()

    def set_host_device(self):
        # devices = [
        #     e for e in self.__root_tree if e.tag == 'devices'
        #     ][0]
        devices = self.__root_tree.find('devices')

        # host_devs = [
        #     d for d in devices if d.tag == 'hostdev'
        #     ]
        host_devs = devices.find('hostdev')

        if not host_devs:
            host_dev = Element('hostdev')
            host_dev.append(
                (
                    ET.fromstring(
                        "<source>"
                        "</source>"
                    )
                )
            )

            host_dev.attrib['mode'] = 'subsystem'
            host_dev.attrib['type'] = 'usb'
            devices.insert(-1, host_dev)

        self.__tree.write(self._xml_file)
        self.read_xml()

    def read_xml(self, xml_config_file_path=None):
        xml_file = xml_config_file_path if xml_config_file_path else self._xml_file
        self.__tree = ET.parse(xml_file)
        self.__root_tree = self.__tree.getroot()

        self.type = self.__root_tree.attrib['type']
        self.name = self.__root_tree.find('name').text
        self.description = self.__root_tree.find('description').text
        self.memory = self.__root_tree.find('memory').text
        self.currentMemory = self.__root_tree.find('currentMemory').text
        clock = self.__root_tree.find('clock')
        if clock:
            self.clock.offset = clock.attrib['offset']
            self.clock.timezone = clock.attrib['timezone']

        vcpu = self.__root_tree.find('vcpu')

        if 'current' in vcpu.attrib:
            self.vcpu.current = vcpu.attrib['current']

        self.vcpu.value = vcpu.text

        cputune = self.__root_tree.find('cputune')

        shares = cputune.find('shares')
        self.cputune.shares = shares.text

        features = self.__root_tree.find('features')

        self.features = [e.tag for e in features]

        os = self.__root_tree.find('os')

        type = os.find('type')
        self.os.type.arch = type.attrib['arch']
        self.os.type.machine = type.attrib['machine']
        self.os.type.value = type.text
        boots = os.find('boot')
        self.os.boot = [d.attrib['dev'] for d in boots]

        devices = self.__root_tree.find('devices')

        emulator = devices.find('emulator')
        self.devices.emulator = emulator.text

        disks = devices.findall('disk')

        self.devices.disks = []
        for disk in disks:
            d = Disk()
            d.type = disk.attrib['type']
            d.device = disk.attrib['device']

            source_attributes = ['file', 'dev']
            source = disk.find('source')
            for key in source_attributes:
                if key in source.attrib:
                    d.source.__dict__[key] = source.attrib[key]

            target_attributes = ['dev', 'bus']
            target = disk.find('target')

            for key in target_attributes:
                if key in target.attrib:
                    d.target.__dict__[key] = target.attrib[key]

            driver_attributes = ['type', 'name', 'cache', 'discard']
            for e in disk:
                if e.tag == 'driver':
                    for key in driver_attributes:
                        if key in e.attrib:
                            d.driver.__dict__[key] = e.attrib[key]

            address_attributes = ['type', 'controller', 'bus', 'target', 'unit']
            for e in disk:
                if e.tag == 'address':
                    for key in address_attributes:
                        if key in e.attrib:
                            d.address.__dict__[key] = e.attrib[key]

            readonly = disk.find('readonly')
            if readonly:
                d.readonly = True

            self.devices.disks.append(d)

        interface = devices.find('interface')

        source = interface.find('source')
        if source:
            self.devices.interface.source.bridge = source.attrib['bridge']

        mac = interface.find('mac')
        if mac:
            self.devices.interface.mac.address = mac.attrib['address']

        target = interface.find('target')
        if target:
            self.devices.interface.target.dev = target.attrib['dev']

        alias = interface.find('alias')
        if alias:
            self.devices.interface.alias.name = alias.attrib['name']

        model = interface.find('model')
        if model:
            self.devices.interface.model.type = model.attrib['type']

        #  virsh console
        console = devices.find('console')
        if console:
            self.devices.console.type = console.attrib['type']
            console_target = console.find('target')
            if console_target.items():
                self.devices.console.target.type = console_target.attrib['type']
                self.devices.console.target.port = console_target.attrib['port']

        serial = devices.find('serial')
        if serial:
            self.devices.serial.type = serial.attrib['type']
            serial_target = console.find('target')
            if serial_target.items():
                self.devices.serial.target.port = serial_target.attrib['port']

        graphics = interface.find('graphics')
        if graphics:
            graphic_attributes = ['type', 'listen', 'passwd']
            for key in graphic_attributes:
                if key in graphics.attrib:
                    self.devices.graphics.__dict__[key] = graphics.attrib[key]

        input = devices.find('input')
        if input:
            input_attributes = ['type', 'bus']
            for key in input_attributes:
                if key in input.attrib:
                    self.devices.input.__dict__[key] = input.attrib[key]

        # # Actually this does not works...
        # host_devs = devices.find('hostdev')
        # # Get just type and model
        # if host_devs:
        #     host_devs_usb = [d for d in host_devs if d.attrib['type'] == 'usb']
        #     if host_devs_usb:
        #         usb = host_devs_usb[0]
        #
        #         usb_dev_attributes = ['type', 'mode']
        #         for key in usb_dev_attributes:
        #             if key in usb.attrib:
        #                 self.devices.host_dev.__dict__[key] = usb.attrib[key]

        # But this should
        host_dev = devices.find('hostdev')
        if host_dev:
            usb_dev_attributes = ['type', 'mode']
            for key in usb_dev_attributes:
                if key in host_dev.attrib:
                    self.devices.host_dev.__dict__[key] = host_dev.attrib[key]

        else:
            # Reset to default
            self.devices.host_dev = HostDev()
