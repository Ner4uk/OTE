from time import sleep

from onapp_helper import test
from onapp_helper.base_helper import BaseHelper


class Action:
    schedule_build_virtual_server = 'ScheduleBuildVirtualServer'


class TargetType:
    transaction = "Transaction"
    alert = "Alert"


class Status:
    warn = 'warn'
    failed = 'failed'
    cancelled = 'cancelled'


class ActivityLog(BaseHelper):
    route = 'logs'
    root_tag = 'log_item'
    TARGET_TYPE = TargetType
    STATUS = Status
    ACTION = Action

    def __init__(self, id=None):
        self.target_id = None
        self.target_type = ''
        self.resource_diff_ids = None
        self.action = ''
        self.status = ''
        self.id = id
        if self.id:
            test.update_object(self)

    def _get_log_item(self, page=1):
        """Get a list of log items objects from selected page"""
        test.log.info(
            "Get list of log items from {0} page...".format(page)
        )
        return self._get_objects(query='page/{0}'.format(page))

    def wait_for_log_item(
            self,
            action,
            target_id=None,
            expected_status="complete",
            pages=31,
            params_keys=None,
            param_value=None
    ):
        # reset log_item id
        self.id = None  # Reset log item instance
        test.log.info('\n' + ('*' * 80))
        test.log.info(
            "Waiting for {0} with parent_id - {1}...".format(action, target_id)
        )
        for page in range(1, pages):
            if self.wait_for_action(
                lambda: self._find_log_item(
                    page, action, target_id, params_keys, param_value
                ) is True,
                timeout=10
            ):
                break
        else:
            self.cause_of_failure = "Transaction '{}' has not been found".format(
                action
            )
            self.action = action

        status = None
        if self.id:
            for i in range(300):
                test.update_object(self)
                if self.status == expected_status:
                    test.log.info(self.status)
                    status = True
                    break
                elif self.status == self.STATUS.failed:
                    test.log.error('{0} Failed...'.format(action))
                    status = False
                    break
                elif self.status == self.STATUS.cancelled:
                    test.log.warning('{0} Cancelled...'.format(action))
                    status = False
                    break
                elif i == 299:
                    test.log.warning('Waiting time out...')
                    self.cause_of_failure = 'Waiting time out...'
                    status = None
                else:
                    sleep(10)
        if not status:
            self.error[self.action] = self.status
        return status

    def _find_log_item(
            self, page, action, target_id, params_keys, param_value
    ):
        """
        Find a log item by target_id and action.
        If success return True and update log item obj.
        """
        log_item = None
        for li in self._get_log_item(page):
            if li.target_id == target_id and li.action == action:
                if params_keys:
                    if self._get_value_from_dict(
                            li.params, params_keys
                    ) == param_value:
                        log_item = li
                        break
                else:
                    log_item = li
                    break

        if log_item:
            self.__dict__.update(log_item.__dict__)
            return True
        return False

    @staticmethod
    def _get_value_from_dict(params_dict, params_keys):
        """
        Get value from dict using iterable obj params_keys
        :param params_dict: dictionary in general from transaction params
        :param params_keys: list or tuple of dict keys.
        :return: value located by keys.
        """
        value = params_dict
        for key in params_keys:
            value = value[key]

        return value

    def approve(self):
        test.log.info('Approve log item - {}'.format(self.id))
        return test.put_object(
            self, url=f"/{self.route}/{self.id}/approve.json"
        )

    def decline(self):
        test.log.info('Decline log item - {}'.format(self.id))
        return test.put_object(
            self, url=f"/{self.route}/{self.id}/decline.json"
        )

    def wait_for_alert(
            self,
            action,
            target_type,
            target_id,
            timeout=100,
            step=10
    ):
        """
        These are actions in Alert table - they can be of status 'notice', 'warn' etc.
        :param step: seconds to sleep between mysql requests cycles, the request results limited by the period step*2
        :param action: required, e.g. 'hypervisor_is_online'
        :return: True if the action appeared or False if time is out
        """

        while timeout:
            result = test.cp.mysql_execute(f"select target_id from alerts where target_type=\'{target_type}\' and "
                                           f"action=\'{action}\' and created_at > DATE_SUB(UTC_TIMESTAMP, "
                                           f"INTERVAL {step*2} SECOND) limit 10;")
            if str(target_id) in result:
                test.log.warning(f"Found {action} for {target_type} with id {target_id}")
                return True
            timeout -= 1
            sleep(step)
        test.log.error(f"Timed out waiting for action {action} for {target_type} with id {target_id}...")
        return False