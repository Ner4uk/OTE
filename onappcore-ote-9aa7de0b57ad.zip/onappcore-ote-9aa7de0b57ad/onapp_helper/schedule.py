from onapp_helper.base_helper import BaseHelper
from onapp_helper import test


class Period:
    def __init__(self):
        self.days = 'days'
        self.weeks = 'weeks'
        self.months = 'months'
        self.years = 'years'


class Status:
    def __init__(self):
        self.enabled = 'enabled'
        self.disabled = 'disabled'


class Schedule(BaseHelper):
    PERIOD = Period()
    STATUS = Status()

    def __init__(self, target=None, id=None):
        """

        :param id:
        :param target: disk or server obj
        """
        self.parent_obj = target
        self.root_tag = 'schedule'
        self.id = id

        self.action = "autobackup"
        self.duration = 1
        self.period = ''
        self.rotation_period = 1
        self.status = ''
        self.start_at = ''

        if self.id:
            test.update_object(self)

    def get_all_system_schedules(self):
        test.log.info("Get all cloud schedules...")
        return self._get_objects(route='settings/schedules')

    def create(self):
        data = {
            self.root_tag: {
                "action": self.action,
                "duration": self.duration,
                "period": self.period,
                "rotation_period": self.rotation_period,
                "status": self.status,
                "start_at": self.start_at
            }
        }
        test.log.info("Create schedule...")
        return test.post_object(self, data=data)

    def edit(self):
        data = {
            self.root_tag: {
                "action": self.action,
                "duration": self.duration,
                "period": self.period,
                "rotation_period": self.rotation_period,
                "status": self.status,
                "start_at": self.start_at
            }
        }
        test.log.info("Edit schedule...")
        return test.put_object(self, data=data)

    def route(self):
        if self.parent_obj:
            return '{}/{}/schedules'.format(self.parent_obj.route, self.parent_obj.id)
        return 'settings/schedules'
