from onapp_helper.base_helper import BaseHelper
from onapp_helper.data_store import DataStore
from onapp_helper import test


class ServerType:
    virtual = 'virtual'
    vpc = 'vpc'
    smart = 'smart'
    osm = 'osm'


class DataStoreZone(BaseHelper):
    route = 'settings/data_store_zones'
    root_tag = 'data_store_group'
    SERVER_TYPE = ServerType()

    def __init__(self, id=None):
        self.id = id
        self.label = 'ATDataStoreZone'
        self.location_group_id = None
        self.server_type = self.SERVER_TYPE.virtual  # since 5.3
        if self.id:
            test.update_object(self)

    def create(self):
        test.log.info("Create data store zone...")
        data = {
            self.root_tag: {
                "label": self.label,
                "server_type": self.server_type,
                "location_group_id": self.location_group_id
            }
        }
        return test.post_object(self, data=data)

    def edit(self):
        test.log.info("Edit data store zone...")
        data = {
            self.root_tag: {
                "label": self.label,
                "location_group_id": self.location_group_id
            }
        }
        return test.put_object(self, data=data)

    def attach_ds(self, ds_obj):
        test.log.info("Attach data store to zone...")
        url = '/{0}/{1}/data_stores/{2}/attach.json'.format(
            self.route, self.id, ds_obj.id
        )
        return test.post_object(self, url=url)

    def detach_ds(self, ds_obj):
        test.log.info("Detach data store from zone...")
        url = '/{0}/{1}/data_stores/{2}/detach.json'.format(
            self.route, self.id, ds_obj.id
        )
        return test.post_object(self, url=url)

    def get_by_params(self, parameters=None):
        """
        Return the array of objects
        """
        test.log.info("Get data store zone by parameters...")
        objects = []
        for d in self.get_all():
            is_ok = True
            if parameters:
                for key, value in list(parameters.items()):
                    if not d.__dict__[key] == value:
                        is_ok = False
                        break
            if is_ok:
                objects.append(d)
        return objects

    def attached_data_stores(self):
        test.log.info("Get list of attached data stores...")
        return DataStore()._get_objects(
            route="{0}/{1}/data_stores".format(self.route, self.id)
        )