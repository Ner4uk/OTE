from onapp_helper.base_helper import BaseHelper
from onapp_helper import test


class IpAddressJoin(BaseHelper):
    def __init__(self, parent_obj=None):
        """

        :param parent_obj: server obj
        """
        self.parent_obj = parent_obj
        self.root_tag = 'ip_address_join'
        self.ip_address_id = None
        self.network_interface_id = None
        self.address = None  # Since 5.4 instead of ip_address_id

    def get_primary(self):
        """
        Get primary nic ip address join, to get an ip address you need to 
        execute: join.ip_address['address']
        :return: 
        """
        test.log.info(
            "Get primary {}".format(self.__class__.__name__))
        primary_nic_id = self.parent_obj.network_interface.get_primary().id
        ip_address_joins = [
            join for join in self.get_all()
            if join.network_interface_id == primary_nic_id
        ]
        if ip_address_joins:
            return ip_address_joins[0]
        test.log.warning("No IP Addresses found...")
        return False

    def assign_to_server(
            self,
            address=None,
            ip_address_id=None,
            network_interface_id=None,
            used_ip=False,
            own_ip=False
    ):
        """
        Assign an IP address to server.
        :param address: an ip address as string,
        :param network_interface_id: If not specified use primary
        :param used_ip: if True allows to assign used IP addresses
        :param own_ip: if True use own ip addresses
        :return: True if success else False

        # IP addresses assigned to virtual machine
        #
        # Attributes:
        # created_at: "2016-07-27T09:18:31+03:00",
        # id: 2123,
        # ip_address_id: 50891,
        # network_interface_id: 2057,
        # updated_at: "2016-07-27T09:18:31+03:00",
        # ip_address: {
        #     address: "108.123.91.21",
        #     broadcast: "108.123.91.31",
        #     created_at: "2015-12-10T13:29:54+02:00",
        #     customer_network_id: null,
        #     disallowed_primary: false,
        #     gateway: "108.123.91.31",
        #     hypervisor_id: null,
        #     id: 50891,
        #     ip_address_pool_id: null,
        #     network_address: "108.123.91.16",
        #     network_id: 1,
        #     pxe: false,
        #     updated_at: "2016-07-27T09:18:31+03:00",
        #     user_id: null,
        #     free: false,
        #     netmask: "255.255.255.240"
        # }

        """
        test.log.info(
            "Assign {} address to server ({})".format(
                address, self.parent_obj.id
            )
        )
        if network_interface_id is None:
            network_interface_id = self.parent_obj.network_interface.get_primary().id

        data = {
            self.root_tag: {
                "network_interface_id": network_interface_id,
                "used_ip": used_ip,
                "own_ip": own_ip
            }
        }

        if test.cp_version >= 5.4:
            data[self.root_tag]['address'] = address
        else:
            data[self.root_tag]["ip_address_id"] = ip_address_id

        if test.post_object(self, data=data):
            self.parent_obj.get()
            return True if not self.parent_obj.booted else self.transaction_handler(
                'update_firewall', network_interface_id
            )
        return False

    def unassign_from_server(self, network_interface_id=None):
        """
        Since 5.4
        :param network_interface_id: If not specified use primary
        :return: True if success else False
        """
        test.log.info("Unassign from server")
        if network_interface_id is None:
            network_interface_id = self.parent_obj.network_interface.get_primary().id

        if test.delete_object(self):
            self.parent_obj.get()
            return True if not self.parent_obj.booted else self.transaction_handler(
                'update_firewall', network_interface_id
            )
        return False

    def route(self):
        return '{0}/{1}/ip_addresses'.format(
            self.parent_obj.route, self.parent_obj.id
        )

