#  Available since 5.2
import os

from onapp_helper import test
from onapp_helper.base_helper import BaseHelper
from onapp_helper.disk import Disk


class OperatingSystems():
    def __init__(self):
        self.linux = 'linux'
        self.other = 'other'
        self.windows = 'windows'


class OperatingSystemDistros():
    def __init__(self):
        self.ubuntu = 'ubuntu'
        self.rhel = 'rhel'
        self.other = 'other'
        self.windows = '2008'


class OVA(BaseHelper):
    """
    Since 5.7 we have 2 types of OVA templates like source template and
    converted to kvm or vcloud virtualization
    """
    OPERATING_SYSTEMS = OperatingSystems()
    OPERATING_SYSTEM_DISTROS = OperatingSystemDistros()
    route = 'template_ovas'
    root_tag = 'image_template_ova'

    def __init__(self, id=None):
        self.make_public = False
        self.label = ""
        self.version = 1.0
        if test.cp_version >= 5.5:
            self.allowed_hot_migrate = False
        self.min_disk_size = 1
        self.min_memory_size = 128
        self.operating_system = ''
        self.operating_system_distro = ''
        self.operating_system_arch = ''
        self.operating_system_edition = ''
        self.virtualization = ["kvm"]
        self.file_url = ''
        self.backup_server_id = None
        self.id = id
        if self.id:
            test.update_object(self)

    def upload(self):
        self.detect_os()
        data = {
            self.root_tag: {
                "label": self.label,
                "backup_server_id": self.backup_server_id,
                "version": self.version,
                "min_memory_size": self.min_memory_size,
                "file_url": self.file_url
            }
        }

        if test.cp_version < 5.7:
            extended_params = {
                "operating_system": self.operating_system,
                "operating_system_distro": self.operating_system_distro,
                "virtualization": self.virtualization,
                "min_disk_size": self.min_disk_size,
                "make_public": self.make_public
            }
            data[self.root_tag].update(extended_params)
        test.log.info("Upload OVA template")

        if test.cp_version >= 5.5:
            data[self.root_tag]["allowed_hot_migrate"] = self.allowed_hot_migrate

        if test.post_object(self, data=data):
            # wait for transactions
            if self.transaction_handler("download_ova", self.id):
                test.update_object(self)
                test.log.info('State - {}'.format(self.state))
                # print(self.transaction.params['initiator_id'], self.transaction.user_id)
                if self.transaction_handler("extract_ova", self.id):
                    test.update_object(self)
                    test.log.info('State - {}'.format(self.state))
                    # print(self.transaction.params['initiator_id'], self.transaction.user_id)
                    if test.cp_version <= 5.6:  # old ova workflow
                        if self.transaction_handler("import_ovf", self.id):
                            test.update_object(self)
                            test.log.info('State - {}'.format(self.state))
                            # print(self.transaction.params['initiator_id'], self.transaction.user_id)
                            # Waiting for convert_disk_to_vmdk in case not vmdk disk
                            if '.vmdk' not in self.transaction.log_output:
                                if not self.transaction_handler(
                                        'convert_disk_to_vmdk', self.id
                                ):
                                    return False
                            action = "import_disk" if \
                                self.operating_system in ['other', 'windows'] else \
                                "import_disk_partition"
                            if self.transaction_handler(action, self.id):
                                test.update_object(self)
                                test.log.info('State - {}'.format(self.state))
                                if self.operating_system in ['other', 'windows']:
                                    return test.update_object(self)
                                # print(self.transaction.params['initiator_id'], self.transaction.user_id)
                                if self.transaction_handler("parse_fstab", self.id):
                                    test.update_object(self)
                                    test.log.info('State - {}'.format(self.state))
                                    # print(self.transaction.params['initiator_id'], self.transaction.user_id)
                                    if self.transaction_handler(
                                            "convert_ova_to_template", self.id):
                                        test.update_object(self)
                                        test.log.info('State - {}'.format(self.state))
                                        # print(self.transaction.params['initiator_id'], self.transaction.user_id)
                                        return test.update_object(self)
                    else:
                        return test.update_object(self)
        return False

    def convert(
            self,
            label=None,
            make_public=False,
            virtualization='kvm',
            operating_system='Linux',
            operating_system_distro='RHEL',
            operating_system_arch='x64',
            operating_system_edition='',
            allowed_hot_migrate=False
    ):
        """
         only available since 5.7
            converting an OVA method return a new OVA obj.
            :return: OVA obj
        """
        if test.cp_version >= 5.7:
            self.label = label
            if not self.label:
                self.label = f"{operating_system}-" \
                             f"{operating_system_distro}{operating_system_edition}-" \
                             f"{virtualization}" \
                             f"{operating_system_arch} "
            self.detect_os()
            data = {
                self.root_tag: {
                    "label": self.label,
                    "make_public": make_public,
                    "operating_system": operating_system,
                    "operating_system_distro": operating_system_distro,
                    "operating_system_edition": operating_system_edition,
                    "virtualization": virtualization,
                    "allowed_hot_migrate": allowed_hot_migrate,
                    "operating_system_arch": operating_system_arch
                }
            }
            test.log.info("Convert OVA template")

            self.converted_ova = OVA()
            if test.post_object(
                    self.converted_ova,
                    url=f"/{self.route}/{self.id}/converting.json",
                    data=data
            ):
                # wait for transactions
                if self.converted_ova.transaction_handler(
                        "convert_ovf", self.converted_ova.id
                ):
                    test.update_object(self.converted_ova)
                    test.log.info('State - {}'.format(self.converted_ova.state))
                    # print(self.converted_ova.transaction.params['initiator_id'], self.converted_ova.transaction.user_id)
                    if self.converted_ova.transaction_handler(
                            "import_ovf", self.converted_ova.id
                    ):
                        test.update_object(self.converted_ova)
                        test.log.info(
                            'State - {}'.format(self.converted_ova.state)
                        )
                        # Waiting for convert_disk_to_vmdk in case not vmdk disk
                        if '.vmdk' not in self.converted_ova.transaction.log_output:
                            if not self.converted_ova.transaction_handler(
                                    'convert_disk_to_vmdk', self.converted_ova.id
                            ):
                                return False
                        action = "import_disk" if self.converted_ova.operating_system in ['other', 'windows'] \
                            or self.converted_ova.virtualization == ['vcenter'] else "import_disk_partition"
                        if self.converted_ova.transaction_handler(
                                action, self.converted_ova.id
                        ):
                            test.update_object(self.converted_ova)
                            test.log.info(
                                'State - {}'.format(self.converted_ova.state)
                            )
                            if self.converted_ova.operating_system in ['other', 'windows']\
                                    or self.converted_ova.virtualization == ['vcenter']:
                                test.update_object(self.converted_ova)
                                return self.converted_ova
                            # print(self.converted_ova.transaction.params['initiator_id'], self.converted_ova.transaction.user_id)
                            if self.converted_ova.transaction_handler(
                                    "parse_fstab", self.converted_ova.id
                            ):
                                test.update_object(self.converted_ova)
                                test.log.info(
                                    'State - {}'.format(self.converted_ova.state)
                                )
                                # print(self.converted_ova.transaction.params['initiator_id'], self.converted_ova.transaction.user_id)
                                if self.converted_ova.transaction_handler(
                                        "convert_ova_to_template",
                                        self.converted_ova.id
                                ):
                                    test.update_object(self.converted_ova)
                                    test.log.info(
                                        'State - {}'.format(
                                            self.converted_ova.state
                                        )
                                    )
                                    # print(self.transaction.params['initiator_id'], self.transaction.user_id)
                                    test.update_object(self.converted_ova)
                                    return self.converted_ova
        else:
            test.log.error('OVA convert has been introduced in 5.7v')
        return False

    def edit(self):
        """This method is common for different types of OVA! (src and
        converted)"""
        if test.cp_version >= 5.7:
            data = {
                self.root_tag: {
                    "label": self.label,
                    "version": self.version,
                    "min_memory_size": self.min_memory_size
                }
            }

            if self.virtualization:
                data[self.root_tag]["allowed_hot_migrate"] = self.allowed_hot_migrate
        else:
            data = {
                self.root_tag: {
                    "make_public": self.make_public,
                    "label": self.label,
                    "version": self.version,
                    "min_disk_size": self.min_disk_size,
                    "min_memory_size": self.min_memory_size,
                    "operating_system": self.operating_system,
                    "operating_system_distro": self.operating_system_distro,
                    "virtualization": self.virtualization,
                    "file_url": self.file_url,
                    "backup_server_id": self.backup_server_id
                }
            }
            if test.cp_version >= 5.5:
                data[self.root_tag][
                    "allowed_hot_migrate"] = self.allowed_hot_migrate

        test.log.info("Edit OVA template")
        return test.put_object(self, data=data)

    def make_ova_public(self):
        """Supported for old and converted OVA"""
        test.log.info("Make OVA template public")
        url = '/{}/{}/make_public.json'.format(self.route, self.id)
        return test.post_object(self, url=url)

    def delete(self):
        test.log.info("Delete OVA template")
        if test.delete_object(self):
            if self.transaction_handler("destroy_ova", self.id):
                return True
        return False

    def delete_ova_files(self):
        """Supported for old and converted OVA"""
        test.log.info("Delete OVA files")
        url = '/{}/{}/delete_files.json'.format(self.route, self.id)
        if test.post_object(self, url=url):
            if self.transaction_handler("delete_ova_files", self.id):
                return True
        return False

    def get_system(self):
        test.log.info("Get system OVA templates")
        route = '{}/system'.format(self.route)
        return self._get_objects(route=route)

    def get_own(self):
        test.log.info("Get own OVA templates")
        route = '{}/own'.format(self.route)
        return self._get_objects(route=route)

    def get_user(self):
        test.log.info("Get users OVA templates")
        route = '{}/user'.format(self.route)
        return self._get_objects(route=route)

    def search(self, q=None):
        test.log.info("Search OVA templates")
        return self._get_objects(query='search_filter[query]={}'.format(q))

    def get_by_manager_id(self, manager_id):
        test.log.info("Get OVA template by managet id - {}".format(manager_id))
        templates = self.get_all()
        templates = [t for t in templates if t.manager_id == manager_id]
        if templates:
            self.__dict__.update(templates[0].__dict__)
            return self
        test.log.info(
            "Template with manager_id - '{0}' does not exist...".format(
                manager_id
            )
        )
        self.error['template'] = f"Template with manager id '{manager_id}' does not exist."
        return False

    def get_by_id(self, id):
        test.log.info("Get OVA template by id...")
        url = '/{0}/{1}.json'.format(self.route, id)
        if test.get_object(self, url=url):
            self.__dict__.update(self.response[self.root_tag])
            return True
        return False

    def detect_os(self):
        base_name = os.path.basename(self.file_url)
        if 'centos' in base_name.lower():
            self.operating_system_distro = self.OPERATING_SYSTEM_DISTROS.rhel
            self.operating_system = self.OPERATING_SYSTEMS.linux
        elif 'debian' in base_name.lower():
            self.operating_system_distro = self.OPERATING_SYSTEM_DISTROS.ubuntu
            self.operating_system = self.OPERATING_SYSTEMS.linux
        elif 'freebsd' in base_name.lower():
            self.operating_system_distro = self.OPERATING_SYSTEM_DISTROS.other
            self.operating_system = self.OPERATING_SYSTEMS.other
        elif 'suse' in base_name.lower():
            self.operating_system_distro = self.OPERATING_SYSTEM_DISTROS.other
            self.operating_system = self.OPERATING_SYSTEMS.other
        elif 'ubuntu' in base_name.lower():
            self.operating_system_distro = self.OPERATING_SYSTEM_DISTROS.ubuntu
            self.operating_system = self.OPERATING_SYSTEMS.linux
        elif 'win' in base_name.lower():
            self.operating_system_distro = self.OPERATING_SYSTEM_DISTROS.windows
            self.operating_system = self.OPERATING_SYSTEMS.windows

        if 'x86' in base_name.lower():
            self.operating_system_arch = 'x86'
        elif 'x64' in base_name.lower():
            self.operating_system_arch = 'x64'

    def disks(self):
        """
        https://onappdev.atlassian.net/browse/CORE-13171. Since 6.0p3
        :return: A list of OVA disk objects
        """
        disks = Disk(parent_obj=self)
        route = f'{self.route}/{self.id}/disks'
        return disks._get_objects(root_tag='image_template_disk', route=route)
