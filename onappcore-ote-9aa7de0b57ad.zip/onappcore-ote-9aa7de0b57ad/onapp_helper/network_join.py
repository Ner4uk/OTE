from onapp_helper.base_helper import BaseHelper
from onapp_helper import test


class NetworkJoin(BaseHelper):
    def __init__(self, parent_obj=None, id=None):
        """Where obj is HV or HVZ object"""
        self.parent_obj = parent_obj
        self.id = id
        self.root_tag = 'network_join'
        self.interface = 'eth0'
        if self.id:
            test.update_object(self)

    def add(self, network):
        test.log.info("Add network join...")
        data = {
            self.root_tag: {
                "network_id": network.id,
                "interface": self.interface
            }
        }
        return test.post_object(self, data=data)

    def remove(self):
        test.log.info("Remove network join...")
        return test.delete_object(self)

    def route(self):
        return '{0}/{1}/network_joins'.format(
            self.parent_obj.route, self.parent_obj.id
        )