import os

from onapp_helper import test
from onapp_helper.base_helper import BaseHelper


class SshKey(BaseHelper):
    def __init__(self):
        self.root_tag = 'ssh_key'
        self.route = 'settings/ssh_keys'
        self.key = os.popen('cat ~/.ssh/*.pub').read().strip('\n')
        self.id = None

    def add(self, user_id):
        url = f'/users/{user_id}/ssh_keys.json'
        test.log.info("Add ssh key to user profile...")
        data = {self.root_tag: {'key': self.key}}
        return test.post_object(self, url=url, data=data)