from onapp_helper.base_helper import BaseHelper
from onapp_helper import test


class NetworkType:
    def __init__(self):
        self.shared = "Networking::Network"


class Network(BaseHelper):
    route = 'settings/networks'
    root_tag = 'network'
    NETWORK_TYPE = NetworkType()

    def __init__(self, id=None):
        self.label = 'ATNetwork'
        self.network_group_id = None
        self.vlan = False
        self.type = self.NETWORK_TYPE.shared
        self.id = id
        if self.id:
            test.update_object(self)

    def create(self):
        test.log.info("Create network...")
        data = {
            self.root_tag: {
                "label": self.label,
                "network_group_id": self.network_group_id,
                "vlan": self.vlan,
                "type": self.type
            }
        }
        return test.post_object(self, data=data)

    def edit(self):
        test.log.info("Edit network...")
        data = {
            self.root_tag: {
                "label": self.label,
                "network_group_id": self.network_group_id,
                "vlan": self.vlan
            }
        }
        return test.put_object(self, data=data)

    def get_any(self):
        test.log.info("Get any Network...")
        return self.get_by_params()

    def get_by_params(self, parameters=None, **kwargs):
        """
        Return the array of objects
        :param **kwargs: keyword arguments, where key is one of the network
        parameter and value a list of possible values
        """
        test.log.info("Get network by parameters...")
        objects = []
        for net in self.get_all():
            is_ok = True
            if parameters or kwargs:
                for key, value in list(parameters.items() if parameters else
                                    kwargs.items()):
                    if not net.__dict__[key] == value:
                        is_ok = False
                        break
            if is_ok:
                objects.append(net)
        return objects


class ExternalNetwork(Network):
    def __init__(self, id=None):
        self.route = 'settings/external_networks'
        self.root_tag = 'external_network'
        self.label = 'ETNetwork'
        self.network_group_id = None
        self.vlan = False
        self.id = id
        if self.id:
            test.update_object(self)


class VAppNetwork(Network):
    def __init__(self, id=None):
        self.route = 'settings/vapp_networks'
        self.root_tag = 'vapp_network'
        self.label = 'ETNetwork'
        self.network_group_id = None
        self.vlan = False
        self.id = id
        if self.id:
            test.update_object(self)


class OpenstackNetwork(Network):
    def __init__(self, id=None):
        self.route = 'settings/openstack_networks'
        self.root_tag = 'openstack_network'
        self.label = 'OpenStackNetwork'
        self.network_group_id = None
        self.vlan = False
        self.id = id
        if self.id:
            test.update_object(self)


class CloudbootNetwork(Network):
    def __init__(self, id=None):
        self.id = test.cp.mysql_execute(
            "select id from networking_networks where label='CloudBoot';"
        )[0]