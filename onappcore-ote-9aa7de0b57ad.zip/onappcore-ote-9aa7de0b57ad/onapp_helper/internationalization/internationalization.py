from onapp_helper import test
from onapp_helper.base_helper import BaseHelper


class Internationalization(BaseHelper):
    route = 'settings/locales'
    root_tag = 'phrase'
    tag = 'translations'

    def __init__(self, locale_name=None, locale_id=None, text='NANA'):
        self.locale_name = locale_name
        self.locale_id = locale_id
        self.phrase_id = []
        self.text = text

        if self.locale_name:
            test.update_object(self)

    def add_locale(self):
        if self.locale_name:
            data = {
                "locale": {
                    "name": self.locale_name
                }
            }
            test.post_object(self, data=data)

    def get_locale_id(self):
        url = '/{0}.json'.format(self.route)
        if test.get_object(self, url):
            data = self.response
            for i in data:
                if i['locale']['name'] == self.locale_name:
                    self.locale_id = i['locale']['id']
                    test.update_object(self)
                    return self.locale_id

    def translate(self):
        url = '/{0}/{1}.json'.format(self.route, self.locale_name)
        if test.get_object(self, url):
            json_data = self.response
            for i in json_data:
                phrase_id = i['phrase']['id']
                data = {
                            self.tag: {
                                "{}".format(phrase_id): {
                                    "id": "",
                                    "phrase_id": phrase_id,
                                    "locale_id": self.get_locale_id(),
                                    "text": self.text
                                }
                            }
                        }
                url = '/{0}/{1}'.format(self.route, self.locale_name)
                test.patch_object(self, url, data)
            return True