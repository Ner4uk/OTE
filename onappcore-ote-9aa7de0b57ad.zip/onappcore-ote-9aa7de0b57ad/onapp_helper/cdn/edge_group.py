from onapp_helper import test
from onapp_helper.base_helper import BaseHelper


class EdgeGroup(BaseHelper):
    route = 'edge_groups'
    root_tag = route[:-1]

    def __init__(self):
        self.label = 'TESTINGEG'
        self.id = None

    def get_any(self):
        test.log.info("Get any Edge Group...")
        self.__dict__.update(self.get_all()[0].__dict__)
        return True

    def get_by_label(self, label):
        test.log.info("Get Edge Group by label...")
        for eg in self.get_all():
            if label.lower() in eg.label.lower():
                self.__dict__.update(eg.__dict__)
                return True
        self.error = f"No edge group found with the label {label}"
        return False

    def create(self):
        test.log.info("Create Edge Group...")
        data = {
            self.root_tag: {
                "label": self.label
            }
        }
        return test.post_object(self, data=data)

    def get_available_locations(self):
        test.log.info("Get available locations for the Edge Group...")
        return test.get_object(
            self,
            url=f'/{self.route}/{self.id}.json',
            data={"available_locations": True}
        )

    def assign_location(self, location_id):
        test.log.info(f"Assign a location {location_id} to the Edge Group...")
        data = {
            "location": location_id
        }
        return test.post_object(
            self,
            url=f'/{self.route}/{self.id}/assign.json',
            data=data
        )

    def edit(self):
        test.log.info("Edit edge group...")
        data = {
            "label": self.label
        }
        return test.put_object(self, data=data)

    def modify(self, locations=None):
        '''Totally replaces the set of assigned locations with the given one.
        If no locations specified it assigns all the available locations to the Edge Group.'''
        test.log.info("Modifying edge group(locations set)...")
        if locations is None:
            assert self.get_available_locations()
            locations = [
                location['location']['id'] for location in self.available_locations
            ]
        data = {
            "locations": locations
        }
        return test.post_object(
            self,
            url=f'/{self.route}/{self.id}/modify.json',
            data=data
        )
