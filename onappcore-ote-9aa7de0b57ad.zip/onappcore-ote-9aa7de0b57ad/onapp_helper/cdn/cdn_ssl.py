from onapp_helper import test
from onapp_helper.base_helper import BaseHelper
from test_helper.generatorTH import generate_name


class CdnSsl(BaseHelper):
    def __init__(self, id=None):
        self.id = id
        self.cdn_resources = None
        self.cdn_reference = None
        self.name = None
        self.route = 'cdn_ssl_certificates'
        self.root_tag = 'cdn_ssl_certificate'
        if self.id:
            test.update_object(self)

    def params(self):
        #TODO extract big params to the seperate file
        return {
            'name': 'cdn_ssl_autotest_ote-40$#-' + generate_name(),
            'cert': """-----BEGIN CERTIFICATE-----
MIIE+DCCA+CgAwIBAgISESG3JjBw9nYz6gxzVAXyZc1UMA0GCSqGSIb3DQEBCwUA
MGAxCzAJBgNVBAYTAkJFMRkwFwYDVQQKExBHbG9iYWxTaWduIG52LXNhMTYwNAYD
VQQDEy1HbG9iYWxTaWduIERvbWFpbiBWYWxpZGF0aW9uIENBIC0gU0hBMjU2IC0g
RzIwHhcNMTUwODEwMDgxNTQxWhcNMTcwOTI2MTEzOTI3WjA8MSEwHwYDVQQLExhE
b21haW4gQ29udHJvbCBWYWxpZGF0ZWQxFzAVBgNVBAMMDioub25hcHBkZXYuY29t
MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAuQV7zt9TJ0Jov82eu3sb
/baZdWkTt5sNfOzUeAuGaW/pGwpAaU2iYNHLUQThSws70T/iInnoEHiieFlobTFA
yhj4q7yvnhwq6CJ4/hEKVjSHM44WuLHc6nJ9vuwFdGvfm/v69L9UNdJ6zFbINgPi
cGbeCn40p7xuAdlapDAsGrHOyXS1JFxmLdVVbf/zg8/3CE4+959FMjnhlaeZNkHi
5NauRSn90C7zY9NncOFl9pBnqhbRe7nJzuRj3SvG4WBa7QkGp/bYsM3UOf+Fqvlp
HrEy3mfOb3+OQA+JMQOa5Q0LPO7zu1B99Nhi69NlVevGcyeZ/js8L8QbExQuvbvC
VQIDAQABo4IBzjCCAcowDgYDVR0PAQH/BAQDAgWgMEkGA1UdIARCMEAwPgYGZ4EM
AQIBMDQwMgYIKwYBBQUHAgEWJmh0dHBzOi8vd3d3Lmdsb2JhbHNpZ24uY29tL3Jl
cG9zaXRvcnkvMCcGA1UdEQQgMB6CDioub25hcHBkZXYuY29tggxvbmFwcGRldi5j
b20wCQYDVR0TBAIwADAdBgNVHSUEFjAUBggrBgEFBQcDAQYIKwYBBQUHAwIwQwYD
VR0fBDwwOjA4oDagNIYyaHR0cDovL2NybC5nbG9iYWxzaWduLmNvbS9ncy9nc2Rv
bWFpbnZhbHNoYTJnMi5jcmwwgZQGCCsGAQUFBwEBBIGHMIGEMEcGCCsGAQUFBzAC
hjtodHRwOi8vc2VjdXJlLmdsb2JhbHNpZ24uY29tL2NhY2VydC9nc2RvbWFpbnZh
bHNoYTJnMnIxLmNydDA5BggrBgEFBQcwAYYtaHR0cDovL29jc3AyLmdsb2JhbHNp
Z24uY29tL2dzZG9tYWludmFsc2hhMmcyMB0GA1UdDgQWBBRg0v4XYWrzafjHQi0O
ARuPk1GRoDAfBgNVHSMEGDAWgBTqTnzUgC3lFYGGJoyCbcCYpM+XDzANBgkqhkiG
9w0BAQsFAAOCAQEAPGVu3KuqwPEXUky6qD2KfVr+MQMAOGh53ztC44XkRgSeD6ZT
JIj45MTp4jw38NKS3YBv0mqyy1a2EP3qNM8TGFKlINBRkNR/IlXCoB3Ap1UJpAhe
bdGOwzLJxQR2wlaPO09kAslgYLOAAdf2DWrjhdaolWMlJ/5Rxrgdj4z2Y0ox5Ip1
t7mvRsgSVEq63ql3eroknM71xblhZk2DUKPxSy+OAX8Zj6OgpgMtwCuQ9wKbCZO3
IDLMhydULLjF5hVj35ZESMedoXw1t/eTHj/gVptEs99nrKTps7PD+fa/HqzjBpNg
ldl6uf1RAY5uoBayRWSIHt0I1XjtJ5d0msnCvQ==
-----END CERTIFICATE-----""",
            'key': """-----BEGIN PRIVATE KEY-----
MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQC5BXvO31MnQmi/
zZ67exv9tpl1aRO3mw187NR4C4Zpb+kbCkBpTaJg0ctRBOFLCzvRP+IieegQeKJ4
WWhtMUDKGPirvK+eHCroInj+EQpWNIczjha4sdzqcn2+7AV0a9+b+/r0v1Q10nrM
Vsg2A+JwZt4KfjSnvG4B2VqkMCwasc7JdLUkXGYt1VVt//ODz/cITj73n0UyOeGV
p5k2QeLk1q5FKf3QLvNj02dw4WX2kGeqFtF7ucnO5GPdK8bhYFrtCQan9tiwzdQ5
/4Wq+WkesTLeZ85vf45AD4kxA5rlDQs87vO7UH302GLr02VV68ZzJ5n+OzwvxBsT
FC69u8JVAgMBAAECggEBAIB4gEla5GBESnu0CN3hU8RNwCy4c4pvzWPLBpT8W65m
mJPAAI2d7HwR8H0nSFBVUomvNBQAVdTqDtZGLq5zHqu1vyVwdPjyUhCxrxWrO2Q0
QRTZOomwZtcb/JhPRlJafP/Qbab4Gz7sEXxFXeuzss2df9wFWgaGXlRGWhvbnyRA
1/uS9kdhFQova0TAmRkWY4xfFcZT56DBoOaW4knpEBqIcSjjhH2Ol82ZNnN1Qigq
7Mfjo1OKaGdsGZKSMO94NuX77EMDpWOCBc5TBj1VJrLTHT5yGYpcWu8loJcOszJM
laSnXR+WJDKe1c0sxDu5P9sJHkr7JrnXcc20xwyZ7cECgYEA4pBNzzkpU0LWEUhe
Pzf71lIhqy2KXunAuaC3Hvjk6/VwrHBC6od0pzBfGmZlbzu9dWPKTdHgJ7Wn2YCj
Pe3jHGgel/EN4ZY00a0aXRfhSKgkIfUrb4sbe+iDsjuio2kCWQNhfI9fn3lNgeQW
kTYiqBFnIr8I+ip+BbOo1Yr2BY0CgYEA0Q9zDwpKU/FxB+JfUppuznus3Qbz6T0L
0XeUOTPzEU91bFE/b1u/XUShF4mUhCZvrrHnUyn1YQ5UyAaeuajl7ITVFmMFZ/s4
orAKF91MvM+Pkx/aZ++B+0HW4xhC/e/olSrGJo/vXNR6WTo4BaNiIIG48UcKpNLY
OmfJeOWJyekCgYBFceXntqWsF7h147C/v/E5aENZrMPVA+FHBLQckj3Y9Ypr0J0y
NgLTnEgKV4iP58fSy5ue7s2+XjfsuzlOKjSK6H84I3MVymy2OFD0Z/Vtx9wLbJK7
xe/Osx5q60yWugE2N4sSGwA8aXoQblFcgTNuQKdURyoBRDUMml0N12JBoQKBgHy7
2Qx6OUrIXYY0vGcOmVo9VDAz+8eHksuRqzBOHJKRdCACgfSxKwY88liWz7PhMvVq
U/i8qhkUceU+femMKlLqFjFbN1iI/YujuQHwGd71gFZpxOgKcOU2rT2ltiLIx15o
vP05F7mtVKp0IATNLLj0bSIYHvOkkTqXvg+R9JoxAoGBAKVWcjq7lifhK3EQNMYN
PYnn/wphn9s0MZpEJCZ6QeK5YCES4LM+sfGs0MepsK10zcC0NvEG/tOWBpE1nhs8
DMvWixD1m6ykCWlPIbO5vqZy0CfqobhA+lVUZZUhV8T87GFPyIUvAF1asNhC6m38
GfSUzgLn2IQ3bhKqNyD9/d8K
-----END PRIVATE KEY-----"""
        }

    def create(self, *args):
        test.log.info('Create CDN SSL certificate...')
        params = self.params()
        params.update(*args)

        data = { self.root_tag: params }

        return test.post_object(self, data=data)

    def update(self, *args):
        test.log.info('Update CDN SSL certificate...')
        params = self.params()
        params.update(*args)

        data = { self.root_tag: params }

        return test.put_object(self, data=data)

    def search(self, param):
        self._get_objects(query='q={0}'.format(param))
