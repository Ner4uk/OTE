from onapp_helper import test
from onapp_helper.base_helper import BaseHelper

HTTP_PULL = 'HTTP_PULL'
HTTP_PUSH = 'HTTP_PUSH'


class HourlyStat(BaseHelper):
    stat_time = ''
    cost = None
    value = None
    edge_group_id = None
    edge_group_label = ''


class RawLog(BaseHelper):
    pass


class EdgeIps(BaseHelper):
    pass


class StorageServerLocations(BaseHelper):
    route = 'cdn_resources/available_storage_server_locations'
    # root_tag = 'storage_server_location'


class CachingRules(BaseHelper):
    def __init__(self, parent_obj):
        self.parent_obj = parent_obj

    def get_all(self):
        test.get_object(self)
        rules = []
        if self.response and isinstance(self.response, list):
            for responce in self.response:
                o = CachingRules(self.parent_obj)
                o.__dict__.update(responce)
                rules.append(o)
        return rules

    def create(self, **kwargs):
        """

        :param kwargs:
            "name"
            "conditions": {
                "0": {
                    "connective":"if",
                    "subject":"url",
                    "predicate":"default",
                    "value":""
                },
                "1": {
                    "connective":"and",
                    "subject":"cookie",
                    "cookie":"",
                    "predicate":"default",
                    "value":""
                },
                "2": {
                    "connective":"and",
                    "subject":"param",
                    "param":"",
                    "predicate":"default",
                    "value":""
                },
                "3": {
                    "connective":"and",
                    "subject":"header",
                    "header":"",
                    "predicate":"default",
                    "value":""
                }
            },
            "actions": {
                "0": {
                    "act":"force edge to cache",
                    "seconds":""
                },
                "1": {
                    "act":"redirect client",
                    "url":""
                },
                "2": {
                    "act":"set response header",
                    "header":"",
                    "value":""
                },
                "3": {
                    "act":"set custom origin",
                    "value":""
                }
            }


        :return:
        """
        data = {'rule': kwargs}
        return test.post_object(self, url=f"/{self.route}.json", data=data)

    def edit(self, **kwargs):
        id = self.id
        data = {'id': id, 'rule': {**kwargs}}
        return test.put_object(
            self, url=f"/{self.route}/{id}.json", data=data
        )

    def delete(self):
        return test.delete_object(self, url=f"/{self.route}/{self.id}.json")

    @property
    def id(self):
        return [r.name for r in self.get_all()].index(self.name)

    @property
    def route(self):
        return f"{self.parent_obj.route}/{self.parent_obj.id}/http_caching_rules"


class CdnResource(BaseHelper):
    route = 'cdn_resources'
    root_tag = 'cdn_resource'

    def __init__(self, id=None):
        self.caching_rules = CachingRules(self)
        self.id = id
        if id:
            test.update_object(self)

    def create(self, **kwargs):
        data = {
            self.root_tag: kwargs
        }
        return test.post_object(self, data=data)

    def edit(self, **kwargs):
        data = {
            self.root_tag: kwargs
        }
        return test.put_object(self, data=data)

    def get_advanced_details(self):
        url = f'/{self.route}/{self.id}/advanced.json'
        return test.get_object(self, url=url)

    def change_ftp_password(self, ftp_password):
        data = {
            self.root_tag: {
                'ftp_password': ftp_password
            }
        }
        return test.put_object(self, data=data)

    def prefetch(self, prefetch_paths):
        """

        :param prefetch_paths: can be a single path - "/home/123.jpeg" or an
            array of paths - ["/ui3/test1","/ui3/test2","/ui3/test3","/ui3/test4"]
        :return:
        """
        data = {"prefetch_paths": prefetch_paths}
        url = f"/{self.route}/{self.id}/prefetch.json"
        return test.post_object(self, url=url, data=data)

    def purge(self, purge_paths):
        """

        :param purge_paths: can be a single path - "/home/123.jpeg" or an
            array of paths - ["/ui3/test1","/ui3/test2","/ui3/test3","/ui3/test4"]
        :return:
        """
        data = {"purge_paths": purge_paths}
        url = f"/{self.route}/{self.id}/purge.json"
        return test.post_object(self, url=url, data=data)

    def hourly_stat(self, startdate=None, enddate=None):
        """
        :return:
        :param startdate: YYYY-MM-DD+hh:mm:ss
        :param enddate: YYYY-MM-DD+hh:mm:ss
        :return:
        """
        period = []
        if startdate:
            period.append(f"period[startdate]={startdate}")
        if enddate:
            period.append(f"period[enddate]={enddate}")

        url = f"/{self.route}/{self.id}/billing.json"
        if period:
            url = '?'.join([url, '&'.join(period)])
        stat = HourlyStat()
        test.get_object(stat, url=url)
        return stat

    def raw_log(self):
        url = f"/{self.route}/raw_log.json"
        log = RawLog()
        test.get_object(log, url=url)
        return log

    def disable_raw_log(self):
        data = {"raw_log": {"protocol": ""}}
        url = f"/{self.route}/raw_log.json"
        return test.post_object(self, url=url, data=data)

    def configure_raw_log(self, **kwargs):
        """

        :param kwargs:
            To configure the FTP/SFTP delivery protocol:
                "protocol":"ftp",
                "uri":"rawlog.com",
                "user":"username",
                "pass":"password"
            To configure the Syslog delivery protocol:
                "protocol":"syslog",
                "uri":"rawlog.com",
                "syslog_protocol":"tcp",
                "port":"80"
        :return:
        """
        data = {"raw_log": kwargs}
        url = f"/{self.route}/raw_log.json"
        return test.post_object(self, url=url, data=data)

    def get_instructions(self):
        """
        Get Instruction for Live Streaming CDN Internal Resource
        :return:
        """
        url = f'/{self.route}/{self.id}/instructions.json'
        return test.get_object(self, url=url)

    def search(self, search_param):
        """

        :param search_param:
        :return:
        """
        return self._search(search_param)

    def suspend(self):
        url = f"/{self.route}/{self.id}/suspend.json"
        return test.put_object(self, url=url)

    def resume(self):
        url = f"/{self.route}/{self.id}/resume.json"
        return test.put_object(self, url=url)

    def advanced_reporting(self, start=None, end=None, locations=None):
        """

        :param start: the start date of the period for which the statistics
            should be generated ("YYYY-MM-DD HH:MM:SS")
        :param end: the end date of the period for which the statistics
            should be generated("YYYY-MM-DD HH:MM:SS")
        :param locations: the location ID for which the statistics should be
            generated ([12, 23])
        :return:
        """
        data = {"report": {}}
        if start:
            data["report"]['start'] = start
        if end:
            data["report"]['end'] = end
        if locations:
            data["report"]['locations'] = locations

        url = f"/{self.route}/{self.id}/advanced_reporting.json"
        return test.get_object(self, url=url, data=data)

    def available_storage_server_locations(self, type=None, only_active=None):
        '''

        :param type: the optional parameter which describes the Storage
            Server's type - streaming or http;
        :param only_active: the optional parameter which describes the Storage
            Server's status (only_active = true if only all active SSs or
            only_active = false if all the available SSs ).
        :return:
        '''
        url = f'/{self.route}/available_storage_server_locations.json'
        options = []
        if type:
            options.append(f'type={type}')
        if only_active is not None:
            options.append(f'only_active={"true" if only_active else "false"}')

        if options:
            url = '?'.join([url, '&'.join(options)])
        locations = []
        location = StorageServerLocations()
        test.get_object(location, url=url)
        if location.response and isinstance(location.response, list):
            for response in location.response:
                o = StorageServerLocations()
                o.__dict__.update(response)
                locations.append(o)
        return locations

    def edge_ips(self):
        """
        To get the list of edge server IP ranges
        :return:
        """
        url = f'/{self.route}/edge_ips.json'
        ips = EdgeIps()
        test.get_object(ips, url=url)
        return ips


class CdnIpRanges(BaseHelper):
    route = 'cdn_resources/edge_ips'
    root_tag = 'edge_ips'
