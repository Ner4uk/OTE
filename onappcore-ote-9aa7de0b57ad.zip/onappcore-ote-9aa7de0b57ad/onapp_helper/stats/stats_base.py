import time
from onapp_helper import test
from onapp_helper.base_helper import BaseHelper


class StatsBase(BaseHelper):
    def get_last_hour_stats(self):
        """
        Get statistics for the last hour (UTC)
        For example request time - 10:06:33 so in this case we will be
        requesting stats for 09:00:00 - 10:06:33 period.
        :return: stats for the last hour.
        """
        current_time_in_sec = time.time()
        UTC_current_time = time.gmtime(current_time_in_sec)
        UTC_last_time = time.gmtime(current_time_in_sec - 3600)

        start_date = "{YYYY}-{MM}-{DD}+{hh}:00:01".format(
            YYYY=UTC_last_time.tm_year,
            MM=format(UTC_last_time.tm_mon, '02'),
            DD=format(UTC_last_time.tm_mday, '02'),
            hh=format(UTC_last_time.tm_hour, '02'),
        )

        end_date = "{YYYY}-{MM}-{DD}+{hh}:{mm}:{ss}".format(
            YYYY=UTC_current_time.tm_year,
            MM=format(UTC_current_time.tm_mon, '02'),
            DD=format(UTC_current_time.tm_mday, '02'),
            hh=format(UTC_current_time.tm_hour, '02'),
            mm=format(UTC_current_time.tm_min, '02'),
            ss=format(UTC_current_time.tm_sec, '02')
        )
        data = {
            "period": {
                "startdate": start_date,
                "enddate": end_date,
                "use_local_time": False
            }
        }
        test.log.info(
            "Get {} for the last hour...".format(self.__class__.__name__)
        )
        if self.root_tag in ['user_stat']:
            return test.get_object(self, data=data)
        return self._get_objects(data=data)

    def stats_waiter(self):
        # print('Waiting while a new statistics will be generated...')
        test.log.info(
            "Waiting while a new statistics will be generated..."
        )
        if self.wait_for_action(
            lambda: time.localtime(time.time()).tm_min == 0,
            timeout=3600,
            step=20
        ):
            time.sleep(240)
            return True
        return False
