from onapp_helper import test
from onapp_helper.base_helper import BaseHelper
from onapp_helper.stats.stats_base import StatsBase


class UserStats(StatsBase, BaseHelper):
    def __init__(self, parent_obj):
        """
        Initialize UserStats
        :param parent_obj: user obj
        """
        self.parent_obj = parent_obj
        self.vm_cost = 0.0
        self.stat_time = ""
        self.user_resources_cost = 0.0
        self.backup_cost = 0.0
        self.template_cost = 0.0
        self.template_iso_cost = 0.0
        self.storage_disk_size_cost = 0.0
        self.backup_count_cost = 0.0
        self.backup_disk_size_cost = 0.0
        self.template_count_cost = 0.0
        self.template_disk_size_cost = 0.0
        self.monit_cost = 0.0
        self.customer_network_cost = 0.0
        self.edge_group_cost = 0.0
        self.ova_count_cost = 0.0
        self.ova_size_cost = 0.0
        self.total_cost = 0.0
        self.currency_code = ""
        self.root_tag = 'user_stat'
        self.user_id = None
        self.autoscale_cost = 0.0
        self.acceleration_cost = 0.0
        # Since 5.6
        self.vm_discount_due_to_free = 0.0
        self.user_resources_discount_due_to_free = 0.0
        self.backup_discount_due_to_free = 0.0
        self.template_discount_due_to_free = 0.0
        self.template_iso_discount_due_to_free = 0.0
        self.storage_disk_size_discount_due_to_free = 0.0
        self.backup_count_discount_due_to_free = 0.0
        self.backup_disk_size_discount_due_to_free = 0.0
        self.template_count_discount_due_to_free = 0.0
        self.template_disk_size_discount_due_to_free = 0.0
        self.autoscale_discount_due_to_free = 0.0
        self.acceleration_discount_due_to_free = 0.0
        self.ova_count_discount_due_to_free = 0.0
        self.ova_size_discount_due_to_free = 0.0
        self.edge_group_discount_due_to_free = 0.0
        self.total_discount_due_to_free = 0.0
        self.total_cost_with_discount = 0.0
        # Since 5.8
        self.recovery_point_cost = 0.0
        self.recovery_point_discount_due_to_free = 0.0
        # Since 6.9 (https://onappdev.atlassian.net/browse/CORE-13970)
        self.monthly_discount_due_to_free = 0.0

    def get(self):
        #  TODO get stat for last hour.
        """
        Update self attributes from response
        :return: True if success otherwise False
        """
        test.log.info("Get User Stats...")
        return test.get_object(self)

    def get_user_stat_for_the_last_hour(self):
        """
        Get statistics for the last hour (UTC)
        For example request time - 10:06:33 so in this case we will be
        requesting stats for 09:00:00 - 10:06:33 period.
        :return: stats for the last hour.
        """
        return self.get_last_hour_stats()

    def route(self):
        return '{0}/{1}/user_statistics'.format(
            self.parent_obj.route, self.parent_obj.id
        )
