from onapp_helper.base_helper import BaseHelper


class Usage(BaseHelper):
    def __init__(self):
        pass