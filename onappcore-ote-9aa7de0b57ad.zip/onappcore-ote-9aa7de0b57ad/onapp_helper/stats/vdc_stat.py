from onapp_helper import test
from onapp_helper.base_helper import BaseHelper
from onapp_helper.stats.stats_base import StatsBase


class VDCStat(StatsBase, BaseHelper):
    def __init__(self, parent_obj=None):
        """

        :param parent_obj: a resource pool obj
        """
        self.root_tag = 'vdc_stat'
        self.parent_obj = parent_obj
        self.vdc_last_hour_stat = None

    def get_hourly_stat(self, timeout=3600, step=60):
        """
        Getting hourly stat wile response is empty - [].

        :return: vdc_stat
        """
        test.log.info("Get {} hourly statistics".format(self.__class__.__name__))
        return self.wait_for_action(
            self.get_all, timeout=timeout, step=step
        )

    def get_hourly_stat_for_the_last_hour(self):
        """
        Get statistics for the last hour (UTC)
        For example request time - 10:06:33 so in this case we will be
        requesting stats for 09:00:00 - 10:06:33 period.
        :return: stats for the last hour.
        """
        stats = self.get_last_hour_stats()
        if stats:
            self.vdc_last_hour_stat = stats[-1]
            return self.vdc_last_hour_stat
        return False

    def route(self):
        return '{}/{}/statistics'.format(
            self.parent_obj.route, self.parent_obj.id
        )