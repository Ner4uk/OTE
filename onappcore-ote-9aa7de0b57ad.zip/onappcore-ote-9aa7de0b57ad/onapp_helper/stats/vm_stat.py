from onapp_helper import test
from onapp_helper.base_helper import BaseHelper
from onapp_helper.stats.stats_base import StatsBase


class BillingStat:
    """
    Dict of Parts
    """
    def __init__(self, billing_stats):
        self.__dict__.update(billing_stats)
        self.keys = list(billing_stats.keys())


class Part:
    """
    disks, network_interfaces, virtual_machines, service_addon
    """
    def __init__(self, part):
        self.__dict__.update(part)


class Resource:
    def __init__(self, cost, value):
        self.cost = cost
        self.value = value


class Cost:
    """
    Dict in costs array:

    |    {
    |        "value": 100,
    |        "cost": 0.0,
    |        "resource_name": "cpu_shares"
    |    }

    convert to class with attributes:

        * value
        * cost
        * resource_name
    """
    def __init__(self, cost):
        self.__dict__.update(cost)


class VmStat(StatsBase, BaseHelper):
    def __init__(self, parent_obj=None):
        """

        :param parent_obj: a server obj
        """
        self.root_tag = 'vm_hourly_stat'
        self.parent_obj = parent_obj

        self.disk_size = Resource(0, 0)
        self.data_read = Resource(0, 0)
        self.data_written = Resource(0, 0)
        self.reads_completed = Resource(0, 0)
        self.writes_completed = Resource(0, 0)
        self.disk_min_iops = Resource(0, 0)
        self.ip_addresses = Resource(0, 0)
        self.rate = Resource(0, 0)
        self.data_received = Resource(0, 0)
        self.data_sent = Resource(0, 0)
        self.cpu_shares = Resource(0, 0)
        self.cpus = Resource(0, 0)
        self.memory = Resource(0, 0)
        self.template = Resource(0, 0)
        self.cpu_usage = Resource(0, 0)
        self.total = Resource(0, 0)
        self.vm_resources = Resource(0, 0)
        self.usage = Resource(0, 0)
        self.bandwidth_overused = Resource(0, 0)
        self.service_addon = Resource(0, 0)  # Supported automatically

        self.vm_hourly_stats = []
        self.vm_last_hour_stat = None

    def get_hourly_stat(self):
        """
        Get all vm hourly stat.

        :return: list of VmStat objects
        """
        test.log.info("Get VM hourly statistics")
        return self._get_objects()

    def get_hourly_stat_for_the_last_hour(self):
        """
        Get statistics for the last hour (UTC)
        For example request time - 10:06:33 so in this case we will be
        requesting stats for 09:00:00 - 10:06:33 period.
        :return: stats for the last hour.
        """
        stats = self.get_last_hour_stats()
        if stats:
            if test.cp_version >= 5.6:
                self.__dict__.update(stats[-1].__dict__)
                return True
            else:
                self.vm_last_hour_stat = stats[-1]
                self._convert_vm_hourly_stat(self.vm_last_hour_stat)
                return self.vm_last_hour_stat
        return False

    def route(self):
        # https://onappdev.atlassian.net/browse/CORE-11264
        if test.cp_version == 5.6:
            return '{}/{}/vm_stats'.format(
                self.parent_obj.route, self.parent_obj.identifier
            )
        else:
            return '{}/{}/vm_stats'.format(
                self.parent_obj.route, self.parent_obj.id
            )

    def _convert_vm_hourly_stat(self, vm_stat):
        vm_stat.billing_stat = BillingStat(vm_stat.billing_stats)
        del vm_stat.billing_stats  # delete dict to clear memory
        for key in vm_stat.billing_stat.keys:
            print(key)
            # parts = []
            for part in vm_stat.billing_stat.__dict__[key]:
                p = Part(part)
                # costs = []
                for cost in p.costs:
                    c = Cost(cost)
                    if c.resource_name in list(vm_stat.__dict__.keys()) and \
                            key != 'service_addons':
                        vm_stat.__dict__[c.resource_name].cost += c.cost
                        vm_stat.__dict__[c.resource_name].value += c.value
                    else:
                        stat_key = '{}_{}'.format(key, c.resource_name)

                        vm_stat.__dict__[stat_key] = Resource(
                            c.cost, c.value
                        )
                        #         costs.append(c)
                        #     p.costs = costs
                        #     parts.append(p)
                        # vm_stat.billing_stat.__dict__[key] = parts

    # Attempt to use methods to get required parameter.
    # Disks
    def get_disks_data_read_cost(self):
        return self._get_disks_cost('data_read')

    def get_disks_data_read_value(self):
        return self._get_disks_value('data_read')

    def get_disks_data_written_cost(self):
        return self._get_disks_cost('data_written')

    def get_disks_data_written_value(self):
        return self._get_disks_value('data_written')

    def get_disks_input_requests_cost(self):
        return self._get_disks_cost('input_requests')

    def get_disks_input_requests_value(self):
        return self._get_disks_value('input_requests')

    def get_disks_output_requests_cost(self):
        return self._get_disks_cost('output_requests')

    def get_disks_output_requests_value(self):
        return self._get_disks_value('output_requests')

    def get_disks_count_cost(self):
        return self._get_disks_cost('count')

    def get_disks_count_value(self):
        return self._get_disks_value('count')

    def get_disks_disk_size_cost(self):
        return self._get_disks_cost('disk_size')

    def get_disks_disk_size_value(self):
        return self._get_disks_value('disk_size')

    def get_disks_disk_min_iops_cost(self):
        return self._get_disks_cost('disk_min_iops')

    def get_disks_disk_min_iops_value(self):
        return self._get_disks_value('disk_min_iops')

    # Networks
    def get_networks_data_sent_cost(self):
        return self._get_networks_cost('data_sent')

    def get_networks_data_sent_value(self):
        return self._get_networks_value('data_sent')

    def get_networks_data_received_cost(self):
        return self._get_networks_cost('data_received')

    def get_networks_data_received_value(self):
        return self._get_networks_value('data_received')

    def get_networks_count_cost(self):
        return self._get_networks_cost('count')

    def get_networks_count_value(self):
        return self._get_networks_value('count')

    def get_networks_port_speed_cost(self):
        return self._get_networks_cost('port_speed')

    def get_networks_port_speed_value(self):
        return self._get_networks_value('port_speed')

    def get_networks_ip_addresses_cost(self):
        return self._get_networks_cost('ip_addresses')

    def get_networks_ip_addresses_value(self):
        return self._get_networks_value('ip_addresses')

    # Service Addons
    def get_service_addons_count_cost(self):
        return self._get_service_addons_cost('count')

    def get_service_addons_count_value(self):
        return self._get_service_addons_value('count')

    def get_service_addons_memory_cost(self):
        return self._get_service_addons_cost('memory')

    def get_service_addons_memory_value(self):
        return self._get_service_addons_value('memory')

    def get_service_addons_cpus_cost(self):
        return self._get_service_addons_cost('cpus')

    def get_service_addons_cpus_value(self):
        return self._get_service_addons_value('cpus')

    def get_service_addons_disk_size_cost(self):
        return self._get_service_addons_cost('disk_size')

    def get_service_addons_disk_size_value(self):
        return self._get_service_addons_value('disk_size')

    # Virtual Machines
    def get_vm_cpu_time_cost(self):
        return self._get_vm_cost('cpu_time')

    def get_vm_cpu_time_value(self):
        return self._get_vm_value('cpu_time')

    def get_vm_count_cost(self):
        return self._get_vm_cost('count')

    def get_vm_count_value(self):
        return self._get_vm_value('count')

    def get_vm_cpus_cost(self):
        return self._get_vm_cost('cpus')

    def get_vm_cpus_value(self):
        return self._get_vm_value('cpus')

    def get_vm_cpu_units_cost(self):
        return self._get_vm_cost('cpu_units')

    def get_vm_cpu_units_value(self):
        return self._get_vm_value('cpu_units')

    def get_vm_cpu_shares_cost(self):
        return self._get_vm_cost('cpu_shares')

    def get_vm_cpu_shares_value(self):
        return self._get_vm_value('cpu_shares')

    def get_vm_memory_cost(self):
        return self._get_vm_cost('memory')

    def get_vm_memory_value(self):
        return self._get_vm_value('memory')

    # Since 6.0
    def get_template_cost(self):
        return self._get_vm_cost('template_usage')

    # Since 6.0
    def get_template_value(self):
        return self._get_vm_value('template_usage')

    # Since 6.0
    def get_template_id(self):
        return self._get_vm_resource_id('template_usage')

    # Instance Packages
    def get_instance_package_bandwidth_overused_cost(self):
        return self._get_instance_package_cost('bandwidth_overused')

    def get_instance_package_bandwidth_overused_value(self):
        return self._get_instance_package_value('bandwidth_overused')

    # Since 6.0
    def get_instance_package_id(self):
        return self._get_vm_resource_id('instance_package')

    def get_instance_package_cost(self):
        return self._get_vm_cost('instance_package')

    def get_instance_package_value(self):
        return self._get_vm_value('instance_package')

    # Methods to parse billing_stats
    def _get_disks_cost(self, resource_name, key='disks', param='cost'):
        return self._get_billing_stats_params(resource_name, key, param)

    def _get_disks_value(self, resource_name, key='disks', param='value'):
        return self._get_billing_stats_params(resource_name, key, param)

    def _get_networks_cost(
            self, resource_name, key="networking/network_interfaces", param='cost'
    ):
        if test.cp_version >= 5.7:
            key = 'network_interfaces'
        return self._get_billing_stats_params(resource_name, key, param)

    def _get_networks_value(
            self, resource_name, key="networking/network_interfaces", param='value'
    ):
        if test.cp_version >= 5.7:
            key = 'network_interfaces'
        return self._get_billing_stats_params(resource_name, key, param)

    def _get_service_addons_cost(self, resource_name, key='service_addons', param='cost'):
        return self._get_billing_stats_params(resource_name, key, param)

    def _get_service_addons_value(self, resource_name, key='service_addons', param='value'):
        return self._get_billing_stats_params(resource_name, key, param)

    def _get_vm_cost(self, resource_name, key='virtual_machines', param='cost'):
        return self._get_billing_stats_params(resource_name, key, param)

    def _get_vm_value(self, resource_name, key='virtual_machines', param='value'):
        return self._get_billing_stats_params(resource_name, key, param)

    def _get_vm_resource_id(self, resource_name, key='virtual_machines', param='resource_id'):
        return self._get_billing_stats_params(resource_name, key, param)

    def _get_instance_package_cost(self, resource_name, key='instance_packages', param='cost'):
        return self._get_billing_stats_params(resource_name, key, param)

    def _get_instance_package_value(self, resource_name, key='instance_packages', param='value'):
        return self._get_billing_stats_params(resource_name, key, param)

    def _get_billing_stats_params(self, resource_name, key, param=None):
        rez = []
        self.error = []
        if key in self.billing_stats:
            for resources in self.billing_stats[key]:
                # print(resources)
                for cost in resources['costs']:
                    if cost['resource_name'] == resource_name:
                        rez.append(cost[param])
        # Service addon section has been removed since 6.0
        elif key == 'service_addons' and test.cp_version >= 6.0:
            return 0
        else:
            msg = f"'{key}' key not found in billing_stats"
            self.error = [msg]
            test.log.warning(msg)
        return sum(rez)
