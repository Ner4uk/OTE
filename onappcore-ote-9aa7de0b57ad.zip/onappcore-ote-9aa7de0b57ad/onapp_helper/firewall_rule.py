from onapp_helper.base_helper import BaseHelper
from onapp_helper import test


class Command:
    drop = 'DROP'
    accept = 'ACCEPT'


class Protocol:
    tcp = 'TCP'
    udp = 'UDP'
    dccp = 'DCCP'
    sctp = 'SCTP'
    icmp = 'ICMP'


class FirewallRule(BaseHelper):
    root_tag = 'firewall_rule'
    COMMAND = Command()
    PROTOCOL = Protocol()

    def __init__(self, server=None, id=None):
        self.parent_obj = server
        self.address = ''
        self.command = ''
        self.protocol = ''
        self.network_interface_id = None
        self.port = ''
        self.id = id
        if self.id:
            test.update_object(self)

    def apply(self):
        test.log.info("Apply firewall rules")
        url = f'/{self.parent_obj.route}/{self.parent_obj.id}/update_firewall_rules.json'
        if test.post_object(self, url=url):
            if self.transaction_handler(
                "update_custom_firewall_rule", parent_id=self.parent_obj.id
            ):
                return True
        self.error = self.transaction.error
        return False

    def create(self, **kwargs):
        """
        Create a new firewall rule
        :param kwargs:
            address:
            command:
            protocol:
            network_interface_id:
            port:
        :return:
        """
        if kwargs:
            data = {self.root_tag: kwargs}
        else:
            data = {
                self.root_tag: {
                    "address": self.address,
                    "command": self.command,
                    "protocol": self.protocol,
                    "network_interface_id": self.network_interface_id,
                    "port": self.port
                }
            }
        test.log.info("Create a new firewall rule")
        return test.post_object(self, data=data)

    def edit(self, **kwargs):
        """
        Edit the firewall rule
        :param kwargs:
            address:
            command:
            protocol:
            network_interface_id:
            port:
        :return:
        """
        if kwargs:
            data = {self.root_tag: kwargs}
        else:
            data = {
                self.root_tag: {
                    "address": self.address,
                    "command": self.command,
                    "protocol": self.protocol,
                    "network_interface_id": self.network_interface_id,
                    "port": self.port
                }
            }
        test.log.info("Edit firewall rule")
        return test.put_object(self, data=data)

    def move(self, position=None):
        """
        Move firewall rule
        :param position: 'up' or 'down'
        :return:
        """
        test.log.info(
            "Move current firewall rule to {} position".format(position)
        )
        data = {'position': position}
        url = f'/{self.route()}/{self.id}/move.json'
        test.get_object(self, url=url, data=data)

    def set_default(self, rule):
        url = f'/{self.parent_obj.route}/' \
               f'{self.parent_obj.id}/' \
               f'network_interfaces/' \
               f'{self.network_interface_id}.json'
        data = {
            "network_interface": {
                "default_firewall_rule": rule
            }
        }
        test.log.info("Set default firewall rules")
        test.put_object(self, url=url, data=data)

    def route(self):
        return f'{self.parent_obj.route}/{self.parent_obj.id}/firewall_rules'
