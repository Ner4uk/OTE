# ignore
__author__ = 'zhuk'
__doc__ = """"""
__since__ = None  # Describe version since this functional available

from onapp_helper import test
from onapp_helper.base_helper import BaseHelper


class LocationGroup(BaseHelper):
    route = 'settings/location_groups'
    root_tag = 'location_group'

    def __init__(self, id=None):
        self.id = id
        if self.id:
            test.update_object(self)

    def refresh(self):
        return test.get_object(self, url=f'/{self.route}/refresh.json')

