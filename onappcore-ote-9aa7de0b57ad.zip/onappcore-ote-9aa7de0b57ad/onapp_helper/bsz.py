from onapp_helper.base_helper import BaseHelper
from onapp_helper import test


class ServerType:
    virtual = 'virtual'
    smart = 'smart'


class BSZ(BaseHelper):
    route = 'settings/backup_server_zones'
    root_tag = 'backup_server_group'
    SERVER_TYPE = ServerType()

    def __init__(self, id=None):
        self.label = 'ATBSZ'
        self.location_group_id = None
        self.id = id
        self.server_type = self.SERVER_TYPE.virtual
        if self.id:
            test.update_object(self)

    def create(self):
        test.log.info("Create Backup Server Zone...")
        data = {
            self.root_tag: {
                "label": self.label,
                "location_group_id": self.location_group_id,
                "server_type": self.server_type
            }
        }
        return test.post_object(self, data=data)

    def edit(self):
        test.log.info("Edit Backup Server Zone...")
        data = {
            self.root_tag: {
                "label": self.label,
                "location_group_id": self.location_group_id
            }
        }
        return test.put_object(self, data=data)

    def attach_bs(self, bs_obj):
        test.log.info("Attach Backup Server to Zone...")
        url = '/{0}/{1}/backup_servers/{2}/attach.json'.format(
            self.route, self.id, bs_obj.id
        )
        return test.post_object(self, url=url)

    def detach_bs(self, bs_obj):
        test.log.info("Detach Backup Server from Zone...")
        url = '/{0}/{1}/backup_servers/{2}/detach.json'.format(
            self.route, self.id, bs_obj.id
        )
        return test.post_object(self, url=url)

    def get_any(self):
        test.log.info("Get any backup server zone...")
        bs_zones = self.get_all()
        if bs_zones:
            self.__dict__.update(bs_zones[0].__dict__)
            return True
        return False

    def get_by_label(self, label):
        test.log.info("Get backup server zone by label...")
        bs_zones = self.get_all()
        if bs_zones:
            bsz = [
                zone for zone in bs_zones
                if label.lower() in zone.label.lower()
                ]
            if bsz:
                self.__dict__.update(bsz[0].__dict__)
                return True
        return False