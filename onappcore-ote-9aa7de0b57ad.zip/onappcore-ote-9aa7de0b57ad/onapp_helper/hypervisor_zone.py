from time import sleep

from onapp_helper import test
from onapp_helper.backup_server_join import BackupServerJoin
from onapp_helper.base_helper import BaseHelper
from onapp_helper.data_store_join import DataStoreJoin
from onapp_helper.hypervisor import Hypervisor
from onapp_helper.network_join import NetworkJoin


class ServerType:
    virtual = 'virtual'
    baremetal = 'baremetal'
    vpc = 'vpc'
    smart = 'smart'
    osm = 'osm'


class HypervisorZone(BaseHelper):
    route = 'settings/hypervisor_zones'
    root_tag = 'hypervisor_group'
    SERVER_TYPE = ServerType()

    def __init__(self, id=None):
        self.label = 'ATHypervisorZone'
        self.server_type = self.SERVER_TYPE.virtual
        self.location_group_id = None
        self.release_resource_type = "memory_guarantee"
        self.max_vms_start_at_once = 5
        self.recovery_type = "roundrobin"
        self.failover_timeout = 15
        self.run_sysprep = True
        self.default_gateway = ''
        self.vlan = ''
        self.cpu_units = 1000
        self.custom_config = ''

        self.id = id
        if self.id:
            test.update_object(self)

    def create(self):
        test.log.info("Create hypervisor zone...")
        data = {
            self.root_tag: {
                "label": self.label,
                "server_type": self.server_type,
                "location_group_id": self.location_group_id,
                "release_resource_type": self.release_resource_type,
                "max_vms_start_at_once": self.max_vms_start_at_once,
                "recovery_type": self.recovery_type,
                "failover_timeout": self.failover_timeout,
                "run_sysprep": self.run_sysprep,
                "default_gateway": self.default_gateway,
                "vlan": self.vlan,
                "cpu_units": self.cpu_units,
                "custom_config": self.custom_config
            }
        }
        if test.cp_version < 5.6:
            del data[self.root_tag]['custom_config']
        return test.post_object(self, data=data)

    def edit(self):
        test.log.info("Edit hypervisor zone...")
        data = {
            self.root_tag: {
                "label": self.label,
                "server_type": self.server_type,
                "location_group_id": self.location_group_id,
                "release_resource_type": self.release_resource_type,
                "max_vms_start_at_once": self.max_vms_start_at_once,
                "recovery_type": self.recovery_type,
                "failover_timeout": self.failover_timeout,
                "run_sysprep": self.run_sysprep,
                "default_gateway": self.default_gateway,
                "vlan": self.vlan,
                "cpu_units": self.cpu_units
            }
        }
        return test.put_object(self, data=data)

    def attach_hv(self, hv):
        test.log.info("Attach hypervisor to zone...")
        url = '/{0}/{1}/hypervisors/{2}/attach.json'.format(
            self.route, self.id, hv.id
        )
        return test.post_object(self, url=url)

    def detach_hv(self, hv):
        test.log.info("Detach hypervisor from zone...")
        url = '/{0}/{1}/hypervisors/{2}/detach.json'.format(
            self.route, self.id, hv.id
        )
        return test.post_object(self, url=url)

    def get_any(self):
        """
        Return the array of objects
        """
        test.log.info("Get any hypervisor zone...")
        return self.get_by_params()

    def get_by_params(self, parameters=None):
        """
        Return the array of objects
        """
        test.log.info("Get hypervisor zone by parameters...")
        objects = []
        for hvz in self.get_all():
            is_ok = True
            if parameters:
                for key, value in list(parameters.items()):
                    if not hvz.__dict__[key] == value:
                        is_ok = False
                        break
            if is_ok:
                objects.append(hvz)
        return objects

    def data_store_joins(self):
        test.log.info("Get list of data store joins.")
        return DataStoreJoin()._get_objects(
            route="{0}/{1}/data_store_joins".format(self.route, self.id)
        )

    def network_joins(self):
        test.log.info("Get list of network joins.")
        return NetworkJoin()._get_objects(
            route="{0}/{1}/network_joins".format(self.route, self.id)
        )

    def backup_server_joins(self):
        test.log.info("Get list of backup server joins.")
        return BackupServerJoin()._get_objects(
            route="{0}/{1}/backup_server_joins".format(self.route, self.id)
        )

    def attached_hypervisors(self):
        test.log.info("Get list of attached hypervisors...")
        return Hypervisor()._get_objects(
            route="{0}/{1}/hypervisors".format(self.route, self.id)
        )

    def get_is_nodes(self):
        return ISNode(self).get_all()


class ISNode(BaseHelper):
    root_tag = 'node'

    def __init__(self, parent_obj):
        self.parent_obj = parent_obj

    def route(self):
        return 'storage/{}/nodes'.format(self.parent_obj.id)


class ISDataStore(BaseHelper):
    """Not really IS datastore, but the abstract object for limited amount of operations on IS
    After instantiation it contains info on HV zone and all the IS nodes in it"""
    root_tag = 'storage_data_store'
    nodes = None
    name = "ATISDataStore"
    replicas = 1
    stripes = 1
    overcommit = 0
    description = ''

    def __init__(self, parent_obj):
        self.parent_obj = parent_obj

    def route(self):
        return 'storage/{}/data_stores'.format(self.parent_obj.id)

    def create(self):
        test.log.info("Normalizing performance on all IS nodes...")
        for node in self.nodes:
            data = {
                'storage_node': {
                    "performance": 1},  # 0-low,1-normal,2-high
                "endpoint_id": self.parent_obj.id,
                "id": node.id,
            }
            if not test.patch_object(self, url=f"/storage/{self.parent_obj.id}/nodes/{node.id}.json", data=data):
                test.log.error(f"Failed to change nodes performance")
                return False
        test.log.warning("Waiting for nodes to propagate a new performance...")
        sleep(200)  # TODO create a unified constant for all sleep ops, to change all them at once in one place
        test.log.info(f"Create IS datastore in hypervisor zone  {self.parent_obj.label}...")
        data = {
            self.root_tag: {
                "name": self.name,
                "replicas": str(self.replicas),
                "stripes": str(self.stripes),
                "overcommit": str(self.overcommit),
                "node_ids": [node.id for node in self.nodes],
                "endpoint_id": self.parent_obj.id
            }
        }
        return test.post_object(self, data=data)

    def clean_up_zombie_disks(self):
        """Removes zombie disks on all datastores within HV zone"""
        test.log.info(f"Cleaning up zombies in {self.parent_obj.label}...")
        data = {
            "endpoint_id": self.parent_obj.id,
            "storage_health_check_id": 'zombie_disks'
        }
        return test.post_object(self, url=f"/storage/{self.parent_obj.id}/health_checks/zombie_disks/repair_all",
                                data=data)

    def no_zombie_disks(self):
        test.log.info(f"Searching zombies in {self.parent_obj.label}...")
        assert test.get_object(
            self,
            url=f"/storage/{self.parent_obj.id}/health_checks/zombie_disks"
        ), "Cant get zombie disks"
        if self.description == 'Some zombie disks found':
            return False
        return True
