from onapp_helper import test
from onapp_helper.backup import Backup
from onapp_helper.base_helper import BaseHelper
from onapp_helper.payment import Payment
from onapp_helper.ssh_key import SshKey


class User(BaseHelper):
    route = 'users'
    root_tag = route[:-1]

    def __init__(self, user_id=None, bp=None, bucket=None):
        if test.api_version >= 5.6:
            # To keep compatibility with previous tests
            bucket = bucket if bucket else bp
            self.bucket_id = bucket.id if bucket else ''
        else:
            self.bp = bp
            self.billing_plan_id = self.bp.id if self.bp else ''

        self.id = user_id
        self.login = ''
        self.email = ''
        self.password = ''
        self.user_group_id = None
        self.role_ids = [1]
        self.outstanding_amount = 0
        self.payment_amount = 0
        self.total_amount = 0
        self.suspend_after_hours = None
        self.activated_at = None
        self.suspend_at = None
        #self.backups = []
        if self.id:
            test.update_object(self)
        # Since 5.7 https://onappdev.atlassian.net/browse/CORE-10885
        self.monthly_price = 0
        self.discount_due_to_free = 0
        self.total_amount_with_discount = 0
        self.ssh_key = SshKey()

        self.white_list = WhiteList(parent_obj=self)  # White list obj

        self.monthly_bills = MonthlyBill(parent_obj=self)

    def get_all(self, show_deleted=False, short=False):
        test.log.info("Get all users, show_deleted - {}".format(show_deleted))
        return self._get_objects(data={"show_deleted": show_deleted,
                                       "short": short})

    def create(self, **kwargs):
        """
        You can create a new user using self attributes as login, email etc., or
        passing them as kwargs params (login='test', email='test@t.com', ...)
        :param kwargs: login, email, password, role_ids, user_group_id, suspend_after_hours
        :return: True if success else False
        """
        test.log.info("Create a new User...")
        if kwargs:
            data = {self.root_tag: kwargs}
        else:
            data = {
                self.root_tag: {
                    "login": self.login,
                    "email": self.email,
                    "password": self.password,
                    "role_ids": self.role_ids,
                    "user_group_id": self.user_group_id,
                    "suspend_after_hours": self.suspend_after_hours
                }
            }
        if test.api_version < 5.6:
            data[self.root_tag]["billing_plan_id"] = self.billing_plan_id
        else:
            data[self.root_tag]["bucket_id"] = self.bucket_id

        return test.post_object(self, data=data)

    def edit(self, **kwargs):
        """
        Edit User.
        :param login: user login
        :param email: user email
        :param password: user password
        :param role_ids: an array of user role_ids
        if test.cp_version < 5.6
        :param billing_plan_id: user billing_plan_id
        else
        :param bucket_id: user bucket_id
        :param user_group_id: user group id
        :param first_name: user first_name
        :param last_name: user last_name
        :param suspend_at: user suspend_at
        :param registered_yubikey: user registered_yubikey
        :return:
        """
        test.log.info("Edit user...")
        data = {self.root_tag: {}}

        for key, value in list(kwargs.items()):
            data[self.root_tag][key] = value

        return test.put_object(self, data=data)

    def suspend(self):
        test.log.info("Making User as suspend...")
        url = '/{0}/{1}/suspend.json'.format(self.route, self.id)
        return test.post_object(self, url=url)

    def activate(self):
        test.log.info("Activate User...")
        url = '/{0}/{1}/activate.json'.format(self.route, self.id)
        return test.post_object(self, url=url)

    def delete(self, force=True):
        test.log.info("Delete User...")
        if test.delete_object(self, data={"force": force}):
            if self.transaction_handler("destroy_user", self.id):
                if force:
                    if test.wait_for_action(
                        lambda: not test.update_object(self)
                    ):
                        return True
                else:
                    if self.get() and self.status == 'deleted' or not self.get():
                        return True
        return False

    def add_ssh_key(self):
        """
        Add ssh key to user profile
        """
        return self.ssh_key.add(user_id=self.id)

    def remove_ssh_key(self):
        """
        Remove ssh key from user profile
        """
        return self.ssh_key.delete()

    def search(self, phrase='', page=None, per_page=None):
        """
        Search users by phrase
        """
        test.log.info("Search user by phrase '{0}'...".format(phrase))
        query = ''
        if page:
            query += '/page/{}'.format(page)
        if per_page:
            query += '/per_page/{}'.format(per_page)
        if phrase:
            if page or per_page:
                query += '?q={0}'.format(phrase)
            else:
                query += 'q={0}'.format(phrase)

        return self._get_objects(query=query)

    def get_own_virtual_servers(self):
        """
        Return the array of user servers
        """
        test.log.info("Get user servers...")
        #  to prevent recursion import
        from onapp_helper.server import VirtualServer
        return VirtualServer()._get_objects(
            route='{0}/{1}/virtual_machines'.format(self.route, self.id)
        )

    def generate_api_key(self):
        test.log.info("Generate a new api key")
        url = '/{}/{}/make_new_api_key.json'.format(self.route, self.id)
        return test.post_object(self, url=url)

    def backups(
            self,
            searching=None,
            size_from=None,
            size_to=None,
            start_date=None,
            end_date=None
    ):
        """
        Get user backups
        :param searching: a word in backup name
        :param size_from: The size should be indicated in MB.
        :param size_to: The size should be indicated in MB.
        :param start_date: The date should be indicated in the YYYY-MM-DD format.
        :param end_date: The date should be indicated in the YYYY-MM-DD format.
        :return: an array of backups objects.
        """
        test.log.info("Get users backups")

        search_keys = {
            'searching': 'searching',
            'size_from': 'size[from]',
            'size_to': 'size[to]',
            'start_date': 'period[startdate]',
            'end_date': 'period[enddate]',

        }

        return Backup()._search(
            search_keys=search_keys,
            route='{0}/{1}/backups_search'.format(self.route, self.id),
            searching=searching,
            size_from=size_from,
            size_to=size_to,
            start_date=start_date,
            end_date=end_date
        )

    def get_payments(self):
        """
        Get all users payments
        :return: a list of payment objects
        """
        test.log.info("Get {} payments".format(self.__class__.__name__))
        return Payment()._get_objects(
            route='{}/{}/payments'.format(self.route, self.id)
        )

    def clear_white_list_ips(self):
        test.log.info("Clear users white list.")
        url = '/{}/{}/user_white_lists/clear.json'.format(self.route, self.id)
        return test.post_object(url=url)

    def profile(self):
        """
        Update self attributes from profile page
        :return: True if success else False
        """
        return test.get_object(self, url='/profile.json')


class MonthlyBill(BaseHelper):
    month = None
    cost = None
    root_tag = 'vm_stat'

    def __init__(self, parent_obj=None):
        self.parent_obj = parent_obj

    def route(self):
        return '{}/{}/monthly_bills'.format(
            self.parent_obj.route, self.parent_obj.id
        )


class WhiteList(BaseHelper):
    root_tag = 'user_white_list'

    def __init__(self, parent_obj=None):
        self.parent_obj = parent_obj

    def create(self, ip=None, description=None):
        test.log.info(f"Add {ip} to {self.parent_obj} white list")
        data = {
            self.root_tag: {
                'ip': ip,
                'description': description
            }
        }
        return test.post_object(self, data=data)

    def clear(self):
        test.log.info(f"Clear {self.parent_obj} white list.")
        url = f'/{self.parent_obj.route}/{self.parent_obj.id}/user_white_lists/clear.json'
        return test.post_object(url=url)

    def route(self):
        return f'{self.parent_obj.route}/{self.parent_obj.id}/user_white_lists'