# # API calls for the following:
#
# View Hardware Info
# View Hardware Info Custom Fields
# Add Hardware Info Custom Field
# Remove Hardware Info Custom Field
# Update Hardware Info Custom Field

from onapp_helper import test
from onapp_helper.base_helper import BaseHelper


class CustomFields:
    uptime = "uptime"
    cpu = "cpu"
    memory = "memory"
    server_type = "server_type"
    os = "os"
    manufacturer_model = "manufacturer_model"
    bios_serial_number = "bios_serial_number"
    cpu_sockets = "cpu_sockets"
    memory_slots = "memory_slots"
    disks = "disks"
    nics = "nics"


class HardwareInfo(BaseHelper):
    __since__ = 5.7  # https://onappdev.atlassian.net/browse/CORE-10736
    root_tag = "hardware_info"
    CUSTOM_FIELDS = CustomFields()

    def __init__(self, parent_obj):
        self.parent_obj = parent_obj

    def get(self):
        url = '/{}.json'.format(self.route())
        return test.get_object(self, url=url)

    def update_info(self):
        url = '/{}.json'.format(self.route())
        if test.put_object(self, url=url):
            return self.transaction_handler(
                "update_hardware_info", parent_id=self.parent_obj.id
            )
        return False

    def get_custom_fields(self):
        url = "/{}/custom_fields.json".format(self.route())
        return test.get_object(self, url=url)

    def add_custom_field(
            self,
            label,
            value,
            custom_field=None,
            slots=False,
            slot_pos=None
    ):
        data = {
            "custom_fields": {
                "label": label,
                "value": value
            }
        }

        if slots:
            url = "/{}/custom_fields/{}_slots/slot/{}.json".format(
                self.route(), custom_field, slot_pos
            )
        else:
            url = "/{}/custom_fields/{}.json".format(
                self.route(), custom_field
            )

        return test.post_object(self, url=url, data=data)

    def edit_custom_field(
            self,
            label,
            value,
            custom_field=None,
            slots=False,
            position=None,
            slot_pos=None
    ):
        data = {
            "custom_fields": {
                "label": label,
                "value": value
            }
        }

        if slots:
            url = "/{}/custom_fields/{}_slots/slot/{}/{}.json".format(
                self.route(), custom_field, position, slot_pos
            )
        else:
            url = "/{}/custom_fields/{}/{}.json".format(
                self.route(), custom_field, position
            )

        return test.put_object(self, url=url, data=data)

    def delete_custom_field(
            self,
            custom_field=None,
            slots=False,
            position=None,
            slot_pos=None
    ):
        if slots:
            url = "/{}/custom_fields/{}_slots/slot/{}/{}.json".format(
                self.route(), custom_field, position, slot_pos
            )
        else:
            url = "/{}/custom_fields/{}/{}.json".format(
                self.route(), custom_field, position
            )

        return test.delete_object(self, url=url)

    def route(self):
        return "{}/{}/hardware_info".format(
            self.parent_obj.route, self.parent_obj.id
        )
