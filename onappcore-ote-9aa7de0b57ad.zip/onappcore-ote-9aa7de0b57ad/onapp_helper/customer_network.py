from onapp_helper.base_helper import BaseHelper
from onapp_helper import test


class CustomerNetwork(BaseHelper):
    def __init__(self, user, id=None):
        self.route = '{0}/{1}/customer_networks'.format(user.route, user.id)
        self.root_tag = 'customer_network'
        self.id = id
        if self.id:
            test.update_object(self)

    def create(self):
        test.log.info("Create Customer Network...")
        data = {
            self.root_tag: {
                "default_outside_ip_address": {
                    "hypervisor_id": test.env.hv.id
                },
                "ip_address_pool_id": "1",
                "label": "zaza_test",
                "prefix_size": "29",
                "network_group_id": test.env.netz.id,
                "is_nated": "1"
            }
        }
        return test.post_object(self, data=data)
