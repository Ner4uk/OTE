import os
import ipaddress

import ipaddress
from onapp_helper import test
from onapp_helper.base_helper import BaseHelper
from onapp_helper.disk import Disk
from onapp_helper.networks import Network
from onapp_helper.user import User


class VirtualMachineHelper(BaseHelper):
    def associated_datastores_ids(self):
        """Return array of datastore ids associated with current Server."""
        test.log.info("Get associated data stores ids...")
        # Get an array of data stores associated with current VS
        #self._get_handler('/{0}/{1}/disks.json'.format(self.route, self.id))
        return [disk.data_store_id for disk in Disk(parent_obj=self).get_all()]

    def disks(self):
        """Return an array of server's disk object."""
        test.log.info("Get servers disks...")
        return Disk(parent_obj=self)._get_objects(
            route='{0}/{1}/disks'.format(self.route, self.id),
            parent_obj=self
        )

    def is_swap_present(self):
        test.log.info("Check if swap is present...")
        if [d for d in self.disks() if d.is_swap]:
            return True
        return False

    def primary_ip_address(self):
        ip_address = ''
        if self.route == 'baremetal_servers':
            ip_address = self.ip_addresses[0]['ip_address']['address']
        else:
            # Has been rewritten in OnApp interface
            # if test.cp_version >= 5.4:
            #     ip_address = IpAddress().get_key_values(
            #         'address', related_obj=self
            #     )[0]
            # else:
            primary_ip_join = self.ip_address_join.get_primary()
            if primary_ip_join:
                ip_address = primary_ip_join.ip_address['address']
        return ip_address

    def port_speed(self, network_interface=None):
        """ Return real network port speed. Unlimited - 0,
            would be replaced to 'max_network_interface_port_speed' from settings.

        :param network_interface: network_interface obj, get for primary if
        not defined
        """
        test.log.info("Get port speed...")
        if not network_interface:
            network_interface = self.network_interface.get_primary()
        vm_network_interface_port_speed = network_interface.rate_limit
        if not vm_network_interface_port_speed:
            vm_network_interface_port_speed = test.onapp_settings.max_network_interface_port_speed
        return vm_network_interface_port_speed

    def get_primary_disk(self):
        """Return primary disk obj."""
        test.log.info("Get primary disk...")
        return [disk for disk in self.disks() if disk.primary][0]

    def get_swap_disk(self):
        """Return primary disk obj."""
        test.log.info("Get swap disk...")
        return [disk for disk in self.disks() if disk.is_swap][0]

    def ping(self, timeout=60, target=None):
        """
        Ping the server

        :param timeout: ping timeout
        :param target: ip address
        :return: True if success else False
        """
        ip = self.ip_address if not target else target
        if not ip:
            test.log.error(f"Invalid IP address - {ip}")
            return False
        cmd = f"ping -ot {timeout} {ip}"
        test.log.info("Ping the server...")
        test.log.info(cmd)
        return os.system(cmd) == 0

    def price_on_calculated(
            self, hvz_br=None, dsz_br=None, ntz_br=None,
            hvz_rc=None, dsz_rc=None, ntz_rc=None
    ):
        """
          Calculate total price for powered on VS

          Parameters related to old billing
        :param hvz_br: HVZ base resource object
        :param dsz_br: DSZ base resource object
        :param ntz_br: NTZ base resource object

          Parameters related to new billing
        :param hvz_rc: HVZ rate card
        :param dsz_rc: DSZ rate card
        :param ntz_rc: NTZ rate card

        :return: Total price for powered on VS
        """
        if test.cp_version >= 5.6 and test.api_version >= 5.6:
            return self._price_on_calculated_for_bucket(
                hvz_rc=hvz_rc, dsz_rc=dsz_rc, ntz_rc=ntz_rc
            )

        # price ON
        test.log.info("Get price ON...")
        user_servers = User(user_id=self.user_id).get_own_virtual_servers()
        test.update_object(self)
        #  Calculate Price for HVZ
        hvz_price = 0.0
        if hvz_br:
            total_cpus = sum((int(vs.cpus) for vs in user_servers))
            self.cpu_price_on = 0.0
            not_free_cpus = total_cpus - int(hvz_br.limits.limit_free_cpu)
            if not_free_cpus > 0:
                self.cpu_price_on = not_free_cpus * float(hvz_br.prices.price_on_cpu)

            total_cpu_chares = total_cpus * sum((int(vs.cpu_shares) for vs in user_servers))
            self.cpu_shares_price_on = 0.0
            not_free_cpu_shares = total_cpu_chares - int(hvz_br.limits.limit_free_cpu_share)
            if not_free_cpu_shares > 0:
                self.cpu_shares_price_on = not_free_cpu_shares * float(hvz_br.prices.price_on_cpu_share)

            total_memory = sum((int(vs.memory) for vs in user_servers))
            self.memory_price_on = 0.0
            not_free_memory = total_memory - int(hvz_br.limits.limit_free_memory)
            if not_free_memory > 0:
                self.memory_price_on = not_free_memory * float(hvz_br.prices.price_on_memory)

            hvz_price = self.cpu_price_on + self.cpu_shares_price_on + self.memory_price_on

        #  Calculate Price for DSZ
        dsz_price = 0.0
        if dsz_br:
            total_disks_size = sum((int(vs.total_disk_size) for vs in user_servers))
            self.disks_price_on = 0.0
            not_free_disks_size = total_disks_size - int(dsz_br.limits.limit_free)
            if not_free_disks_size > 0:
                self.disks_price_on = not_free_disks_size * float(dsz_br.prices.price_on)

            dsz_price = self.disks_price_on

        #  Calculate Price for NTZ
        ntz_price = 0.0
        if ntz_br:
            total_ips = sum(
                (len(vs.ip_address_join.get_all()) for vs in user_servers)
            )
            # if test.cp_version <= 5.3:
            #     total_ips = sum(
            #         (len(vs.ip_address_join.get_all()) for vs in user_servers)
            #     )
            # else:
            #     total_ips = sum(
            #         (
            #             len(
            #                 IpAddress().get_all(related_obj=vs)
            #             ) for vs in user_servers
            #         )
            #     )
            self.ip_price_on = 0.0
            not_free_ips = total_ips - int(ntz_br.limits.limit_ip_free)
            if not_free_ips > 0:
                self.ip_price_on = not_free_ips * float(ntz_br.prices.price_ip_on)

            # Checking for unlimited value #######################################################################################
            try:
                br_rate_limit_free = int(ntz_br.limits.limit_rate_free)
            except TypeError:
                br_rate_limit_free = test.onapp_settings.get().max_network_interface_port_speed
            ######################################################################################################################
            total_rate_limit = sum((vs.port_speed() for vs in user_servers))
            self.rate_limit_price_on = 0.0
            not_free_rate_limit = total_rate_limit - br_rate_limit_free
            if not_free_rate_limit > 0:
                self.rate_limit_price_on = not_free_rate_limit * float(ntz_br.prices.price_rate_on)

            ntz_price = self.ip_price_on + self.rate_limit_price_on

        price_on = hvz_price + dsz_price + ntz_price
        return price_on

    def _price_on_calculated_for_bucket(
            self, hvz_rc=None, dsz_rc=None, ntz_rc=None
    ):
        """
        Not include free limits
        :param hvz_rc:
        :param dsz_rc:
        :param ntz_rc:
        :return:
        """
        # price ON
        test.log.info("Get price ON...")
        user_servers = User(user_id=self.user_id).get_own_virtual_servers()
        test.update_object(self)
        #  Calculate Price for HVZ
        hvz_price = 0.0
        if hvz_rc:
            total_cpus = sum((int(vs.cpus) for vs in user_servers))
            self.cpu_price_on = 0.0
            # not_free_cpus = total_cpus - int(hvz_rc.prices.limit_free_cpu)
            # if not_free_cpus > 0:
            #     self.cpu_price_on = not_free_cpus * float(
            #         hvz_rc.prices.price_on_cpu
            #     )
            self.cpu_price_on = total_cpus * float(
                hvz_rc.prices.price_on_cpu
            )

            total_cpu_shares = total_cpus * sum(
                (int(vs.cpu_shares) for vs in user_servers)
            )
            self.cpu_shares_price_on = 0.0
            # not_free_cpu_shares = total_cpu_shares - int(
            #     hvz_rc.prices.limit_free_cpu_share
            # )
            # if not_free_cpu_shares > 0:
            #     self.cpu_shares_price_on = not_free_cpu_shares * float(
            #         hvz_rc.prices.price_on_cpu_share
            #     )
            self.cpu_shares_price_on = total_cpu_shares * float(
                hvz_rc.prices.price_on_cpu_share
            )

            total_memory = sum((int(vs.memory) for vs in user_servers))
            self.memory_price_on = 0.0
            # not_free_memory = total_memory - int(
            #     hvz_rc.prices.limit_free_memory
            # )
            # if not_free_memory > 0:
            #     self.memory_price_on = not_free_memory * float(
            #         hvz_rc.prices.price_on_memory
            #     )
            self.memory_price_on = total_memory * float(
                hvz_rc.prices.price_on_memory
            )

            hvz_price = self.cpu_price_on + \
                        self.cpu_shares_price_on + \
                        self.memory_price_on

        #  Calculate Price for DSZ
        dsz_price = 0.0
        if dsz_rc:
            total_disks_size = sum(
                (int(vs.total_disk_size) for vs in user_servers)
            )
            self.disks_price_on = 0.0
            # not_free_disks_size = total_disks_size - int(
            #     dsz_rc.prices.limit_free
            # )
            # if not_free_disks_size > 0:
            self.disks_price_on = total_disks_size * float(
                dsz_rc.prices.price_on
            )

            dsz_price = total_disks_size * float(
                dsz_rc.prices.price_on
            )

        #  Calculate Price for NTZ
        ntz_price = 0.0
        if ntz_rc:
            total_ips = sum(
                (len(vs.ip_address_join.get_all()) for vs in user_servers)
            )
            # if test.cp_version <= 5.3:
            #     total_ips = sum(
            #         (len(vs.ip_address_join.get_all()) for vs in user_servers)
            #     )
            # else:
            #     total_ips = sum(
            #         (
            #             len(
            #                 IpAddress().get_all(related_obj=vs)
            #             ) for vs in user_servers
            #         )
            #     )
            self.ip_price_on = 0.0
            # not_free_ips = total_ips - int(ntz_rc.prices.limit_ip_free)
            # if not_free_ips > 0:
            #     self.ip_price_on = not_free_ips * float(
            #         ntz_rc.prices.price_ip_on
            #     )

            self.ip_price_on = total_ips * float(
                    ntz_rc.prices.price_ip_on
                )

            # Checking for unlimited value #####################################
            # try:
            #     br_rate_limit_free = int(ntz_rc.prices.limit_rate_free)
            # except TypeError:
            #     br_rate_limit_free = test.onapp_settings.get().max_network_interface_port_speed
            ####################################################################
            total_rate_limit = 0
            network_interfaces = []
            # Get network_interfaces for all users vs
            for vs in user_servers:
                network_interfaces.extend(vs.network_interface.get_all())

            # In case network_interface relates to network from bucket we
            # should include free limit.
            for network_interface in network_interfaces:
                net_join = [
                    nj for nj in test.env.network_joins
                    if nj.id == network_interface.network_join_id
                ][0]
                network = Network(id=net_join.network_id)

                vm_network_interface_port_speed = network_interface.rate_limit
                if not vm_network_interface_port_speed:
                    vm_network_interface_port_speed = test.onapp_settings.max_network_interface_port_speed

                if network.network_group_id == test.env.netz.id:
                    total_rate_limit += vm_network_interface_port_speed - \
                                        ntz_rc.prices.limit_rate_free
                else:
                    total_rate_limit += vm_network_interface_port_speed

            self.rate_limit_price_on = 0.0
            # not_free_rate_limit = total_rate_limit - br_rate_limit_free
            # if not_free_rate_limit > 0:
            #     self.rate_limit_price_on = not_free_rate_limit * float(
            #         ntz_rc.prices.price_rate_on
            #     )
            self.rate_limit_price_on = total_rate_limit * float(
                    ntz_rc.prices.price_rate_on
                )

            ntz_price = self.ip_price_on + self.rate_limit_price_on

        price_on = hvz_price + dsz_price + ntz_price
        return price_on

    def price_off_calculated(
            self, hvz_br=None, dsz_br=None, ntz_br=None,
            hvz_rc=None, dsz_rc=None, ntz_rc=None
    ):
        """
          Calculate total price for powered off VS

          Parameters related to old billing
        :param hvz_br: HVZ base resource object
        :param dsz_br: DSZ base resource object
        :param ntz_br: NTZ base resource object

          Parameters related to new billing
        :param hvz_rc: HVZ rate card
        :param dsz_rc: DSZ rate card
        :param ntz_rc: NTZ rate card

        :return: Total price for powered off VS
        """
        if test.cp_version >= 5.6 and test.api_version >= 5.6:
            return self._price_off_calculated_for_bucket(
                hvz_rc=hvz_rc, dsz_rc=dsz_rc, ntz_rc=ntz_rc
            )

        # price OFF
        test.log.info("Get price OFF...")
        user_servers = User(user_id=self.user_id).get_own_virtual_servers()
        test.update_object(self)
        #  Calculate Price for HVZ
        hvz_price = 0.0
        if hvz_br:
            total_cpus = sum((int(vs.cpus) for vs in user_servers))
            self.cpu_price_off = 0.0
            not_free_cpus = total_cpus - int(hvz_br.limits.limit_free_cpu)
            if not_free_cpus > 0:
                self.cpu_price_off = not_free_cpus * float(hvz_br.prices.price_off_cpu)

            total_cpu_chares = total_cpus * sum((int(vs.cpu_shares) for vs in user_servers))
            self.cpu_shares_price_off = 0.0
            not_free_cpu_shares = total_cpu_chares - int(hvz_br.limits.limit_free_cpu_share)
            if not_free_cpu_shares > 0:
                self.cpu_shares_price_off = not_free_cpu_shares * float(hvz_br.prices.price_off_cpu_share)

            total_memory = sum((int(vs.memory) for vs in user_servers))
            self.memory_price_off = 0.0
            not_free_memory = total_memory - int(hvz_br.limits.limit_free_memory)
            if not_free_memory > 0:
                self.memory_price_off = not_free_memory * float(hvz_br.prices.price_off_memory)

            hvz_price = self.cpu_price_off + self.cpu_shares_price_off + self.memory_price_off

        #  Calculate Price for DSZ
        dsz_price = 0.0
        if dsz_br:
            total_disks_size = sum((int(vs.total_disk_size) for vs in user_servers))
            self.disks_price_off = 0.0
            not_free_disks_size = total_disks_size - int(dsz_br.limits.limit_free)
            if not_free_disks_size > 0:
                self.disks_price_off = not_free_disks_size * float(dsz_br.prices.price_off)

            dsz_price = self.disks_price_off

        #  Calculate Price for NTZ
        ntz_price = 0.0
        if ntz_br:
            # if test.cp_version <= 5.3:
            #     total_ips = sum(
            #         (len(vs.ip_address_join.get_all()) for vs in user_servers)
            #     )
            # else:
            #     total_ips = sum(
            #         (
            #             len(
            #                 IpAddress().get_all(related_obj=vs)
            #             ) for vs in user_servers
            #         )
            #     )
            total_ips = sum(
                (len(vs.ip_address_join.get_all()) for vs in user_servers)
            )
            self.ip_price_off = 0.0
            not_free_ips = total_ips - int(ntz_br.limits.limit_ip_free)
            if not_free_ips > 0:
                self.ip_price_off = not_free_ips * float(ntz_br.prices.price_ip_off)

            # Checking for unlimited value #######################################################################################
            try:
                br_rate_limit_free = int(ntz_br.limits.limit_rate_free)
            except TypeError:
                br_rate_limit_free = test.onapp_settings.get().max_network_interface_port_speed
            ######################################################################################################################
            total_rate_limit = sum((vs.port_speed() for vs in user_servers))
            self.rate_limit_price_off = 0.0
            not_free_rate_limit = total_rate_limit - br_rate_limit_free
            if not_free_rate_limit > 0:
                self.rate_limit_price_off = not_free_rate_limit * float(ntz_br.prices.price_rate_off)

            ntz_price = self.ip_price_off + self.rate_limit_price_off

        price_off = hvz_price + dsz_price + ntz_price
        return price_off

    def _price_off_calculated_for_bucket(
            self, hvz_rc=None, dsz_rc=None, ntz_rc=None
    ):
        # price OFF
        test.log.info("Get price OFF...")
        user_servers = User(user_id=self.user_id).get_own_virtual_servers()
        test.update_object(self)
        #  Calculate Price for HVZ
        hvz_price = 0.0
        if hvz_rc:
            total_cpus = sum((int(vs.cpus) for vs in user_servers))
            self.cpu_price_off = 0.0
            # not_free_cpus = total_cpus - int(hvz_rc.prices.limit_free_cpu)
            # if not_free_cpus > 0:
            #     self.cpu_price_off = not_free_cpus * float(
            #         hvz_rc.prices.price_off_cpu
            #     )
            self.cpu_price_off = total_cpus * float(
                hvz_rc.prices.price_off_cpu
            )

            total_cpu_chares = total_cpus * sum(
                (int(vs.cpu_shares) for vs in user_servers)
            )
            self.cpu_shares_price_off = 0.0
            # not_free_cpu_shares = total_cpu_chares - int(
            #     hvz_rc.prices.limit_free_cpu_share
            # )
            # if not_free_cpu_shares > 0:
            #     self.cpu_shares_price_off = not_free_cpu_shares * float(
            #         hvz_rc.prices.price_off_cpu_share
            #     )
            self.cpu_shares_price_off = total_cpu_chares * float(
                hvz_rc.prices.price_off_cpu_share
            )

            total_memory = sum((int(vs.memory) for vs in user_servers))
            self.memory_price_off = 0.0
            # not_free_memory = total_memory - int(
            #     hvz_rc.prices.limit_free_memory
            # )
            # if not_free_memory > 0:
            #     self.memory_price_off = not_free_memory * float(
            #         hvz_rc.prices.price_off_memory
            #     )
            self.memory_price_off = total_memory * float(
                hvz_rc.prices.price_off_memory
            )

            hvz_price = self.cpu_price_off + self.cpu_shares_price_off + self.memory_price_off

        #  Calculate Price for DSZ
        dsz_price = 0.0
        if dsz_rc:
            total_disks_size = sum((int(vs.total_disk_size) for vs in user_servers))
            self.disks_price_off = 0.0
            # not_free_disks_size = total_disks_size - int(
            #     dsz_rc.prices.limit_free
            # )
            # if not_free_disks_size > 0:
            #     self.disks_price_off = not_free_disks_size * float(
            #         dsz_rc.prices.price_off
            #     )
            self.disks_price_off = total_disks_size * float(
                dsz_rc.prices.price_off
            )

            dsz_price = self.disks_price_off

        #  Calculate Price for NTZ
        ntz_price = 0.0
        if ntz_rc:
            # if test.cp_version <= 5.3:
            #     total_ips = sum(
            #         (len(vs.ip_address_join.get_all()) for vs in user_servers)
            #     )
            # else:
            #     total_ips = sum(
            #         (
            #             len(
            #                 IpAddress().get_all(related_obj=vs)
            #             ) for vs in user_servers
            #         )
            #     )
            total_ips = sum(
                (len(vs.ip_address_join.get_all()) for vs in user_servers)
            )
            self.ip_price_off = 0.0
            # not_free_ips = total_ips - int(ntz_rc.prices.limit_ip_free)
            # if not_free_ips > 0:
            #     self.ip_price_off = not_free_ips * float(
            #         ntz_rc.prices.price_ip_off
            #     )
            self.ip_price_off = total_ips * float(
                ntz_rc.prices.price_ip_off
            )

            # Checking for unlimited value #####################################
            # try:
            #     br_rate_limit_free = int(ntz_rc.prices.limit_rate_free)
            # except TypeError:
            #     br_rate_limit_free = test.onapp_settings.get().max_network_interface_port_speed
            ####################################################################
            total_rate_limit = 0
            network_interfaces = []
            # Get network_interfaces for all users vs
            for vs in user_servers:
                network_interfaces.extend(vs.network_interface.get_all())

            # In case network_interface relates to network from bucket we
            # should include free limit.
            for network_interface in network_interfaces:
                net_join = [
                    nj for nj in test.env.network_joins
                    if nj.id == network_interface.network_join_id
                ][0]
                network = Network(id=net_join.network_id)

                vm_network_interface_port_speed = network_interface.rate_limit
                if not vm_network_interface_port_speed:
                    vm_network_interface_port_speed = test.onapp_settings.max_network_interface_port_speed

                if network.network_group_id == test.env.netz.id:
                    total_rate_limit += vm_network_interface_port_speed - \
                                        ntz_rc.prices.limit_rate_free
                else:
                    total_rate_limit += vm_network_interface_port_speed

            self.rate_limit_price_off = 0.0
            # not_free_rate_limit = total_rate_limit - br_rate_limit_free
            # if not_free_rate_limit > 0:
            #     self.rate_limit_price_off = not_free_rate_limit * float(
            #         ntz_rc.prices.price_rate_off
            #     )
            self.rate_limit_price_off = total_rate_limit * float(
                ntz_rc.prices.price_rate_off
            )

            ntz_price = self.ip_price_off + self.rate_limit_price_off

        price_off = hvz_price + dsz_price + ntz_price
        return price_off

    def download_100MB_of_data(self):
        test.log.info("Download 100MB of data from CP...")
        if not self.booted:
            self.start()
        command = "scp -i /home/onapp/.ssh/id_rsa " \
                  "-o StrictHostKeyChecking=no " \
                  "-o UserKnownHostsFile=/dev/null " \
                  "-o PasswordAuthentication=no /tmp/zaza_test_10MB root@{}:/root/".format(self.ip_address)
        count = 10
        for i in range(count):
            test.log.info('{0} left...'.format(str(count - i)))
            result = test.cp.execute(command)
            if 'No such file or directory' in result:
                return False
        return True

        # TODO
        # Check if file present on VS with appropriate size

    def copy_100MB_of_data(self):
        test.log.info("Copy 100MB of data...")
        if not self.booted:
            self.start()
        command = "cp -f /root/zaza_test_10MB /root/one_more_zaza_test_10MB"
        count = 10
        for i in range(count):
            test.log.info('{0} left...'.format(str(count - i)))
            self.execute(command)
        return True
        # TODO
        # Check if file present on VS with appropriate size

    def write_data(self, size=None, path='/'):  # TODO looks like this method is not using.
        """ size in MB"""
        self.execute(
            'cd {0} && dd if=/dev/urandom of={1}GB bs=1024k count={2}'.format(
                path, size, size
            )
        )

    def execute(
            self,
            command,
            user=None,
            password=None,
            port=None,
            target=None,
            timeout=10
    ):
        exit_status, data = self.ext_execute(
            command,
            user=user,
            password=password,
            port=port,
            target=target,
            timeout=timeout
        )
        return data

    def ext_execute(
            self,
            command,
            user=None,
            password=None,
            port=None,
            target=None,
            timeout=10
    ):
        """
        Executing command on the server via ssh. In case ip address is not
        global execute command via CP.

        :param command: command for ececute
        :param user: user
        :param port: port, default is 22
        :param target: an ip address, if not specified use the first one
        :return: exit_status, data
        """
        test.log.info('>' * 80)
        test.log.info("Executing {0} ...".format(command))
        # Execute from server
        data = ''
        exit_status = None

        if target:
            # Execute command on target ip address even if this ip address is
            # not public
            if password is None:
                password = self.initial_root_password

            self.ssh.host = target
            try:
                exit_status, data = self.ssh.ext_execute(
                    command,
                    timeout=timeout,
                    user=user,
                    password=password,
                    port=port
                )
            except TimeoutError as e:
                self.error['ssh_execute_failed'] = e
            except ConnectionError as e:
                self.error['ssh_execute_failed'] = e

        else:
            target = self.ip_address

            if ipaddress.IPv4Address(target).is_global:
                # if user:
                #     self.ssh.user = user
                # if port:
                #     self.ssh.port = port
                if password is None:
                    password = self.initial_root_password

                self.ssh.host = target
                try:
                    exit_status, data = self.ssh.ext_execute(
                        command,
                        timeout=timeout,
                        user=user,
                        password=password,
                        port=port
                    )
                except TimeoutError as e:
                    self.error['ssh_execute_failed'] = e
                except ConnectionError as e:
                    self.error['ssh_execute_failed'] = e
            # Execute from CP in case we have not public IP address or vs can not be pinged from current machine
            else:
                exit_status, data = test.cp.ext_execute(
                    command=command,
                    tunnel_host=target,
                    tunnel_port=port,
                    timeout=timeout
                )
                if 'ssh_execute_failed' in test.cp.error:
                    self.error = test.cp.error

        test.log.info('<' * 80)
        return exit_status, data

    # Getting Native Parameters
    def native_disk_size(self, mount_point):
        """Return disk size in GB"""
        test.log.info("Get real disk size for {0}...".format(mount_point))
        output = self.execute("df -k {}".format(mount_point), timeout=30)
        if output:
            for line in output.split('\n'):
                if mount_point in line and \
                                "No such file or directory" not in line:
                    disks_info = line.split()[1]
                    return float(disks_info) / 1048576
        return 0

    def native_swap_size(self):
        """Return size in GB"""
        test.log.info("Get real disk size for swap...")
        if self.operating_system == 'freebsd':
            output = self.execute("swapinfo -hk")
            if output:
                memory_info = output.split('\n')
                total = sum(
                    [float(s.split()[1]) for s in memory_info if '/dev' in s]
                )
                return total / 1048576
        elif self.operating_system in ['linux', "coreos"]:
            output = self.execute("free -k")
            if output:
                memory_info = output.split('\n')
                for s in memory_info:
                    if s.split()[0] == 'Swap:':
                        return float(s.split()[1]) / 1048576
        return 0

    def native_ram_size(self):
        """Return size in MB"""
        test.log.info("Get real ram size...")
        if self.operating_system == 'freebsd':
            output = self.execute("dmesg | grep memory")
            if output:
                memory_info = output.split('\n')
                total = sum(
                    [
                        float(s.split()[3]) for s in memory_info
                        if 'real memory' in s
                        ]
                ) / 1048576
                return total # / 1048576
        elif self.operating_system in ['linux', "coreos"]:
            output = self.execute("free -k")
            if output:
                memory_info = output.split('\n')
                for s in memory_info:
                    if s.split()[0] == 'Mem:':
                        return float(s.split()[1]) / 1024
        return 0

    def native_cpus_count(self):
        cpuinfo = self.execute('cat /proc/cpuinfo | grep -cw processor')
        if cpuinfo:
            for l in cpuinfo.split('\n'):
                try:
                    return int(l)
                except ValueError as e:
                    test.log.error(e)
        return 0

    def _add_to_template_store(self, template_store_label='zaza_auto_test'):
        """ Use this method when you have a template not added to template store yet."""
        # Create template store if not exist
        if not self.template_store.get_by_label(template_store_label):
            self.template_store.label = template_store_label
            self.template_store.create()
        if self.template_store.get_by_label(template_store_label):
            # Get all templates attached to template store
            relations = self.template_store.relation_group_template.attached_templates()
            relation = [
                relation for relation in relations
                if relation.template_id == self.template.id
                ]
            if not relation:
                # Add template to template store
                self.template_store.relation_group_template.template_id = self.template.id
                self.template_store.relation_group_template.attach_template_to_group()

    def get_price_per_hour(self):
        test.update_object(self)
        return self.price_per_hour

    def get_price_per_hour_powered_off(self):
        test.update_object(self)
        return self.price_per_hour_powered_off

    def _set_ssh_params(self):
        """
        Set/update ssh host and password
        :return:
        """
        # Set ssh parameters
        self.ssh.host = self.ip_address
        if self.route == 'application_servers':
            self.initial_root_password = self.get_initial_root_password()
        elif self.route == "container_servers":
            self.ssh.user = 'core'

        self.ssh.password = self.initial_root_password

    def get_backups_size(self):
        return sum([b.backup_size for b in self.get_backups()])

    def get_backups_count(self):
        return len(self.get_backups())

    def get_auto_backups_size(self):
        return sum(
            [
                b for b in self.get_backups()
                if b.initiated != 'manual'
            ]
        )

    def get_auto_backups_count(self):
        return len(
            [
                b for b in self.get_backups()
                if b.initiated != 'manual'
            ]
        )

    def get_manual_backups_size(self):
        return sum(
            [
                b for b in self.get_backups()
                if b.initiated == 'manual'
            ]
        )

    def get_manual_backups_count(self):
        return len(
            [
                b for b in self.get_backups()
                if b.initiated == 'manual'
            ]
        )

    def get_grub_config_file_path(self):
        """
        Add to VS obj grub_conf_file_path attribute
        :param vs: vs obj
        :return:
        """
        paths = [
            '/boot/grub2/grub.cfg',
            '/boot/grub/grub.cfg',
            '/boot/grub/grub.conf',
            '/boot/grub/menu.lst',
        ]

        self.grub_conf_file_path = ''
        for path in paths:
            exit_status, data = self.ext_execute(f'[ -e {path} ]')
            if exit_status == 0:
                self.grub_conf_file_path = path
                break