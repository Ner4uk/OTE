import os
import socket

from onapp_helper import test
from onapp_helper.base_helper import BaseHelper
from onapp_helper.resolver import Resolver
from onapp_helper.template import Template
from onapp_helper.virtual_machine import VirtualMachine
from onapp_helper.template_ova import OVA
from onapp_helper.iso import ISO


class VirtualServer(VirtualMachine):
    def __init__(self, server_id=None):
        self.id = server_id
        self.data_store_group_swap_id = None
        self.licensing_type = None
        self.licensing_key = None
        # super(VirtualServer, self).__init__()
        super().__init__()
        if test.cp_version >= 5.5:
            self.service_addon_ids = list()

        if test.api_version >= '5.10':
            self.disks_attributes = []
            self.network_interfaces_attributes = []

        if self.id:
            test.update_object(self)
            self.ip_address = self.primary_ip_address()
            if self.template_id:
                if not self.template.get_by_id(self.template_id):
                    self.template = OVA(id=self.template_id)
                    if self.template.error:
                        self.template = ISO(id=self.template_id)

            # Update SSH settings
            self.ssh.host = self.ip_address
            self.ssh.password = self.initial_root_password

    def create(self, approve=False, **kwargs):
        """
        Create server.
        To set specific parameters for creating you need to set appropriate
        attributes before creation.
        """

        if kwargs:
            data = {self.root_tag: kwargs}
        else:
            if self.template.id is None:
                self.set_template()
            elif self.template_id is None:
                self.template_id = self.template.id
            elif (
                        self.template.id != self.template_id
            ) and self.template.id is not None:
                self.template_id = self.template.id

            if self.instance_package_id:
                data = {
                    self.root_tag: {
                        "template_id": self.template_id,
                        "label": self.label,
                        "hostname": self.hostname,
                        "domain": self.domain,
                        "required_ip_address_assignment": self.required_ip_address_assignment,
                        "required_virtual_machine_build": self.required_virtual_machine_build,
                        "initial_root_password": self.initial_root_password,
                        "primary_disk_min_iops": self.primary_disk_min_iops,
                        "swap_disk_min_iops": self.swap_disk_min_iops,
                        "instance_package_id": self.instance_package_id,
                        "enable_autoscale": self.enable_autoscale,
                        "required_virtual_machine_startup": self.required_virtual_machine_startup
                    }
                }
            else:
                #  in this case we can set memory less than template.min_memory_size to check validation.
                if not self.memory:
                    if self.memory < self.template.min_memory_size:
                        self.memory = self.template.min_memory_size
                # in this case we can set primary_disk_size less than template.min_disk_size to check validation.
                if not self.primary_disk_size and self.template.type != 'ImageTemplateOva':
                    self.primary_disk_size = self.template.min_disk_size
                data = {
                    self.root_tag: {
                        "template_id": self.template_id,
                        "label": self.label,
                        "hostname": self.hostname,
                        "domain": self.domain,
                        "hypervisor_group_id": self.hypervisor_group_id,
                        "hypervisor_id": self.hypervisor_id,
                        "memory": self.memory,
                        "cpus": self.cpus,
                        "cpu_shares": self.cpu_shares,
                        "data_store_group_primary_id": self.data_store_group_primary_id,
                        "primary_disk_size": self.primary_disk_size,
                        "data_store_group_swap_id": self.data_store_group_swap_id,
                        "swap_disk_size": self.swap_disk_size,
                        "primary_network_group_id": self.primary_network_group_id,
                        "required_ip_address_assignment": self.required_ip_address_assignment,
                        "rate_limit": self.rate_limit,
                        "required_virtual_machine_build": self.required_virtual_machine_build,
                        "initial_root_password": self.initial_root_password,
                        "primary_disk_min_iops": self.primary_disk_min_iops,
                        "swap_disk_min_iops": self.swap_disk_min_iops,
                        "enable_autoscale": self.enable_autoscale,
                        "recipe_joins_attributes": self.recipe_joins_attributes,
                        "custom_recipe_variables": self.custom_recipe_variables,
                        "strict_virtual_machine_id": self.strict_virtual_machine_id,
                        "required_virtual_machine_startup": self.required_virtual_machine_startup,
                        "cpu_topology": self.cpu_topology,
                        "cpu_sockets": self.cpu_sockets
                    }
                }

            if test.cp_version >= 5.4:
                data[self.root_tag]["selected_ip_address"] = self.selected_ip_address
            else:
                data[self.root_tag]["selected_ip_address_id"] = self.selected_ip_address_id

            if test.cp_version >= 5.5:
                data[self.root_tag]["service_addon_ids"] = self.service_addon_ids
                # data[self.root_tag]['cpu_threads'] = self.cpu_threads

            if test.cp_version >= 5.8:
                if 'cpu_threads' in data[self.root_tag]:
                    data[self.root_tag].pop('cpu_threads')

            # For Multi disks and networks
            if test.api_version >= '5.10':
                if test.env:
                    # If not self.disks_attributes create with default params
                    # Add primary and swap disks if not specified before
                    if not self.disks_attributes \
                            and self.template.type != 'ImageTemplateOva':
                        # Primary
                        self.disks_attributes.append(
                            {
                                'disk_size': self.template.min_disk_size,
                                'data_store_id': test.env.ds.id,
                                'primary': True,
                                'is_swap': False,
                                'min_iops': 1
                            }
                        )
                        if self.template.allowed_swap:
                            # Swap
                            self.disks_attributes.append(
                                {
                                    'disk_size': 1,
                                    'data_store_id': test.env.ds.id,
                                    'primary': False,
                                    'is_swap': True,
                                    'min_iops': 1
                                }
                            )

                    # Add attributes for network if not specified before
                    # Primary
                    if not self.network_interfaces_attributes:
                        self.network_interfaces_attributes.append(
                            {
                                'network_id': test.env.net.id,
                                'ip_net_id': test.env.ip_net.id,
                                'ip_range_id': test.env.ip_range.id,
                                'ip_address': test.env.ip_address.address,
                                'rate_limit': self.rate_limit
                            }
                        )

                keys = [
                    'data_store_group_primary_id',
                    'primary_disk_size',
                    'data_store_group_swap_id',
                    'swap_disk_size',
                    'primary_disk_min_iops',
                    'swap_disk_min_iops',
                    'primary_network_group_id',
                    'rate_limit',
                ]

                [
                    data[self.root_tag].pop(key) for key in keys
                    if key in data[self.root_tag]
                ]

                data[self.root_tag]['disks_attributes'] = self.disks_attributes
                data[self.root_tag]['network_interfaces_attributes'] = self.network_interfaces_attributes

            if self.initial_root_password_encryption_key:
                data[self.root_tag]["initial_root_password_encryption_key"] = \
                    self.initial_root_password_encryption_key
                data[self.root_tag]["initial_root_password_encryption_key_confirmation"] = \
                    self.initial_root_password_encryption_key

            if self.template.operating_system == "windows":
                data[self.root_tag]['licensing_type'] = self.licensing_type
                data[self.root_tag]['licensing_key'] = self.licensing_key

        self._set_build_transactions_actions()

        if self._create(data, approve=approve):
            self._initialise_additional_server_attributes()
            return True
        return False

    def create_from_template(self, template):
        """
        Method with the smallest amount of required attributes
        to create virtual server
        """
        self.template = template
        data = {
            self.root_tag: {
                "template_id": self.template_id or self.template.id,
                "label": self.template.label,
                "hostname": self.hostname,
                "domain": self.domain,
                "hypervisor_group_id": self.hypervisor_group_id,
                "hypervisor_id": self.hypervisor_id,
                "memory": self.template.min_memory_size,
                "cpus": self.cpus,
                "cpu_shares": self.cpu_shares,
                "primary_disk_size": self.template.min_disk_size,
                "swap_disk_size": self.swap_disk_size,
                "required_ip_address_assignment": 0,
                "rate_limit": self.rate_limit,
                "required_virtual_machine_build": self.required_virtual_machine_build,
                "initial_root_password": '',
                "enable_autoscale": self.enable_autoscale,
                "required_virtual_machine_startup": self.required_virtual_machine_startup,
                "cpu_topology": self.cpu_topology,
                "network_interfaces_attributes": [{"network_id": test.env.net.id}]
            }
        }

        if self.template.operating_system == "windows":
            data[self.root_tag]['licensing_type'] = self.licensing_type
            data[self.root_tag]['licensing_key'] = self.licensing_key
        self._set_build_transactions_actions()

        if self._create(data):
            self._initialise_additional_server_attributes()
            return True
        return False

    def _set_build_transactions_actions(self):
        # Describe transaction actions for different templates.
        if self.template.type == "ImageTemplate":
            if self.template.operating_system == "linux":
                self.build_transaction_actions = (
                    'provisioning',
                    'configure_operating_system',
                )
            elif self.template.operating_system == "freebsd":
                self.build_transaction_actions = (
                    'provisioning',
                    'configure_operating_system',
                    'provision_freebsd'
                )
            elif self.template.operating_system == 'windows':
                self.build_transaction_actions = (
                    'provisioning',
                    'configure_operating_system',
                    'provision_win'
                )
            else:
                raise SystemError(
                    "Undefined template operating system - {}".format(
                        self.template.operating_system
                    )
                )

        elif self.template.type == "ImageTemplateOva":
            if self.template.operating_system == 'windows':
                self.build_transaction_actions = (
                    'provisioning',
                    'configure_operating_system',
                    'provision_win'
                )
            elif self.template.operating_system == 'other':
                self.build_transaction_actions = (
                    'provisioning',
                    'configure_operating_system'
                )
            elif self.template.properties['grub']:
                self.build_transaction_actions = (
                    'provisioning',
                    'configure_operating_system',
                    'provision_grub'
                )
            elif not self.template.properties['grub']:
                self.build_transaction_actions = (
                    'provisioning',
                    'configure_operating_system',
                    'install_grub'
                )
        elif self.template.type == "ImageTemplateIso":
            self.build_transaction_actions = (
                'build_virtual_machine',
            )
        else:
            raise SystemError(
                "Undefined template type - {}".format(self.template.type)
            )

    def accelerate(self):
        """Accelerate Virtual Server"""
        test.log.info('Accelerate virtual server')
        url = f'/{self.route}/{self.id}/accelerate.json'
        if test.post_object(url=url):
            # May be we should wait for some transaction
            return True
        return False

    def decelerate(self):
        """Decelerate Virtual Server"""
        test.log.info('Decelerate virtual server')
        url = f'/{self.route}/{self.id}/decelerate.json'
        if test.post_object(url=url):
            # May be we should wait for some transaction
            return True
        return False


class SST:
    """
    Storage Server Type
    """
    def __init__(self):
        self.http = 'http'
        self.streaming = 'streaming'


class StorageServer(VirtualMachine):
    STORAGE_SERVER_TYPE = SST()
    route = 'storage_servers'
    root_tag = route[:-1]

    def __init__(self, server_id=None):
        self.id = server_id
        super(StorageServer, self).__init__()
        self.cdn_location = None
        self.storage_server_type = None
        if self.id:
            test.update_object(self)
            self.ip_address = self.primary_ip_address()
            self.template.get_by_id(self.template_id)
        else:
            self.template.get_by_manager_id('cdn')  # need to get min memory size and something else.
            self.template_id = self.template.id

    def create(self):
        """
        Create server.
        To set specific parameters for creating you need to set appropriate
        attributes before creation.
        """

        #  in this case we can set memory less than template.min_memory_size to check validation.
        if not self.memory:
            if self.memory < self.template.min_memory_size:
                self.memory = self.template.min_memory_size
        # in this case we can set primary_disk_size less than template.min_disk_size to check validation.
        if not self.primary_disk_size:
            self.primary_disk_size = self.template.min_disk_size
        data = {
            self.root_tag: {
                "template_id": self.template_id,
                "label": self.label,
                "hostname": self.hostname,
                "hypervisor_group_id": self.hypervisor_group_id,
                "hypervisor_id": self.hypervisor_id,
                "memory": self.memory,
                "cpus": self.cpus,
                "cpu_shares": self.cpu_shares,
                "data_store_group_primary_id": self.data_store_group_primary_id,
                "primary_disk_size": self.primary_disk_size,
                "data_store_group_swap_id": self.data_store_group_swap_id,
                "swap_disk_size": self.swap_disk_size,
                "primary_network_group_id": self.primary_network_group_id,
                "required_ip_address_assignment": self.required_ip_address_assignment,
                "rate_limit": self.rate_limit,
                "required_virtual_machine_build": self.required_virtual_machine_build,
                "initial_root_password": self.initial_root_password,
                "primary_disk_min_iops": self.primary_disk_min_iops,
                "swap_disk_min_iops": self.swap_disk_min_iops,
                "enable_autoscale": self.enable_autoscale,
                "storage_server_type": self.storage_server_type,
                "cdn_location": self.cdn_location
            }
        }

        if test.cp_version >= 5.4:
            data[self.root_tag]["selected_ip_address"] = self.selected_ip_address
        else:
            data[self.root_tag]["selected_ip_address_id"] = self.selected_ip_address_id

        self.build_transaction_actions = (
            'provisioning',
            'configure_operating_system'
        )

        if self._create(data):
            if self.transaction.transaction_handler('create_cdn_server'):
                self._initialise_additional_server_attributes()
                return True
        return False


class SmartServer(VirtualMachine):
    route = 'smart_servers'
    root_tag = route[:-1]

    def __init__(self, server_id=None):
        self.id = server_id
        super(SmartServer, self).__init__()
        if self.id:
            test.update_object(self)
            self.ip_address = self.primary_ip_address()
            self.template.get_by_id(self.template_id)

    def create(self):
        """
        Create server.
        To set specific parameters for creating you need to set appropriate
        attributes before creation.
        """
        self.set_template()

        #  in this case we can set memory less than template.min_memory_size to check validation.
        if not self.memory:
            if self.memory < self.template.min_memory_size:
                self.memory = self.template.min_memory_size
        # in this case we can set primary_disk_size less than template.min_disk_size to check validation.
        if not self.primary_disk_size:
            self.primary_disk_size = self.template.min_disk_size
        data = {
            self.root_tag: {
                "template_id": self.template.id,
                "label": self.label,
                "hostname": self.hostname,
                "domain": self.domain,
                "hypervisor_group_id": self.hypervisor_group_id,
                "hypervisor_id": self.hypervisor_id,
                "memory": self.memory,
                "cpus": self.cpus,
                "cpu_shares": self.cpu_shares,
                "data_store_group_primary_id": self.data_store_group_primary_id,
                "primary_disk_size": self.primary_disk_size,
                "data_store_group_swap_id": self.data_store_group_swap_id,
                "swap_disk_size": self.swap_disk_size,
                "primary_network_group_id": self.primary_network_group_id,
                "required_ip_address_assignment": self.required_ip_address_assignment,
                "rate_limit": self.rate_limit,
                "required_virtual_machine_build": self.required_virtual_machine_build,
                "initial_root_password": self.initial_root_password,
                "primary_disk_min_iops": self.primary_disk_min_iops,
                "swap_disk_min_iops": self.swap_disk_min_iops,
                "enable_autoscale": self.enable_autoscale
            }
        }

        if test.cp_version >= 5.4:
            data[self.root_tag]["selected_ip_address"] = self.selected_ip_address
        else:
            data[self.root_tag]["selected_ip_address_id"] = self.selected_ip_address_id

        if self.template.operating_system == "windows":
            data[self.root_tag]['licensing_type'] = 'mak'

        self.build_transaction_actions = (
            'provisioning',
            'configure_operating_system'
        )

        if self._create(data):
            self._initialise_additional_server_attributes()
            return True
        return False


def wrap_vm_methods_for_openstack(op):
    def temporary_change_srv_type(self):
        """temporary change server_type to 'virtual_machine' because name of the action for openstack server is
        the same as for virtual machine """
        self.server_type = 'virtual_machine'
        ret = op(self)
        self.server_type = self.root_tag
        return ret

    return temporary_change_srv_type


class OpenstackServer(VirtualMachine):
    route = 'openstack_servers'
    root_tag = server_type = route[:-1]
    openstack_id = None

    def __init__(self, server_id=None):
        self.id = server_id
        super(OpenstackServer, self).__init__()
        if self.id:
            test.update_object(self)
        self.required_virtual_machine_startup = 0

    def create(self):
        """
        Create openstack server.
        The only needed meaningful params as for now are label, template and instance package.
        """
        self.set_template()

        data = {
            self.root_tag: {
                "template_id": self.template.id,
                "label": self.label,
                "required_instance_package_analysis": 0,
                "instance_package_id": self.instance_package_id,
                "enable_autoscale": 0,
            }
        }

        self.build_transaction_actions = (
            'provision_openstack_server',
        )
        if self._create(data):
            self.wait_for_action(
                lambda: self.get() and self.openstack_id,
                timeout=10,
                step=2
            )
            self._initialise_additional_server_attributes()
            return True
        return False

    @wrap_vm_methods_for_openstack
    def edit(self):
        """
        Edit openstack server.
        The only available parameters at this stage are the label and instance package
        """
        test.log.info("Edit the server...")
        data = {
            self.root_tag: {
                "label": self.label,
                "instance_package_id": self.instance_package_id
            }
        }
        test.log.info("Start to edit server...")
        if test.put_object(self, data=data):
            action_resize_server = 'resize_openstack_server'
            action_change_label = 'update_openstack_server'
            if self.transaction_handler(
                    action_resize_server, pages=2
            ) or self.transaction_handler(
                action_change_label, pages=2
            ):
                return test.update_object(self)
        return False

    @wrap_vm_methods_for_openstack
    def delete(self):
        test.log.info("Start to destroy server...")
        return super(OpenstackServer, self).delete()

    @wrap_vm_methods_for_openstack
    def shutdown(self):
        test.log.info("Start to shutdown server...")
        return super(OpenstackServer, self).shutdown()

    @wrap_vm_methods_for_openstack
    def reboot(self):
        test.log.info("Start to reboot server...")
        return super(OpenstackServer, self).reboot()

    @wrap_vm_methods_for_openstack
    def start(self):
        test.log.info("Start server...")
        return super(OpenstackServer, self).start()


class Attributes:
    def __init__(self):
        self.for_minutes = 5
        self.units = 0
        self.enabled = False
        self.value = 0


class AutoscaleNodeAttributes:
    def __init__(self):
        self.cpus = 1
        self.cpu_shares = 1
        self.memory = 384
        self.rate_limit = 1


class ClusterNodeAttributes:
    def __init__(self, node):
        self.virtual_machine_id = node.id
        self.ip_address_id = node.ip_addresses[0]['ip_address']['id']


class LoadBalancerAttributes:
    def __init__(self):
        self.label = ''
        self.rate_limit = 1
        self.hostname = ''
        self.primary_network_group_id = test.env.netz.id
        self.hypervisor_group_id = test.env.hvz.id
        self.hypervisor_id = test.env.hv.id


class LoadBalancer(VirtualMachine):
    route = 'load_balancers'
    root_tag = 'load_balancer'

    def __init__(self, server_id=None):
        self.id = server_id
        super(LoadBalancer, self).__init__()

    def rebuild(self):
        """Rebuild the server. Return True if success."""
        test.log.info("Rebuild the server...")
        test.log.info("Rebuild the server with id - {0}".format(self.id))
        url = '/{0}/{1}/rebuild.json'.format(self.route, self.id)
        if test.post_object(self, url=url):
            if self._wait_for_create():
                test.update_object(self)
                return True
        return False


class LoadBalancingCluster(BaseHelper):
    CLUSTER_TYPE_AUTOSCALE = 'autoscaleout'
    CLUSTER_TYPE_CLUSTER = 'cluster'

    def __init__(self, server_id=None):
        self.id = server_id
        # delattr(VirtualMachine, 'label')
        # delattr(VirtualMachine, 'rate_limit')
        self.route = 'load_balancing_clusters'
        self.root_tag = 'load_balancing_cluster'

        if self.id:
            self._dict_to_class()
        else:
            self.ports = []
            self.cluster_type = ''
            self.config = {
                'min_node_amount': 0,
                'max_node_amount': 0
            }
            self.load_balancer_attributes = LoadBalancerAttributes()
            self.autoscale_node_attributes = AutoscaleNodeAttributes()
            self.cluster_node_attributes = []
            self.auto_scaling_in_memory_attributes = Attributes()
            self.auto_scaling_in_cpu_attributes = Attributes()
            self.auto_scaling_out_memory_attributes = Attributes()
            self.auto_scaling_out_cpu_attributes = Attributes()
            self.image_template_id = None

    def create(self):
        if self.cluster_type == self.CLUSTER_TYPE_AUTOSCALE:
            data = {
                self.root_tag: {
                    "config": self.config,
                    "ports": self.ports,
                    "image_template_id": self.image_template_id,
                    "auto_scaling_in_cpu_attributes": {
                        "for_minutes": self.auto_scaling_in_cpu_attributes.for_minutes,
                        "units": self.auto_scaling_in_cpu_attributes.units,
                        "enabled": self.auto_scaling_in_cpu_attributes.enabled,
                        "value": self.auto_scaling_in_cpu_attributes.value
                    },
                    "auto_scaling_in_memory_attributes": {
                        "for_minutes": self.auto_scaling_in_memory_attributes.for_minutes,
                        "units": self.auto_scaling_in_memory_attributes.units,
                        "enabled": self.auto_scaling_in_memory_attributes.enabled,
                        "value": self.auto_scaling_in_memory_attributes.value
                    },
                    "auto_scaling_out_memory_attributes": {
                        "for_minutes": self.auto_scaling_out_memory_attributes.for_minutes,
                        "units": self.auto_scaling_out_memory_attributes.units,
                        "enabled": self.auto_scaling_out_memory_attributes.enabled,
                        "value": self.auto_scaling_out_memory_attributes.value
                    },
                    "auto_scaling_out_cpu_attributes": {
                        "for_minutes": self.auto_scaling_out_cpu_attributes.for_minutes,
                        "units": self.auto_scaling_out_cpu_attributes.units,
                        "enabled": self.auto_scaling_out_cpu_attributes.enabled,
                        "value": self.auto_scaling_out_cpu_attributes.value
                    },
                    "load_balancer_attributes": {
                        "label": self.load_balancer_attributes.label,
                        "hostname": self.load_balancer_attributes.hostname,
                        "rate_limit": self.load_balancer_attributes.rate_limit,
                        "primary_network_group_id": self.load_balancer_attributes.primary_network_group_id,
                        "hypervisor_group_id": self.load_balancer_attributes.hypervisor_group_id,
                        "hypervisor_id": self.load_balancer_attributes.hypervisor_id
                    },
                    "cluster_type": self.cluster_type,
                    "node_attributes": {
                        "cpus": self.autoscale_node_attributes.cpus,
                        "cpu_shares": self.autoscale_node_attributes.cpu_shares,
                        "memory": self.autoscale_node_attributes.memory,
                        "rate_limit": self.autoscale_node_attributes.rate_limit
                    }
                }
            }

        elif self.cluster_type == self.CLUSTER_TYPE_CLUSTER:
            nodes_attributes = []
            for node_attribute in self.cluster_node_attributes:
                nodes_attributes.append(
                    {
                        "ip_address_id": node_attribute.ip_address_id,
                        "virtual_machine_id": node_attribute.virtual_machine_id
                    }
                )
            data = {
                self.root_tag: {
                    "load_balancer_attributes": {
                        "label": self.load_balancer_attributes.label,
                        "hostname": self.load_balancer_attributes.hostname,
                        "hypervisor_group_id": self.load_balancer_attributes.hypervisor_group_id,
                        "hypervisor_id": self.load_balancer_attributes.hypervisor_id,
                        "primary_network_group_id": self.load_balancer_attributes.primary_network_group_id,
                        "rate_limit": self.load_balancer_attributes.rate_limit
                    },
                    "cluster_type": self.cluster_type,
                    "nodes_attributes": nodes_attributes,
                    "ports": self.ports
                }
            }

        else:
            raise SystemError('Undefined cluster type.')

        if test.post_object(self, data=data):
            self._dict_to_class()
            if self.transaction_handler(
                    'startup_virtual_machine', self.load_balancer.id
            ):
                self._dict_to_class()
                return True
        self._dict_to_class()
        return False

    def add_nodes(self, nodes):
        """

        :param nodes: an array of nodes obj (simple virtual server)
        :return: True if success otherwise False
        """
        if self.cluster_type == self.CLUSTER_TYPE_AUTOSCALE:
            test.log.warning('Current cluster type is not supporting this method.')
            return False

        nodes_attributes = []
        for node in nodes:
            node_attribute = ClusterNodeAttributes(node)
            nodes_attributes.append(
                {
                    "ip_address_id": node_attribute.ip_address_id,
                    "virtual_machine_id": node_attribute.virtual_machine_id
                }
            )

        data = {
            self.root_tag: {
                "nodes_attributes": nodes_attributes
            }
        }

        if test.put_object(self, data=data):
            if type(self.load_balancer) == dict:
                parent_id = self.load_balancer['id']
            else:
                parent_id = self.load_balancer.id

            if self.transaction_handler(
                    "configure_load_balancer", parent_id
            ):
                self._dict_to_class()
                return True

        return False

    def destroy_node(self, nodes):
        """

        :param nodes: an array of nodes obj (simple virtual server)
        :return:
        """

        if self.cluster_type == self.CLUSTER_TYPE_AUTOSCALE:
            test.log.warning('Current cluster type is not supporting this method.')
            return False

        nodes_attributes = {}
        if nodes:
            for node in nodes:
                for load_balancing_cluster_node in self.nodes:
                    lbc_node = load_balancing_cluster_node['load_balancing_cluster_node']
                    if node.id == lbc_node['virtual_machine_id']:
                        nodes_attributes["{}".format(lbc_node['id'])] = {
                            "_destroy": True,
                            "id": lbc_node['id'],
                            "ip_address_id": lbc_node['ip_address_id']
                        }

        data = {
            self.root_tag: {
                "nodes_attributes": nodes_attributes
            }
        }

        if test.put_object(self, data=data):
            self._dict_to_class()
            return True
        return False

    def edit(self):
        if self.cluster_type == self.CLUSTER_TYPE_AUTOSCALE:
            data = {
                self.root_tag: {
                    "config": self.config,
                    "ports": self.ports,
                    "auto_scaling_in_cpu_attributes": {
                        "for_minutes": self.auto_scaling_in_cpu_attributes.for_minutes,
                        "units": self.auto_scaling_in_cpu_attributes.units,
                        "enabled": self.auto_scaling_in_cpu_attributes.enabled,
                        "value": self.auto_scaling_in_cpu_attributes.value
                    },
                    "auto_scaling_in_memory_attributes": {
                        "for_minutes": self.auto_scaling_in_memory_attributes.for_minutes,
                        "units": self.auto_scaling_in_memory_attributes.units,
                        "enabled": self.auto_scaling_in_memory_attributes.enabled,
                        "value": self.auto_scaling_in_memory_attributes.value
                    },
                    "auto_scaling_out_memory_attributes": {
                        "for_minutes": self.auto_scaling_out_memory_attributes.for_minutes,
                        "units": self.auto_scaling_out_memory_attributes.units,
                        "enabled": self.auto_scaling_out_memory_attributes.enabled,
                        "value": self.auto_scaling_out_memory_attributes.value
                    },
                    "auto_scaling_out_cpu_attributes": {
                        "for_minutes": self.auto_scaling_out_cpu_attributes.for_minutes,
                        "units": self.auto_scaling_out_cpu_attributes.units,
                        "enabled": self.auto_scaling_out_cpu_attributes.enabled,
                        "value": self.auto_scaling_out_cpu_attributes.value
                    }
                }
            }

        elif self.cluster_type == self.CLUSTER_TYPE_CLUSTER:
            data = {
                self.root_tag: {
                    "load_balancer_attributes": {
                        "label": self.load_balancer_attributes.label,
                        "rate_limit": self.load_balancer_attributes.rate_limit
                    },
                    "ports": self.ports
                }
            }

        else:
            raise SystemError('Undefined cluster type.')

        if test.put_object(self, data=data):
            self._dict_to_class()

            if self.transaction_handler(
                    "configure_load_balancer",
                    self.load_balancer.id
            ):
                self._dict_to_class()
                return True
        return False

    def _dict_to_class(self):
        if hasattr(self, 'id') and self.id:  # Allow do not update resource without id like settings, cloud config etc.
            if test.update_object(self):
                lb = self.load_balancer
                self.load_balancer = LoadBalancer(
                    server_id=self.load_balancer['id']
                )
                self.load_balancer.__dict__.update(lb)  # dict to class attributes
                return True
        return False


class EST:
    """
    Edge Server Type
    """
    def __init__(self):
        self.http = 'http'
        self.streaming = 'streaming'


class EdgeServer(VirtualMachine):
    EDGE_SERVER_TYPE = EST()
    route = 'edge_servers'
    root_tag = route[:-1]

    def __init__(self, server_id=None):
        self.id = server_id
        super(EdgeServer, self).__init__()
        self.cdn_location = None
        self.edge_server_type = None
        if self.id:
            test.update_object(self)
            self.ip_address = self.primary_ip_address()
            self.template.get_by_id(self.template_id)
        else:
            self.template.get_by_manager_id('cdn')  # need to get min memory size and something else.

    def create(self):
        """
        Create server.
        To set specific parameters for creating you need to set appropriate
        attributes before creation.
        """

        #  in this case we can set memory less than template.min_memory_size to check validation.
        if not self.memory:
            if self.memory < self.template.min_memory_size:
                self.memory = self.template.min_memory_size
        # in this case we can set primary_disk_size less than template.min_disk_size to check validation.
        if not self.primary_disk_size:
            self.primary_disk_size = self.template.min_disk_size
        data = {
            self.root_tag: {
                "template_id": self.template.id,
                "label": self.label,
                "hostname": self.hostname,
                "hypervisor_group_id": self.hypervisor_group_id,
                "hypervisor_id": self.hypervisor_id,
                "memory": self.memory,
                "cpus": self.cpus,
                "cpu_shares": self.cpu_shares,
                "data_store_group_primary_id": self.data_store_group_primary_id,
                "primary_disk_size": self.primary_disk_size,
                "data_store_group_swap_id": self.data_store_group_swap_id,
                "swap_disk_size": self.swap_disk_size,
                "primary_network_group_id": self.primary_network_group_id,
                "required_ip_address_assignment": self.required_ip_address_assignment,
                "rate_limit": self.rate_limit,
                "required_virtual_machine_build": self.required_virtual_machine_build,
                "initial_root_password": self.initial_root_password,
                "primary_disk_min_iops": self.primary_disk_min_iops,
                "swap_disk_min_iops": self.swap_disk_min_iops,
                "enable_autoscale": self.enable_autoscale,
                "cdn_location": self.cdn_location,
                "storage_server_type": self.edge_server_type
            }
        }

        if test.cp_version >= 5.4:
            data[self.root_tag]["selected_ip_address"] = self.selected_ip_address
        else:
            data[self.root_tag]["selected_ip_address_id"] = self.selected_ip_address_id

        self.build_transaction_actions = (
            'provisioning',
            'configure_operating_system'
        )

        if self._create(data):
            if self.transaction.transaction_handler('create_cdn_server'):
                self._initialise_additional_server_attributes()
                return True
        return False


class ContainerServer(VirtualMachine):
    route = 'container_servers'
    root_tag = route[:-1]

    def __init__(self, server_id=None):
        self.id = server_id
        super(ContainerServer, self).__init__()
        self.rate_limit = 0
        self.cloud_config = self.read_cloud_config_from_origin()
        self.template = Template()
        self.ssh.user = 'core'

        if self.id:
            test.update_object(self)
            self.ip_address = self.primary_ip_address()
        else:
            self.template.get_by_manager_id('coreoscurrentx64')  # need to get min memory size and something else.

    def create(self):
        """
        Create server.
        To set specific parameters for creating you need to set appropriate
        attributes before creation.
        """

        if self.template.error:
            self.error = self.template.error
            return False

        #  in this case we can set memory less than template.min_memory_size to check validation.
        if not self.memory:
            if self.memory < self.template.min_memory_size:
                self.memory = self.template.min_memory_size
        # in this case we can set primary_disk_size less than template.min_disk_size to check validation.
        if not self.primary_disk_size:
            self.primary_disk_size = self.template.min_disk_size
        data = {
            self.root_tag: {
                "template_id": self.template.id,
                "label": self.label,
                "hostname": self.hostname,
                "domain": self.domain,
                "hypervisor_group_id": self.hypervisor_group_id,
                "hypervisor_id": self.hypervisor_id,
                "memory": self.memory,
                "cpus": self.cpus,
                "cpu_shares": self.cpu_shares,
                "data_store_group_primary_id": self.data_store_group_primary_id,
                "primary_disk_size": self.primary_disk_size,
                "data_store_group_swap_id": self.data_store_group_swap_id,
                "swap_disk_size": self.swap_disk_size,
                "primary_network_group_id": self.primary_network_group_id,
                "required_ip_address_assignment": self.required_ip_address_assignment,
                "rate_limit": self.rate_limit,
                "required_virtual_machine_build": self.required_virtual_machine_build,
                "initial_root_password": self.initial_root_password,
                "primary_disk_min_iops": self.primary_disk_min_iops,
                "swap_disk_min_iops": self.swap_disk_min_iops,
                "enable_autoscale": self.enable_autoscale,
                "cloud_config": self.cloud_config
            }
        }

        if test.cp_version >= 5.4:
            data[self.root_tag]["selected_ip_address"] = self.selected_ip_address
        else:
            data[self.root_tag]["selected_ip_address_id"] = self.selected_ip_address_id

        self.build_transaction_actions = (
            'provisioning',
            'configure_operating_system'
        )
        if self._create(data):
            self._initialise_additional_server_attributes()
            return True
        return False

    # cloud_conf = """#cloud-config
    # write-files:
    #   - path: /etc/hosts
    #     permissions: '0644'
    #     content: |
    #       $public_ipv4  master1 coreos00
    #       109.123.91.163  master2 coreos01
    #
    # coreos:
    #   etcd2:
    #     name: master2
    #     initial-cluster: master1=http://109.123.91.154:2380,master2=http://109.123.91.163:2380
    #     initial-advertise-peer-urls: http://$public_ipv4:2380
    #     advertise-client-urls: http://$public_ipv4:2379,http://$public_ipv4:4001
    #     listen-client-urls: http://0.0.0.0:2379,http://0.0.0.0:4001
    #     listen-peer-urls: http://$public_ipv4:2380,http://$public_ipv4:7001
    #   fleet:
    #     public-ip: $public_ipv4
    #     metadata: "role=master"
    #   flannel:
    #     interface: $public_ipv4
    #   units:
    #     - name: etcd2.service
    #       command: start
    #     - name: fleet.service
    #       command: start
    #     - name: flanneld.service
    #       command: start
    #     """

    def get_cloud_config(self):
        test.log.info("Get cloud-config from Container server...")
        url = '/{}/{}/cloud_config.json'.format(self.route, self.id)
        data = {
            self.root_tag: {
                "cloud_config": self.cloud_config
            }
        }
        return test.get_object(self, url=url, data=data)

    def add_cloud_config(self):
        test.log.info("Add cloud-config to Container server...")
        url = '/{}/{}/cloud_config.json'.format(self.route, self.id)
        data = {
            self.root_tag: {
                "cloud_config": self.cloud_config
            }
        }
        return test.patch_object(self, url=url, data=data)

    def edit_cloud_config(self):
        test.log.info("Edit cloud-config on Container server...")
        url = '/{}/{}/cloud_config.json'.format(self.route, self.id)
        data = {
            self.root_tag: {
                "cloud_config": self.cloud_config
            }
        }
        return test.put_object(self, url=url, data=data)

    @staticmethod
    def read_cloud_config_from_origin():
        cloud_config = ''
        with open(
                os.path.join(test.wd, 'conf/cloud_config.yml')
        ) as cloud_config:
            cloud_config = cloud_config.read()
        return cloud_config


class BaremetalServer(VirtualMachine):
    route = 'baremetal_servers'
    root_tag = route[:-1]

    def __init__(self, server_id=None):
        self.id = server_id
        super(BaremetalServer, self).__init__()

        if test.api_version >= '5.10':
            self.disks_attributes = []
            self.network_interfaces_attributes = []

        if self.id:
            test.update_object(self)
            self.ip_address = self.primary_ip_address()
            self.template.get_by_id(self.template_id)

    def create(self):
        """
        Create server.
        To set specific parameters for creating you need to set appropriate
        attributes before creation.
        """
        self.set_template()

        #  in this case we can set memory less than template.min_memory_size to check validation.
        if not self.memory:
            if self.memory < self.template.min_memory_size:
                self.memory = self.template.min_memory_size
        # in this case we can set primary_disk_size less than template.min_disk_size to check validation.
        if not self.primary_disk_size:
            self.primary_disk_size = self.template.min_disk_size
        data = {
            self.root_tag: {
                "template_id": self.template.id,
                "label": self.label,
                "hostname": self.hostname,
                "domain": self.domain,
                "hypervisor_group_id": self.hypervisor_group_id,
                "hypervisor_id": self.hypervisor_id,
                "primary_network_group_id": self.primary_network_group_id,
                "required_ip_address_assignment": self.required_ip_address_assignment,
                "required_virtual_machine_build": self.required_virtual_machine_build,
                "initial_root_password": self.initial_root_password,
                "recipe_joins_attributes": self.recipe_joins_attributes,
                "custom_recipe_variables": self.custom_recipe_variables
            }
        }

        if test.cp_version >= 5.4:
            data[self.root_tag]["selected_ip_address"] = self.selected_ip_address
        else:
            data[self.root_tag]["selected_ip_address_id"] = self.selected_ip_address_id

        # For Multi disks and networks
        if test.api_version >= '5.10':
            if test.env:

                # If not self.disks_attributes create with default params
                # Add primary and swap disks if not specified before
                if not self.disks_attributes:
                    # Primary
                    self.disks_attributes.append(
                        {
                            'disk_size': self.template.min_disk_size,
                            'data_store_id': test.env.ds.id,
                            'primary': True,
                            'is_swap': False,
                            'min_iops': 1
                        }
                    )
                    if self.template.allowed_swap:
                        # Swap
                        self.disks_attributes.append(
                            {
                                'disk_size': 1,
                                'data_store_id': test.env.ds.id,
                                'primary': False,
                                'is_swap': True,
                                'min_iops': 1
                            }
                        )

                # Add attributes for network if not specified before
                # Primary
                if not self.network_interfaces_attributes:
                    self.network_interfaces_attributes.append(
                        {
                            'network_id': test.env.net.id,
                            'ip_net_id': test.env.ip_net.id,
                            'ip_range_id': test.env.ip_range.id,
                            'ip_address': test.env.ip_address.address,
                            'rate_limit': self.rate_limit
                        }
                    )
            keys = [
                'data_store_group_primary_id',
                'primary_disk_size',
                'data_store_group_swap_id',
                'swap_disk_size',
                'primary_disk_min_iops',
                'swap_disk_min_iops',
                'primary_network_group_id',
            ]

            [
                data[self.root_tag].pop(key) for key in keys
                if key in data[self.root_tag]
            ]

            data[self.root_tag]['disks_attributes'] = self.disks_attributes
            data[self.root_tag]['network_interfaces_attributes'] = self.network_interfaces_attributes

        if self.template.operating_system == "windows":
            data[self.root_tag]['licensing_type'] = 'mak'

        self.build_transaction_actions = (
            'provision_baremetal_server',
        )
        # Create
        if self._create(data):
            self._initialise_additional_server_attributes()
            return True
        return False

    def enable_recovery(self):
        url = "/{}/{}/enable_recovery.json".format(self.route, self.id)
        return test.put_object(self, url=url)

    def disable_recovery(self):
        url = "/{}/{}/disable_recovery.json".format(self.route, self.id)
        return test.put_object(self, url=url)


class ApplicationServer(VirtualMachine):
    route = 'application_servers'
    root_tag = route[:-1]

    def __init__(self, server_id=None):
        self.id = server_id
        super().__init__()
        self.rate_limit = 0
        if self.id:
            test.update_object(self)
            self.ip_address = self.primary_ip_address()
            self.template.get_by_id(self.template_id)
            # Update SSH settings
            self.ssh.host = self.ip_address
            self.initial_root_password = self.get_initial_root_password()
            self.ssh.password = self.initial_root_password
        else:
            self.template.get_by_manager_id('applicationserver')  # need to get min memory size and something else.
            self.template_id = self.template.id
        #NOTE - self.server_type = virtual_machine as default
        # (using for transaction_handler).
        # print(
        #     'Application Server template name - {}\n'.format(
        #         self.template.file_name
        #     )
        # )

    def create(self, **kwargs):
        """
        Create server.
        To set specific parameters for creating you need to set appropriate
        attributes before creation.
        """
        if self.template.error:
            self.error = self.template.error
            return False

        if kwargs:
            data = {self.root_tag: kwargs}
        else:
            #  in this case we can set memory less than template.min_memory_size to check validation.
            if not self.memory:
                if self.memory < self.template.min_memory_size:
                    self.memory = self.template.min_memory_size
            # in this case we can set primary_disk_size less than template.min_disk_size to check validation.
            if not self.primary_disk_size:
                self.primary_disk_size = self.template.min_disk_size
            data = {
                self.root_tag: {
                    "label": self.label,
                    "hostname": self.hostname,
                    "hypervisor_group_id": self.hypervisor_group_id,
                    "hypervisor_id": self.hypervisor_id,
                    "memory": self.memory,
                    "cpus": self.cpus,
                    "cpu_shares": self.cpu_shares,
                    "data_store_group_primary_id": self.data_store_group_primary_id,
                    "primary_disk_size": self.primary_disk_size,
                    "data_store_group_swap_id": self.data_store_group_swap_id,
                    "swap_disk_size": self.swap_disk_size,
                    "primary_network_group_id": self.primary_network_group_id,
                    "required_ip_address_assignment": self.required_ip_address_assignment,
                    "rate_limit": self.rate_limit,
                    "required_virtual_machine_build": self.required_virtual_machine_build,
                    "primary_disk_min_iops": self.primary_disk_min_iops,
                    "swap_disk_min_iops": self.swap_disk_min_iops,
                    "enable_autoscale": self.enable_autoscale
                }
            }

            if test.cp_version >= 5.4:
                data[self.root_tag]["selected_ip_address"] = self.selected_ip_address
                data[self.root_tag]["domain"] = self.domain
            else:
                data[self.root_tag]["selected_ip_address_id"] = self.selected_ip_address_id

        # Check resolvers
        if not [
            resolver for resolver in Resolver().get_all()
            if resolver.network_id == test.env.net.id
            ]:
            # print("\n!!! Please create resolver for network with id - {0}".format(test.env.net.id))
            test.log.warning(
                "!!! Please create resolver for network with id - {0}".format(
                    test.env.net.id
                )
            )
        # a type of actions we have to waiting for excluding building discs
        self.build_transaction_actions = (
            'provisioning',
            'configure_operating_system'
        )
        if self._create(data):
            if self.transaction_handler('configure_application_server'):
                self._initialise_additional_server_attributes()
                return True
        return False

    def connected(self, timeout=60):
        """
        Check if connection to Application Server established (2002 port is
        open)
        :param timeout: how many times check connection.
        :return: True port is open, else False
        """
        test.log.info("Check if application server is connected...")
        # Check if 2002 port is open
        if self.wait_for_action(
            lambda: self.port_status(2002) == 0,
            timeout=timeout
        ):
            # print("Connection to Application Server established.")
            test.log.info(
                "Connection to Application Server established..."
            )
            return True
        # print("No connection to Application Server. Time out error...")
        test.log.info(
            "No connection to Application Server. Time out error..."
        )
        return False

    def get_initial_root_password(self):
        """ Getting initial_root_password from DB on CP."""
        if not test.cp.db_user:
            test.cp.db_init()

        q = 'SELECT initial_root_password FROM virtual_machines WHERE id = {0}'.format(self.id)
        response = test.cp.mysql_execute(query=q)
        if response:
            #  to get correct password from database
            # for example from 'O?\\\\4!0]yYhsu' -> 'O?\\4!0]yYhsu'
            import codecs
            return codecs.decode(response[0], 'unicode_escape')
        return ''

    def webuzo_version(self):
        """
        Get webuzo version installed on Application server.
        :return: webuzo version
        """
        return self.execute('php /usr/local/webuzo/cli.php -v')

    def port_status(self, port):
        """
        Check if specified port is open
        :param port: server port
        :return: 0 if success else another status code.
        """
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        return sock.connect_ex((self.ip_address, port))


class Accelerator(VirtualMachine):
    route = 'accelerators'
    root_tag = route[:-1]

    def __init__(self, server_id=None):
        self.id = server_id
        super(Accelerator, self).__init__()
        if self.id:
            test.update_object(self)
            self.ip_address = self.primary_ip_address()
        else:
            self.template.get_by_manager_id('cdn')  # need to get min memory size and something else.

    def create(self):
        """
        Create server.
        To set specific parameters for creating you need to set appropriate
        attributes before creation.
        """

        #  in this case we can set memory less than template.min_memory_size to check validation.
        if not self.memory:
            if self.memory < self.template.min_memory_size:
                self.memory = self.template.min_memory_size
        # in this case we can set primary_disk_size less than template.min_disk_size to check validation.
        if not self.primary_disk_size:
            self.primary_disk_size = self.template.min_disk_size
        data = {
            self.root_tag: {
                "template_id": self.template.id,
                "label": self.label,
                "hostname": self.hostname,
                "hypervisor_group_id": self.hypervisor_group_id,
                "hypervisor_id": self.hypervisor_id,
                "memory": self.memory,
                "cpus": self.cpus,
                "cpu_shares": self.cpu_shares,
                "data_store_group_primary_id": self.data_store_group_primary_id,
                "primary_disk_size": self.primary_disk_size,
                "data_store_group_swap_id": self.data_store_group_swap_id,
                "swap_disk_size": self.swap_disk_size,
                "primary_network_group_id": self.primary_network_group_id,
                "required_ip_address_assignment": self.required_ip_address_assignment,
                "rate_limit": self.rate_limit,
                "required_virtual_machine_build": self.required_virtual_machine_build,
                "initial_root_password": self.initial_root_password,
                "primary_disk_min_iops": self.primary_disk_min_iops,
                "swap_disk_min_iops": self.swap_disk_min_iops,
                "enable_autoscale": self.enable_autoscale
            }
        }

        if test.cp_version >= 5.4:
            data["selected_ip_address"] = self.selected_ip_address
        else:
            data["selected_ip_address_id"] = self.selected_ip_address_id

        self.build_transaction_actions = (
            'provisioning',
            'configure_operating_system'
        )

        if self._create(data):
            if self.transaction_handler('create_cdn_server'):
                self._initialise_additional_server_attributes()
                return True
        return False

    def rerun_creation_script(self):
        test.log.info("Rerun creation script")
        if test.post_object(
                url=f"/{self.route}/{self.id}/rerun_creation_scripts.json"
        ):
            return self.transaction_handler('create_cdn_server')
        return False

    def pause_all(self):
        """Pause all accelerators"""
        test.log.info("Pause all accelerators")
        return test.post_object(url=f'/{self.route}/pause_all.json')

    def resume_all(self):
        """Resume all accelerators"""
        test.log.info('Resume all accelerators')
        return test.post_object(url=f'/{self.route}/resume_all.json')
