from onapp_helper.base_helper import BaseHelper
from onapp_helper import test



class Autoscaling(BaseHelper):
    def __init__(self, server, id=None):
        self.server = server
        self.route = '{0}/{1}/auto_scaling'.format(
            self.server.route, self.server.id
        )
        self.enabled = 0
        self.for_minutes = None
        self.limit_trigger = None
        self.adjust_units = None
        self.up_to = None
        self.id = id

    def create(self):
        test.log.info(
            "Create {0} resource with {1} scale type...".format(
                self.resource, self.scale_type
            )
        )
        self.route = '{0}/{1}/auto_scaling'.format(
            self.server.route, self.server.id
        )
        data = {
            "auto_scaling_configurations": {
                self.scale_type: {
                    self.resource: {
                        "enabled": self.enabled,
                        "for_minutes": self.for_minutes,
                        "limit_trigger": self.limit_trigger,
                        "adjust_units": self.adjust_units,
                        "up_to": self.up_to
                    }
                }
            }
        }
        return test.post_object(self, data=data)


class CpuUp(Autoscaling):
    def __init__(self, server, id=None):
        Autoscaling.__init__(self, server, id)
        self.resource = 'cpu'
        self.scale_type = 'up'


class MemoryUp(Autoscaling):
    def __init__(self, server, id=None):
        Autoscaling.__init__(self, server, id)
        self.resource = 'memory'
        self.scale_type = 'up'


class DiskUp(Autoscaling):
    def __init__(self, server, id=None):
        Autoscaling.__init__(self, server, id)
        self.resource = 'disk'
        self.scale_type = 'up'


class CpuDown(Autoscaling):
    def __init__(self, server, id=None):
        Autoscaling.__init__(self, server, id)
        self.resource = 'cpu'
        self.scale_type = 'down'


class MemoryDown(Autoscaling):
    def __init__(self, server, id=None):
        Autoscaling.__init__(self, server, id)
        self.resource = 'memory'
        self.scale_type = 'down'


class DiskDown(Autoscaling):
    def __init__(self, server, id=None):
        Autoscaling.__init__(self, server, id)
        self.resource = 'disk'
        self.scale_type = 'down'




