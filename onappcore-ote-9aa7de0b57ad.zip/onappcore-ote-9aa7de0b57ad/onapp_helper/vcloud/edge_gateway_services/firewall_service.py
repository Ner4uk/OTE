from onapp_helper.base_helper import BaseHelper
from onapp_helper import test



class FirewallService(BaseHelper):
    def __init__(self, id=None):
        self.root_tag = 'vcloud_firewall_service'
        self.id = id

        self.default_action = 'DROP'
        self.edge_gateway_id = None
        self.enabled = True
        self.log_default_action = False

        if self.id:
            self.route = 'firewall_services/{0}'.format(id)
            test.log.info("Get FirewallService...")
            test.update_object(self)
