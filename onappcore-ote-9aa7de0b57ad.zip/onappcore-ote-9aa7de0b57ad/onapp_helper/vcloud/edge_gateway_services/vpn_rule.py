from onapp_helper.base_helper import BaseHelper
from onapp_helper import test



class VpnRule(BaseHelper):
    def __init__(self, vpn_service, id=None):
        self.vpn_service = vpn_service
        self.route = '{0}/tunnels'.format(self.vpn_service.route)
        self.root_tag = 'vcloud_vpn_rule'
        self.id = id

        self.enabled = False
        self.rule_type = "DNAT"
        self.network_id = "679"
        self.original_ip = "192.168.1.1"
        self.original_port = "80"
        self.translated_ip = "192.168.1.100"
        self.translated_port = "82"
        self.protocol = "TCP"

        if self.id:
            test.update_object(self)

    def create(self):
        test.log.info("Create VpnRule...")
        data = {
            self.root_tag: {
                "enabled": self.enabled,
                "rule_type": self.rule_type,
                "network_id": self.network_id,
                "original_ip": self.original_ip,
                "original_port": self.original_port,
                "translated_ip": self.translated_ip,
                "translated_port": self.translated_port,
                "protocol": self.protocol
            }
        }
        if test.post_object(self, data=data):
            if self.transaction_handler(
                    'create_vpn_rule',
                    self.vpn_service.edge_gateway_id
            ):
                return True
        return False

    def edit(self):
        test.log.info("Edit VpnRule...")
        data = {
            self.root_tag: {
                "enabled": self.enabled,
                "rule_type": self.rule_type,
                "network_id": self.network_id,
                "original_ip": self.original_ip,
                "original_port": self.original_port,
                "translated_ip": self.translated_ip,
                "translated_port": self.translated_port,
                "protocol": self.protocol
            }
        }
        if test.put_object(self, data=data):
            if self.transaction_handler(
                    'update_vpn_rule',
                    self.vpn_service.edge_gateway_id
            ):
                return True
        return False

    def delete(self):
        test.log.info("Delete VpnRule...")
        if test.delete_object(self):
            if self.transaction_handler(
                    'delete_vpn_rule',
                    self.vpn_service.edge_gateway_id
            ):
                return True
        return False

    def get_all(self):
        test.log.info("Get VpnRules...")
        rules = []
        if test.get_object(self):
            for rule in self.response:
                rules.append(VpnRule(self.vpn_service, rule[self.root_tag]['id']))
        return rules
