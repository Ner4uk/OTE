from onapp_helper.base_helper import BaseHelper
from onapp_helper import test



class FirewallRule(BaseHelper):
    def __init__(self, firewall_service, id=None):
        self.firewall_service = firewall_service
        self.route = '{0}/firewall_rules'.format(self.firewall_service.route)
        self.root_tag = 'vcloud_firewall_rule'
        self.id = id

        self.enabled = False
        self.description = "Testing FW Rule"
        self.command = "ACCEPT"
        self.address = "192.168.1.1"
        self.source_port = "80"
        self.destination_ip = "109.123.91.18"
        self.port = "80"
        self.protocol = "TCP"
        self.enable_logging = False

        if self.id:
            test.update_object(self)

    def create(self):
        test.log.info("Create FirewallRule...")
        data = {
            self.root_tag: {
                "enabled": self.enabled,
                "description": self.description,
                "command": self.command,
                "address": self.address,
                "source_port": self.source_port,
                "destination_ip": self.destination_ip,
                "port": self.port,
                "protocol": self.protocol,
                "enable_logging": self.enable_logging
            }
        }
        if test.post_object(self, data=data):
            if self.transaction_handler(
                    'create_firewall_rule',
                    self.firewall_service.edge_gateway_id
            ):
                return True
        return False

    def edit(self):
        test.log.info("Edit FirewallRule...")
        data = {
            self.root_tag: {
                "enabled": self.enabled,
                "description": self.description,
                "command": self.command,
                "address": self.address,
                "source_port": self.source_port,
                "destination_ip": self.destination_ip,
                "port": self.port,
                "protocol": self.protocol,
                "enable_logging": self.enable_logging
            }
        }
        if test.put_object(self, data=data):
            if self.transaction_handler(
                    'update_firewall_rule',
                    self.firewall_service.edge_gateway_id
            ):
                return True
        return False

    def delete(self):
        test.log.info("Delete FirewallRule...")
        if test.delete_object(self):
            if self.transaction_handler(
                    'delete_firewall_rule',
                    self.firewall_service.edge_gateway_id
            ):
                return True
        return False

    def get_all(self):
        test.log.info("Get all FirewallRules...")
        rules = []
        if test.get_object(self):
            for rule in self.response:
                rules.append(FirewallRule(self.firewall_service, rule[self.root_tag]['id']))
        return rules
