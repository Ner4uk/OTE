from onapp_helper.base_helper import BaseHelper
from onapp_helper import test



class NatService(BaseHelper):
    def __init__(self, id=None):
        self.root_tag = 'vcloud_nat_service'
        self.id = id

        self.default_action = None
        self.edge_gateway_id = None
        self.enabled = True
        self.log_default_action = False

        if self.id:
            self.route = 'nat_services/{0}'.format(id)
            test.update_object(self)
