from onapp_helper.base_helper import BaseHelper
from onapp_helper import test


class ResourcePool(BaseHelper):
    route = 'vdcs'
    root_tag = 'vdc'

    def __init__(self, id=None):
        self.id = id
        self.label = ''
        self.user_group_id = None
        self.provider_vdc_id = None
        self.allocation_models = "AllocationVApp"
        self.cpu_allocated = 0
        self.memory_allocated = 0
        self.guaranteed_cpu = 0
        self.guaranteed_memory = 0
        self.vm_quota = 0
        self.cpu_limit = 0
        self.memory_limit = 0
        self.vcpu_speed = 0
        self.thin_provisioning = False
        self.fast_provisioning = False
        self.data_store_group_id = 0
        self.data_store_size = 0
        if self.id:
            test.update_object(self)

    # Create/Edit/Delete - https://onappdev.atlassian.net/browse/CORE-5962
    def create(self):
        """AllocationPool has:
            cpu_allocated (GHz),
            memory_allocated(GB),
            guaranteed_cpu(%),
            guaranteed_memory(%),
            vm_quota(number);
           ReservationPool has:
            cpu_allocated,
            memory_allocated,
            vm_quota;
           AllocationVApp has:
            guaranteed_cpu,
            guaranteed_memory,
            vm_quota,
            cpu_limit(GHz),
            memory_limit(GB),
            vcpu_speed(MHz);"""
        test.log.info("Create ResourcePool...")
        data = {
            self.root_tag: {
                "label": self.label,
                "user_group_id": self.user_group_id,
                "provider_vdc_id": self.provider_vdc_id,
                "allocation_model": self.allocation_models,
                "thin_provisioning": self.thin_provisioning,
                "fast_provisioning": self.fast_provisioning,
                "data_stores_attributes": [
                    {
                        "data_store_group_id": self.data_store_group_id,
                        "data_store_size": self.data_store_size,
                        "data_store_type": "vcloud"
                    }
                ]
            }
        }
        data = self._set_allocation_model_related_data(data)

        if test.post_object(self, data=data):
            if self.transaction_handler('create_vdc_without_template', self.id):
                if test.update_object(self):
                    return True

        return False

    def edit(self):
        """AllocationPool has:
            cpu_allocated (GHz),
            memory_allocated(GB),
            guaranteed_cpu(%),
            guaranteed_memory(%),
            vm_quota(number);
           ReservationPool has:
            cpu_allocated,
            memory_allocated,
            vm_quota;
           AllocationVApp has:
            guaranteed_cpu,
            guaranteed_memory,
            vm_quota,
            cpu_limit(GHz),
            memory_limit(GB),
            vcpu_speed(MHz);"""
        test.log.info("Edit ResourcePool...")
        data = {
            self.root_tag: {
                "allocation_model": self.allocation_models,
                "thin_provisioning": self.thin_provisioning,
                "fast_provisioning": self.fast_provisioning
            }
        }
        data = self._set_allocation_model_related_data(data)
        if test.put_object(self, data=data):
            if self.transaction_handler('update_vdc', self.id):
                if test.update_object(self):
                    return True
        return False

    def delete(self):
        test.log.info("Delete ResourcePool...")
        if test.delete_object(self):
            if self.transaction_handler('destroy_vdc', self.id):
                return True
        return False

    # def get_all(self):
    #     """
    #     Return the array of objects
    #     """
    #     test.log.info("Get all ResourcePool...")
    #     objects = []
    #     if self._get_handler('/{0}.json'.format(self.route)):
    #         for u in self.response:
    #             obj = ResourcePool()
    #             obj.__dict__.update(u[self.root_tag])
    #             objects.append(obj)
    #     return objects

    def _set_allocation_model_related_data(self, data):
        if self.allocation_models == "AllocationPool":
            data[self.root_tag]['cpu_allocated'] = self.cpu_allocated
            data[self.root_tag]['memory_allocated'] = self.memory_allocated
            data[self.root_tag]['guaranteed_cpu'] = self.guaranteed_cpu
            data[self.root_tag]['guaranteed_memory'] = self.guaranteed_memory
            data[self.root_tag]['vm_quota'] = self.vm_quota
            data[self.root_tag]['vcpu_speed'] = self.vcpu_speed
        elif self.allocation_models == "ReservationPool":
            data[self.root_tag]['cpu_allocated'] = self.cpu_allocated
            data[self.root_tag]['memory_allocated'] = self.memory_allocated
            data[self.root_tag]['vm_quota'] = self.vm_quota
        elif self.allocation_models == "AllocationVApp":
            data[self.root_tag]['guaranteed_cpu'] = self.guaranteed_cpu
            data[self.root_tag]['guaranteed_memory'] = self.guaranteed_memory
            data[self.root_tag]['vm_quota'] = self.vm_quota
            data[self.root_tag]['cpu_limit'] = self.cpu_limit
            data[self.root_tag]['memory_limit'] = self.memory_limit
            data[self.root_tag]['vcpu_speed'] = self.vcpu_speed
        return data
