from onapp_helper.base_helper import BaseHelper
from onapp_helper.vcloud.vapp_template import VAppTemplate
from onapp_helper import test



#class VCloudVappTemplate(RequestHandler):
#    def __init__(self):
#        #self.vcloud_catalog = vcloud_catalog
#        #self.route = '%s/%s/vapp_templates' % (self.vcloud_catalog.route, self.vcloud_catalog.id)
#        self.root_tag = 'vcloud_vapp_template'
#        #self.id = id
#
#    def get_virtual_machines(self):
#        """Return an array of virtual machines:
#
#        [
#
#            {
#
#                "identifier": "vm-d5de903c-2c75-4c09-aca8-572e418e28fe",
#                "name": "Centos66_PV_controller",
#                "disks":
#
#            [
#
#                {
#                    "label": "Hard disk 1",
#                    "capacity": "4096"
#                }
#
#            ],
#            "nics":
#
#                    [
#                        "0"
#                    ],
#                    "cpus": "1",
#                    "cores_per_socket": "1",
#                    "memory": "1024"
#                }
#
#        ]
#        """
#        return self.virtual_machines
#
#    #    self.label = ''
#    #    self.ovf_url = ''
#    #
#    #    #if self.id:
#    #    #    test.update_object(self)
#    #
#    #def add(self):
#    #    data = {
#    #        self.root_tag: {
#    #            "vdc_id": self.vdc_id,
#    #            "ovf_url": self.ovf_url
#    #        }
#    #    }
#    #    url = '/%s.json' % self.route
#    #    return self._post_handler(url, data)
#    #
#    #def get(self):
#    #    """Return an array of vapp templates."""
#    #    test.log.info("Get all vcloud_vapp_template...")
#    #    objects = []
#    #    if self._get_handler('/%s.json' % self.route):
#    #        for vcloud_vapp_template in self.response:
#    #            obj = VCloudVappTemplate(self.test)
#    #            obj.__dict__.update(vcloud_vapp_template[self.root_tag])
#    #            objects.append(obj)
#    #    return objects


class VCloudMedia(BaseHelper):
    def __init__(self):
        #self.vcloud_catalog = vcloud_catalog
        #self.route = '%s/%s/media' % (self.vcloud_catalog.route, self.vcloud_catalog.id)
        self.root_tag = 'vcloud_media'
        #self.id = id
    #
    #    self.label = ''
    #    self.ovf_url = ''
    #
    #    #if self.id:
    #    #    test.update_object(self)
    #
    ##def add(self):
    ##    data = {
    ##        self.root_tag: {
    ##            "vdc_id": self.vdc_id,
    ##            "ovf_url": self.ovf_url
    ##        }
    ##    }
    ##    url = '/%s.json' % self.route
    ##    return self._post_handler(url, data)
    #
    #def get(self):
    #    """Return an array of vcloud media."""
    #    test.log.info("Get all vcloud_media...")
    #    objects = []
    #    if self._get_handler('/%s.json' % self.route):
    #        for vcloud_media in self.response:
    #            obj = VCloudMedia(self.test)
    #            obj.__dict__.update(vcloud_media[obj.root_tag])
    #            objects.append(obj)
    #    return objects


class VCloudCatalog(BaseHelper):
    route = 'catalogs'
    root_tag = 'vcloud_catalog'

    def __init__(self, id=None):
        self.id = id
        self.vapp_template = VAppTemplate(self)
        self.vdc_id = ''  # vCloud resource pool id
        self.label = ''
        self.user_group_id = ''
        self.data_store_id = ''

        if self.id:
            test.update_object(self)

    def create(self):
        test.log.info("Create Catalog...")
        data = {
            self.root_tag: {
                "vdc_id": self.vdc_id,
                "label": self.label,
                "user_group_id": self.user_group_id,
                "data_store_id": self.data_store_id
            }
        }
        if test.post_object(self, data=data):
            if self.transaction_handler("create_vcloud_catalog", self.id):
                self.vapp_template.__init__(self)
                return True

        return False

    #def edit(self):
    #    data = {
    #        self.root_tag: {
    #            "vdc_id": self.vdc_id,
    #            "label": self.label,
    #            "description": self.description,
    #            "gateway_backing_config": self.gateway_backing_config,
    #            "ha_enabled": self.ha_enabled,
    #            "external_network_ids": self.external_network_ids,
    #            "use_default_route_for_dns_relay": self.use_default_route_for_dns_relay
    #        }
    #    }
    #    url = '/%s/%s.json' % (self.route, self.id)
    #    return self._put_handler(url, data)

    def delete(self):
        test.log.info("Delete Catalog - %d..." % self.id)
        if test.delete_object(self):
            if self.transaction_handler("delete_vcloud_catalog", self.id):
                return True

        return False

    def get_all(self):
        """
        Return the array of objects
        """
        test.log.info("Get all Catalogs...")
        objects = []
        if test.get_object(self):
            for u in self.response:
                obj = VCloudCatalog(u[self.root_tag]['id'])
                objects.append(obj)
        return objects

    def get(self):
        """
        Get Catalog details
        """
        test.log.info("Get Catalog details...")
        if test.update_object():
            self.__dict__.update(self.response[self.root_tag])
            return True
        return False

    def get_media(self):
        """Return an array of vcloud media."""
        test.log.info("Get all vcloud_media...")
        objects = []
        url = '/{0}/{1}/media.json'.format(self.route, self.id)
        if test.get_object(self, url=url):
            if self.response:
                for vcloud_media in self.response:
                    obj = VCloudMedia()
                    obj.__dict__.update(vcloud_media[obj.root_tag])
                    objects.append(obj)
        return objects

    def add_vapp_template(self):
        return self.vapp_template.add_vapp_template()

    def delete_vapp_template(self):
        return self.vapp_template.delete_vapp_template()

    def get_vapp_templates(self):
        return self.vapp_template.get_vapp_templates()