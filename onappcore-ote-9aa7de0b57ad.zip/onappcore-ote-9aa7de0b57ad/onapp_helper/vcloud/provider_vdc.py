from onapp_helper.base_helper import BaseHelper


class ProviderVDC(BaseHelper):
    root_tag = 'provider_vdc'
    route = 'provider_vdcs'

    def __init__(self):
        # Working with first element of provider vdcs
        self.cpu_allocated = 0
        self.cpu_total = 0
        self.cpu_used = 0
        self.enabled = None
        self.hypervisor_id = 0
        self.identifier = ""
        self.memory_allocated = 0
        self.memory_total = 0
        self.memory_used = 0
        self.storage_policies = []
        self.external_networks = []
        self.network_pools = []
        self.id = 0

        # url = "/provider_vdcs.json"
        # self._get_handler(url)
        # self.provider_vdcs = self.response

    # def get_all(self):
    #     """ Return an array of provider_vdcs objects."""
    #     url = '/{0}.json'.format(self.route)
    #     provider_vdcs = []
    #     if self._get_handler(url):
    #         for provider_vdc in self.response:
    #             obj = ProviderVDC()
    #             obj.__dict__.update(provider_vdc[self.root_tag])
    #             provider_vdcs.append(obj)
    #     return provider_vdcs

    def edge_gateway_uplink_network_id(self):
        if self.external_networks:
            return self.external_networks[0]['external_network']['id']
        return None

    def default_network_pool(self, hv_id):
        network_pools = self.network_pools
        if network_pools:
            return [
                nt_pool['network_pool']['identifier'].split('-', 1)[1] for nt_pool in network_pools
                if nt_pool['network_pool']['hypervisor_id'] == hv_id
                ][0]
        return None