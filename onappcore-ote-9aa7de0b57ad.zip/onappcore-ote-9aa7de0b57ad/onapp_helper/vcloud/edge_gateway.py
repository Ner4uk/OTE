from onapp_helper.base_helper import BaseHelper
from onapp_helper import test



class EdgeGateways(BaseHelper):
    route = 'edge_gateways'
    root_tag = 'edge_gateway'

    def __init__(self, id=None):
        self.id = id

        self.vdc_id = ''  # vCloud resource pool id
        self.label = ''
        self.description = ''
        self.gateway_backing_config = ''
        self.ha_enabled = ''
        self.external_network_ids = []
        self.use_default_route_for_dns_relay = ''

        if self.id:
            test.update_object(self)

    def create(self):
        test.log.info("Create EdgeGateway...")
        data = {
            self.root_tag: {
                "vdc_id": self.vdc_id,
                "label": self.label,
                "description": self.description,
                "gateway_backing_config": self.gateway_backing_config,
                "ha_enabled": self.ha_enabled,
                "external_network_ids": self.external_network_ids,
                "use_default_route_for_dns_relay": self.use_default_route_for_dns_relay
            }
        }
        if test.post_object(self, data=data):
            if self.transaction_handler("create_edge_gateway", self.id):
                return True
        return False

    def edit(self):
        test.log.info("Edit EdgeGateway...")
        data = {
            self.root_tag: {
                "vdc_id": self.vdc_id,
                "label": self.label,
                "description": self.description,
                "gateway_backing_config": self.gateway_backing_config,
                "ha_enabled": self.ha_enabled,
                "external_network_ids": self.external_network_ids,
                "use_default_route_for_dns_relay": self.use_default_route_for_dns_relay
            }
        }
        return test.put_object(self, data=data)

    def get_all(self):
        """
        Return the array of objects
        """
        test.log.info("Get all EdgeGateways...")
        objects = []
        if test.get_object(self):
            for u in self.response:
                obj = EdgeGateways()
                obj.__dict__.update(u[self.root_tag])
                objects.append(obj)
        return objects

    # def get(self):
    #     """
    #
    #     """
    #     test.log.info("Get EdgeGateway...")
    #     if test.get_object(
    #             self, url='/{0}/{1}.json'.format(self.route, self.id)
    #     ):
    #         self.__dict__.update(self.response[self.root_tag])
    #         return True
    #     return False

    def get_external_network_ids(self, vdc_id):
        ids = []
        url = '/{0}/external_networks.json?vdc_id={1}'.format(self.route, vdc_id)
        if test.get_object(self, url=url):
            for en in self.response:
                ids.append(str(en['id']))
        return ids

    # get interfaces attached to edge gateway.
    # https://onappdev.atlassian.net/browse/CORE-7028
