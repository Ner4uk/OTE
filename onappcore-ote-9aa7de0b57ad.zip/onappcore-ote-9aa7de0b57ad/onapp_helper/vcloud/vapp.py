from onapp_helper import test
from onapp_helper.base_helper import BaseHelper
from onapp_helper.data_store import DataStore
from onapp_helper.vcloud.org_network import OrgNetworks


class Vapp(BaseHelper):
    route = 'vapps'
    root_tag = route[:-1]

    def __init__(self, id=None):
        self.org_network = OrgNetworks().get_all()[0]
        self.name = ''
        self.vdc_id = ''  # this is resource pool id in CP
        self.vapp_template_ids = []
        self.vapp_ids = []
        self.vapp_template_id = ""
        self.networks = []
        self.blank_vapp = '0'

        self.vapp_template_vms = []
        self.storage_policy = ""
        self.disk_space = ""

        self.id = id
        if self.id:
            test.update_object(self)

    def compose(self):
        """
            name = ''
            vdc_id = ''
            blank_vapp = "1" OTHERWISE consider the following
            vapp_template_ids = []
            vapp_ids = []
        """
        test.log.info("Compose vapp...")
        if self.blank_vapp == "1":
            data = {
                self.root_tag: {
                    "name": self.name,
                    "vdc_id": self.vdc_id,
                    "blank_vapp": self.blank_vapp
                }
            }
        else:
            data = {
                self.root_tag: {
                    "name": self.name,
                    "vdc_id": self.vdc_id,
                    "vapp_template_ids": str(self.vapp_template_ids),
                    "vapp_ids": str(self.vapp_ids)
                }
            }
        url = '/{0}/compose.json'.format(self.route)
        if test.post_object(self, url=url, data=data):
            if self.transaction_handler('compose_vapp', self.id):
                return True
        return False

    def recompose(self, template):
        """
            name = ''
            vdc_id = ''
            vapp_template_ids = []
        """
        test.log.info("Recompose vapp...")
        temp_vm = template.virtual_machines[0]
        data = {
            self.root_tag: {
                "vapp_template_id": str(template.id),
                "virtual_machines": {
                    "virtual_machine_0": {
                        "id": template.virtual_machines[0]['identifier'],
                        "name": template.label + '_added_to_vapp',
                        "cpus": temp_vm['cpus'],
                        "cores_per_socket": temp_vm['cores_per_socket'],
                        "memory": temp_vm['memory'],
                        "storage_policy": "303",
                        "hard_disks": {
                            "hard_disk_1": {
                                "label": temp_vm['disks'][0]['label'],
                                "disk_space": str(int(int(temp_vm['disks'][0]['capacity']) / 1000)),
                                "storage_policy": ""}},
                        "boot_vm": "true"}}}}
        url = f"/{self.route}/{self.id}/recompose.json"
        if test.put_object(self, url=url, data=data):
            if self.transaction_handler('recompose_vapp', self.id):
                return True
        return False

    def edit(self):
        """Edit server.
        To set specific parameters for editing you need to set appropriate
        attributes before creation.

        """
        test.log.info("Edit the Vapp name...")
        data = {
            self.root_tag: {"name": self.name}
        }
        test.log.info("Start to edit Vapp...")
        if test.put_object(self, data=data):
            action_edit_vapp = 'update_vapp'
            if self.transaction_handler(action_edit_vapp, pages=2):
                return test.update_object(self)
        return False

    def add_from_catalog(self):
        test.log.info("Add from catalog...")
        self.data_stores = DataStore().get_by_params()
        data = {
            self.root_tag: {
                "name": self.name,
                "vapp_template_id": self.vapp_template_id,
                "vdc_id": self.vdc_id,
                # "networks": self.networks,
                "virtual_machines": {
                    # "vm-7e6c3fe6-c7c0-404c-9874-5141e2b39e32": {
                    #    "name": "CentOS",
                    #    "vcpu_per_vm": "4",
                    #    "core_per_socket": "1",
                    #    "memory": "1024",
                    #    "storage_policy": self.storage_policy,
                    #    "hard_disks": {
                    #        "Hard disk 1": {
                    #            "disk_space": self.disk_space
                    #        }
                    #    }
                    # }
                }
            }
        }

        ## Example for Template
        # {
        #     "vapp": {
        #         "name": "APIvApp",
        #         "vdc_id": "31",
        #         "vapp_template_id": "15",
        #         "virtual_machines": {
        #             "virtual_machine_0": {
        #                 "id": "vm-d50358cd-9a94-47fd-b302-429b2023f3a0",
        #                 "name": "VM1",
        #                 "cpus": "1",
        #                 "cores_per_socket": "1",
        #                 "memory": "512",
        #                 "storage_policy": "60",
        #                 "hard_disks": {
        #                     "hard_disk_1": {
        #                         "disk_space": "3"
        #                     }
        #                 },
        #                 "nics": {
        #                     "nic_0": {
        #                         "network_id": "2"
        #                     }
        #                 }
        #             },
        #         "virtual_machine_1": {
        #             "id": "vm-bc11995c-1429-47a6-8cca-39d50a3865df",
        #             "name": "VM2",
        #             "cpus": "1",
        #             "cores_per_socket": "1",
        #             "memory": "512",
        #             "storage_policy": "60",
        #             "hard_disks": {
        #                 "hard_disk_1": {
        #                     "disk_space": "3"
        #                 }
        #             },
        #             "nics": {
        #                 "nic_0": {
        #                     "network_id": "1"
        #                 }
        #             }
        #         }
        #         }
        #     }
        # }


        vm_counter = 0
        for vapp_template_vm in self.vapp_template_vms:
            vm_key = 'virtual_machine_{0}'.format(str(vm_counter))
            vm_params = {}
            vm_params["identifier"] = vapp_template_vm["identifier"]
            vm_params["name"] = vapp_template_vm["name"]
            vm_params["cpus"] = vapp_template_vm["cpus"]
            vm_params["core_per_socket"] = vapp_template_vm["cores_per_socket"]
            vm_params["memory"] = vapp_template_vm["memory"]
            # vm_params["storage_policy"] = [ds.id for ds in self.data_stores if int(bool(ds.vdc_id)) == int(self.vdc_id)][0]
            # vm_params["storage_policy"] = list(filter(lambda ds: int(ds.vdc_id) == int(self.vdc_id), self.data_stores))[0]
            vm_params["storage_policy"] = self._get_storage_policy(data_stores=self.data_stores)
            disk_space = str(int(vapp_template_vm["disks"][0]["capacity"]) / 1024)
            vm_params["hard_disks"] = {
                vapp_template_vm["disks"][0]["label"].lower().replace(' ', '_'): {
                    "disk_space": disk_space
                }
            }
            for nic in vapp_template_vm["nics"]:
                vm_params["nics"] = {
                    "nic_{0}".format(nic): {
                        "network_id": self.org_network.id
                    }
                }

            data[self.root_tag]["virtual_machines"][vm_key] = vm_params
            # vm_key = int(vm_key[-1])
            vm_counter += 1

        if test.post_object(self, data=data):
            if self.transaction_handler('provision_vapp', self.id):
                return True
        return False

    def _get_storage_policy(self, data_stores):
        """
        This func for get storage_policy
        """

        for ds in data_stores:
            if ds.vdc_id == int(self.vdc_id):
                return str(ds.vdc_id)

    def delete(self):
        test.log.info("Delete vapp...")
        if test.delete_object(self):
            if self.transaction_handler("destroy_vapp", self.id):
                return True
        return False

    # def get_all(self):
    #     """
    #         Return the array of objects
    #     """
    #     test.log.info("Get all Vapps...")
    #     objects = []
    #     if self._get_handler('/{0}.json'.format(self.route)):
    #         for vapp in self.response:
    #             obj = Vapp()
    #             obj.__dict__.update(vapp[self.root_tag])
    #             objects.append(obj)
    #     return objects

    def get(self):
        """
            Return the array of objects
        """
        test.log.info("Get Vapp...")
        if test.update_object(self):
            self.__dict__.update(self.response[self.root_tag])
            return True
        return False

    def get_vapp_virtual_servers(self):
        """
            Return the array of virtual machines hashes
        """
        vapp_servers = []
        test.log.info("Get Vapp servers...")
        url = '/{0}/{1}/virtual_machines.json'.format(self.route, self.id)
        if test.get_object(self, url=url):
            for vm in self.response:
                vapp_servers.append(vm['virtual_machine'])
        return vapp_servers
