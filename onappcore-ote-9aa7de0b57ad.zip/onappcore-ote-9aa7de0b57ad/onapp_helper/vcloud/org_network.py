from onapp_helper.base_helper import BaseHelper
from onapp_helper import test



class OrgNetworks(BaseHelper):
    route = 'org_networks'
    root_tag = 'org_network'

    def __init__(self, id=None):
        self.id = id
        self.label = ''
        self.vdc_id = ''
        self.fence_mode = "bridged" # natRouted, isolated, bridged
        self.parent_network_id = ""
        self.network_gateway_cidr = ""
        self.edge_gateway = ''
        self.shared = "0"
        self.use_gateway_dns = "0"
        self.dns_addresses = ""
        self.dns_suffix = ""
        self.start_address = ""
        self.end_address = ""

        if self.id:
            test.update_object(self)

    # def get_all(self):
    #     """
    #     Return the array of objects
    #     """
    #     test.log.info("Get all OrgNetworks...")
    #     objects = []
    #     if self._get_handler('/{0}.json'.format(self.route)):
    #         for u in self.response:
    #             obj = OrgNetworks()
    #             obj.__dict__.update(u[self.root_tag])
    #             objects.append(obj)
    #     return objects

    def get(self, id):
        """
        Return the array of objects
        """
        test.log.info("Get OrgNetwork...")
        if test.get_object(self, url='/{0}/{1}.json'.format(self.route, id)):
            self.__dict__.update(self.response[self.root_tag])
            return True
        return False

    def create(self):
        test.log.info("Create OrgNetwork...")
        data = {
            self.root_tag: {
                "label": self.label,
                "vdc_id": self.vdc_id,
                "fence_mode": self.fence_mode,
                "parent_network_id": self.parent_network_id,
                "network_gateway_cidr": self.network_gateway_cidr,
                "shared": self.shared,
                "edge_gateway": self.edge_gateway,
                "use_gateway_dns": self.use_gateway_dns,
                "dns_addresses": self.dns_addresses,
                "dns_suffix": self.dns_suffix,
                "ip_ranges": [
                    {
                        "start_address": self.start_address,
                        "end_address": self.end_address
                    }
                ]
            }
        }

        if test.post_object(self, data=data):
            if self.transaction_handler('create_org_network', parent_id=self.vdc_id):
                test.update_object(self)
                return True
        return False

    def edit(self):
        test.log.info("Edit OrgNetwork...")
        data = {
            self.root_tag: {
                "label": self.label,
                "shared": self.shared
            }
        }

        if test.put_object(self, data=data):
            if self.transaction_handler('update_org_network', self.id):
                test.update_object(self)
                return True
        return False

    def delete(self):
        test.log.info("Delete OrgNetwork...")

        if test.delete_object(self):
            if self.transaction_handler('destroy_org_network', self.id):
                return True
        return False