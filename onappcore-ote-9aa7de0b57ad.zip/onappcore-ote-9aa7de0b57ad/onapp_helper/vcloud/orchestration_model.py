from onapp_helper.base_helper import BaseHelper
from onapp_helper.vcloud.provider_vdc import ProviderVDC
from onapp_helper.vcloud.resource_pool import ResourcePool
from onapp_helper.vcloud.edge_gateway import EdgeGateways
from onapp_helper import test



class OrchestrationModel(BaseHelper):
    route = 'vcloud/templates'
    root_tag = 'vcloud_template'

    def __init__(self, hv_id, id=None):
        """vdc_model_type - allocation/reservation/pay_as_you_go"""

        self.provider_vdc = ProviderVDC()
        self.provider_vdc.get_first()
        self.resource_pool = ResourcePool()
        self.edge_gateway = EdgeGateways()

        # properties
        self.label = "zaza_test"
        self.hypervisor_id = hv_id
        self.provider_vdc_id = self.provider_vdc.id

        # Compute Options
        self.vdc_model_type = ""
        # vDC Properties
        self.cpu_allocation_min = 1
        self.cpu_allocation_max = 12
        self.cpu_allocation_default = 1
        self.cpu_allocation_customizable = 1
        self.cpu_allocation_visible = 1
        self.cpu_allocation = self.cpu_allocation_min

        self.cpu_guaranteed_min = 1
        self.cpu_guaranteed_max = 100
        self.cpu_guaranteed_default = 10
        self.cpu_guaranteed_customizable = 1
        self.cpu_guaranteed_visible = 1
        self.cpu_guaranteed = self.cpu_guaranteed_min

        self.vcpu_speed_min = 1
        self.vcpu_speed_max = 3
        self.vcpu_speed_default = 1
        self.vcpu_speed_customizable = True
        self.vcpu_speed_visible = True
        self.vcpu_speed = self.vcpu_speed_min

        self.memory_min = 4
        self.memory_max = 40
        self.memory_default = 8
        self.memory_customizable = 1
        self.memory_visible = 1
        self.memory = self.memory_min

        self.memory_guaranteed_min = 20
        self.memory_guaranteed_max = 100
        self.memory_guaranteed_default = 20
        self.memory_guaranteed_customizable = 1
        self.memory_guaranteed_visible = 1
        self.memory_guaranteed = self.memory_guaranteed_min

        self.vm_number_min = 1
        self.vm_number_max = 500
        self.vm_number_default = 100
        self.vm_number_customizable = 1
        self.vm_number_visible = 1
        self.vm_number = self.vm_number_min

        self.memory_quota_min = 4
        self.memory_quota_max = 40
        self.memory_quota_default = 8
        self.memory_quota_customizable = True
        self.memory_quota_visible = True
        self.memory_quota = self.memory_quota_min

        self.cpu_quota_min = 10
        self.cpu_quota_max = 100
        self.cpu_quota_default = 40
        self.cpu_quota_customizable = True
        self.cpu_quota_visible = True
        self.cpu_quota = self.cpu_quota_min

        # Network Options
        self.default_network_pool = self.provider_vdc.default_network_pool(self.hypervisor_id)  # network group identifier
        self.edge_gateway_name = 'ZazaAPITest'
        self.edge_gateway_uplink_network_id = self.provider_vdc.edge_gateway_uplink_network_id()  #!!! external network
        self.enable_thin_provisioning = 0
        self.enable_fast_provisioning = 1
        #  Get fake network, which has a lot of ip addresses
        external_network_id = 0
        external_network = [
            net['external_network'] for net in self.provider_vdc.external_networks
            if 'fake' in net['external_network']['label'].lower()
            ]
        if external_network:
            external_network_id = external_network[0]['id']
        self.edge_gateway_uplink_networks = [external_network_id,]

        self.data_stores_to_create = []
        self.network_to_create = []
        if id:
            self.id = id
            test.update_object(self)

    def create(self):
        test.log.info("Create orchestration model...")
        data_stores = self.provider_vdc.storage_policies
        for ds in data_stores:
            if ds['storage_policy']['hypervisor_id'] == self.hypervisor_id:
                self.data_stores_to_create.append(
                    {
                        "label": ds['storage_policy']['label'],
                        "id": ds['storage_policy']['identifier'],
                        "min": 0,
                        "max": 999999,
                        "default": 100,
                        "data_store_customizable": True,
                        "data_store_visible": True,
                        "use_it": True
                    }
                )
        data = {
            self.root_tag: {
                "label": self.label,
                "hypervisor_id": self.hypervisor_id,
                "provider_vdc_id": self.provider_vdc_id,
                "vdc_model_type": self.vdc_model_type,
                "default_network_pool": self.default_network_pool,
                "edge_gateway_name": self.edge_gateway_name,
                "edge_gateway_uplink_network_id": self.edge_gateway_uplink_network_id,
                "enable_thin_provisioning": self.enable_thin_provisioning,
                "enable_fast_provisioning": self.enable_fast_provisioning,
                "data_stores_to_create": self.data_stores_to_create,
                "networks_to_create": self.network_to_create
            }
        }

        if self.vdc_model_type == 'allocation':
            data[self.root_tag].update(self._data_for_allocation_type())
        elif self.vdc_model_type == 'reservation':
            data[self.root_tag].update(self._data_for_reservation_type())
        elif self.vdc_model_type == 'pay_as_you_go':
            data[self.root_tag].update(self._data_for_pay_as_you_go_type())

        if test.post_object(self, data=data):
            return test.update_object(self)
        return False

    def edit(self):
        test.log.info("Edit orchestration model...")
        # currently is not supported.
        pass

    def deploy(self, user_group_id):
        """vcpu_speed - taken from info_hub.yml"""
        test.log.info("Deploy orchestration model...")
        data_stores_to_deploy = []
        for ds in self.data_stores_to_create:
            data_stores_to_deploy.append(
                {
                    "label": ds['label'],
                    "id": ds['id'],
                    "disk_space": "100"
                }
            )
        url = "/{0}/{1}/deploy.json".format(self.route, self.id)
        data = {
            self.root_tag: {
                "user_group_id": str(user_group_id),
                "vdc_label": self.__class__.__name__ + self.vdc_model_type.capitalize(),
                "cpu_allocation": self.cpu_allocation,
                "cpu_guaranteed": self.cpu_guaranteed,
                "vcpu_speed": self.vcpu_speed,
                "cpu_quota": self.cpu_quota,
                "memory": self.memory,
                "memory_guaranteed": self.memory_guaranteed,
                "memory_quota": self.memory_quota,
                "vm_number": self.vm_number,
                "storage_profile": data_stores_to_deploy[0]['id'],
                "data_stores_created": data_stores_to_deploy,
                #"networks_to_create": self.network_to_create,
                "edge_gateway_uplink_networks": self.edge_gateway_uplink_networks
            }
        }
        if test.post_object(self, url=url, data=data):
            self.resource_pool = [
                rp for rp in self.resource_pool.get_all()
                if rp.label == data[self.root_tag]['vdc_label']
                ][0]
            self.edge_gateway = [
                eg for eg in self.edge_gateway.get_all()
            ][-1]
            #  Deployment includes some transactions like create resource pool, create data store, create edge gateway
            # create_org_network...
            # create_org_network the last so try to wait for it
            return self.transaction_handler(
                'create_org_network', self.resource_pool.id
            )
        return False

    def delete_deployed(self):
        test.log.info("Delete deployed orchestration model...")
        if self.resource_pool.delete():
            if self.transaction_handler('destroy_vdc', self.resource_pool.id):
                return True
        return False

    def _data_for_allocation_type(self):
        return {
            "cpu_allocation_min": self.cpu_allocation_min,
            "cpu_allocation_max": self.cpu_allocation_max,
            "cpu_allocation_default": self.cpu_allocation_default,
            "cpu_allocation_customizable": self.cpu_allocation_customizable,
            "cpu_allocation_visible": self.cpu_allocation_visible,
            "cpu_guaranteed_min": self.cpu_guaranteed_min,
            "cpu_guaranteed_max": self.cpu_guaranteed_max,
            "cpu_guaranteed_default": self.cpu_guaranteed_default,
            "cpu_guaranteed_customizable": self.cpu_guaranteed_customizable,
            "cpu_guaranteed_visible": self.cpu_guaranteed_visible,
            "vcpu_speed_min": self.vcpu_speed_min,
            "vcpu_speed_max": self.vcpu_speed_max,
            "vcpu_speed_default": self.vcpu_speed_default,
            "vcpu_speed_customizable": self.vcpu_speed_customizable,
            "vcpu_speed_visible": self.vcpu_speed_visible,
            "memory_min": self.memory_min,
            "memory_max": self.memory_max,
            "memory_default": self.memory_default,
            "memory_customizable": self.memory_customizable,
            "memory_visible": self.memory_visible,
            "memory_guaranteed_min": self.memory_guaranteed_min,
            "memory_guaranteed_max": self.memory_guaranteed_max,
            "memory_guaranteed_default": self.memory_guaranteed_default,
            "memory_guaranteed_customizable": self.memory_guaranteed_customizable,
            "memory_guaranteed_visible": self.memory_guaranteed_visible,
            "vm_number_min": self.vm_number_min,
            "vm_number_max": self.vm_number_max,
            "vm_number_default": self.vm_number_default,
            "vm_number_customizable": self.vm_number_customizable,
            "vm_number_visible": self.vm_number_visible
        }

    def _data_for_reservation_type(self):
        return {
            "cpu_allocation_min": self.cpu_allocation_min,
            "cpu_allocation_max": self.cpu_allocation_max,
            "cpu_allocation_default": self.cpu_allocation_default,
            "cpu_allocation_customizable": self.cpu_allocation_customizable,
            "cpu_allocation_visible": self.cpu_allocation_visible,
            "memory_min": self.memory_min,
            "memory_max": self.memory_max,
            "memory_default": self.memory_default,
            "memory_customizable": self.memory_customizable,
            "memory_visible": self.memory_visible,
            "vm_number_min": self.vm_number_min,
            "vm_number_max": self.vm_number_max,
            "vm_number_default": self.vm_number_default,
            "vm_number_customizable": self.vm_number_customizable,
            "vm_number_visible": self.vm_number_visible
        }

    def _data_for_pay_as_you_go_type(self):
        return {
            "cpu_guaranteed_min": self.cpu_guaranteed_min,
            "cpu_guaranteed_max": self.cpu_guaranteed_max,
            "cpu_guaranteed_default": self.cpu_guaranteed_default,
            "cpu_guaranteed_customizable": self.cpu_guaranteed_customizable,
            "cpu_guaranteed_visible": self.cpu_guaranteed_visible,
            "cpu_quota_min": self.cpu_quota_min,
            "cpu_quota_max": self.cpu_quota_max,
            "cpu_quota_default": self.cpu_quota_default,
            "cpu_quota_customizable": self.cpu_quota_customizable,
            "cpu_quota_visible": self.cpu_quota_visible,
            "vcpu_speed_min": self.vcpu_speed_min,
            "vcpu_speed_max": self.vcpu_speed_max,
            "vcpu_speed_default": self.vcpu_speed_default,
            "vcpu_speed_customizable": self.vcpu_speed_customizable,
            "vcpu_speed_visible": self.vcpu_speed_visible,
            "memory_quota_min": self.memory_quota_min,
            "memory_quota_max": self.memory_quota_max,
            "memory_quota_default": self.memory_quota_default,
            "memory_quota_customizable": self.memory_quota_customizable,
            "memory_quota_visible": self.memory_quota_visible,
            "memory_guaranteed_min": self.memory_guaranteed_min,
            "memory_guaranteed_max": self.memory_guaranteed_max,
            "memory_guaranteed_default": self.memory_guaranteed_default,
            "memory_guaranteed_customizable": self.memory_guaranteed_customizable,
            "memory_guaranteed_visible": self.memory_guaranteed_visible,
            "vm_number_min": self.vm_number_min,
            "vm_number_max": self.vm_number_max,
            "vm_number_default": self.vm_number_default,
            "vm_number_customizable": self.vm_number_customizable,
            "vm_number_visible": self.vm_number_visible
        }
