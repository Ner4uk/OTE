
from onapp_helper import test
from onapp_helper.base_helper import BaseHelper


class Organization(BaseHelper):
    route = 'organizations'
    root_tag = 'vcloud_organization'

    def __init__(self, id=None):
        self.label = ''
        self.hypervisor_id = None
        self.create_user_group = False
        self.company_billing_plan_id = None
        self.id = id
        if self.id:
            test.update_object(self)

    def create(self):
        test.log.info("Create {}".format(self.__class__.__name__))
        data = {
            self.root_tag: {
                "label": self.label,
                "hypervisor_id": self.hypervisor_id,
                "create_user_group": self.create_user_group,
                "company_billing_plan_id": self.company_billing_plan_id,
            }
        }
        if test.post_object(self, data=data):
            return self.transaction_handler("create_organization")
        return False

    def delete(self):
        test.log.info("Delete organization - {}".format(self.id))
        if test.delete_object(self):
            return self.transaction_handler("delete_organization")
        return False


