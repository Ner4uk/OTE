from onapp_helper.base_helper import BaseHelper
from onapp_helper import test



class VAppTemplate(BaseHelper):
    def __init__(self, catalog, id=None):
        self.catalog = catalog
        self.route = '{0}/{1}/vapp_templates'.format(self.catalog.route, self.catalog.id)
        self.root_tag = 'vcloud_vapp_template'
        self.id = id
        self.vdc_id = ''  # vCloud resource pool id
        self.label = 'vAppTemplateAPITest'
        self.ovf_url = 'http://downloads.repo.onapp.com/vShield_Manager.ovf'

        if self.id:
            test.update_object(self)

    def add_vapp_template(self):
        test.log.info("Add vapp template...")
        data = {
            self.root_tag: {
                'label': self.label,
                'ovf_url': self.ovf_url
            }
        }
        if test.post_object(self, data=data):
            self.id = self.response[self.root_tag]['id']
            if self.transaction_handler("create_vcloud_vapp_template", self.id):
                return True
        return False

    def delete_vapp_template(self):
        test.log.info("Delete vapp template...")
        if test.delete_object(self):
            if self.transaction_handler("delete_vcloud_vapp_template", self.id):
                return True
        return False

    def get_vapp_templates(self):
        """Return an array of vapp templates."""
        test.log.info("Get all vcloud vapp template...")
        objects = []
        if test.get_object(self):
            for vcloud_vapp_template in self.response:
                obj = VAppTemplate(self.catalog)
                obj.__dict__.update(vcloud_vapp_template[obj.root_tag])
                objects.append(obj)
        return objects

    def get_virtual_machines(self): # ???
        return self.virtual_machines