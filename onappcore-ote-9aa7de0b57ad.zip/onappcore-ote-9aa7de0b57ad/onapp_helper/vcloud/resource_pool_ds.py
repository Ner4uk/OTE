from onapp_helper.base_helper import BaseHelper
from onapp_helper.data_store import DataStore
from onapp_helper import test


class ResourcePoolDS(BaseHelper):
    def __init__(self, resource_pool, id=None):
        self.ds = DataStore()

        self.resource_pool = resource_pool
        self.root_tag = 'data_store'
        self.id = id
        self.data_store_size = 0
        self.data_store_group_id = 0
        self.enabled = True

    def add(self):
        test.log.info("Add ResourcePool Data Store...")
        data = {
            self.root_tag: {
                "data_store_group_id": self.data_store_group_id,
                "data_store_size": self.data_store_size,
                "data_store_type": "vcloud"
            }
        }
        if test.post_object(self, data=data):
            if self.transaction_handler('create_data_store', self.resource_pool.id):
            # In 4.3 API impossible to get an id of ds using simple way so we do it by magic way :)
                self.id = [
                    ds.id for ds in self.ds.get_by_params(
                        {
                            "data_store_type": ["vcloud"],
                            "vdc_id": [self.resource_pool.id]
                        }
                    )
                ][-1]
                return True
        return False

    def get(self):
        test.log.info("Get ResourcePool Data Store...")
        return test.update_object(self)

    def update(self):
        test.log.info("Update ResourcePool Data Store...")
        data = {
            self.root_tag: {
                "enabled": self.enabled,
                "data_store_size": self.data_store_size
            }
        }

        if test.put_object(self, data=data):
            if self.transaction_handler('update_data_store', self.id):
                return True
        return False

    def delete(self):
        test.log.info("Delete ResourcePool Data Store...")

        if test.delete_object(self):
            if self.transaction_handler('destroy_data_store', self.id):
                return True
        return False

    def route(self):
        return "vdcs/{0}/data_stores".format(self.resource_pool.id)



