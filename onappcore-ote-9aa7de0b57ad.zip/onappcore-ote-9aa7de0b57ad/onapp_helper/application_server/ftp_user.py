from onapp_helper.base_helper import BaseHelper
from ftplib import FTP
import os
from onapp_helper import test


class FTPUser(BaseHelper):
    def __init__(self, apps_obj=None):
        self.apps = apps_obj
        self.root_tag = 'ftp_user'
        self.route = '{0}/{1}/ftp_users'.format(self.apps.route, self.apps.id)
        self.login = 'zazaftptestuser'
        self.password = ''
        self.path = self.login
        self.identifier = None
        self.ftp_obj = FTP()
        self.host = ''
        self.file_name = 'ftp_test_file.txt'

    def get_all(self):
        test.log.info("Get all FTP users...")
        if test.get_object(self):
            return self.response
        return False

    def create(self):
        """
        Update attributes and return "True" if succeed,
        if not - AssertionError.
        """
        self.host = self.apps.ip_address
        test.log.info("Create FTP user...")
        if not self.password:
            self.password = test.generate_password()
        self.apps.connected()
        data = {
            self.root_tag: {
                "password": self.password,
                "password_confirmation": self.password,
                "login": self.login,
                "path": "www/{0}".format(self.path)
            }
        }
        return test.post_object(self, data=data)

    def find_by_login(self, login=None):
        """
        Update attributes and return "True" if user present, if not - False.
        """
        if not login:
            login = self.login
        test.log.info("Find FTP user by login - {0}...".format(login))
        ftp_users = self.get_all()
        users = [
            u[self.root_tag] for u in ftp_users
            if login in u[self.root_tag]['login']
            ]
        if users:
            self.__dict__.update(users[0])
            return True
        return False

    def delete(self):
        """Execute DELETE frp user request."""
        test.log.info("Delete FTP user...")
        self.apps.connected()
        return test.delete_object(
            self,
            url='/{0}/{1}.json'.format(self.route, self.identifier)
        )

    def upload_file(self, file_name):
        """
        Upload file
        """
        try:
            test.log.info("Try to connect to {0}...".format(self.host))
            test.log.info(self.ftp_obj.connect(self.host))
            test.log.info(
                "Try to connect with login - {0}, pass - {1}...".format(
                    self.login, self.password
                )
            )
            test.log.info(self.ftp_obj.login(user=self.login, passwd=self.password))

            test.log.info("File for upload - {0}".format(file_name))
            with open(file_name, 'rb') as f:
                test.log.info("Try to upload file...")
                test.log.info(
                    self.ftp_obj.storbinary(
                        'STOR {0}'.format(file_name), f)
                )
                self.ftp_obj.close()
                test.log.info("Success...")
                return True
        except Exception:
            #  TODO - actually return <attribute 'args' of 'BaseException' objects>, expect some message.
            test.log.exception(Exception.args)
            # print(Exception.args)
        return False

    def check_if_file_present(self, file_name):
        """Check if 'ftp_test_file.txt' is present on AS"""
        test.log.info("Check if file is present...")
        test.log.info(self.ftp_obj.connect(self.host))
        test.log.info(self.ftp_obj.login(user=self.login, passwd=self.password))
        l = self.ftp_obj.nlst()
        test.log.info(l)
        test.log.info(self.ftp_obj.close())
        return file_name in l

    def delete_file(self, file_name):
        """Delete 'ftp_test_file.txt' by ftp from AS."""
        test.log.info("Delete file...")
        test.log.info(self.ftp_obj.connect(self.host))
        test.log.info(self.ftp_obj.login(user=self.login, passwd=self.password))
        test.log.info(self.ftp_obj.delete(file_name))
        l = self.ftp_obj.nlst()
        test.log.info(self.ftp_obj.close())
        return False if file_name in l else True
