from onapp_helper.base_helper import BaseHelper
from onapp_helper import test



class Service(BaseHelper):
    def __init__(self, apps_obj):
        self.parent_obj = apps_obj
        self.route = "{0}/{1}/services".format(
            self.parent_obj.route, self.parent_obj.id
        )
        self.root_tag = "service"
        self.id = ''
        self.name = ''
        self.status = ''

    def start(self):
        test.log.info('Start {0} service...'.format(self.name))
        url = '/{0}/{1}/start.json'.format(self.route, self.id)
        return test.put_object(self, url=url)

    def stop(self):
        test.log.info('Stop {0} service...'.format(self.name))
        url = '/{0}/{1}/stop.json'.format(self.route, self.id)
        return test.put_object(self, url=url)

    def restart(self):
        test.log.info('Restart {0} service...'.format(self.name))
        url = '/{0}/{1}/restart.json'.format(self.route, self.id)
        return test.put_object(self, url=url)
