# Supported since 5.0
from onapp_helper.base_helper import BaseHelper
from onapp_helper import test



# ApplicationServer methods only
class DataBaseUser(BaseHelper):
    """
    Create a new DataBase User instance.
    """
    def __init__(self, apps_obj=None):
        self.apps = apps_obj
        self.route = '{0}/{1}/database_users'.format(
            self.apps.route, self.apps.id
        )
        self.root_tag = "database_user"
        #self.id = None
        self.name = ''
        self.password = ''

    def get_database_users(self):
        """
        Return an array of available database users dict like:
            - {"database_user": {"name": "test"}}
        """
        test.log.info("Get database users...")
        self.apps.connected()
        if test.get_object(self):
            return self.response
        else:
            test.log.error(self.error)
        return []

    def create(self):
        """name, password"""
        test.log.info("Create database user...")
        if not self.password:
            self.password = test.generate_password()
        self.apps.connected()
        data = {
            self.root_tag: {
                "name": self.name,
                "password": self.password
            }
        }
        return test.post_object(self, data=data)

    def delete(self):
        test.log.info("Delete database user...")
        self.apps.connected()
        url = '/{0}/{1}.json'.format(self.route, self.name)
        return test.delete_object(self, url=url)

    def update_db_user_privileges(self, database):
        test.log.info("Update database user privileges...")
        self.apps.connected()
        data = {
            self.root_tag: {
                "db_name": database.db,   # name - the same is using for user.
                "host": database.host,
                "prilist": database.prilist
            }
        }
        url = '/{0}/{1}/privileges.json'.format(self.route, self.name)
        return test.put_object(self, url=url, data=data)

    def change_db_user_password(self):
        test.log.info("Change database user password...")
        self.apps.connected()
        data = {
            self.root_tag: {
                "password": self.password
            }
        }
        url = '/{0}/{1}/change_password.json'.format(self.route, self.name)
        return test.put_object(self, url=url, data=data)

    def unassign_user_from_database(self, database):
        test.log.info("Unassign user from database...")
        self.apps.connected()
        data = {
            self.root_tag: {
                "db_name": database.db
            }
        }
        url = '/{0}/{1}/privileges.json'.format(self.route, self.name)
        return test.put_object(self, url=url, data=data)