from onapp_helper.base_helper import BaseHelper
from onapp_helper import test



class Domain(BaseHelper):
    def __init__(self, apps_obj):
        self.parent_obj = apps_obj
        self.route = "{0}/{1}/domains".format(
            self.parent_obj.route, self.parent_obj.id
        )
        self.root_tag = "domain"
        #self.domains = []

    def all_domains(self):
        test.log.info("Get all domains...")
        if self.parent_obj.connected():
            return self._get_objects()
        return []

    def add_addon_domain_with_custom_path(self, domain='', path=''):
        test.log.info(
            "Add addon domain - {0}, with custom path - '{1}'...".format(
                domain, path
            )
        )
        data = {
            self.root_tag: {
                "domain": domain,
                "path": path
            }
        }
        return self._add_domain(data)

    def add_domain_to_an_existed_app(self, domain='', application_id=''):
        test.log.info(
            "Add domain - {0} to an existed app - {1}...".format(
                domain, application_id
            )
        )
        data = {
            self.root_tag: {
                "domain": domain,
                "application_id": application_id
            }
        }
        return self._add_domain(data)

    def add_parked_domain(self, domain=''):
        test.log.info("Add parked domain - {0}...".format(domain))
        data = {
            self.root_tag: {
                "domain": domain
            }
        }
        return self._add_domain(data)

    def delete(self, identifier=''):
        test.log.info("Delete domain - {0}...".format(identifier))
        self.parent_obj.connected()
        """Execute DELETE domain request."""
        url = '/{0}/{1}.json'.format(self.route, identifier)
        return test.delete_object(self, url=url)

    def _add_domain(self, data):
        self.parent_obj.connected()
        url = '/{0}.json'.format(self.route)
        return test.post_object(self, url=url, data=data)
