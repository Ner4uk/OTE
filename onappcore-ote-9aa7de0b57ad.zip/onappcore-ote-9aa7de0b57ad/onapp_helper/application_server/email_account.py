from onapp_helper.base_helper import BaseHelper
from onapp_helper import test



class EmailAccount(BaseHelper):
    def __init__(self, apps_obj):
        """
        In this helper some attributes is not the same as returned parameters:
        for example 'user'.
        [

            {
                "email_account": {
                    "count": 7,
                    "identifier": "c5dd0a590d18783d998d50be7559984e",
                    "space": "164K",
                    "user": "zaza@109.123.91.29"
                }
            }

        ]
        :param apps_obj:
        """

        self.parent_obj = apps_obj
        self.route = "{0}/{1}/email_accounts".format(
            self.parent_obj.route, self.parent_obj.id
        )
        self.root_tag = "email_account"
        self.user = ''
        self.domain = self.parent_obj.ip_address
        self.password = ''
        self.identifier = ''

    def create(self):
        test.log.info("Create an email account...")
        data = {
            self.root_tag: {
                "user": self.user,
                "domain": self.domain,
                "password": self.password,
                "password_confirmation": self.password
            }
        }
        #  Update attributes
        if test.post_object(self, data=data):
            # account = [
            # account for account in self.get_for_current_domain()
            # if self.user in account.user
            # ][0]
            # self.__dict__.update(account.__dict__)
            return self
        return False

    def get_for_domain(self, domain):
        test.log.info(
            "Get email accounts for {} domain...".format(domain)
        )
        return self._get_objects(
            query='domain={}'.format(domain)
        )

    def delete(self):
        """
        Delete the email account for specific domain.
        If domain the same as ip_address we need not using
        data during removing.
        """
        test.log.info("Delete an email account...")
        url = '/{0}/{1}.json'.format(self.route, self.identifier)
        data = {}
        if self.domain != self.parent_obj.ip_address:
            data = {"domain_name": self.domain}
        return test.delete_object(self, url=url, data=data)

