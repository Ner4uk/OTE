# Supported since 5.0
from onapp_helper.base_helper import BaseHelper
from onapp_helper import test



# ApplicationServer methods only
class DataBase(BaseHelper):
    def __init__(self, apps_obj=None):
        """
        Create a new instance of DataBase
        :param apps_obj: an Application Server obj
        """
        self.apps = apps_obj
        self.route = '{0}/{1}/databases'.format(self.apps.route, self.apps.id)
        self.root_tag = "database"
        #self.id = None
        self.db = ''  # db name
        self.host = 'localhost'
        self.prilist = {}

    def get_databases(self):
        """
        Return an array of available database dict like:
            {"database": {"db": "test"}}
        """
        test.log.info("Get databases...")
        self.apps.connected()
        if test.get_object(self):
            return self.response
        else:
            test.log.error(self.error)
        return []

    def create(self):
        """Set db - database name."""
        test.log.info("Create database...")
        self.apps.connected()
        data = {
            self.root_tag: {
                'db': self.db
            }
        }
        return test.post_object(self, data=data)

    def delete(self):
        """
        Delete data base.
        :return: True if success else False
        """
        test.log.info("Delete database...")
        self.apps.connected()
        url = '/{0}/{1}.json'.format(self.route, self.db)
        return test.delete_object(self, url=url)

    def assign_user(self, user):
        """
        Assign a database user to database
        :param user: a database user obj
        :return: True if success else False
        """
        test.log.info("Assign user to database...")
        self.apps.connected()
        data = {
            self.root_tag: {
                "db_user": user.name,
                "host": self.host,
                "prilist": self.prilist
            }
        }
        url = '/{0}/{1}/assign_user.json'.format(self.route, self.db)
        return test.post_object(self, url=url, data=data)

    def get_users_assigned_to_db(self):
        """Return a hash of database users dict like:

        |    {
        |        "database_users": [
        |            {
        |                "database_user": {
        |                    "name": "zaza",
        |                    "prilist": {
        |                        "HOST": "localhost",
        |                        "SELECT": true,
        |                        "INSERT": true,
        |                        "UPDATE": true,
        |                        "DELETE": true,
        |                        "CREATE": true,
        |                        "DROP": true,
        |                        "REFERENCES": true,
        |                        "INDEX": true,
        |                        "ALTER": true,
        |                        "LOCK_TABLES": true,
        |                        "CREATE_VIEW": true,
        |                        "SHOW_VIEW": true,
        |                        "CREATE_ROUTINE": true,
        |                        "EXECUTE": true,
        |                        "TRIGGER": true,
        |                        "CREATE_TEMPORARY_TABLES": true
        |                    }
        |                }
        |            }
        |        ]
        |    }

        :return: response if success else empty list
        """
        test.log.info("Get users assigned to database...")
        self.apps.connected()
        url = '/{0}/{1}/privileges.json'.format(self.route, self.db)
        if test.get_object(self, url=url):
            return self.response
        else:
            test.log.error(self.error)
        return []