from onapp_helper.base_helper import BaseHelper
import os
import re
from onapp_helper import test


class Application(BaseHelper):
    def __init__(self, apps_obj=None):
        """
        Create a new Application instance
        :param apps_obj: an Application Server obj
        """
        self.parent_obj = apps_obj
        self.route = '{0}/{1}/applications'.format(
            self.parent_obj.route, self.parent_obj.id
        )
        self.root_tag = "application"
        self.softdirectory = ''
        self.id = None
        self.attributes = {}

    def get_available_applications(self):
        """ Get list of an application objects available to installation."""
        test.log.info("Get available applications...")
        #self.apps.connected()
        return self._get_objects(
            route='{0}/available'.format(self.route)
        )

    def get_by_name(self, name):
        """
        Get application by name
        :param name: application name (zikula, wordpress, etc...)
        :return: application, and update self attributes.
        """
        test.log.info("Get application with name - {}...".format(name))
        #self.apps.connected()
        apps = [
            app for app in self.get_available_applications()
            if app.name == name
            ]
        if apps:
            self.__dict__.update(apps[0].__dict__)
            return self
        return False

    def get_script_attributes(self):
        """
        Get a script attributes required for installation.
        :return: Update self attributes attribute and return True if success
        else False.
        """
        test.log.info("Get script attributes...")
        #self.apps.connected()
        url = '/{0}/{1}/script/{2}.json'.format(
            self.parent_obj.route, self.parent_obj.id, self.script_id
        )
        if test.get_object(self, url=url):
            self.attributes = self.response['script']
            return True
        return False

    def add_application(self, force=False):
        """
        Add a new application by script_id
        :param force: if True automatically resolve conflict attributes
        :return: True if success otherwise False
        """
        test.log.info("Add application...")
        #self.apps.connected()
        #  Set correct attributes for creation application
        if force:
            self._prepare_attributes()
        data = {
            self.root_tag: {
                "script_id": self.script_id
            }
        }
        data[self.root_tag].update(self.attributes)
        return test.post_object(self, data=data)

    def applications(self):
        """ Get list of installed application objects."""
        test.log.info("Get applications...")
        #self.apps.connected()
        return self._get_objects()

    def delete_application(self, app_id=None):
        """
        Delete an application.
        :param app_id: application id, is not required.
        :return: True if success else False
        """
        test.log.info("Delete application...")
        #self.apps.connected()
        if not app_id:
            app_id = self.id
        data = {
            self.root_tag: {
                "id": app_id,
                "remove_directory": "1",
                "remove_database": "1",
                "remove_database_user": "1"
            }
        }
        return test.delete_object(self, data=data)

    def _is_responsible(self, timeout=60):
        """
        Try to get software_url, returns True if successfully
        otherwise returns False.
        :param timeout: how many times check if responsible
        :return: True if success else False
        """
        test.log.info(
            "Check if application ({0}) is responsible...".format(
                self.software_url
            )
        )

        if self.wait_for_action(
                lambda: self._get_to_software_url() is True,
                timeout=timeout
        ):
            test.log.info("The application is responsible...")
            return True

        test.log.info("The application is not responsible...")
        return False

    def _get_to_software_url(self):
        """
        Connecting to software_url
        :return: True if status code 200 else False
        """
        host, route = os.path.split(self.software_url)
        rez = re.findall('[0-9.]+', host)
        if rez:
            host = rez[0]
        else:
            test.log.error("Can not parse software_url - {}".format(
                self.software_url)
            )
            return False

        test.session.method_handler(
            url='/{0}/'.format(route),
            host=host
        )
        return test.session.response.status_code == 200

    def _prepare_attributes(self):
        """
        Preparing attributes to install application automatically
        :return: Nothing
        """
        for key, value in list(self.attributes.items()):
            if value.__class__.__name__ == 'list':
                self.attributes[key] = value[0] if len(value) else ''
            elif 'mail' in key:
                self.attributes[key] = '{}@ote.test'.format(value)
            elif 'softdb' in key and len(value) >= 8:
                    self.attributes[key] = value[:7]
