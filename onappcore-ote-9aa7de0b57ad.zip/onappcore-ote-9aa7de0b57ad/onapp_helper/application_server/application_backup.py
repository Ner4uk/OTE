from onapp_helper.base_helper import BaseHelper
from onapp_helper import test



# ApplicationServer methods only
class AppBackup(BaseHelper):
    def __init__(self, app_obj):
        """
        Create a new Application Backup instance.
        :param app_obj: an application obj
        """
        self.app = app_obj
        self.apps = self.app.parent_obj
        self.route = '{0}/{1}/backups'.format(self.app.route, self.app.id)
        self.root_tag = 'backup'
        self.application = {}
        self.backup_note = "Test App Backup"

    def take_application_backup(self):
        """
        Take an application backup
        :return: True if success else False
        """
        test.log.info("Take application backup...")
        self.apps.connected()
        data = {
            self.root_tag: {
                "application_id": self.app.id,
                "backup_directory": "1",
                "backup_database": "1",
                "note": self.backup_note
            }
        }
        url = '/{0}.json'.format(self.route[:-1])  # TODO - POST should be with 's'

        if test.post_object(self, url=url, data=data):

            return self.transaction_handler(
                'take_application_backup', self.apps.id
            )
        return False

    def restore_application_backup(self):
        """
        Restore the application backup
        :return: True if success else False
        """
        test.log.info("Restore application backup...")
        self.apps.connected()
        data = {
            self.root_tag: {
                "restore_directory": "1",
                "restore_database": "1"
            }
        }
        url = '/{0}/{1}/restore.json'.format(
            ''.join(self.route.split('/{0}'.format(self.app.id))),
            self.identifier
        )

        if test.post_object(self, url=url, data=data):
            return self.transaction_handler(
                'restore_application_backup', self.apps.id
            )
        return False

    def get_application_backups(self):
        """
        Get a list of application backups
        :return:
        """
        test.log.info("Get application backup...")
        self.apps.connected()
        url = '/{0}.json'.format(
            ''.join(self.route.split('/{0}'.format(self.app.id)))
        )  # remove app id from url
        test.get_object(self, url=url)
        return self.response

    def find_by_backup_note_type(self):
        test.log.info("Find by backup note type...")
        self.apps.connected()
        taken_backups_list = self.get_application_backups()
        backup = [
            b for b in taken_backups_list
            if b[self.root_tag]['backup_note'] == self.backup_note
            ][0]
        if backup:
            self.__dict__.update(backup[self.root_tag])
            return True
        return False

    def delete_application_backup(self):
        test.log.info("Delete application backup...")
        self.apps.connected()
        url = '/{0}/{1}/destroy.json'.format(
            ''.join(self.route.split('/{0}'.format(self.app.id))),
            self.identifier
        )
        return test.delete_object(self, url=url)
