from onapp_helper.base_helper import BaseHelper
from onapp_helper import test



class SystemApp(BaseHelper):
    def __init__(self, apps_obj):
        self.parent_obj = apps_obj
        self.route = "{0}/{1}/system_apps".format(
            self.parent_obj.route, self.parent_obj.id
        )
        self.root_tag = "system_app"
        self.system_apps = []

    def get_all(self, filter=None):
        test.log.info("Get all system app...")
        self.parent_obj.connected()
        # TODO - rewrite to use _get_objects
        all_system_apps = self._get_objects()
        if filter:
            return [obj for obj in all_system_apps if filter in obj.api_name]
        return all_system_apps

    def get_by_api_name(self, api_name=''):
        test.log.info(
            "Get system application with api_name = {}...".format(api_name)
        )
        self.parent_obj.connected()
        apps = self.get_all(filter=api_name)
        if apps:
            self.__dict__.update(apps[0].__dict__)
            return self
        return False

    def install(self, id=None):
        if not id:
            id = self.id
        test.log.info(
            "Install system application with id - {0}...".format(id)
        )
        self.parent_obj.connected()
        url = '/{0}/{1}/install.json'.format(self.route, id)
        if test.put_object(self, url=url):
            return self.transaction_handler(
                'install_system_app', self.parent_obj.id
            )
        return False

    def switch_php_version(self, api_name=None):
        if not api_name:
            api_name = self.api_name
        test.log.info("Switch PHP version to {0}...".format(api_name))
        self.parent_obj.connected()
        url = '/{0}/{1}/settings/switch_php_version.json'.format(
            self.parent_obj.route, self.parent_obj.id
        )
        data = {
            "php_version": api_name
        }
        return test.put_object(self, url=url, data=data)

    def uninstall(self, id=None):
        if not id:
            id = self.id
        test.log.info(
            "Uninstall system application with id - {0}...".format(id)
        )
        self.parent_obj.connected()
        url = '/{0}/{1}/uninstall.json'.format(self.route, id)
        if test.put_object(self, url=url):
            return self.transaction_handler(
                'uninstall_system_app', self.parent_obj.id
            )
        return False


