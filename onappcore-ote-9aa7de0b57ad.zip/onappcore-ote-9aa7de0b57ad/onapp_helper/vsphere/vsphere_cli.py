# adopted code bits from https://github.com/vmware/pyvmomi-community-samples
import atexit
import ssl
import sys

from onapp_helper import test



from pyVmomi import vim
from pyVim import connect
from pyVim.connect import Disconnect
from pyVim.task import WaitForTask

DUMPMEMORY = False  # do not save RAM to snapshot
QUIESCE = False


class VSphereVM:
    '''
    the adapted VM object with the wrapped methods is placed in VSphereVM.vm property the plenty of other(native
    VSphere)) methods like Clone Rename Migrate Destroy Suspend and even CreateScreenshot as well as loads of native
    properties etc. accessible through the generic VM object which sits in VSphereVM.vm.vm property - feel free to
    add them wrapped here as soon as they are needed.
    '''

    def __init__(self, vm_name):
        context = ssl._create_unverified_context()
        test.log.info('Trying to connect to VCENTER SERVER . . .')
        vc_connection = connect.Connect(test.vcenter_host, 443,
                                        test.vcenter_login,
                                        test.vcenter_password,
                                        sslContext=context)
        atexit.register(Disconnect, vc_connection)
        test.log.info('Connected to VCENTER SERVER')
        content = vc_connection.RetrieveContent()
        self.vm = None
        container = content.viewManager.CreateContainerView(
            content.rootFolder, [vim.VirtualMachine], True)
        for c in container.view:
            if c.name == vm_name:
                self.vm = c
                break
        if not self.vm:
            test.log.error(f"Virtual Machine {vm_name} doesn't exists")
            sys.exit()
        self.name = self.vm.name

    def on(self):
        ret = WaitForTask(self.vm.PowerOn())
        if ret == 'success':
            return True
        test.log.error(f"The requested VSphere action completed with status {ret}")
        return False

    def off(self):
        ret = WaitForTask(self.vm.PowerOff())
        if ret == 'success':
            return True
        test.log.error(f"The requested VSphere action completed with status {ret}")
        return False

    def reset(self):
        ret = WaitForTask(self.vm.Reset())
        if ret == 'success':
            return True
        test.log.error(f"The requested VSphere action completed with status {ret}")
        return False

    def restore_from_snapshot(self, snap_name):
        snap_obj = self.get_snapshots_by_name(snap_name)
        # if len(snap_obj) is 0; then no snapshots with specified name
        if len(snap_obj) == 1:
            snap_obj = snap_obj[0].snapshot
            test.log.warning(f"Reverting to snapshot {snap_name}")
            ret = WaitForTask(snap_obj.RevertToSnapshot_Task())
            if ret == 'success':
                return True
            test.log.error(f"The requested VSphere action completed with status {ret}")
            return False
        else:
            test.log.warning(f"No snapshots found with name {snap_name} on VM {self.name}")
        return False

    def create_snapshot(self, snap_name):
        test.log.info(f"Creating snapshot {snap_name} for virtual machine {self.name}")
        description = "Created from OTE"
        ret = WaitForTask(self.vm.CreateSnapshot(snap_name, description, DUMPMEMORY, QUIESCE))
        if ret == 'success':
            return True
        test.log.error(f"The requested VSphere action completed with status {ret}")
        return False

    def remove_snapshot(self, snap_name):
        snap_obj = self.get_snapshots_by_name(snap_name)
        # if len(snap_obj) is 0; then no snapshots with specified name
        if len(snap_obj) == 1:
            snap_obj = snap_obj[0].snapshot
            test.log.info(f"Removing snapshot {snap_name}")
            ret = WaitForTask(snap_obj.RemoveSnapshot_Task(True))
            if ret == 'success':
                return True
            test.log.error(f"The requested VSphere action completed with status {ret}")
            return False
        else:
            test.log.warning(f"No snapshots found with name {snap_name} on VM {self.vm.name}")
        return False

    def list_snapshots(self):
        return self._list_snapshots_recursively(snapshots=self.vm.snapshot.rootSnapshotList)

    def _list_snapshots_recursively(self, snapshots):
        snapshot_data = []
        snap_text = ""
        for snapshot in snapshots:
            snap_text = "Name: %s; Description: %s; CreateTime: %s; State: %s" % (
                snapshot.name, snapshot.description,
                snapshot.createTime, snapshot.state)
            snapshot_data.append(snap_text)
            snapshot_data = snapshot_data + self._list_snapshots_recursively(
                snapshot.childSnapshotList)
        return snapshot_data

    def get_snapshots_by_name(self, snapname):
        return self._get_snapshots_by_name_recursively(snapshots=self.vm.snapshot.rootSnapshotList, snapname=snapname)

    def _get_snapshots_by_name_recursively(self, snapshots, snapname):
        snap_obj = []
        for snapshot in snapshots:
            if snapshot.name == snapname:
                snap_obj.append(snapshot)
            else:
                snap_obj = snap_obj + self._get_snapshots_by_name_recursively(snapshot.childSnapshotList, snapname)
        return snap_obj

    def power_state(self):
        return self.vm.runtime.powerState
