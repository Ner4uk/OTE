from onapp_helper.base_helper import BaseHelper
from onapp_helper import test


class DataStore(BaseHelper):
    route = 'settings/data_stores'
    root_tag = 'data_store'

    def __init__(self, id=None):
        self.id = id
        self.label = 'ATDataStore'
        # self.data_store_group_id = None
        self.local_hypervisor_id = None
        self.ip = ''
        self.enabled = True
        self.data_store_size = 0
        self.data_store_type = None
        self.data_store_group_id = None
        if self.id:
            test.update_object(self)
        # Since 6.1
        self.trim = None  # only for lvm

    def create(self):
        test.log.info("Create data store...")
        data = {
            self.root_tag: {
                "label": self.label,
                "data_store_group_id": self.data_store_group_id,
                "local_hypervisor_id": self.local_hypervisor_id,
                "ip": self.ip,
                "enabled": self.enabled,
                "data_store_size": self.data_store_size,
                "data_store_type": self.data_store_type
            }
        }
        return test.post_object(self, data=data)

    def edit(self, **kwargs):
        test.log.info("Edit data store...")
        if kwargs:
            data = {self.root_tag: kwargs}
        else:
            data = {
                self.root_tag: {
                    "label": self.label,
                    "data_store_group_id": self.data_store_group_id,
                    "local_hypervisor_id": self.local_hypervisor_id,
                    "ip": self.ip,
                    "enabled": self.enabled,
                    "data_store_size": self.data_store_size,
                    "data_store_type": self.data_store_type
                }
            }
        return test.put_object(self, data=data)

    def get_any(self):
        """
        Return the objects
        """
        test.log.info("Get any lvm data store...")
        return self.get_by_params({'data_store_type': ['lvm']})

    def get_by_label(self, label):
        """
        Return the objects
        """
        test.log.info("Get data store by label...")
        return self.get_by_params({'label': [label]})

    def get_solid_fire(self):
        """
        Return the objects
        """
        test.log.info("Get solidfire data store...")
        return self.get_by_params({'data_store_type': ['solidfire']})

    def get_by_params(self, parameters=None, **kwargs):
        """
        Return the array of DS objects

        :param parameters: dict of object parameters where value is an array
            of possible values. For example: {'data_store_type': ['solidfire']}
            where:

                * data_store_type - ds parameter;
                * solidfire - ds type, can be lvm, solidfire, etc

        :param **kwargs: keyword arguments, where key is one of the ds
        parameter and value a list of possible values

        :return: objects filtered by parameters
        """
        test.log.info("Get data store by parameters...")

        objects = [ds for ds in self.get_all() if ds.enabled]

        if parameters or kwargs:
            for key, values in list(parameters.items() if parameters else
                                    kwargs.items()):
                objects = [
                    obj for obj in objects if obj.__dict__[key] in values
                    ]
        return objects

    def get_best_by_free_space(self, objects):
        # Get ds id with less space usage
        data_store = self._ds_with_less_usage(objects)
        if data_store:
            for obj in objects:
                if obj.id == data_store.id:
                    # Update self attributes
                    self.__dict__.update(obj.__dict__)
                    break
            return True
        return False

    def _ds_with_less_usage(self, obj_list):
        """Return data store obj with less usage."""
        data_stores = [(obj.data_store_size - obj.usage, obj)
                       for obj in obj_list
                       if obj.data_store_size - obj.usage >= 6
                       and obj.enabled
                       and not obj.local_hypervisor_id]
        if data_stores:
            try:
                data_stores.sort()
            # looks like size in sortable DataStores is equal
            # this is rising the error like: "TypeError: unorderable types: DataStore() < DataStore()"
            except TypeError:
                pass
            self.__init__(data_stores[-1][-1].id)
            return True
        return False