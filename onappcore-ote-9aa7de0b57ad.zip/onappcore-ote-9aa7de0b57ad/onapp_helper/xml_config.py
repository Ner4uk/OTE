# Since 5.5
# https://onappdev.atlassian.net/browse/CORE-8680
# Advanced VS management for KVM

from os import system

from onapp_helper import test
from onapp_helper.base_helper import BaseHelper
from onapp_helper.domain_xml_parser import Domain


class XmlConfig(BaseHelper):
    """
        Working process:
        1. Get xml_config from server via API.
        2. Write xml_config to tmp directory.
        3. Initialise domain obj using path to xml_config file in tmp directory

        Actual xml_config is located in the tmp directory
    """
    def __init__(self, server=None):
        self.parent_obj = server
        self.xml_config = None
        self.xml_config_edited = None

        xml_file = f'/tmp/{self.parent_obj.identifier}.xml' if \
            self.parent_obj else None
        self.domain = Domain(xml_file=xml_file)

    def get_xml_config(self):
        # Get xml config from VS
        if test.get_object(self):
            return self._rewrite_xml(self.xml_config_file_path)
        return False

    def reset_xml_config(self):
        url = '/{}.json'.format(self.route())
        if test.delete_object(self, url=url):
            return self._rewrite_xml(self.xml_config_file_path)
        return False

    def update_xml_config(self, reboot=False):
        """
        Before this you have to edit domain obj attribute.
        :param reboot: Set True to reboot the server else False.
        :return: True if success else False.
        """
        # In case permissions testing we have not valid self.xml_config
        # and it is impossible to read xml.
        if self.xml_config:
            with open(self.xml_config_file_path) as xml:
                self.xml_config = xml.read()

        data = {
            self.root_tag: {
                "xml_config": self.xml_config,
                "reboot": reboot
            }
        }
        url = '/{}.json'.format(self.route())
        if test.put_object(self, data=data, url=url):
            self._rewrite_xml(self.xml_config_file_path)
            if reboot:
                if self.transaction_handler(
                    'reboot_virtual_machine',
                    parent_id=self.parent_obj.id
                ):
                    self.parent_obj.get()
                    return True
            else:
                return True
        return False

    def delete(self):
        """
        Remove xml config file from /tmp directory. It is just OTE method.
        Not a part of onapp API.

        """
        system('rm -rfv {}'.format(self.xml_config_file_path))

    def _rewrite_xml(self, xml_config_file_path):
        # Write to file
        with open(xml_config_file_path, mode='w') as xml:
            xml.write(self.xml_config)

        # Read xml_config to work with domain object
        self.domain.read_xml(xml_config_file_path)
        return self.xml_config

    def route(self):
        return '{}/{}/xml_config'.format(
            self.parent_obj.route, self.parent_obj.id
        )

    @property
    def root_tag(self):
        return self.parent_obj.root_tag

    @property
    def xml_config_file_path(self):
        return '/tmp/{}.xml'.format(self.parent_obj.identifier)
