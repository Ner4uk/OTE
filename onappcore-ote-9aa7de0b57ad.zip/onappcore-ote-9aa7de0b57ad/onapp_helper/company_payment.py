from onapp_helper import test
from onapp_helper.base_helper import BaseHelper


class CompanyPayment(BaseHelper):
    root_tag = 'payment'
    route = 'billing/company/payments'

    def __init__(self):
        self.payer_id = None
        self.invoice_number = None
        self.amount = None

    def create(self):
        test.log.info('Create a new company payment...')
        data = {
            self.root_tag: {
                "payer_id": self.payer_id,
                "invoice_number": self.invoice_number,
                "amount": self.amount
            }
        }
        return test.post_object(self, data=data)

    def edit(self):
        test.log.info('Edit the company payment with id - {}...'.format(self.id))
        data = {
            self.root_tag: {
                "payer_id": self.payer_id,
                "invoice_number": self.invoice_number,
                "amount": self.amount
            }
        }
        return test.put_object(self, data=data)

    def get_company_payments(self, company_id=None):
        data = {}
        if company_id:
            key = "payer" if test.cp_version < 6.0 else "payer_id"
            data = {key: company_id}
        test.log.info('Get all payments for company - {}...'.format(company_id))
        return self._get_objects(data=data)
