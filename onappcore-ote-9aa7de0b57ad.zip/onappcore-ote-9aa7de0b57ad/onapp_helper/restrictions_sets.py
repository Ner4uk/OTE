from onapp_helper import test
from onapp_helper.base_helper import BaseHelper
from onapp_helper.user import User

from engine.lib.session import Session
from datetime import datetime


class RestrictionsSet(BaseHelper):
    route = 'restrictions/sets'
    root_tag = 'restrictions_set'

    def __init__(self, id=None):
        self.id = id
        self.label = ''
        self.role_ids = []
        self.resource_ids = []

        if self.id:
            test.update_object(self)
            self.role_ids = [
                role['role']['id'] for role in self.roles
            ]
            self.resource_ids = [
                resource['restrictions_resource']['id'] for resource in self.restrictions_resources
            ]

    def create(self):
        test.log.info("Create RestrictionsSet...")
        data = {
            self.root_tag: {
                "label": self.label,
                "role_ids": self.role_ids,
                "resource_ids": self.resource_ids
            }
        }
        return test.post_object(self, data=data)

    def edit(self):
        test.log.info("Edit RestrictionsSet...")
        data = {
            self.root_tag: {
                "label": self.label,
                "role_ids": self.role_ids,
                "resource_ids": self.resource_ids
            }
        }
        test.log.info("Edit RestrictionsSet...")
        return test.put_object(self, data=data)

    def delete(self):
        test.log.info("Delete RestrictionsSet...")
        return test.delete_object(self)

    def clone(self):
        cloned = RestrictionsSet()
        cloned.label = "Copy of {} id {}".format(self.label, self.id)
        cloned.role_ids = self.role_ids
        cloned.resource_ids = self.resource_ids
        cloned.create()
        return cloned

    def get_user_by_role(self):
        restriction_set_role_ids_set = set(self.role_ids)
        selected_users = []
        users = User().get_all()
        for user in users:
            user_role_ids_set = set(user.role_ids)
            if restriction_set_role_ids_set.intersection(user_role_ids_set):
                selected_users.append(user)
        return selected_users

    # def clone(self, restriction_id=None):
    #     """
    #     clone takes restriction_id and retrieve from it roles_ids & resource_ids,
    #     than based on them create new restriction_set
    #     """
    #     role_ids = []
    #     resource_ids = []
    #     url = "/{}/{}.json".format(self.route, restriction_id)
    #     if test.get_object(self, url):
    #         json_data = self.response
    #         for key, value in json_data.items():
    #             new_dict = dict(value)
    #
    #             num_roles = len(new_dict['roles'])
    #             num_resources = len(new_dict['restrictions_resources'])
    #
    #             for j in range(num_roles):
    #                 role_ids.append(new_dict['roles'][j]['role']['id'])
    #             for i in range(num_resources):
    #                 resource_ids.append(new_dict['restrictions_resources'][i]['restrictions_resource']['id'])
    #             data = {
    #                 self.root_tag: {
    #                     "label": "Copy of {} id {}".format(self.label, self.id),
    #                     "role_ids": role_ids,
    #                     "resource_ids": resource_ids
    #                 }
    #             }
    #             return test.post_object(self, data=data)
    #     else:
    #         return False

        #  Uncomment if getting user groups will take a lot of time.
        # def get_all(self):
        #     """
        #     Return the array of objects
        #     """
        #     per_page = 10
        #     test.log.info("Get all user groups...")
        #     objects = []
        #     if test.get_object(
        #             self,
        #             url='/{0}.json/page/1/per_page/{1}'.format(self.route, per_page)
        #     ):
        #         x_total = int(self.headers['X-Total'])
        #         for u in self.response:
        #             obj = UserGroup()
        #             obj.__dict__.update(u[self.root_tag])
        #             objects.append(obj)
        #
        #         if x_total > per_page:
        #             for page in range(2, int(x_total/per_page) + 2):
        #                 if test.get_object(
        #                         self,
        #                         url='/{0}.json/page/{1}/per_page/{2}'.format(
        #                             self.route, page, per_page
        #                         )
        #                 ):
        #                     if int(self.headers['X-Page']) != page:
        #                         break
        #                     for u in self.response:
        #                         obj = UserGroup()
        #                         obj.__dict__.update(u[self.root_tag])
        #                         objects.append(obj)
        #
        #     return objects

        # def get(self, id):
        #     """
        #     Return the array of objects
        #     """
        #     test.log.info("Get all users...")
        #     if test.update_object(self):
        #         self.__dict__.update(self.response[self.root_tag])
        #         return True
        #     return False
