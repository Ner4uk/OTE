from onapp_helper import test
from onapp_helper.base_helper import BaseHelper


class PayerType:
    user = 'user'
    user_group = 'company'


class Payment(BaseHelper):
    """
    Base class for payments, to use with users or companies set parent obj.
    """
    root_tag = 'payment'
    PAYER_TYPE = PayerType()

    def __init__(self, parent_obj=None):
        """
        Payments
        :param parent_obj: user or company obj since 6.0
        """
        if test.api_version < 5.7:
            self.route = 'billing/user/payments'
        elif test.api_version < 5.8:
            self.route = 'billing/user_payments'
        elif test.api_version < 6.0:
            # https://onappdev.atlassian.net/browse/CORE-11725
            self.route = 'billing/payments'
            self.payer_id = None
            self.payer_type = None
        else:
            # https://onappdev.atlassian.net/browse/CORE-9627
            self.route = 'billing/user/payments'
            self.parent_obj = parent_obj
            self.payer_id = None

        self.invoice_number = None
        self.amount = None

    def create(self):
        """
        Create a new payment
        :return: True if success else False
        """
        test.log.info('Create a new payment...')
        data = {
            self.root_tag: {
                "payer_id": self.payer_id,
                "invoice_number": self.invoice_number,
                "amount": self.amount
            }
        }
        # https://onappdev.atlassian.net/browse/CORE-9627
        if 6.0 > test.api_version >= 5.8:
            data[self.root_tag]['payer_type'] = self.payer_type
        return test.post_object(self, data=data)

    def edit(self):
        """
        Edit payment
        :return: True if success else False
        """
        test.log.info('Edit payment...')

        data = {
            self.root_tag: {
                "payer_id": self.payer_id,
                "invoice_number": self.invoice_number,
                "amount": self.amount
            }
        }

        return test.put_object(self, data=data)

    def get_all(self, payer=None, user_id=None, payer_type=None, payer_id=None):
        """
        Get all payments
        :param payer: till 5.7
        :param user_id: till 5.8
        :param payer_type: since 5.8
        :param payer_id: since 5.8
        :return:
        """
        if test.cp_version < 5.7:
            data = {"payer": payer}
        elif test.cp_version < 5.8:
            data = {"user_id": user_id}
        # https://onappdev.atlassian.net/browse/CORE-9627
        elif 5.8 <= test.cp_version < '5.10':
            data = {
                "payer_id": payer_id,
                "payer_type": payer_type
            }
        else:
            data = {
                "payer_id": payer_id
            }

        test.log.info("Get payments for payer_type {}".format(payer_type))
        return self._get_objects(data=data)

    def get(self):
        """
        Get payment details
        :return: payment if success else False
        """
        test.log.info("Get payment details")
        if test.update_object(self):
            return self
        return False


    # def get_all(self, payer_type=None):
    #     """
    #     Actually in 5.8 there is some changes in Payments
    #     :param payer: user or user group obj
    #     :return: a list of payments
    #     """
    #     data = {}
    #     if payer:
    #         data['user_id'] = payer.id
    #         data['payer_type'] = payer.payer_type
    #
    #     route = payer.route if payer else self.parent_obj.route
    #     id = payer.id if payer else self.parent_obj.id
    #
    #     return self._get_objects(
    #         route='{}/{}/payments'.format(
    #             route, id
    #         ),
    #         data=data
    #     )