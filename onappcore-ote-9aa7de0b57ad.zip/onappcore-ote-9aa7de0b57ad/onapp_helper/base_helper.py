#  The layer between session and object
import time
from re import findall as re_findall

from onapp_helper import test


class TransactionAction:
    run_recipe_event_on_vm = 'run_recipe_event_on_vm'
    service_addons_complete = 'service_addons_complete'


class BaseHelper:
    """
    In general should be inherited by each onapp helper class.
    """
    error = {}
    response = None
    # related_obj = None # has been implemented for new networking api in 5.4
    parent_obj = None
    root_tag = None
    id = None
    TRANSACTION_ACTION = TransactionAction

    def unlock(self):
        if hasattr(self, 'locked') and self.locked:
            test.log.info(
                "Unlock the {}...".format(self.__class__.__name__)
            )
            return test.post_object(
                self,
                url='/{0}/{1}/unlock.json'.format(self.route, self.id)
            )

    def get(self):
        """
        Get (update) obj details.
        :return: True if success else False
        """
        test.log.info(
            "Get {} - {}...".format(self.__class__.__name__, self.id)
        )
        return test.update_object(self)

    def get_all(self, **kwargs):
        """
        Get all objects for particular class. Can be redefined.
        :param kwargs: key - object attribute, value - object value
        :return: objects
        """
        test.log.info("Get all {}s...".format(self.__class__.__name__))
        if not kwargs:
            return self._get_objects()
        objects = self._get_objects()
        for key, value in list(kwargs.items()):
            objects = [o for o in objects if o.__dict__[key] == value]
        return objects

    def get_first(self):
        """ Reassign current obj to first element from provider vdcs."""
        self.__dict__ = self.get_all()[0].__dict__
        return self

    def get_key_values(self, key):
        """
        Get an array of values by specific key for all objects.
        :param key: obj attribute as string
        :param related_obj: see _get_objects method
        :param parent_obj: see _get_objects method
        :return: a list of values by key
        """
        test.log.info("Get all values for key - {}".format(key))
        return [obj.__dict__[key] for obj in self.get_all()]

    def get_unique_key_values(self, key):
        """
        Get an array of unique values by specific key for all objects.
        :param key: obj attribute as string
        :param related_obj: see get_all method
        :return: a list of values by key
        """
        test.log.info("Get unique values for key - {}".format(key))
        return list(
            {obj.__dict__[key] for obj in self.get_all()}
        )

    def delete(self):
        """
        Delete obj without transaction.
        :return: True if success else False
        """
        test.log.info(
            "Delete {} - {}...".format(self.__class__.__name__, self.id)
        )
        return test.delete_object(self)

    def _get_objects(
            self,
            route=None,
            root_tag=None,
            query=None,
            data=None,
            **kwargs
    ):
        """
        Is using for all objects with similar structure where we can get all
        objects as a list.
        !!! Use this method to get a new objects.
        :param route: can be class attribute or method,
        set it if route != self.route;
        :param root_tag: set if root_tag != obj.root_tag
        :param parent_obj: parent class obj (as for Disk, Backup etc.;
        :param query: a string like 'q=user_login' - example for users;
        :param data: dict obj;
        :param related_obj: see get_all method;
        :param kwargs: in general can be used by for base/company resources
        :return: a list of objects or empty list if no objects or some error
        occurred.
        """
        objects = []

        if not route:
            route = self._set_route()

        # build url from route, in case pagination enable the url is almost
        # ready
        url = '/{0}.json'.format(route) \
            if 'json' not in route \
            else '/{0}'.format(route)  # route='{0}.json/page/1/per_page/1'.format(obj.route)

        # get objects from search result
        if query:
            if 'page' in query:
                url += '/{0}'.format(query)
            else:
                url += '?{0}'.format(query)

        test.log.info(
            "Get all {}s from {}...".format(self.__class__.__name__, url)
        )
        if test.get_object(self, url=url, data=data):
            if self.response:
                # May be in future
                # return (self._create_an_object(
                #     response, parent_obj, root_tag, **kwargs
                # ) for response in self.response)
                for o in self.response:
                    if kwargs:
                        obj = self.__class__(**kwargs)
                    elif self.parent_obj:
                        obj = self.__class__(self.parent_obj)  # For backups,
                        # templates, disks, etc...
                    else:
                        obj = self.__class__()

                    if root_tag:
                        obj.__dict__.update(o[root_tag])
                    else:
                        if obj.root_tag in [
                            'service_addon_group',
                            'recipe_group',
                        ]:
                            test.log.warning(
                                "Change response for {}".format(obj.root_tag)
                            )
                            obj.__dict__.update(o)
                        else:
                            obj.__dict__.update(o[obj.root_tag])
                    objects.append(obj)
        return objects

    def _url(self):
        # Possible to use route like method or argument
        return '/{0}/{1}.json'.format(self._set_route(), self.id)

    def _set_route(self):
        """
        Actually we have two types of route - as attribute and as method.
        This allows you to use both of them.
        :return: route
        """
        # Possible to use route like method or argument
        if hasattr(self.route, '__call__'):
            return self.route()
        return self.route

    @staticmethod
    def wait_for_action(action, *args, timeout=300, step=1, **kwargs):
        """
        Waiting for executing some action.
        :param action: func obj (if expression use lambda: expression)
        :param timeout: time out in sec.
        :param step: time interval
        :return: result of executed action or False if time is out
        """
        while timeout > 0:
            result = action(*args, **kwargs)

            if result:
                return result

            timeout -= step
            time.sleep(step)
        # raise TimeoutError("{} executing timeout.".format(action_name))
        test.log.error('Waiting time out...')
        return result

    def _search(self, search_keys, route=None, root_tag=None, **kwargs):
        """Base search method"""
        params = []
        for key, value in list(kwargs.items()):
            if value:
                if isinstance(value, str) and ',' in value:
                    for v in value.split(','):
                        params.append('{}={}'.format(
                            search_keys[key].format(key), v)
                        )
                else:
                    params.append('{}={}'.format(
                        search_keys[key].format(key), value)
                    )

        query_str = '&'.join(params)

        return self._get_objects(
            route=route, root_tag=root_tag, query=query_str
        )

    # Transaction Handler
    def transaction_handler(
            self,
            action,
            parent_id=None,
            pages=31,
            params_keys=None,
            param_value=None,
            timeout=300
    ):
        """
        Handle the transaction. In case not success status add an error message
        to error obj attribute.
        :param action: transaction action name
        :param parent_id: parent object id
        :param pages: amount of pages for looking a transaction
        :param params_dict: dictionary in general from transaction params
        :param params_keys: list or tuple of dict keys.
        :return: True if success else False
        """
        if not parent_id:
            parent_id = self.id
        self.transaction = Transaction()
        if self.transaction._wait_for_transaction(
                action, parent_id, pages, params_keys, param_value, timeout
        ):
            return True

        self.error['transaction'] = {
            'action': self.transaction.action,
            'status': self.transaction.status,
            'reason': self.transaction.cause_of_failure,
            'url': test.session.url[:-5]  # without '.json'
        }
        return False

    def transactions_handler(
            self,
            transactions_chain,
            pages=31,
            params_keys=None,
            param_value=None,
            timeout=300
    ):
        """
        Handling a list of transactions specified by action and parent_id
        :param transactions_chain: a list of pair (action, parent_id)
        :param pages: amount of pages for looking a transaction
        :param params_dict: dictionary in general from transaction params
        :param params_keys: list or tuple of dict keys.
        :return: True if success else False
        """
        for action, parent_id in transactions_chain:
            if not self.transaction_handler(
                    action,
                    parent_id=parent_id,
                    pages=pages,
                    params_keys=params_keys,
                    param_value=param_value,
                    timeout=timeout
            ):
                return False
        return True

    def __repr__(self):
        return "{} - {}".format(self.__class__.__name__, self.id)


class Transaction(BaseHelper):
    route = 'transactions'
    root_tag = 'transaction'

    def __init__(self, id=None):
        self.log_output = ""
        self.action = ''
        self.status = ''
        self.cause_of_failure = ''
        self.error = {}
        self.id = id
        if self.id:
            test.update_object(self)

    def _get_transactions(self, page=1):
        """Get a list of transaction dict from selected page"""
        test.log.info(
            "Get list of transactions from {0} page...".format(page)
        )
        return self._get_objects(query='page/{0}'.format(page))

    def _wait_for_transaction(
            self, action, parent_id, pages, params_keys, param_value, timeout
    ):
        # reset transaction id
        self.id = None  # Reset transaction instance
        label = ' '.join([i.capitalize() for i in action.split('_')])
        test.log.info('\n' + ('>' * 80))
        test.log.info(
            "Waiting for {0} with parent_id - {1}...".format(label, parent_id)
        )
        for page in range(1, pages):
            if page == 1:
                if self.wait_for_action(
                    lambda: self._find_transaction(
                        page, action, parent_id, params_keys, param_value
                    ) is True,
                    timeout=10
                ):
                    break
            else:
                if self._find_transaction(
                        page, action, parent_id, params_keys, param_value
                ):
                    break
        else:
            self.cause_of_failure = "Transaction '{}' has not been found".format(
                action
            )
            self.action = action

        status = None
        if self.id:
            for i in range(timeout):
                test.update_object(self)
                if self.status == 'complete':
                    test.log.info('Complete')
                    status = True
                    break
                elif self.status == 'failed':
                    test.log.error('{0} Failed...'.format(label))
                    #  Find an error message
                    # TODO (should be refactored)
                    if self.log_output:
                        #  Describe possible error messages (see transaction
                        # log output)
                        error_types = [
                            'Fatal',
                            'System Error',
                            'Initialize Fatal'
                        ]
                        # Find described errors in log output
                        error_messages = re_findall(
                            '|'.join(
                                ['{}.*'.format(e) for e in error_types]
                            ), self.log_output
                        )
                        self.cause_of_failure = error_messages[0] if \
                            error_messages else self.log_output

                        test.log.error(self.cause_of_failure)
                    status = False
                    break
                elif self.status == 'cancelled':
                    test.log.warning('{0} Cancelled...'.format(label))
                    status = False
                    break
                elif i == 299:
                    test.log.warning('Waiting time out...')
                    self.cause_of_failure = 'Waiting time out...'
                    status = None
                else:
                    time.sleep(10)
        if not status:
            self.error[self.action] = self.status

        test.log.info('\n' + ('<' * 80))
        return status

    def _find_transaction(
            self, page, action, parent_id, params_keys, param_value
    ):
        """
        Find a transaction by parent_id and action.
        If success return True and update transaction obj.

        params_keys - list of keys to value:
            "event": {
                "service_addon_event": {
                "id": 191,
                ...
                }
            } => ["event", "id"]
        """
        transaction = None
        for t in self._get_transactions(page):
            if t.parent_id == parent_id and t.action == action:
                if params_keys:
                    if self._get_value_from_dict(
                            t.params, params_keys
                    ) == param_value:
                        transaction = t
                        break
                else:
                    transaction = t
                    break

        if transaction:
            self.__dict__.update(transaction.__dict__)
            return True
        return False

    @staticmethod
    def _get_value_from_dict(params_dict, params_keys):
        """
        Get value from dict using iterable obj params_keys
        :param params_dict: dictionary in general from transaction params
        :param params_keys: list or tuple of dict keys.
        :return: value located by keys.
        """
        value = params_dict
        for key in params_keys:
            value = value[key]

        return value
