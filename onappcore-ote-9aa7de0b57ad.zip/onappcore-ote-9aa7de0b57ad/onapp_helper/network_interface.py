# Network Interface assigned to virtual machine
#
# Attributes:
# [
#
#     {
#         "network_interface": {
#             "connected": null,
#             "created_at": "2016-08-15T16:06:22+03:00",
#             "default_firewall_rule": "ACCEPT",
#             "edge_gateway_id": null,
#             "id": 96,
#             "identifier": "c4qsqef9yzc0rd",
#             "label": "eth0",
#             "mac_address": "00:16:3e:a6:02:53",
#             "network_join_id": 9,
#             "primary": true,
#             "rate_limit": 0,
#             "updated_at": "2016-08-15T16:06:22+03:00",
#             "usage": null,
#             "usage_last_reset_at": null,
#             "usage_month_rolled_at": null,
#             "virtual_machine_id": 94
#         }
#     }
#
# ]
from onapp_helper.base_helper import BaseHelper
from onapp_helper import test
from onapp_helper.stats.usage import Usage


class NetworkInterface(BaseHelper):
    def __init__(self, parent_obj=None):
        """

        :param parent_obj: server obj
        """
        self.parent_obj = parent_obj
        self.root_tag = 'network_interface'
        self.label = "eth1"
        self.rate_limit = 1
        self.primary = True
        self.network_join_id = None
        self.current_rate_limit = ""

    def get_primary(self):
        test.log.info("Get primary {}".format(self.__class__.__name__))
        primary_network_interface = [
            net for net in self.get_all() if net.primary
            ]
        if primary_network_interface:
            return primary_network_interface[0]
        return False

    def add(self, **kwargs):
        """
        Add network to server.
        :param kwargs:
            label - network interface label (eth0 for example)
            rate_limit - rate limit
            primary - set True for primary interface, else False
            network_join_id - network join id
        :return:
        """
        test.log.info(
            "Add Network Join ID - {} To Network Interface {}...".format(
                self.network_join_id, self.label
            )
        )
        if kwargs:
            data = {self.root_tag: kwargs}
        else:
            data = {
                self.root_tag: {
                    "label": self.label,
                    "rate_limit": self.rate_limit,
                    "primary": self.primary,
                    "network_join_id": self.network_join_id
                }
            }
        if test.post_object(self, data=data):
            action = f'attach_{self.root_tag}'
            parent_id = self.id
            if self.parent_obj.__class__.__name__ == 'OpenstackServer':
                action = f'add_{self.root_tag}'
                parent_id = self.parent_obj.id
            if self.parent_obj.template.type == 'ImageTemplateIso':
                action = f'reboot_{self.parent_obj.root_tag}'
                parent_id = self.parent_obj.id
            if self.parent_obj.template.centos5:
                if self.parent_obj.hypervisor_type == 'xen':
                    action = f'attach_{self.root_tag}'
                    parent_id = self.id
                else:
                    action = f'reboot_{self.parent_obj.root_tag}'
                    parent_id = self.parent_obj.id

            return self.transaction_handler(action, parent_id=parent_id)
        return False

    def edit(self, **kwargs):
        """
        Edit network.
        :param label: network label
        :param rate_limit: rate limit (0 to set unlimited)
        :param primary: True or False
        :return:
        """
        action = None
        data = {self.root_tag: {}}

        for key, value in list(kwargs.items()):
            data[self.root_tag][key] = value
            if key == 'rate_limit' and value != self.rate_limit:
                action = 'update_rate_limit'

        test.log.info("Edit {}".format(self.__class__.__name__))
        if test.put_object(self, data=data):
            if action:
                if self.transaction_handler(action):
                    return test.update_object(self)
            return test.update_object(self)
        return False

    def delete(self, destroy_all_interface=True):
        """Destroy the network."""
        test.log.info("Start to destroy network...")
        if test.delete_object(self):
            return self.transaction_handler('detach_{0}'.format(self.root_tag))
        return False

    def net_hourly_stats(self, start_date=None, end_date=None):
        """
        Get Network hourly statistics
        :param start_date: "YYYY-MM-DD+hh:mm:ss"
        :param end_date: "YYYY-MM-DD+hh:mm:ss"
        :return: an array of network usage objects
        """
        test.log.info("Get {} hourly stats".format(self.__class__.__name__))
        params = []
        if start_date:
            params.append("period[startdate]={}".format(start_date))
        if end_date:
            params.append("period[enddate]={}".format(end_date))

        query_str = '&'.join(params)
        return Usage()._get_objects(
            route='{}/{}/network_interfaces/{}/usage'.format(
                self.parent_obj.route, self.parent_obj.id, self.id
            ),
            root_tag='net_hourly_stat',
            query=query_str
        )

    def route(self):
        return '{0}/{1}/network_interfaces'.format(
            self.parent_obj.route, self.parent_obj.id
        )
