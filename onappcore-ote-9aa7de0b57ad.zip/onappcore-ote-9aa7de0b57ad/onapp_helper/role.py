from onapp_helper.base_helper import BaseHelper
from onapp_helper import test


class Approvals:
    root_tag = 'transaction_action_approvals'


class Role(BaseHelper):
    route = 'roles'
    root_tag = 'role'

    def __init__(self, id=None):
        self.id = id
        self.label = ''
        self.permission_ids = []
        self.approvals = Approvals()
        if self.id:
            test.update_object(self)
            self.permission_ids = self._get_permission_ids()

    def create(self):
        test.log.info('Create a new role...')
        data = {
            self.root_tag: {
                'label': self.label,
                'permission_ids': self.permission_ids
            }
        }
        return test.post_object(self, data=data)

    def edit(self):
        test.log.info('Edit role with id {}...'.format(self.id))
        data = {
            self.root_tag: {
                'label': self.label,
                'permission_ids': self.permission_ids
            }
        }
        return test.put_object(self, data=data)

    def clone(self):
        test.log.info('Clone role with id {}...'.format(self.id))
        url = '/{0}/{1}/clone.json'.format(self.route, self.id)
        clone = Role()
        if test.post_object(clone, url=url):
            clone.permission_ids = self._get_permission_ids(obj=clone)
            return clone
        return False

    def get_by_label(self, label):
        test.log.info('Get role with label {}...'.format(label))
        return [role for role in self.get_all() if role.label == label][0]

    def get_all(self):
        test.log.info("Get all roles")
        roles = self._get_objects()
        for role in roles:
            role.permission_ids = self._get_permission_ids(obj=role)
        return roles

    def get_approvals(self):
        """
        Return a list of dicts with approvals data
        :return: List
        """
        test.log.info("Get approvals")
        url = '/{0}/{1}/approvals.json'.format(self.route, self.id)
        if test.get_object(self.approvals, url=url):
            return self.approvals.transaction_action_approvals

    def set_approvals(self, approval_ids):
        """
        Set approvals
        :param approval_ids: a list of approval ids
        :return: True if success else False
        """
        test.log.info("Set approvals")
        url = '/{0}/{1}/approvals.json'.format(self.route, self.id)
        data = {"transaction_action_approval_ids": approval_ids}

        return test.put_object(self, url=url, data=data)

    def _get_permission_ids(self, obj=None):
        if not obj:
            obj = self

        return [p['permission']['id'] for p in obj.permissions]
