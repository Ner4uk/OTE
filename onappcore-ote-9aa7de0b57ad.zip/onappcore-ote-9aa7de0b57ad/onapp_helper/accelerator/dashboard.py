__author__ = 'zhuk'
__doc__ = """"""
__since__ = 6.0  # Describe version since this functional available

from onapp_helper import test
from onapp_helper.networks import Network


def get_all():
    return Network()._get_objects(route='settings/cdn_network_accelerations')


def activate(network_id):
    return test.post_object(
        Network,
        url='/settings/cdn_network_accelerations.json',
        data={'network_id': network_id}
    )


def deactivate(network_id):
    return test.delete_object(
        Network,
        url=f'/settings/cdn_network_accelerations/{network_id}.json'
    )
