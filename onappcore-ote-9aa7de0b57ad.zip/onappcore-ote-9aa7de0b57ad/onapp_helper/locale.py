from onapp_helper import test
from onapp_helper.base_helper import BaseHelper


class Phrase(BaseHelper):
    root_tag = 'phrase'

    def __init__(self, locale=None):
        self.locale = locale
        self.locale_id = None

    def translate(self, text):
        data = {
            "translations": {
                "{}".format(self.id): {
                    "phrase_id": self.id,
                    "locale_id": self.locale_id,
                    "text": text
                }
            }
        }
        test.patch_object(self, data=data)

    def route(self):
        return 'settings/locales/{}'.format(self.locale)


# class Locale:
#     route = 'settings/locales'
#
#     def __init__(self):
