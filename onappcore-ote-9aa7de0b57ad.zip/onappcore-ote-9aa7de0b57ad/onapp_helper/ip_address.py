import ipaddress
from onapp_helper.base_helper import BaseHelper
from onapp_helper.ip_range import IpRange
from onapp_helper.ip_network import IpNetwork
from onapp_helper import test


class IpAddress(BaseHelper):
    """
    Provide an access to IP Addresses.
    Since 5.4 we have some changes in API and logic.
    """
    def __init__(self, parent_obj=None):
        """

        :param parent_obj: Network obj
        """
        self.parent_obj = parent_obj
        self.root_tag = 'ip_address'
        self.address = None
        self.netmask = ""
        self.broadcast = ""
        self.disallowed_primary = ""
        self.network_address = ""
        self.gateway = ""
        self.id = None
        if test.cp_version >= 5.4:
            self.ip_range_id = None
            self.user_id = None
        # Do not remember what is this
        # if ip_address_dict:
        #     self._update(ip_address_dict)

    def create(self):
        data = {
            self.root_tag: {
                "address": self.address,
                "netmask": self.netmask,
                "gateway": self.gateway
            }
        }
        test.log.info("Create a new {}".format(self.__class__.__name__))
        return test.post_object(self, data=data)

    def edit(self):
        data = {
            self.root_tag: {
                "address": self.address,
                "netmask": self.netmask,
                "gateway": self.gateway
            }
        }
        test.log.info("Edit {}".format(self.__class__.__name__))
        return test.put_object(self, data=data)

    def assign_to_user(self, ip_addresses=None, user_id=None):
        """
        Assign an ip address or addresses to user
        :param user_id: user id
        For onapp <= 5.3
        :param ip_addresses: an array of ip addresses id (array of id's, integer)
        For onapp >= 5.4
        :param ip_addresses: ip address like '10.0.23.20' (array of ip's, string)
        :return: True if success else False
        """
        test.log.info("Assign {} to user".format(self.__class__.__name__))
        if test.cp_version < 6.0:
            data = {
                self.root_tag: ip_addresses,
                "user_id": user_id
            }
        else:  # https://onappdev.atlassian.net/browse/CORE-10301
            data = {
                'assign': {
                    self.root_tag: ip_addresses,
                    "user_id": user_id
                }
            }
        action_name = 'assign'

        url = '/{0}/{1}.json'.format(self.route(), action_name)
        return test.post_object(self, url=url, data=data)

    def unassign_from_user(self, ip_addresses=None):
        """
        Unassign ip addresses by specified ip addresses ids
        :param ip_addresses: an array of ip addresses ids
        :return: True if success else False
        """
        test.log.info("Unassign {} from user".format(self.__class__.__name__))
        if test.cp_version < 6.0:
            data = {
                "ip_addresses": ip_addresses
            }
        else:  # https://onappdev.atlassian.net/browse/CORE-10301
            data = {
                'unassign': {
                    self.root_tag: ip_addresses
                }
            }

        action_name = 'unassign'

        url = '/{0}/{1}.json'.format(self.route(), action_name)
        return test.post_object(self, url=url, data=data)

    def assign_to_server(
            self,
            server,
            address=None,
            network_interface_id=None,
            used_ip=False,
            own_ip=False
    ):
        """
        Assign an IP address to server. Since 5.4
        :param server: The server obj for which this ip address is assigned to.
        :param address: an ip address as string,
        :param network_interface_id: If not specified use primary
        :param used_ip: if True allows to assign used IP addresses
        :param own_ip: if True use own ip addresses
        :return: True if success else False

        # IP addresses assigned to virtual machine
        #
        # Attributes:
        # created_at: "2016-07-27T09:18:31+03:00",
        # id: 2123,
        # ip_address_id: 50891,
        # network_interface_id: 2057,
        # updated_at: "2016-07-27T09:18:31+03:00",
        # ip_address: {
        #     address: "108.123.91.21",
        #     broadcast: "108.123.91.31",
        #     created_at: "2015-12-10T13:29:54+02:00",
        #     customer_network_id: null,
        #     disallowed_primary: false,
        #     gateway: "108.123.91.31",
        #     hypervisor_id: null,
        #     id: 50891,
        #     ip_address_pool_id: null,
        #     network_address: "108.123.91.16",
        #     network_id: 1,
        #     pxe: false,
        #     updated_at: "2016-07-27T09:18:31+03:00",
        #     user_id: null,
        #     free: false,
        #     netmask: "255.255.255.240"
        # }

        """
        test.log.info(
            "Assign {} address to server ({})".format(
                address, server.id
            )
        )
        if network_interface_id is None:
            network_interface_id = server.network_interface.get_primary().id

        if address is None:
            address = self.address

        data = {
            self.root_tag: {
                "address": address,
                "network_interface_id": network_interface_id,
                "used_ip": used_ip,
                "own_ip": own_ip
            }
        }

        url = "/{}.json".format(self.route(server=server))

        if test.post_object(self, url=url, data=data):
            action = 'update_fixed_ip' \
                if self.parent_obj.__class__.__name__ == 'OpenstackNetwork' \
                else 'update_firewall'
            return self.transaction_handler(
                action, parent_id=network_interface_id
            )
        return False

    def unassign_from_server(self, server, network_interface_id=None):
        """
        Since 5.4
        :param server: The server obj for which this ip address is
        unassigned from.
        :param network_interface_id: If not specified use primary
        :return: True if success else False
        """
        test.log.info("Unassign {} from server".format(self.__class__.__name__))
        if network_interface_id is None:
            network_interface_id = server.network_interface.get_primary().id

        url = "/{}.json".format(self.route(server=server))

        data = {
            self.root_tag: [self.address]
        }

        if test.delete_object(self, url=url, data=data):
            return self.transaction_handler(
                'update_firewall', parent_id=network_interface_id
            )
        return False

    def __get_available_from_range(self, ip_range, selected_ip_addresses=None):
        """
        Get available ip address from range (Since 5.4)
        If IP address once has been selected
        :param range: ip range obj
        :return: ip address as string if success else False
        """
        test.log.info(
            "Get available {} from range".format(self.__class__.__name__)
        )
        if selected_ip_addresses is None:
            selected_ip_addresses = []

        if ip_range.ipv4:
            ip_address_obj = ipaddress.IPv4Address
        else:
            ip_address_obj = ipaddress.IPv6Address

        allocated_ip_addresses = [
            ip.address for ip in self.get_all() if ip.ip_range_id == ip_range.id
        ]

        ip_address = ip_address_obj(ip_range.start_address)
        while ip_address <= ip_address_obj(ip_range.end_address):
            if (
                        ip_address.exploded not in allocated_ip_addresses
            ) and (
                        ip_address.exploded not in selected_ip_addresses
            ):
                self.address = ip_address.exploded
                return self.address
            ip_address += 1

        else:
            self.error['ip_address'] = "No free IP addresses in ip_range {}".format(ip_range.id)
            return False

    def __get_free_from_network(self):
        """
        Get free ip address obj from network (for OnApp <= 5.3)
        :return: ip address obj if success else False
        """
        test.log.info(
            "Get free {} from network".format(self.__class__.__name__))
        rez = [
            ip for ip in self.get_all()
            if ip.free and not ip.user_id
            ]
        if rez:
            return rez[0]

        self.error['ip_address'] = "No free IP addresses in network {}".format(
            self.parent_obj.id)
        return False

    def is_free(self, address):
        """
        Check if specified address is free (Not assigned to User or server)
        :param address: ip address
        :return: True if address is free else False
        """
        test.log.info(
            "Check if {} is free".format(address)
        )
        return address not in self.get_key_values("address")

    def get_free(self, ip_range=None, selected_ip_addresses=None):
        """
        Get free ip address object
        :param selected_ip_addresses: an array of already selected ip addresses
        :param ip_range: if range specified - get free ip address from this
            range else from all network ranges
        :return: ip address object.(see address attribute to know if ip
        address obj is valid)
        """
        test.log.info("Get free {}".format(self.__class__.__name__))

        if selected_ip_addresses is None:
            selected_ip_addresses = []

        ip_address = IpAddress(parent_obj=self.parent_obj)
        if test.cp_version >= 5.4:
            #  Select an ip address
            if ip_range:
                ip_ranges = [ip_range]
            else:
                ip_nets = IpNetwork(parent_obj=self.parent_obj).get_all()
                if ip_nets:
                    ip_ranges = IpRange(parent_obj=ip_nets[0]).get_all()

            if ip_ranges:
                ip_address = IpAddress(parent_obj=self.parent_obj)
                for ip_range in ip_ranges:
                    ip_address.__get_available_from_range(
                        ip_range, selected_ip_addresses
                    )
                    if ip_address.address:
                        break
        else:
            ip_address = self.__get_free_from_network()
        return ip_address

    def route(self, server=None):
        """
        Return route depends on condition.
        :param server: server obj if you working with server IP address
        :return: route
        """
        if server:
            return '{0}/{1}/ip_addresses'.format(
                server.route, server.id
            )

        # return '{0}/{1}/ip_addresses'.format(
        #     self.parent_obj.route, self.parent_obj.id
        # )

        # https://onappdev.atlassian.net/browse/CORE-9758
        return 'settings/networks/{0}/ip_addresses'.format(self.parent_obj.id)
