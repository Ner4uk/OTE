from onapp_helper.base_helper import BaseHelper
from onapp_helper.recipe.recipe_step import RecipeStep
from onapp_helper import test


class Compatibility:
    unix = 'unix'
    windows = 'windows'


class ScriptType:
    bat = 'bat'
    vbs = 'vbs'
    powershell = 'powershell'


class Recipe(BaseHelper):
    COMPATIBLE_WITH = Compatibility()
    SCRIPT_TYPE = ScriptType
    root_tag = 'recipe'
    route = 'recipes'

    def __init__(self, id=None):
        self.id = id
        self.label = self.__class__.__name__
        self.compatible_with = ''
        self.description = ''
        self.recipe_step = RecipeStep(self)
        self.script_type = ''

        if self.id:
            test.update_object(self)

    def create(self):
        data = {
            self.root_tag: {
                "label": self.label,
                "description": self.description,
                "compatible_with": self.compatible_with
            }
        }
        if self.compatible_with == 'windows':
            data[self.root_tag]['script_type'] = self.script_type
        test.log.info(
            "Create a new {}...".format(self.__class__.__name__)
        )
        return test.post_object(self, data=data)

    def edit(self):
        data = {
            self.root_tag: {
                "label": self.label,
                "description": self.description,
                "compatible_with": self.compatible_with
            }
        }
        if self.compatible_with == 'windows':
            data[self.root_tag]['script_type'] = self.script_type
        test.log.info(
            "Edit {}...".format(self.__class__.__name__)
        )
        return test.put_object(self, data=data)

    def servers_using_recipe(self):
        """
        Getting a list of servers which used current recipe
        :return: list of servers which used current recipe.
        """
        test.log.info(
            "Get a list of servers which is using current recipe."
        )
        from onapp_helper.server import VirtualServer
        return VirtualServer()._get_objects(
            route='{}/{}/applied_to_vs'.format(self.route, self.id)
        )

    def run_on_servers(self, *args):
        """
        Run recipe on servers
        :param args: an vs objects
        :return: True if success else False
        """

        data = {
            "virtual_machines": [s.identifier for s in list(args)]
        }
        url = '/{}/{}/run.json'.format(self.route, self.id)

        test.log.info(
            "Running recipe {} on servers...".format(self.id)
        )
        if test.post_object(self, url=url, data=data):
            for server in list(args):
                if not self.transaction_handler(
                        "run_recipe_on_vm", parent_id=server.id
                ):
                    return False
            return True
        return False
