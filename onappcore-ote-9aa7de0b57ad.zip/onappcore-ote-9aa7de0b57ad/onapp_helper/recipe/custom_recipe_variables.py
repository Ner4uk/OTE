from onapp_helper.base_helper import BaseHelper
from onapp_helper import test


class CustomRecipeVariable(BaseHelper):
    root_tag = 'custom_recipe_variable'

    def __init__(self, parent_obj=None, id=None):
        """
        CustomRecipeVariable

        :param parent_obj: Some server obj
        :param id: customer recipe id
        """
        self.parent_obj = parent_obj
        self.name = ''
        self.id = id
        self.enabled = False
        self.value = ''
        if self.parent_obj:
            self.virtual_machine_id = self.parent_obj.id
        if self.id:
            test.update_object(self)

    def create(self):
        """
        Create customer recipe variable

        :return: True if success else False
        """
        data = {
            self.root_tag: {
                "name": self.name,
                "value": self.value,
                "enabled": self.enabled
            }
        }
        test.log.info("Create a new {}".format(self.__class__.__name__))
        return test.post_object(self, data=data)

    def edit(self):
        """
        Edit customer recipe variable

        :return: True if success else False
        """
        data = {
            self.root_tag: {
                "name": self.name,
                "value": self.value,
                "enabled": self.enabled
            }
        }
        test.log.info(
            "Edit the {} with id {}".format(self.__class__.__name__, self.id)
        )
        test.post_object(self, data=data)

    def route(self):
        return '{}/{}/custom_recipe_variables'.format(
            self.parent_obj.route, self.parent_obj.id
        )

    def get_as_dict(self):
        """
        Get attributes as dict in general for custom_recipe_variables during
        server creation.
        :return: onapp representation of CustomRecipeVariable
        """
        return {
            self.root_tag: {
                "name": self.name,
                "value": self.value,
                "enabled": self.enabled
            }
        }
