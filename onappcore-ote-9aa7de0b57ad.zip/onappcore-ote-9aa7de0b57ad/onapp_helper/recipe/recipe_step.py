from onapp_helper.base_helper import BaseHelper
from onapp_helper import test


class ResultSource:
    """
        exit_code - an exit status, e.g. 0 will be returned on success

        To use exit code in the VBS or PowerShell scripts, you have to specify it directly in the script. For example:

        VBS
        Script:
        WScript.Echo "test"
        WScript.Quit 95

        PowerShell
        Script:
        get-date -displayhint date
        exit 227
        std_out - standard output
        std_err - standard error
        std_out_and_std_err - standard output and standard error
    """
    exit_code = 'exit_code'
    std_out = 'std_out'
    std_err = 'std_err'
    std_out_and_std_err = 'std_out_and_std_err'


class FurtherSteps:
    """
        proceed - proceed to the next step.
        fail - terminate the recipe and mark it as failed.
        stop - terminate the recipe and mark it as successful.
        goto_step - specify the step to proceed to. If you specify the nonexistent step, the recipe will be stopped.
    """
    proceed = 'proceed'
    fail = 'fail'
    stop = 'stop'
    goto_step = 'goto_step'


class RecipeStep(BaseHelper):
    RESULT_SOURCE = ResultSource
    ON_SUCCESS = FurtherSteps
    ON_FAILURE = FurtherSteps

    def __init__(self, recipe, id=None):
        self.recipe = recipe
        self.id = id

        self.script = ''
        self.result_source = ''
        self.pass_anything_else = None
        self.pass_values = 0  # Set values which will be consider as passed (
        # exit code or something else use with fail_anything_else as True)
        self.number = None
        self.on_success = ''
        self.on_failure = ''
        self.success_goto_step = None
        self.fail_values = -1  # Set values which will be consider as fail (
        # exit code or something else use with pass_anything_else as True)
        self.fail_anything_else = None
        self.failure_goto_step = None

        self.root_tag = 'recipe_step'

        if self.id:
            test.update_object(self)

    def create(self):
        data = {
            self.root_tag: {
                "script": self.script,
                "result_source": self.result_source,
                "pass_anything_else": self.pass_anything_else,
                "pass_values": self.pass_values,
                "on_success": self.on_success,
                "success_goto_step": self.success_goto_step,
                "fail_anything_else": self.fail_anything_else,
                "fail_values": self.fail_values,
                "on_failure": self.on_failure,
                "failure_goto_step": self.failure_goto_step
            }
        }
        test.log.info("Create a new {}...".format(self.__class__.__name__))
        return test.post_object(self, data=data)

    def edit(self):
        data = {
            self.root_tag: {
                "script": self.script,
                "result_source": self.result_source,
                "pass_anything_else": self.pass_anything_else,
                "pass_values": self.pass_values,
                "on_success": self.on_success,
                "success_goto_step": self.success_goto_step,
                "fail_anything_else": self.fail_anything_else,
                "fail_values": self.fail_values,
                "on_failure": self.on_failure,
                "failure_goto_step": self.failure_goto_step
            }
        }
        test.log.info("Edit {}...".format(self.__class__.__name__))
        return test.put_object(self, data=data)

    def swap_step_location(self, recipe_step_number):
        url = '/{}/recipe_steps/{}/move_to/{}.json'.format(
            self.route(), self.id, recipe_step_number
        )
        test.log.info(
            "Move current recipe to {} position...".format(recipe_step_number))
        return test.put_object(self, url=url)

    def route(self):
        return "{}/{}/recipe_steps".format(self.recipe.route, self.recipe.id)