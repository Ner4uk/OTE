from onapp_helper.base_helper import BaseHelper
from onapp_helper import test


class ServerEventType:
    """
        vm_provisioning - run the recipe during VS provisioning
        vm_network_rebuild - run the recipe when rebuilding a network
        vm_disk_add - run the recipe when adding a disk
        vm_nic_add - run the recipe when adding a network interface
        vm_disk_resize - run the recipe when resizing a VS disk
        vm_resize - run the recipe when resizing a VS
    """
    vm_provisioning = 'vm_provisioning'
    vm_network_rebuild = 'vm_network_rebuild'
    vm_disk_add = 'vm_disk_add'
    vm_nic_add = 'vm_nic_add'
    vm_disk_resize = 'vm_disk_resize'
    vm_resize = 'vm_resize'

    # Since 6.1 (https://onappdev.atlassian.net/browse/CORE-13078)
    vm_ip_address_add = 'vm_ip_address_add'
    vm_ip_address_remove = 'vm_ip_address_remove'

    # Since 6.1 (https://onappdev.atlassian.net/browse/CORE-13816)
    vm_nic_remove = 'vm_nic_remove'
    vm_destroy = 'vm_destroy'
    vm_start = 'vm_start'
    vm_stop = 'vm_stop'
    vm_reboot = 'vm_reboot'
    vm_hot_migrate = 'vm_hot_migrate'
    vm_hot_full_migrate = 'vm_hot_full_migrate'
    vm_cold_migrate = 'vm_cold_migrate'
    vm_full_migrate = 'vm_full_migrate'
    vm_failover = 'vm_failover'


class HypervizorZoneEventType(ServerEventType):
    """
        hv_goes_online - run the recipe when the compute resource comes online
        hv_goes_offline - run the recipe when the compute resource goes offline

        NOTE: The recipe will be triggered when the statistics is not received
        from a compute resource for a certain period of time for some reason.
        If the compute resource is offline, the recipe will not run.
    """
    hv_goes_online = 'hv_goes_online'
    hv_goes_offline = 'hv_goes_offline'


class ControlPanelEventType(ServerEventType):
    """
        kvm_hv_goes_online - run the recipe when the KVM compute resource comes online
        kvm_hv_goes_offline - run the recipe when the KVM compute resource goes offline
        xen_hv_goes_online - run the recipe when the Xen compute resource comes online
        xen_hv_goes_offline - run the recipe when the Xen compute resource goes offline
        vmware_hv_goes_online - run the recipe when the VMware compute resource comes online
        vmware_hv_goes_offline - run the recipe when the VMware compute resource goes offline
        NOTE: The recipe will be triggered when the statistics is not received
        from a compute resource for a certain period of time for some reason.
        If the compute resource is offline, the recipe will not run.

    """
    kvm_hv_goes_online = 'kvm_hv_goes_online'
    kvm_hv_goes_offline = 'kvm_hv_goes_offline'
    xen_hv_goes_online = 'xen_hv_goes_online'
    xen_hv_goes_offline = 'xen_hv_goes_offline'
    vmware_hv_goes_online = 'vmware_hv_goes_online'
    vmware_hv_goes_offline = 'vmware_hv_goes_offline'


class RecipeJoin(BaseHelper):
    SERVER_EVENT_TYPE = ServerEventType
    HYPERVIZOR_ZONE_EVENT_TYPE = HypervizorZoneEventType
    CONTROL_PANEL_EVENT_TYPE = ControlPanelEventType

    def __init__(self, recipe_id=None, parent_obj=None):
        """

        :param recipe_id: an id of a recipe assigned to parent_obj. If parent_obj
        is not specified use control panel recipe joins
        :param parent_obj: virtual, smart, baremetal servers, templates,
        compute zones. If None means ControlPanel
        """
        self.recipe_id = recipe_id
        self.parent_obj = parent_obj
        self.root_tag = 'recipe_join'
        self.event_type = ''

    def assign(self):
        data = {
            self.root_tag: {
                "recipe_id": self.recipe_id,
                "event_type": self.event_type
            }
        }
        test.log.info("Assign recipe")
        return test.post_object(self, data=data)

    def remove(self):
        test.log.info("Unassign recipe")
        return test.delete_object(self)

    def get_assigned_recipe(self):
        test.log.info("Get a list of assigned recipes")
        return test.get_object(self)

    def route(self):
        if not self.parent_obj:
            return 'settings/control_panel/recipe_joins'
        return '{}/{}/recipe_joins'.format(
            self.parent_obj.route, self.parent_obj.id
        )
