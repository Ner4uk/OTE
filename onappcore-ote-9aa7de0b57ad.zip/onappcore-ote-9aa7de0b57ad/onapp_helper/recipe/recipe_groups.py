from onapp_helper.base_helper import BaseHelper
from onapp_helper import test


class RecipeGroup(BaseHelper):
    route = 'recipe_groups'
    root_tag = route[:-1]

    def __init__(self):
        self.label = 'TESTINGRG'
        self.id = None

    def get_any(self):
        test.log.info("Get any RecipeGroup...")
        recipe_groups = self.get_all()
        if recipe_groups:
            self.__dict__.update(recipe_groups[0].__dict__)
            return self
        return False

    def get_by_label(self, label):
        test.log.info("Get RecipeGroup by label...")
        recipe_groups = [
            rg for rg in self.get_all() if label.lower() in rg.label.lower()
            ]
        if recipe_groups:
            self.__dict__.update(recipe_groups[0].__dict__)
            return self
        return False

    def create(self):
        test.log.info("Create RecipeGroup...")
        data = {
            self.root_tag: {
                "label": self.label
            }
        }
        return test.post_object(self,  data=data)


class RecipeGroupRelation(BaseHelper):
    def __init__(self, parent_obj):
        """

        :param parent_obj: recipe group obj
        """
        self.parent_obj = parent_obj
        self.root_tag = 'recipe_group_relation'
        self.id = 0
        self.recipe_id = 0
        self.price = 0

    def attach_recipe_to_group(self, recipe_id=None, price=0):
        """
        Attach recipe to the group.
        :param recipe_id: an id of recipe
        :param price: service addon price
        :return: True if success otherwise False
        """
        test.log.info("Attach recipe to group...")
        if not recipe_id:
            recipe_id = self.recipe_id
        data = {
            self.root_tag: {
                "recipe_id": recipe_id
            }
        }

        if test.cp_version < 5.6:
            data[self.root_tag]["price"] = price

        return test.post_object(self, data=data)

    def edit(self):
        test.log.info(
            "Edit recipe group relation {}...".format(self.id)
        )
        data = {
            self.root_tag: {
                "price": self.price
            }
        }
        return test.put_object(self, data=data)

    def attached_recipes(self):
        """ Return an array of attached recipes to a group"""
        test.log.info("Attached recipes...")
        return self._get_objects()

    def detach_recipe_from_group(self, recipe_id=None):
        test.log.info("Detach recipe from group...")
        if not recipe_id:
            recipe_id = self.id
        url = "/{0}/{1}.json".format(self.route(), recipe_id)
        return test.delete_object(self, url=url)

    def route(self):
        return '{0}/{1}/recipe_group_relations'.format(
            self.parent_obj.route, self.parent_obj.id
        )
