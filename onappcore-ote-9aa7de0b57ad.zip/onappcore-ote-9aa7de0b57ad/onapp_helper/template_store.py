from onapp_helper.base_helper import BaseHelper
from onapp_helper import test


class RelationGroupTemplate(BaseHelper):
    def __init__(self, template_store):
        self.parent_obj = template_store
        self.root_tag = 'relation_group_template'
        self.id = 0
        self.template_id = 0
        self.price = 0

    def attach_template_to_group(self, template_id=None):
        test.log.info("Attach template to group...")
        if not template_id:
            template_id = self.template_id
        data = {
            self.root_tag: {
                "template_id": template_id,
                "price": self.price
            }
        }
        if test.cp_version >= '5.10':
            data[self.root_tag].pop("price")

        return test.post_object(self, data=data)

    def attached_templates(self):
        """ Return an array of attached templates to a group"""
        test.log.info("Attached templates...")
        return self._get_objects()

    def detach_template_from_group(self, related_template_id=None):
        test.log.info("Detach template from group...")
        if not related_template_id:
            related_template_id = self.id
        url = "/{0}/{1}.json".format(self.route(), related_template_id)
        return test.delete_object(self, url=url)

    def change_price(self, price):
        test.log.info("Change price...")
        data = {
            self.root_tag: {
                "price": price
            }
        }
        return test.put_object(self, data=data)

    def route(self):
        return '{0}/{1}/relation_group_templates'.format(
            self.parent_obj.route, self.parent_obj.id
        )


class TemplateStore(BaseHelper):
    def __init__(self, id=None):
        self.route = 'settings/image_template_groups'
        self.root_tag = 'image_template_group'
        self.relation_group_template = RelationGroupTemplate(self)
        self.label = ''
        self.mak = False
        self.kms_host = ''
        self.kms_port = ''
        self.kms = False
        self.own = False
        self.kms_server_label = ''
        self.id = id
        if self.id:
            test.update_object(self)

    def get_any(self):
        test.log.info("Get any template store...")
        self.__dict__.update(self.get_all()[0].__dict__)
        return True

    def get_by_label(self, label):
        test.log.info("Get template store by label...")
        t_store = [
            store for store in self.get_all()
            if label.lower() in store.label.lower()
        ]
        if t_store:
            self.__dict__.update(t_store[0].__dict__)
            return True
        return False

    # def get(self):
    #     test.log.info("Get template stores...")
    #     return test.get_object(self)

    def create(self):
        test.log.info("Create template store...")
        data = {
            self.root_tag: {
                "label": self.label,
                "mak": self.mak,
                "kms_host": self.kms_host,
                "kms_port": self.kms_port,
                "kms": self.kms,
                "own": self.own,
                "kms_server_label": self.kms_server_label
            }
        }
        return test.post_object(self, data=data)

    def edit(self):
        test.log.info("Edit template store...")
        data = {
            self.root_tag: {
                "label": self.label,
                "mak": self.mak,
                "kms_host": self.kms_host,
                "kms_port": self.kms_port,
                "kms": self.kms,
                "own": self.own,
                "kms_server_label": self.kms_server_label
            }
        }
        return test.put_object(self, data=data)


class MyTemplateGroup(BaseHelper):
    def __init__(self, id=None):
        self.route = 'settings/image_template_groups'
        self.root_tag = 'image_template_group'
        self.relation_group_template = RelationGroupTemplate(self)
        self.label = ''
        self.mak = False
        self.kms_host = ''
        self.kms_port = ''
        self.kms = False
        self.own = False
        self.kms_server_label = ''
        self.parent_id = None
        self.user_id = None
        self.id = id
        if self.id:
            test.update_object(self)

    def create(self):
        test.log.info("Create my template group...")
        data = {
            self.root_tag: {
                "user_id": self.user_id,
                "parent_id": self.parent_id,
                "label": self.label,
                "mak": self.mak,
                "kms_host": self.kms_host,
                "kms_port": self.kms_port,
                "kms": self.kms,
                "own": self.own,
                "kms_server_label": self.kms_server_label
            }
        }
        return test.post_object(self, data=data)

    def edit(self):
        test.log.info("Edit my template group...")
        data = {
            self.root_tag: {
                "label": self.label,
                "mak": self.mak,
                "kms_host": self.kms_host,
                "kms_port": self.kms_port,
                "kms": self.kms,
                "own": self.own,
                "kms_server_label": self.kms_server_label
            }
        }
        # url = '/{}/{}.json'.format(self.route, self.id)
        return test.put_object(self, data=data)

    def get(self):
        test.log.info("Get my template group...")
        return test.get_object(self)
