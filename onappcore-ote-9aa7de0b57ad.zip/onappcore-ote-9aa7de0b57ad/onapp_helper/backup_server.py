from onapp_helper.base_helper import BaseHelper
from onapp_helper.backup import Backup
from onapp_helper import test


class BackupServer(BaseHelper):
    route = 'settings/backup_servers'
    root_tag = 'backup_server'

    def __init__(self, id=None):
        self.label = 'ATBSZ'
        self.enabled = True
        self.capacity = 40
        self.ip_address = ''
        self.backup_ip_address = ''
        self.backup_server_group_id = None
        self.os_version = None  # This is getting by API as int 5, 6 or 7 - depends on CentOS release version (Since 5.2)
        self.id = id
        self.ssh_port = 22
        if self.id:
            test.update_object(self)

    def create(self):
        test.log.info("Create Backup Server...")
        data = {
            self.root_tag: {
                "label": self.label,
                "enabled": self.enabled,
                "capacity": self.capacity,
                "ip_address": self.ip_address,
                "backup_ip_address": self.backup_ip_address,
                "backup_server_group_id": self.backup_server_group_id
            }
        }
        return test.post_object(self, data=data)

    def edit(self):
        test.log.info("Edit Backup Server...")
        data = {
            self.root_tag: {
                "label": self.label,
                "enabled": self.enabled,
                "capacity": self.capacity,
                "ip_address": self.ip_address,
                "backup_ip_address": self.backup_ip_address
            }
        }
        return test.put_object(self, data=data)

    def backups(
            self,
            searching=None,
            size_from=None,
            size_to=None,
            start_date=None,
            end_date=None):
        """
        Get backup servers backups
        :param searching: a word in backup name
        :param size_from: The size should be indicated in MB.
        :param size_to: The size should be indicated in MB.
        :param start_date: The date should be indicated in the YYYY-MM-DD format.
        :param end_date: The date should be indicated in the YYYY-MM-DD format.
        :return: an array of backups objects.
        """
        test.log.info("Search backups on Backup Server...")

        search_keys = {
            'searching': 'searching',
            'size_from': 'size[from]',
            'size_to': 'size[to]',
            'start_date': 'period[startdate]',
            'end_date': 'period[enddate]',

        }

        return Backup()._search(
            search_keys=search_keys,
            route='{0}/{1}/backups_search'.format(self.route, self.id),
            searching=searching,
            size_from=size_from,
            size_to=size_to,
            start_date=start_date,
            end_date=end_date
        )

    def get_for_ova(self):
        """
        Get backup server for OVA
        :return: backup server obj.
        """
        #  Select BS for OVA
        test.log.info("Get Backup Server for OVA...")
        backup_servers = [
            bs for bs in test.env.backup_servers
            if bs.enabled
            and bs.backup_server_group_id
            and bs.distro != 'centos5'
            ]
        if backup_servers:
            test.log.info(
                'Select backup server with an id - {}'.format(
                    backup_servers[0].id
                )
            )
            return backup_servers[0]
        return False

    def execute(self, command):
        """
        Execute command on BS
        :param command: command
        :return: output
        """
        exit_code, output = self.ext_execute(command)
        return output

    def ext_execute(self, command):
        """
        External execute on BS
        :param command: command
        :return: a tuple of exit code and output
        """
        test.log.info("Execute {} on Backup Server...".format(command))
        return test.cp.ext_execute(
            command,
            tunnel_host=self.ip_address,
            tunnel_port=self.ssh_port
        )

    def upgrade_static(self, version=None):
        """
        https://docs.onapp.com/display/54GS/Install+Backup+Server#InstallBackupServer-InstallStaticBackupServer

        :return:
        """

        test.log.info("Upgrade static Backup Server...")
        # Download and install the latest OnApp YUM repository file and
        # install new packages
        self.execute(
            'rpm -Uvh http://rpm.repo.onapp.com/repo/onapp-repo-{}.noarch.rpm'.format(
                version if version else str(test.cp_version)
            )
        )

        # Install the OnApp Backup Server installer package
        self.execute(
            'yum install onapp-bk-install -y'
        )

        # # Update your server OS components
        # test.cp.execute(
        #     '/onapp/onapp-hv-install/onapp-hv-{}-install.sh -y'.format(
        #         self.hypervisor_type
        #     ),
        #     tunnel_host=self.ip_address
        # )

        # Run the installer. It is recommended to download Base, Load Balancer
        # and CDN templates while running the installer. You may rerun the
        # installer later with the -t option
        self.execute(
            'sh /onapp/onapp-bk-install/onapp-bk-install.sh -a'
        )
