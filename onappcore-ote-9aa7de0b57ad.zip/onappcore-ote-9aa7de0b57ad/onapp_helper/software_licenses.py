from onapp_helper import test
from onapp_helper.base_helper import BaseHelper


class SoftwareLicenses(BaseHelper):
    route = 'software_licenses'
    root_tag = "software_license"

    def __init__(self, id=None):
        self.arch = None
        self.edition = []
        self.tail = None
        self.distro = None
        self.license = None
        self.total = None
        self.count = None
        self.id = id
        if self.id:
            test.update_object(self)

    def create(self, **kwargs):
        """
        To add a software license send the following parameters:
        :param kwargs:
            arch* - Windows OS architecture (x64 or x86)
            total* - the total number of machines allowed by the license
            distro* - Windows OS distribution (2003, 2008, Windows 7)
            count*- the number of licenses used of a total allowed
            tail* - parameter specifies the updated release of
                Windows OS distribution. If updated, than parameter is R2,
                otherwise – empty
            edition* - Windows OS edition or an array of editions if allowed by
                the license (STD – Standard, ENT –Enterprise, WEB – web and
                DC – Data center)

            license* - the license for the software on which the template will be based
        :return:
        """
        data = {self.root_tag: kwargs}
        return test.post_object(self, url=f'/{self.route}.json', data=data)

    def edit(self, **kwargs):
        """
        To edit the software license send the following parameters:
        :param kwargs:
            arch* - Windows OS architecture (x64 or x86)
            total* - the total number of machines allowed by the license
            distro* - Windows OS distribution (2003, 2008, Windows 7)
            count*- the number of licenses used of a total allowed
            tail* - parameter specifies the updated release of
                Windows OS distribution. If updated, than parameter is R2,
                otherwise – empty
            edition* - Windows OS edition or an array of editions if allowed by
                the license (STD – Standard, ENT –Enterprise, WEB – web and
                DC – Data center)

            license* - the license for the software on which the template will be based
        :return:
        """
        data = {self.root_tag: kwargs}
        return test.put_object(
            self, url=f'/{self.route}/{self.id}.json', data=data
        )

    def has_free(self):
        return self.total - self.count

    def get_for_template(self, template):
        licenses = [
            l for l in self.get_all() if self._license_is_valid(l, template)
        ]
        if licenses:
            self.__dict__.update(licenses[0].__dict__)
            return True
        return False

    @staticmethod
    def _license_is_valid(license, template):
        return license.has_free() \
               and license.arch == template.operating_system_arch \
               and template.operating_system_edition in license.edition \
               and template.operating_system_distro == license.distro \
               and (
                   template.operating_system_tail == license.tail or (
                   template.operating_system_tail is None and license.tail == ''
                   )
               )
