import os
from onapp_helper import test
import re


from onapp_helper.base_helper import BaseHelper
from onapp_helper.network_join import NetworkJoin
from onapp_helper.backup_server_join import BackupServerJoin
from onapp_helper.data_store_join import DataStoreJoin
from onapp_helper.cloud_boot_ip_address import CloudBootIpAddress
from onapp_helper.activity_log import ActivityLog


class Hypervisor(BaseHelper):
    route = 'settings/hypervisors'
    root_tag = 'hypervisor'

    def __init__(self, **kwargs):
        self.api_url = kwargs.get('api_url', '')
        self.label = kwargs.get('label', 'ATHypervisor')
        self.ip_address = kwargs.get('ip_address', '')
        # backup_ip_address - reserved ip address
        self.backup_ip_address = kwargs.get('backup_ip_address', '')
        self.hypervisor_type = kwargs.get('hypervisor_type', '')
        self.segregation_os_type = kwargs.get('segregation_os_type', 'any_os')
        self.enabled = kwargs.get('enabled', True)
        self.disable_failover = kwargs.get('disable_failover', True)
        self.collect_stats = kwargs.get('collect_stats', True)
        self.hypervisor_group_id = kwargs.get('hypervisor_group_id')
        self.cpu_units = kwargs.get('cpu_units', 1000)
        self.fake = kwargs.get('fake', False)
        self.os_version = kwargs.get('os_version')  # This is getting by API as int 5, 6 or 7 - depends on CentOS release version (Since 5.2)
        self.activity = ActivityLog()
        self.ssh_port = kwargs.get('ssh_port', 22)
        self.vcenter_login = kwargs.get('vcenter_login', '')
        self.vcenter_password = kwargs.get('vcenter_password', '')
        self._installed_packages = list()  # for testing usage

        self.id = kwargs.get('id')
        if self.id:
            test.update_object(self)

    def create(self):
        test.log.info("Create hypervisor...")
        data = {
            self.root_tag: {
                "label": self.label,
                "ip_address": self.ip_address,
                "backup_ip_address": self.backup_ip_address,
                "hypervisor_type": self.hypervisor_type,
                "enabled": self.enabled,
                "disable_failover": self.disable_failover,
                "collect_stats": self.collect_stats,
                "hypervisor_group_id": self.hypervisor_group_id,
                "cpu_units": self.cpu_units
            }
        }
        return test.post_object(self, data=data)

    def create_vcenter(self):
        test.log.info("Create hypervisor...")
        data = {
            self.root_tag: {
                "label": self.label,
                "hypervisor_type": 'vcenter',
                "segregation_os_type": self.segregation_os_type,
                "enabled": self.enabled,
                "disable_failover": self.disable_failover,
                "collect_stats": self.collect_stats,
                "hypervisor_group_id": self.hypervisor_group_id,
                "cpu_units": self.cpu_units,
                "connection_options": {
                    "operation_mode": "single_mode",
                    "api_url": self.api_url,
                    "login": self.vcenter_login,
                    "password": self.vcenter_password
                    }
            }
        }

        if test.post_object(self, data=data):
            if self.transaction_handler(
                'add_vcenter_to_cp', parent_id=self.id
            ):
                test.update_object(self)
                return True
        return False

    def edit(self, **kwargs):
        test.log.info("Edit hypervisor...")
        if kwargs:
            data = {self.root_tag: kwargs}
        else:
            data = {
                self.root_tag: {
                    "label": self.label,
                    "ip_address": self.ip_address,
                    "backup_ip_address": self.backup_ip_address,
                    "hypervisor_type": self.hypervisor_type,
                    "enabled": self.enabled,
                    "disable_failover": self.disable_failover,
                    "collect_stats": self.collect_stats,
                    "hypervisor_group_id": self.hypervisor_group_id,
                    "cpu_units": self.cpu_units
                }
            }
        return test.put_object(self, data=data)

    def edit_vcenter(self):
        test.log.info("Edit hypervisor...")
        data = {
            self.root_tag: {
                "label": self.label,
                "ip_address": self.ip_address,
                "segregation_os_type": self.segregation_os_type,
                "backup_ip_address": self.backup_ip_address,
                "cpu_units": self.cpu_units,
                "enabled": self.enabled,
                "collect_stats": self.collect_stats,
                "disable_failover": self.disable_failover,
                "hypervisor_group_id": self.hypervisor_group_id,
                "connection_options": {
                    "operation_mode": "single_mode",
                    "api_url": self.api_url,
                    "login": self.vcenter_login,
                    "password": self.vcenter_password
                    }
            }
        }
        return test.put_object(self, data=data)

    def data_store_joins(self):
        test.log.info("Get list of data store joins.")
        return DataStoreJoin()._get_objects(
            route="{0}/{1}/data_store_joins".format(self.route, self.id)
        )

    def network_joins(self):
        test.log.info("Get list of network joins.")
        return NetworkJoin()._get_objects(
            route="{0}/{1}/network_joins".format(self.route, self.id)
        )

    def backup_server_joins(self):
        test.log.info("Get list of backup server joins.")
        return BackupServerJoin()._get_objects(
            route="{0}/{1}/backup_server_joins".format(self.route, self.id)
        )

    def get_virtual(self):
        """Return an array of hv"""
        test.log.info("Get virtual hypervisors...")
        return self.get_by_params(parameters={'server_type': ["virtual"]})

    def get_vcloud(self):
        """Return an array of hv"""
        test.log.info("Get vcloud hypervisors...")
        return self.get_by_params(parameters={'hypervisor_type': ["vcloud"]})

    def get_by_params(self, parameters=None, **kwargs):
        """
        Return the array of HV objects

        :param parameters: dict of object parameters where value is an array
            of possible values. For example: {'hypervisor_type': ["vcloud"]}
            where:

                * hypervisor_type - hv parameter;
                * vcloud - hv type, can be xen, kvm, etc...
        :param **kwargs: keyword arguments, where key is one of the hv
        parameter and value a list of possible values

        :return: objects filtered by parameters
        """
        objects = [hv for hv in self.get_all() if hv._can_be_used()]

        #  Exclude or include CloudBoot HV
        cloud_boot_hv_ids = CloudBootIpAddress().get_key_values('hypervisor_id')
        if test.use_cloud_boot_hv:
            objects = [obj for obj in objects if obj.id in cloud_boot_hv_ids]
        else:
            objects = [
                obj for obj in objects if obj.id not in cloud_boot_hv_ids
            ]

        if parameters or kwargs:
            for key, values in list(parameters.items() if parameters else
                                    kwargs.items()):
                objects = [
                    obj for obj in objects if obj.__dict__[key] in values
                ]
        return objects

    def get_best_by_ram(self, objects):
        test.log.info("Get best by RAM...")
        hv = self._hv_with_more_ram(objects)
        # Update self attributes
        self.__dict__.update(hv.__dict__)

    def _hv_with_more_ram(self, obj_list):
        hvs = []
        for obj in obj_list:
            hvs.append((obj.free_mem, obj))
        if hvs:
            hvs.sort()
            return hvs[-1][-1]
        return self

    def _can_be_used(self):
        if self.enabled and self.online and self.hypervisor_group_id:
            if ('fake' in self.label.lower()) == self.fake:
                return True
        elif 'vcloud' in test.hv_types and self.hypervisor_type == 'vcloud':
            return True
        else:
            return False

    def upgrade_static(self, version=None):
        """
        https://docs.onapp.com/display/51GS/Upgrade+Guide+for+Cloud+with+Static+Servers

        :return:
        """
        test.log.info("Upgrade static HV")
        if not version:
            version = str(test.cp_version)

        self.execute('yum clean all')
        # This step applies to RHEL/CentOS 5.x Xen compute resources only.
        # Run the following command:
        if self.hypervisor_type == 'xen' and self.os_version == 5:
            self.execute(
                'rm -f /etc/yum.repos.d/GITCO-*.repo'
            )
        if version == 6.0:
            if self.hypervisor_type == 'xen' and self.os_version == 7:
                self.execute('rpm -e centos-release-xen-46')
        # Download and install the latest OnApp YUM repository file and
        # install new packages
        self.execute(
            'rpm -Uvh http://rpm.repo.onapp.com/repo/onapp-repo-{}.noarch.rpm'.format(version)
        )

        # Upgrade OnApp compute resource installer package
        self.execute(
            'yum update onapp-hv-install -y'
        )

        # Update your server OS components
        # !!! Can not be executed with -a option !!!
        # test.cp.execute(
        #     '/onapp/onapp-hv-install/onapp-hv-{}-install.sh -y -a'.format(
        #         self.hypervisor_type
        #     ),
        #     tunnel_host=self.ip_address
        # )

        # Run compute resource installer
        self.execute(
            '/onapp/onapp-hv-install/onapp-hv-{}-install.sh -a'.format(
                self.hypervisor_type
            )
        )
        # For CentOS 6/7 KVM and CentOS 7 Xen compute resources
        # to download new recovery images, run:
        # /onapp/onapp-hv-install/onapp-hv-xen-install.sh -t
        if (
                        self.hypervisor_type == 'kvm' and
                        self.distro in ['centos6', 'centos7']
        ) or (
                        self.hypervisor_type == 'xen' and
                        self.distro in ['centos7']
        ):
            self.execute(
                f"/onapp/onapp-hv-install/onapp-hv-{self.hypervisor_type}-install.sh -t -a"
            )

        #  Steps for installation
        # # Run one of the following commands depending on CentOS version:
        # # For CentOS 5.x compute resources:
        # if self.os_version == 5:
        #     test.cp.execute(
        #         'yum install gdisk lsblk-wrapper', tunnel_host=self.ip_address
        #     )
        # # For CentOS 6.x compute resources:
        # elif self.os_version == 6:
        #     test.cp.execute(
        #         'yum install gdisk util-linux-ng', tunnel_host=self.ip_address
        #     )
        # else:
        #     print(
        #         'No actions found for HV with {} os version, please see {} documentation...'.format(
        #             self.os_version,
        #             test.cp_version
        #         )
        #     )

    def install_static(self, version=None):
        # TODO should be extended/improved/fixed!!!
        """
        https://docs.onapp.com/display/51GS/Upgrade+Guide+for+Cloud+with+Static+Servers

        :return:
        """
        test.log.info("Install static HV")
        if not version:
            version = str(test.cp_version)
        # This step applies to RHEL/CentOS 5.x Xen compute resources only.
        # Run the following command:
        # if self.hypervisor_type == 'xen' and self.os_version == 5:
        #     self.execute(
        #         'rm -f /etc/yum.repos.d/GITCO-*.repo'
        #     )
        # Download and install the latest OnApp YUM repository file and
        # install new packages
        self.execute(
            'rpm -Uvh http://rpm.repo.onapp.com/repo/onapp-repo-{}.noarch.rpm'.format(version)
        )

        # Upgrade OnApp compute resource installer package
        self.execute(
            'yum install onapp-hv-install -y'
        )

        # # Update your server OS components
        # test.cp.execute(
        #     '/onapp/onapp-hv-install/onapp-hv-{}-install.sh -y'.format(
        #         self.hypervisor_type
        #     ),
        #     tunnel_host=self.ip_address
        # )

        # Run compute resource installer
        self.execute(
            '/onapp/onapp-hv-install/onapp-hv-{}-install.sh -a'.format(
                self.hypervisor_type
            )
        )

        self.execute('yum install gdisk lsblk-wrapper -y')

        # configure
        # self.execute(
        #     '/onapp/onapp-hv-install/onapp-hv-config.sh -h ' \
        #            '<CP_HOST_IP> -p [HV_HOST_IP] -f <FILE_TRANSFER_SERVER_IP> -b <HV_BSNET_IP>'
        # )

        #  Steps for installation
        # # Run one of the following commands depending on CentOS version:
        # # For CentOS 5.x compute resources:
        # if self.os_version == 5:
        #     test.cp.execute(
        #         'yum install gdisk lsblk-wrapper', tunnel_host=self.ip_address
        #     )
        # # For CentOS 6.x compute resources:
        # elif self.os_version == 6:
        #     test.cp.execute(
        #         'yum install gdisk util-linux-ng', tunnel_host=self.ip_address
        #     )
        # else:
        #     print(
        #         'No actions found for HV with {} os version, please see {} documentation...'.format(
        #             self.os_version,
        #             test.cp_version
        #         )
        #     )

    def remove_onapp_packages(self):
        """
        Remove onapp packages.
        :return:
        """
        test.log.info("Remove all onapp packages")
        self.execute("rpm -qa | grep onapp | xargs -I _ yum remove _ -y")

    def domain_is_running(self, domain, timeout=5):
        """
        Check if specified domain is running on HV
        :param domain: a virtual server identifier
        :param timeout: timeout
        :return: True if running else False
        """
        test.log.info(
            "Check if domain '{}' is running on HV - {}".format(domain, self.id)
        )
        command = self._command_to_check_domain_state(domain)
        return self.wait_for_action(
            lambda: self._is_domain_running(command) is True,
            timeout=timeout
        )

    def _command_to_check_domain_state(self, domain):
        """
        Get command to check domain state.
        :param domain: server identifier
        :return: command
        """
        if self.hypervisor_type in ['kvm', 'openstack'] or (
                        self.hypervisor_type == 'xen' and
                        self.distro == 'centos7'
        ):
            return "virsh domstate {}".format(domain)
        elif self.hypervisor_type == 'xen' and test.cp_version < 5.7:
            return "xm domstate {}".format(domain)
        elif self.hypervisor_type == 'xen' and test.cp_version >= 5.7:
            return "virsh domstate {}".format(domain)
        else:
            raise KeyError(
                "{} HV type does not support current method.".format(
                    self.hypervisor_type
                )
            )

    def _is_domain_running(self, command):
        """
        Check if domain is running.
        :param command: command for executing on HV
        :return: True if success else False
        """
        rez = test.cp.execute(command, tunnel_host=self.ip_address)
        if 'running' in rez or 'idle' in rez:
            return True
        return False

    def execute(self, command):
        """
        Execute command on HV
        :param command: command
        :return: output
        """
        exit_code, output = self.ext_execute(command)
        return output

    def ext_execute(self, command):
        """
        External execute on HV
        :param command: command
        :return: a tuple of exit code and output
        """
        return test.cp.ext_execute(
            command,
            tunnel_host=self.ip_address,
            tunnel_port=self.ssh_port
        )

    def wait_till_online(self):
        return self.activity.wait_for_alert(
            action='hypervisor_is_online',
            target_type='hypervisor',
            target_id=self.id,
            step=20
        )

    def get_firewall_rules(self, key):
        """
        Get firewall rules by key

        :param key: key for grep
        :return: result string
        """
        test.log.info("Get HV firewall rules")
        return self.execute(
            command='iptables -L -n | grep {}'.format(key)
        )

    def get_firewall_rules_count(self, key):
        """
        Get a count of firewall rules by key

        :param key: key for grep
        :return: integer
        """
        test.log.info("Get count of HV firewall rules")
        rez = self.execute(
            command="iptables -nL FORWARD | grep -wc '{0}'".format(key)
        )
        return int(rez.split('\n')[0])

    def get_iptables_rules_list(self, server_identifier, nic_identifier):
        """
         Get a list of iptables rules (https://onappdev.atlassian.net/browse/INSTALLER-232)
        :param server_identifier: server identifier
        :param nic_identifier: servers network interface identifier
        :return: a list of iptables files
        """
        test.log.info("Get HV ip tables rules")
        rez = self.execute(
            command='ls -l /onapp/iptables/{} | grep {}'.format(
                server_identifier, nic_identifier
            )
        ).split('\n')
        # To exclude additional strings:
        return [file for file in rez if nic_identifier in file]

    def reboot(self, force=True, schedule_failover=False, confirm=True):
        test.log.info(f"Reboot hypervisor {self.label}")
        data = {
            self.root_tag: {
                'force': force,
                'schedule_failover': schedule_failover,
                'confirm': confirm
            }
        }
        return test.put_object(
            self,
            url=f"/{self.route}/{self.id}/reboot.json",
            data=data
        )

    def ping(self):
        rez = test.cp.execute(
            command='ping -c 1 {}'.format(self.ip_address),
            verbose=False
        )
        return True if '100% packet loss' not in rez else False

    def health_report(self):
        test.log.info('Please wait...')

        report = [(hv, hv.ping()) for hv in self.get_all()]
        test.log.info('Thanks!')
        for hv, status in report:
            print("{:5}{:>17} {:<20}".format(status, hv.ip_address, hv.label))

    def check_if_data_mounted(self):
        """
        Check on HV if data folder is mounted
        """
        rez = self.execute(command='mount|grep data')
        return True if 'data' in rez else False

    def mount_templates(self, target, dir='/onapp/templates'):
        """
        Mount templates directory from target server to current HV
        :param target: an ip address of target server
        :param dir: a template directory
        :return:
        """
        self._mount_dir(target, dir)

    def mount_backups(self, target, path='/onapp/backups'):
        """
        Mount backups directory from target server to current HV
        :param target: an ip address of target server
        :param path: a backups directory
        :return:
        """
        self._mount_dir(target, path)

    def virsh_console_works(self, server):
        """
        Check if virsh console is working on HV for server
        :param server: server obj
        :return: True if success else False
        """
        # install expect if not installed
        if 'expect' not in self._installed_packages:
            exit_code, output = self.ext_execute('expect -v')
            if exit_code != 0:
                self.execute('yum install expect -y')
            self._installed_packages.append('expect')

        script_path = f'/tmp/virsh_console_check_{server.identifier}.sh'

        # https://gist.github.com/shalk/7003628
        script = rf"""#!/bin/bash

expect -c "
    set timeout 10
    spawn virsh console {server.identifier} 
    expect {{
    \"Escape character\" {{send \"\r\r\" ; exp_continue}} 
    \"Escape character\" {{send \"\r\r\" ; exp_continue}} 
    \"login:\" {{send \"root\r\"; exp_continue}}
    \"Password:\" {{send \"{server.initial_root_password}\r\";}} 
    }} 
    expect \"~ #\"
    send \"echo  123\r\" 
    expect \"123\"
    send \"date\r\"
    send \"exit\r\"
    expect \"login:\"
    send \"\"
    expect eof
"
        """
        # exit_code, output = self.ext_execute(f'ls -l {script_path}')
        # if exit_code:
        # Write file locally
        with open(script_path, 'w') as s:
            s.write(script)

        # Upload to CP
        os.system(f'scp {script_path} root@{test.cp.host}:{script_path}')

        # Move to HV
        test.cp.execute(
            f'scp {script_path} root@{self.ip_address}:{script_path}'
        )

        exit_code, output = self.ext_execute(f'bash {script_path}')
        # Output example:
        # spawn virsh console ywrmnkhvicuaya
        # Connected to domain ywrmnkhvicuaya
        # Escape character is ^]
        #
        # CentOS release 6.10 (Final)
        # Kernel 2.6.32-754.2.1.el6.x86_64 on an x86_64
        #
        # otetest.localdomain login:
        # CentOS release 6.10 (Final)
        # Kernel 2.6.32-754.2.1.el6.x86_64 on an x86_64
        #
        # otetest.localdomain login: root
        # Password:
        # Last login: Mon May  6 16:30:30 on hvc0
        # [root@otetest ~]# echo  123
        # 123
        # [root@otetest ~]# date
        # Mon May  6 16:45:12 EEST 2019
        # [root@otetest ~]# exit
        # logout
        #
        # CentOS release 6.10 (Final)
        # Kernel 2.6.32-754.2.1.el6.x86_64 on an x86_64
        #
        # otetest.localdomain login:

        if 'Password' in output:  # means that console is working
            return True
        else:
            return False

    @staticmethod
    def get_destination(server):
        """ Get destination HV to migrate a server """
        # To omit recursive import
        from onapp_helper.hypervisor_zone import HypervisorZone

        server_hv = Hypervisor(id=server.hypervisor_id)
        hvs = [
            hv for hv in HypervisorZone(
                id=server_hv.hypervisor_group_id
            ).attached_hypervisors()
            if server_hv.id != hv.id and hv.online and hv.enabled
        ]
        if hvs:
            return hvs[0]
        return False

    def _mount_dir(self, target, dir):
        cmd = f'{target}:{dir} {dir} nfs rsize=8192,wsize=8192,timeo=14,intr,vers=3'

        exit_code, output = self.ext_execute(f'[ -d {dir} ]')
        if not exit_code:
            self.execute(f'mkdir {dir}')

        if dir not in self.execute(f'cat /etc/fstab | grep {dir}'):
            self.execute(f'echo \'{cmd}\' >> /etc/fstab')

    @property
    def distro_number(self):
        digits = re.findall(pattern=r'\d+', string=self.distro)
        return int(digits[0]) if digits else None

    def import_vmware(self):
        """trigger the same transaction as Resync from vCenter"""
        url = '/{}/{}/import_vmware'.format(self._set_route(), self.id)
        if test.post_object(self, url=url, data={}):
            if self.transaction_handler(
                'add_vcenter_to_cp', parent_id=self.id
            ):
                test.update_object(self)
                return True
        return False
