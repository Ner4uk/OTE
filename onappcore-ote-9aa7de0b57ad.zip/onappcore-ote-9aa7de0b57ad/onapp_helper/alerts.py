from onapp_helper import test
from onapp_helper.base_helper import BaseHelper
from onapp_helper.disk import Disk


class Alerts(BaseHelper):
    route = 'alerts'
    root_tag = route

    def __init__(self):
        self.zombie_domains = []
        self.zombie_disks = []
        self.zombie_data_stores = []
        self.zombie_transactions = []

    def get(self):
        test.log.info("Get Alerts...")
        test.get_object(self)
        return self

    def remove_zombie_disks(self):
        if self.zombie_disks:
            for disk in self.zombie_disks:
                Disk().remove_zombie_lv(disk)

