import pytest

from onapp_helper import test
from onapp_helper.server import VirtualServer

test.use_public_network = False
test.load_env()


@pytest.mark.skipif(
    test.cp_version < 5.3,
    reason="Current CP version ({0}) does not support this functionality ".format(test.cp_version)
)
class TestCreateVSExample:
    def setup_class(self):
        try:
            self.vs = VirtualServer()
        except AssertionError as e:
            self.teardown_class(self)
            exit(e)

    def teardown_class(self):
        attributes = (
            'vs',
        )
        test.clean_up_resources(attributes, self)

    def test_create_vs(self):
        self.vs.label = self.__name__
        assert self.vs.create(), self.vs.error