#!/usr/bin/env bash

PYTHON_VERSION="3.6.1"
CONF="conf" #conf files folder name
IMAGE="ote_image" #image name
CONTAINER="ote_container" #container name
BUILD=false
PARTIAL=false
RUN=false
CLEANUP=false
INFO=false
SSH="$HOME/.ssh"
HELP=true
ENTER=false

generate_dockerfile()
{
if [ $# -eq 0 ]; then
log "Generating the Dockerfile for a complete OTE container..."
cat > ./Dockerfile << EOF
#FULL OTE CONTAINER
FROM python:$PYTHON_VERSION
ARG ssh_prv_key
ARG ssh_pub_key

RUN apt-get update && apt-get install -y vim

RUN pip install virtualenv

# Authorize SSH Host
RUN mkdir -p /root/.ssh && chmod 0700 /root/.ssh && ssh-keyscan bitbucket.org > /root/.ssh/known_hosts

# Add the keys and set permissions
RUN echo "\$ssh_prv_key" > /root/.ssh/id_rsa && echo "\$ssh_pub_key" > /root/.ssh/id_rsa.pub && chmod 600 /root/.ssh/id_rsa && chmod 600 /root/.ssh/id_rsa.pub

RUN git clone git@bitbucket.org:onappcore/ote.git
WORKDIR /ote
RUN ./ote --install
COPY conf/*.cfg ./conf/

RUN echo 'export PYTHONPATH="/ote"\nsource /ote/venv/ote3.6/bin/activate'>>/root/.bashrc
ENTRYPOINT /bin/bash
EOF
else
log "Generating the Dockerfile for a partial OTE container..."
cat > ./Dockerfile << EOF
#PARTIAL OTE CONTAINER
FROM python:$PYTHON_VERSION
ARG ssh_prv_key
ARG ssh_pub_key

RUN apt-get update && apt-get install -y vim

RUN pip install virtualenv

# Authorize SSH Host
RUN mkdir -p /root/.ssh && chmod 0700 /root/.ssh && ssh-keyscan bitbucket.org > /root/.ssh/known_hosts

# Add the keys and set permissions
RUN echo "\$ssh_prv_key"> /root/.ssh/id_rsa && echo "\$ssh_pub_key" > /root/.ssh/id_rsa.pub && chmod 600 /root/.ssh/id_rsa && chmod 600 /root/.ssh/id_rsa.pub

WORKDIR /ote
RUN git archive --remote=git@bitbucket.org:onappcore/ote.git HEAD requirements.txt | tar -x
RUN virtualenv /tmp/venv && \
    . /tmp/venv/bin/activate && \
	pip install -r requirements.txt
RUN echo 'export PATH="$PATH:/ote"\nexport PYTHONPATH="/ote"\nsource /tmp/venv/bin/activate'>>/root/.bashrc
#RUN echo 'reset\necho "\\n\\n\\033[0;36mTO QUIT CONTAINER AND LEAVE IT RUNNING PRESS \\033[0;31m<Ctrl>+<p>\\033[0;36m, THEN \\033[0;31m<Ctrl>+<q>\\033[0m\\n\\n\\n\\n\\n\\n\\n\\n"'>>/root/.bashrc
ENTRYPOINT /bin/bash
EOF
fi
passed
}



# Reset
Color_Off="\033[0m"       # Text Reset

# Bold
BBlack="\033[1;30m"       # Black
BRed="\033[1;31m"         # Red
BGreen="\033[1;32m"       # Green
BYellow="\033[1;33m"      # Yellow
BBlue="\033[1;34m"        # Blue
BPurple="\033[1;35m"      # Purple
BCyan="\033[1;36m"        # Cyan
BWhite="\033[1;37m"       # White

# Underline
UCyan="\033[4;36m"        # Cyan
UWhite="\033[4;37m"       # White

# Bold High Intensty
BIRed="\033[1;91m"        # Red
BIGreen="\033[1;92m"      # Green
BICyan="\033[1;96m"       # Cyan
BIWhite="\033[1;97m"      # White

Invert="\033[33;5;7m"

die() {
    echo -e "\n$BIRed $1 $Color_Off" >&2
    exit 1
}

log() {
    printf "\n$BYellow $1 $Color_Off"
}

passed() {
    echo -e "..............................$BIGreen [OK] $Color_Off"
}

usage()
{
	echo -e "
    $UWhite Available options:$Color_Off

	$BICyan-b$Color_Off || $BICyan--build$Color_Off tries to build the image with ready-to-use OTE inside. Requires internet connection
	$BICyan-p$Color_Off || $BICyan--partial$Color_Off builds partial image(will use existing ote project in current directory)
	$BICyan-r$Color_Off || $BICyan--run$Color_Off runs the ote docker container and opens console in it
	$BICyan-e$Color_Off || $BICyan--enter$Color_Off opens a running container's terminal session for you
	$BICyan-c$Color_Off || $BICyan--cleanup$Color_Off destroys all the docker containers and erase all images ( $Invert BE CAREFULL IF YOU HAVE SOME DOCKER STUFF APART OF THIS ONE! $Color_Off )
        $BICyan-i$Color_Off || $BICyan--info$Color_Off shows info about your docker stuff.
	$BICyan-s$Color_Off || $BICyan--ssh-location$Color_Off $BBlue<location of ssh-keys>$Color_Off
	$BICyan-h$Color_Off || $BICyan--help$Color_Off shows this help text.

    $Invert $BWhite Be sure to run script from the folder which contains conf dir with all the required conf files for OTE. $Color_Off

    $UWhite Example:$Color_Off

	$BIGreen $0 -b -r -c --ssh-location /Users/vasya/.ssh $Color_Off

	this does full cleanup of docker items, builds and starts the container and opens console in it

	Given your keys allowed to access to ote repo, the simplest way is to run
	$BIGreen $0 -b -r -c$Color_Off
	"
}

has_access_to_git()
{
     log "Checking access to repo..."
     git ls-remote git@bitbucket.org:onappcore/ote.git > /dev/null 2>&1
      RES=$?
            if [ "$RES" -ne "0" ]; then
              echo "You dont have access to the GIT OTE repository. Make sure you can get access first."
              exit 1
            fi
      passed
}

check__ssh_keys()
{
     log "Checking keys..."
     if [ ! -r "${SSH}/id_rsa" ] || [ ! -r "${SSH}/id_rsa.pub" ] ; then
         die "ssh files not found at ${SSH}/ ! (or you do not have read permissions)"
     fi
     passed
}

check__conf()
{
     log "Checking conf files..."
     if [ ! -r "${CONF}/clouds.cfg" ] || [ ! -r "${CONF}/test.cfg" ] ; then
         die "Configuration files not found at ${CONF}/ ! (or you do not have read permissions)"
     fi
     passed
}

check_docker()
{
     log "Checking docker..."
     $(docker ps &>/dev/null) || die 'Either docker service not installed, or not started, or you do not have permissions to use it!'
     passed
}

info()
{
    docker ps -a
    docker images
    docker network ls
    docker volume ls
}

clean_up()
{
    log "Cleaning up all the docker stuff..."
    exec 2>/dev/null
    docker stop $(docker ps -a -q)
    docker rm $(docker ps -a -q)
    docker rmi $(docker images -q)
    docker rmi $(docker images|cut -d ' ' -f1|tail +2) #cleanup the images that failed to remove previous
    docker volume rm $(docker volume ls -q)
    exec 2>&1
}

build()
{
    log "Building container...\n\n"
    docker build --no-cache -t $IMAGE --build-arg ssh_prv_key="$(cat $SSH/id_rsa)" --build-arg ssh_pub_key="$(cat $SSH/id_rsa.pub)" .
    RES=$?
    if [ "$RES" -ne "0" ]; then
      die "Failed to build the container!"
      exit 1
    fi
    log "The container has been built and is ready for use\n"
}

run_container()
{
    if [ "$(docker ps -a | grep $CONTAINER)" ]; then
        if [ "$(docker ps -aq -f status=exited -f name=$CONTAINER)" ]; then
            log "There is a stopped container - starting it..."
            docker start $CONTAINER &>/dev/null || die "Failed to start a stopped container - consider doing a cleanup and rebuild"
        else
            log "The container is already running..."
            return 0
        fi
    else
        if [[ $(head -n 1 Dockerfile) == *"FULL"* ]]; then
            log "Creating a container..."
            docker run -itd --name=$CONTAINER $IMAGE /bin/bash &>/dev/null
        else
            log "Creating a container with the current folder mounted into it..."
            docker run -itd -v $PWD:/ote --name=$CONTAINER $IMAGE /bin/bash &>/dev/null
        fi
    fi
    passed
}

enter_container()
{
    docker exec -it $CONTAINER /bin/bash
}

check_image()
{
    log "Checking image..."
    if [[ !"$(docker images -q $IMAGE> /dev/null)" == "" ]]; then
      die "The docker image $IMAGE does not exist - build it first!"
    fi
    passed
}

if [ -z "$*" ]; then usage; exit; fi

while [ "$1" != "" ]; do
  case $1 in
    -h| -\?| --help )        usage; exit ;;
    -b | --build )           BUILD=true;;
    -p | --partial )         PARTIAL=true;;
    -r | --run )             RUN=true;;
    -e | --enter )           ENTER=true;;
    -c | --cleanup )         CLEANUP=true;;
    -i | --info )            INFO=true;;
    -s | --ssh-location )       #Takes an option argument; ensure it has been specified.
        if [ "$2" ]; then
            SSH=$2
            shift
        else
            die 'ERROR: "--ssh-location" requires a non-empty option argument.'
        fi
        ;;
    -?* )                   usage; die "Unknown option $1 used - see the usage explanation above."
  esac
  shift
done

check_docker

if $INFO; then
    info
fi

if $CLEANUP; then
    clean_up
fi

if $BUILD; then
    check__ssh_keys
    check__conf
    if $PARTIAL; then
        generate_dockerfile partial
    else
        generate_dockerfile
    fi
    build
fi


if $RUN; then
    check_image
    run_container || die 'Something went wrong'
fi

if $ENTER; then
    check_image
    run_container || die 'Something went wrong'
    log "Entering container...\n\n"
    enter_container || die "Something went wrong..."
fi